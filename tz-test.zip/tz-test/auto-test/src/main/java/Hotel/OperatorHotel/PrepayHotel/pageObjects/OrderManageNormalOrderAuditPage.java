package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class OrderManageNormalOrderAuditPage {

	public static WebDriver driver;

	private static WebElement element;
	private static List<WebElement> elementList;
	private static Select selectNum;

	@Test
	public static void getWebDriver(WebDriver webdriver) {

		driver = webdriver;

	}

	// Location 正常单审核 -- “取消预订”(审核) btn 元素
	@Test
	public static WebElement getCancel_Link() throws Exception {

		try {
			element = driver.findElement(By.id("operator_cancel_order"));
			Log.info("CancelBooking_Link element is found in Order_AuditOrder Page");
		} catch (Exception e) {
			Log.error("CancelBooking_Link element is not found in Order_AuditOrder Page");
		}
		return element;
	}

	// Location 正常单审核 -- “修改订单”(审核) btn 元素
	@Test
	public static WebElement getModify_Link() throws Exception { 

		try {
			element = driver.findElement(By.id("operator_modify_order"));
			Log.info("ModifyOrder_Link element is found in Order_AuditOrder Page");
		} catch (Exception e) {
			Log.error("ModifyOrder_Link element is not found in Order_AuditOrder Page");
		}
		return element;
	}

	// Location 正常单审核 -- “确认预订”(审核) btn 元素
	@Test
	public static WebElement getConfirmBooking_Link() throws Exception {

		try {
			element = driver.findElement(By.xpath("html/body/div[3]/div[2]/form/div/div[1]/div[2]/div[3]/a[4]/span[2]"));
			Log.info("Confirm_Link element is found in Order_AuditOrder Page");
		} catch (Exception e) {
			Log.error("Confirm_Link element is not found in Order_AuditOrder Page");
		}
		return element;
	}

	// Location 正常单审核 -- “重新支付” btn 元素
	@Test
	public static WebElement getOrderPayAgain() throws Exception {

		try {
			element = driver.findElement(By.id("operator_pay_order_again"));
			Log.info("operator_pay_order_again element is found in Order_AuditOrder Page");
		} catch (Exception e) {
			Log.error("operator_pay_order_again element is not found in Order_AuditOrder Page");
		}
		return element;
	}
	
	// ******************************酒店确认码 弹层元素Location Start
	// ************************************
 
	// Loaction 酒店确认码 Radio 元素
	// 同时Location 酒店确认码 Input 输入框元素
	@Test
	public static List<WebElement> getConfirmBooking_ConfirmID1()
			throws Exception {

		try {
			try {
				element = driver.findElement(By
						.xpath(".//*[@id='confirmBookingPopWin']/div[1]"));
				Log.info(element
						+ " Confirm_Order element is found in BookingClass Page");
			} catch (Exception e) {
				Log.error("Confirm_Order element is not found in BookingClass Page");
			}
			elementList = element.findElements(By.tagName("input"));
			Log.info("Confirm_Order elements is found in Order_AuditOrder Page");
		} catch (Exception e) {
			Log.error("Confirm_Order elements is not found in Order_AuditOrder Page");
		}
		return elementList;
	}

	// Loaction 无酒店确认码 Radio 元素
	@Test
	public static WebElement getConfirmBooking_ConfirmID2() throws Exception {

		try {

			element = driver
					.findElement(By
							.xpath(".//*[@id='confirmBookingPopWin']/div[2]/label/input"));
			Log.info("Confirm_Order element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("Confirm_Order element is not found in Order_AuditOrder Page");
		}

		return element;
	}

	// Loaction 酒店确认码信息 -- 确认btn 元素
	@Test
	public static WebElement getConfirmBooking_Save() throws Exception {

		try {
			element = driver.findElement(By.id("confirmBooking_save"));
			Log.info("ConfirmBooking_Save element is found in Order_AuditOrder Page");
		} catch (Exception e) {
			Log.error("ConfirmBooking_Save element is not found in Order_AuditOrder_Page");
		}
		return element;
	}

	// Loaction 酒店确认码信息 -- 取消btn 元素
	@Test
	public static WebElement getConfirmBooking_Cancel() throws Exception {

		try {
			element = driver.findElement(By.id("confirmBooking_cancel"));
			Log.info("ConfirmBooking_Cancel element is found in Order_AuditOrder_Page");
		} catch (Exception e) {
			Log.error("ConfirmBooking_Cancel element is not found in Order_AuditOrder_Page");
		}
		return element;
	}

	// ******************************酒店确认码 弹层元素Location End
	// ************************************

	// *****************************结算修改提醒 弹层元素Location Start
	// ***********************************

	// Location 修改结算提醒 -- 现结元素
	// 同时location “上午”“下午”选择框
	@Test
	public static List<WebElement> getCount_NOW_SETTLE() throws Exception {

		try {
			try {
				element = driver.findElement(By
						.xpath(".//*[@id='checkoutContainer']/div[1]"));
				Log.info(element
						+ " Confirm_Order element is found in BookingClass Page");
			} catch (Exception e) {
				Log.error("Confirm_Order element is not found in Order_AuditOrder_Page");
			}
			elementList = element.findElements(By.tagName("input"));
			Log.info("Confirm_Order elements is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("Confirm_Order elements is not found in Order_AuditOrder_Page");
		}
		return elementList;
	}

	// Location 修改结算提醒 -- 周结页面元素
	@Test
	public static WebElement getCount_WEEK_SETTLE() throws Exception {

		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='checkoutContainer']/div[2]/label[1]/input"));
			Log.info(element.getAttribute("value")
					+ " AddRate element is found in Order_AuditOrder_Page");
		} catch (Exception e) {
			Log.error("AddRate element is not found in Order_AuditOrder_Page");
		}
		return element;
	}

	// Location 修改结算提醒 -- 半月结页面元素
	@Test
	public static WebElement getCount_HALF_MONTH_SETTLE() throws Exception {

		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='checkoutContainer']/div[2]/label[2]/input"));
			Log.info(element.getAttribute("value")
					+ " AddRate element is found in Order_AuditOrder_Page");
		} catch (Exception e) {
			Log.error("AddRate element is not found in Order_AuditOrder_Page");
		}
		return element;
	}

	// Location 修改结算提醒 -- 月结页面元素
	@Test
	public static WebElement getCount_MONTH_SETTLE() throws Exception {

		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='checkoutContainer']/div[2]/label[3]/input"));
			Log.info(element.getAttribute("value")
					+ " AddRate element is found in Order_AuditOrder_Page");
		} catch (Exception e) {
			Log.error("AddRate element is not found in Order_AuditOrder_Page");
		}
		return element;
	}

	// Location 修改结算提醒 -- 保存 -- 预订页面元素
	@Test
	public static WebElement getCount_Save() throws Exception {

		try {
			element = driver.findElement(By.id("saveSettle"));
			Log.info("saveSettle element is found in Order_AuditOrder_Page");
		} catch (Exception e) {
			Log.error("saveSettle element is not found in Order_AuditOrder_Page");
		}
		return element;
	}

	// Location 修改结算提醒 -- 取消 -- 预订页面元素
	@Test
	public static WebElement getCount_Cancle() throws Exception {

		try {
			element = driver.findElement(By.id("cancelSettle"));
			Log.info("cancelSettle element is found in Order_AuditOrder_Page");
		} catch (Exception e) {
			Log.error("cancelSettle element is not found in Order_AuditOrder_Page");
		}
		return element;
	}

	// *****************************结算修改提醒 弹层元素Location End
	// ***********************************
	
	//Location 取消调账--取消原因  元素
	@Test
	public static WebElement getCancelRemarkElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("cancelRemark"));
			Log.info("cancelRemark elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("cancelRemark elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location 取消调账--取消--保存 元素
	@Test
	public static WebElement getCancelOrderSaveElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("cancelOrderWindow_save"));
			Log.info("cancelOrderWindow_save elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("cancelOrderWindow_save elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	// *****************************邮件短信发送 Location Start***********************************
	
	//Location 文件发送的下拉选择框Select
	@Test
	public static Select getAllSendFile() throws Exception{
		
		try{
			selectNum = new Select(driver.findElement(By.cssSelector("select[id='ddl_sendFile']")));
			Log.info("SendFile Select element is found in Order_AuditOrder_Page Page");
		}catch (Exception e){
			Log.error("SendFile Select element is not found in Order_AuditOrder_Page Page");
		}
		return selectNum;
	}
	
	//Location 收件人文本框元素
	@Test
	public static WebElement getReceiver() throws Exception{
		
		try{
			element = driver.findElement(By.id("receiver"));
			Log.info("receiver elements is found in Order_AuditOrder_Page Page");
		}catch (Exception e){
			Log.error("receiver elements is not found in Order_AuditOrder_Page Page");
		}
		return element;
	}
	
	//Location "重发"元素
	@Test
	public static WebElement getResendBtn() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='container']/div[5]/div/a"));
			Log.info("ResendBtn elements is found in Order_AuditOrder_Page Page");
		}catch (Exception e){
			Log.error("ResendBtn elements is not found in Order_AuditOrder_Page Page");
		}
		return element;
	}
	
	//Location 入住短信 发送Btn
	public static WebElement getMessageSendBtn() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='smTemplate']/ul/li[2]/a/span[2]"));
			Log.info("ResendBtn elements is found in Order_AuditOrder_Page Page");
		}catch (Exception e){
			Log.error("ResendBtn elements is not found in Order_AuditOrder_Page Page");
		}
		return element;
	}
	
	// *****************************邮件短信发送  Location End***********************************
	
	//*******************Cashpay Order Detail checkpoint 获取**********************

	// 获取--出发城市--element
	public static WebElement getDFromCity() throws Exception {

		try {
			element = driver.findElement(By
					.xpath(".//*[@id='mainContent']/div[6]/div[2]/table/tbody/tr[1]/td[4]"));
			Log.info("FromCity value is found in Order Detail Page");
		} catch (Exception e) {
			Log.error("FromCity value is not found in Order Detail Page");
		}
		return element;
	}

	// 获取--入住日期--element
	public static WebElement getDCheckinDate() throws Exception {

		try {
			element = driver.findElement(By
					.id(".//*[@id='mainContent']/div[6]/div[2]/table/tbody/tr[4]/td[2]"));
			Log.info("CheckinDate value is found in Order Detail Page");
		} catch (Exception e) {
			Log.error("CheckinDate value is not found in Order Detail Page");
		}
		return element;
	}

	// 获取--离店日期--element
	public static WebElement getDCheckoutDate() throws Exception {

		try {
			element = driver.findElement(By
					.id(".//*[@id='mainContent']/div[6]/div[2]/table/tbody/tr[4]/td[4]"));
			Log.info("CheckoutDate value is found in Order Detail Page");
		} catch (Exception e) {
			Log.error("CheckoutDate value is not found in Order Detail Page");
		}
		return element;
	}

	// 获取--预订间数--element
	public static WebElement getDRoomNumber() throws Exception {

		try {
			element = driver.findElement(By
					.id(".//*[@id='mainContent']/div[6]/div[2]/table/tbody/tr[4]/td[6]"));
			Log.info("RoomNumber value is found in Order Detail Page");
		} catch (Exception e) {
			Log.error("RoomNumber value is not found in Order Detail Page");
		}
		return element;
	}

	// 获取--房客姓名--element
	public static WebElement getDName() throws Exception {

		try {
			element = driver.findElement(By
					.id(".//*[@id='mainContent']/div[9]/table/tbody/tr/td[3]"));
			Log.info("Name value is found in Order Detail Page");
		} catch (Exception e) {
			Log.error("Name value is not found in Order Detail Page");
		}
		return element;
	}

	// 获取--联系人姓名--element
	public static WebElement getDContactName() throws Exception {

		try {
			element = driver.findElement(By
					.id(".//*[@id='mainContent']/div[10]/table/tbody/tr/td[1]"));
			Log.info("ContactName element is found in Order Detail Page");
		} catch (Exception e) {
			Log.error("ContactName element is not found in Order Detail Page");
		}
		return element;
	}

	// 获取--联系人确认方式--element
	public static WebElement getDConfirmType() throws Exception {

		try {
			element = driver.findElement(By
					.id(".//*[@id='mainContent']/div[10]/div[2]"));
			elementList = element.findElements(By.tagName("input"));
			Log.info("ConfirmType element is found in Order Detail Page");
		} catch (Exception e) {
			Log.error("ConfirmType element is not found in Order Detail Page");
		}
		return element;
	}

	// 获取--联系人手机--element
	public static WebElement getDMobileNo() throws Exception {

		try {
			element = driver.findElement(By
					.id(".//*[@id='mainContent']/div[10]/table/tbody/tr/td[2]"));
			Log.info("MobileNo element is found in Order Detail Page");
		} catch (Exception e) {
			Log.error("MobileNo element is not found in Order Detail Page");
		}
		return element;
	}

	// 获取--固定电话--element
	public static WebElement getDTelephone() throws Exception {

		try {
			element = driver.findElement(By
					.id("html/body/section/div[4]/table/tbody/tr/td[4]"));
			Log.info("Telephone element is found in Order Detail Page");
		} catch (Exception e) {
			Log.error("Telephone element is not found in Order Detail Page");
		}
		return element;
	}

	// 获取--Email--element
	public static WebElement getDEmail() throws Exception {

		try {
			element = driver.findElement(By
					.id(".//*[@id='mainContent']/div[10]/table/tbody/tr/td[5]"));
			Log.info("Email element is found in Order Detail Page");
		} catch (Exception e) {
			Log.error("Email element is not found in Order Detail Page");
		}
		return element;
	}

	// 获取--取消订单--element
	public static WebElement getCancelOrder() throws Exception {

		try {
			element = driver.findElement(By
					.xpath(".//*[@id='ac']/div/span[2]/a/span[2]"));
			Log.info("CancelOrder element is found in Order Detail Page");
		} catch (Exception e) {
			Log.error("CancelOrder element is not found in Order Detail Page");
		}
		return element;
	}

}

package Hotel.OperatorHotel.GTAHotel.appModules;

import org.openqa.selenium.WebDriver;

import Hotel.OperatorHotel.GTAHotel.pageObjects.OrderManageOrderListPage;
import Hotel.OperatorHotel.OperatorLogin.utility.Log;

public class OrderManageOrderListAction {

	public static void transmitDriver(WebDriver driver) throws Exception{
		OrderManageOrderListPage.getWebDriver(driver);
	}
	
	//在订单输入框中输入订单号
	public static void OrderIdInput(String OrderId) throws Exception{
		OrderManageOrderListPage.OrderIdInput().sendKeys(OrderId);
		Log.info("*************OrderIdInput is writed**************");
	}
	
	//点击搜索按钮搜索出目标订单
	public static void SearchOrder() throws Exception{
		OrderManageOrderListPage.SearchOrder().click();
		Log.info("*************SearchOrder is clicked**************");
	}
	
	//点击目标订单订单号
	public static void OrderClick() throws Exception{
		OrderManageOrderListPage.OrderIdClick().click();
		Log.info("*************OrderClick is clicked**************");
	}
}

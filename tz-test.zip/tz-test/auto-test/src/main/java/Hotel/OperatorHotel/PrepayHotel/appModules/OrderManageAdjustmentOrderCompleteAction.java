package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.pageObjects.OrderManageAdjustmentOrderCompletePage;
import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class OrderManageAdjustmentOrderCompleteAction {

	private static WebDriver webdriver;

	//调账单 完成页面 Action
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webdriver = driver;
		OrderManageAdjustmentOrderCompletePage.getWebDriver(webdriver);
	}
	
	//"创建调账"btn Action
	@Test
	public static void excuteAdjustmentOrderCreateBtn() throws Exception {
		
		OrderManageAdjustmentOrderCompletePage.getAdjustmentOrderCreateBtnElement().click();
		Log.info("AdjustmentOrderCreateBtn btn is clicked");
	}
	
	//"创建变更单"btn Action
	@Test
	public static void excuteEndorseOrderCreateBtn() throws Exception {
		
		OrderManageAdjustmentOrderCompletePage.getEndorseOrderCreateBtnElement().click();
		Log.info("EndorseOrderCreateBtn btn is clicked");
	}
	
	//"创建退订单"btn Action
	@Test
	public static void excuteRefundOrderCreateBtn() throws Exception {
		
		OrderManageAdjustmentOrderCompletePage.getRefundOrderCreateBtnElement().click();
		Log.info("RefundOrderCreateBtn btn is clicked");
	}
	
	//"创建退订单"btn Action
	@Test
	public static void excuteModifyOrderBtn() throws Exception {
		
		OrderManageAdjustmentOrderCompletePage.getModifyOrderCreateBtnElement().click();
		Log.info("ModifyOrderBtn btn is clicked");
	}
	
}

package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class OrderManagePublicCheckPointPage {
 
	private static WebElement element;
	public static WebDriver driver;
	
	public static void getWebDriver(WebDriver webdriver){
		
		driver = webdriver;
	}
	
	//订单页 验证点元素集
	//订单页面公用：正常单、变更单、调账单、退订单
	//当前只适用 订单审核 页面的元素
	/********************************订单信息  Start***********************************/
	
	/**
	 * 创建订单 -- 订单信息 -- 采购备注
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getPurchaseRemark() throws Exception{
		
		try{
			element = driver.findElement(By.name("purchaseRemark"));
			Log.info("purchaseRemark element is found in create Order page");
		}catch (Exception e){
			Log.error("purchaseRemark element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 订单信息 -- 内部备注
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getInternalRemark() throws Exception{
		
		try{
			element = driver.findElement(By.name("internalRemark"));
			Log.info("internalRemark element is found in create Order page");
		}catch (Exception e){
			Log.error("internalRemark element is not found in create Order page");
		}
		return element;
	}
	
	/********************************订单信息  End ***********************************/
	
	/********************************预订产品  Start***********************************/
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 酒店所在城市
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoCityName() throws Exception{
		
		try{
			element = driver.findElement(By.name("hotelDetailBo.cityName"));
			Log.info("hotelDetailBo.cityName element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.cityName element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 酒店名称
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoHotelName() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='readonly_bookingProduct']/tbody/tr[1]/td[6]"));
			Log.info("hotelDetailBo.hotelName element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.hotelName element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 酒店地址
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoHotelAddress() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='readonly_bookingProduct']/tbody/tr[1]/td[8]"));
			Log.info("hotelDetailBo.hotelAddress element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.hotelAddress element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 酒店房型
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoRoomCat() throws Exception{
		
		try{
			element = driver.findElement(By.name("hotelDetailBo.roomCat"));
			Log.info("hotelDetailBo.roomCat element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.roomCat element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 酒店电话
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoMainPhone() throws Exception{
		
		try{
			element = driver.findElement(By.name("hotelDetailBo.mainPhone"));
			Log.info("hotelDetailBo.mainPhone element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.mainPhone element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 酒店床型
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoBedType() throws Exception{
		
		try{
			element = driver.findElement(By.name("hotelDetailBo.bedType"));
			Log.info("hotelDetailBo.bedType element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.bedType element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 入住人数	
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoRoomerNo() throws Exception{
		
		try{
			element = driver.findElement(By.name("hotelDetailBo.roomerNo"));
			Log.info("hotelDetailBo.roomerNo element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.roomerNo element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 价格计划
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoBookingclassName() throws Exception{
		
		try{
			element = driver.findElement(By.name("hotelDetailBo.bookingclassName"));
			Log.info("hotelDetailBo.bookingclassName element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.bookingclassName element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 礼包信息
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoGiftPkg() throws Exception{
		
		try{
			element = driver.findElement(By.name("hotelDetailBo.giftPkg"));
			Log.info("hotelDetailBo.giftPkg element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.giftPkg element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 入住日期
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoCheckinDate() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='readonly_bookingProduct']/tbody/tr[4]/td[2]"));
			Log.info("hotelDetailBo.checkinDate element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.checkinDate element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 离店日期
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoCheckoutDate() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='readonly_bookingProduct']/tbody/tr[4]/td[4]"));
			Log.info("hotelDetailBo.checkoutDate element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.checkoutDate element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 间数
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoRoomNo() throws Exception{
		
		try{
			element = driver.findElement(By.name("hotelDetailBo.roomNo"));
			Log.info("hotelDetailBo.roomNo element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.roomNo element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 夜数
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoNightNo() throws Exception{
		
		try{
			element = driver.findElement(By.id("nightNo"));
			Log.info("hotelDetailBo.nightNo element is found in create Order page");
		}catch (Exception e){
			Log.error("hotelDetailBo.nightNo element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 产品信息 -- 政策收入
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getPolicyFeeYuan() throws Exception{
		
		try{
			element = driver.findElement(By.name("policyFeeYuan"));
			Log.info("policyFeeYuan element is found in create Order page");
		}catch (Exception e){
			Log.error("policyFeeYuan element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 费用明细 -- 底价
	 * 目前只是获取第一晚
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getBasicFeeYuan() throws Exception{
		
		try{
			element = driver.findElement(By.id("fee_row_basicFeeYuan_0"));
			Log.info("basicFeeYuan element is found in create Order page");	
		}catch (Exception e){
			Log.error("basicFeeYuan element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 费用明细 -- 小计底价
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getTotalBasicFeeYuan() throws Exception{
		
		try{
			element = driver.findElement(By.id("totalBasicFeeYuan"));
			Log.info("totalBasicFeeYuan element is found in create Order page");	
		}catch (Exception e){
			Log.error("totalBasicFeeYuan element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 费用明细 -- 卖价
	 * 目前只是获取第一晚
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSellingFeeYuan() throws Exception{
		
		try{
			element = driver.findElement(By.id("fee_row_sellingFeeYuan_0"));
			Log.info("sellingFeeYuan element is found in create Order page");	
		}catch (Exception e){
			Log.error("sellingFeeYuan element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 费用明细 -- 小计卖价
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getTotalSellingFeeYuan() throws Exception{
		
		try{
			element = driver.findElement(By.id("totalSellingFeeYuan"));
			Log.info("totalSellingFeeYuan element is found in create Order page");	
		}catch (Exception e){
			Log.error("totalSellingFeeYuan element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 费用明细 -- 加价
	 * 目前只是获取第一晚
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getMarkupFeeYuan() throws Exception{
		
		try{
			element = driver.findElement(By.id("fee_row_markupFeeYuan_0"));
			Log.info("markupFeeYuan element is found in create Order page");	
		}catch (Exception e){
			Log.error("markupFeeYuan element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 费用明细 -- 小计加价
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getTotalMarkupFeeYuan() throws Exception{
		
		try{
			element = driver.findElement(By.id("totalMarkupFeeYuan"));
			Log.info("totalMarkupFeeYuan element is found in create Order page");	
		}catch (Exception e){
			Log.error("totalMarkupFeeYuan element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 费用明细 -- 每日合计
	 * 目前只是获取第一晚
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getDailyTotal() throws Exception{
		
		try{
			element = driver.findElement(By.id("dailyTotal_0"));
			Log.info("dailyTotal_0 element is found in create Order page");	
		}catch (Exception e){
			Log.error("dailyTotal_0 element is not found in create Order page");
		}
		return element;
	}
	
	
	/**
	 * 创建订单 -- 预订产品 -- 费用明细 -- 合计
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHeJi() throws Exception{
		
		try{
			element = driver.findElement(By.id("heji"));
			Log.info("heji element is found in create Order page");	
		}catch (Exception e){
			Log.error("heji element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 修改价格说明备注
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getPriceChangeRemark() throws Exception{
		
		try{
			element = driver.findElement(By.id("priceChangeRemark"));
			Log.info("priceChangeRemark element is found in create Order page");	
		}catch (Exception e){
			Log.error("priceChangeRemark element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 备注说明 
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoRemark() throws Exception{
		
		try{
			element = driver.findElement(By.name("hotelDetailBo.remark"));
			Log.info("hotelDetailBo.remark element is found in create Order page");	
		}catch (Exception e){
			Log.error("hotelDetailBo.remark element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 订单金额 -- 实际收入
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getOrderTotalShow() throws Exception{
		
		try{
			element = driver.findElement(By.name("totalOrderFeeYuan"));
			Log.info("orderTotal_show element is found in create Order page");	
		}catch (Exception e){
			Log.error("orderTotal_show element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 订单金额 -- 政策成本
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getTotalBasicFeeYuanShow() throws Exception{
		
		try{
			element = driver.findElement(By.name("totalBasicFeeYuan"));
			Log.info("totalBasicFeeYuan_show element is found in create Order page");	
		}catch (Exception e){
			Log.error("totalBasicFeeYuan_show element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 订单金额 -- 加价
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getTotalMarkupFeeYuanShow() throws Exception{
		
		try{
			element = driver.findElement(By.name("totalMarkupFeeYuan"));
			Log.info("totalMarkupFeeYuan_show element is found in create Order page");	
		}catch (Exception e){
			Log.error("totalMarkupFeeYuan_show element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 订单金额 -- 手续费
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getOrderProcedureFeeYuan() throws Exception{
		
		try{
			element = driver.findElement(By.id("orderProcedureFeeYuan"));
			Log.info("orderProcedureFeeYuan element is found in create Order page");	
		}catch (Exception e){
			Log.error("orderProcedureFeeYuan element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 本单挂账 -- 实际成本
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getActualCost() throws Exception{
		
		try{
			element = driver.findElement(By.id("actualCost"));
			Log.info("actualCost element is found in create Order page");	
		}catch (Exception e){
			Log.error("actualCost element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 本单挂账 -- 挂账金额
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSettleOrderFeeYuan() throws Exception{
		
		try{
			element = driver.findElement(By.id("settleOrderFeeYuan"));
			Log.info("settleOrderFeeYuan element is found in create Order page");	
		}catch (Exception e){
			Log.error("settleOrderFeeYuan element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 本单挂账 -- 留账金额
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getReservationFeeYuanShow() throws Exception{
		
		try{
			element = driver.findElement(By.id("reservationFeeYuan_show"));
			Log.info("reservationFeeYuan_show element is found in create Order page");	
		}catch (Exception e){
			Log.error("reservationFeeYuan_show element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 本单挂账 -- 挂账备注
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSettleRemark() throws Exception{
		
		try{
			element = driver.findElement(By.id("settleRemark"));
			Log.info("settleRemark element is found in create Order page");	
		}catch (Exception e){
			Log.error("settleRemark element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 酒店规定 -- 宾客备注
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoGuestRemark() throws Exception{
		
		try{
			element = driver.findElement(By.id("hotelDetailBo.guestRemark"));
			Log.info("hotelDetailBo.guestRemark element is found in create Order page");	
		}catch (Exception e){
			Log.error("hotelDetailBo.guestRemark element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 酒店规定 -- 入住时间
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoCheckinProvision() throws Exception{
		
		try{
			element = driver.findElement(By.id("readonly_hotelTerm_checkinDate"));
			Log.info("readonly_hotelTerm_checkinDate element is found in create Order page");	
		}catch (Exception e){
			Log.error("readonly_hotelTerm_checkinDate element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 酒店规定 -- 退房时间
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoCheckoutProvision() throws Exception{
		
		try{
			element = driver.findElement(By.id("readonly_hotelTerm_checkoutDate"));
			Log.info("readonly_hotelTerm_checkoutDate element is found in create Order page");	
		}catch (Exception e){
			Log.error("readonly_hotelTerm_checkoutDate element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 酒店规定 -- 取消\变更
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getHotelDetailBoCancleProvision() throws Exception{
		
		try{
			element = driver.findElement(By.id("readonly_hotelTerm_cancleProvision"));
			Log.info("readonly_hotelTerm_cancleProvision element is found in create Order page");	
		}catch (Exception e){
			Log.error("readonly_hotelTerm_cancleProvision element is not found in create Order page");
		}
		return element;
	}
	
	/********************************预订产品  End ***********************************/
	
	/*****************************供应商信息  Start **********************************/
	
	/**
	 * 创建订单 -- 预订产品 -- 供应商信息 -- 姓名
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSupplierBookingcontact() throws Exception{
		
		try{
			element = driver.findElement(By.id("supplier_bookingcontact"));
			Log.info("supplier_bookingcontact element is found in create Order page");	
		}catch (Exception e){
			Log.error("supplier_bookingcontact element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 供应商信息 -- 手机
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSupplierMobileno() throws Exception{
		
		try{
			element = driver.findElement(By.id("supplier_mobileno"));
			Log.info("supplier_mobileno element is found in create Order page");	
		}catch (Exception e){
			Log.error("supplier_mobileno element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 供应商信息 -- 传真
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSupplierFax() throws Exception{
		
		try{
			element = driver.findElement(By.id("supplier_fax"));
			Log.info("supplier_fax element is found in create Order page");	
		}catch (Exception e){
			Log.error("supplier_fax element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 供应商信息 -- 座机
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSupplierTelephone() throws Exception{
		
		try{
			element = driver.findElement(By.id("supplier_telephone"));
			Log.info("supplier_telephone element is found in create Order page");	
		}catch (Exception e){
			Log.error("supplier_telephone element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 供应商信息 -- Email
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSupplierEmail() throws Exception{
		
		try{
			element = driver.findElement(By.id("supplier_email"));
			Log.info("supplier_email element is found in create Order page");	
		}catch (Exception e){
			Log.error("supplier_email element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 供应商信息 -- 传真接收时间
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSupplierWorkTime() throws Exception{
		
		try{
			element = driver.findElement(By.id("supplier_workTime"));
			Log.info("supplier_workTime element is found in create Order page");	
		}catch (Exception e){
			Log.error("supplier_workTime element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 供应商信息 -- 供应商名称
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSupplierSuppilerName() throws Exception{
		
		try{
			element = driver.findElement(By.id("supplier_suppilerName"));
			Log.info("supplier_suppilerName element is found in create Order page");	
		}catch (Exception e){
			Log.error("supplier_suppilerName element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 供应商信息 -- 开户银行
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSupplierBankName() throws Exception{
		
		try{
			element = driver.findElement(By.id("supplier_bankName"));
			Log.info("supplier_bankName element is found in create Order page");	
		}catch (Exception e){
			Log.error("supplier_bankName element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 供应商信息 -- 开户名
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSupplierAccountName() throws Exception{
		
		try{
			element = driver.findElement(By.id("supplier_accountName"));
			Log.info("supplier_accountName element is found in create Order page");	
		}catch (Exception e){
			Log.error("supplier_accountName element is not found in create Order page");
		}
		return element;
	}
	
	/**
	 * 创建订单 -- 预订产品 -- 供应商信息 -- 账号
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getSupplierAccountNo() throws Exception{
		
		try{
			element = driver.findElement(By.id("supplier_accountNo"));
			Log.info("supplier_accountNo element is found in create Order page");	
		}catch (Exception e){
			Log.error("supplier_accountNo element is not found in create Order page");
		}
		return element;
	}
	
	/******************************供应商信息  End ***********************************/
	
	/**
	 * 订单 -- 获取当前订单的状态
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	public static WebElement getOrderStatus() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("div[class='status_ing statusContainer ']"));
			Log.info("OrderStatus element is found in create Order page");	
		}catch (Exception e){
			Log.error("OrderStatus element is not found in create Order page");
		}
		return element;
	}
}

package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.pageObjects.HotelMaintainAuditPage;
import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class HoetlMaintainAuditAction {
 
	private static WebDriver webdriver;
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webdriver = driver;
		HotelMaintainAuditPage.getWebDriver(webdriver);
	}
	
	//审核通过
	@Test
	public static void excuteAuditPass() throws Exception{
		
		HotelMaintainAuditPage.getAuditPassElement().click();
		Log.info("AuditPass btn is clicked");
	}
	
	//审核驳回
	@Test
	public static void excuteAuditFailed() throws Exception{
		
		HotelMaintainAuditPage.getAuditFailedElement().click();
		Log.info("AuditFailed btn is clicked");
	}
	
	//审核关闭
	@Test
	public static void excuteAuditClosed() throws Exception{
		
		HotelMaintainAuditPage.getAuditClosedElement().click();
		Log.info("AuditClosed btn is clicked");
	}
}

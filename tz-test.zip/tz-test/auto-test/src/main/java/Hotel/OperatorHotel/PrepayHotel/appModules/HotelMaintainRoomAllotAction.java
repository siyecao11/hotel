package Hotel.OperatorHotel.PrepayHotel.appModules;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.OperatorLogin.utility.Utils;
import Hotel.OperatorHotel.PrepayHotel.pageObjects.HotelMaintainRoomAllotPage;
import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class HotelMaintainRoomAllotAction {

	private static List<WebElement> eList;
	private static List<WebElement> noOfAllotedNoList;
	private static List<WebElement> cutOffDayList;
	private static List<Select> allotTypeList;
	private static Select selectAllotType;
	private static WebElement element;
	private static WebDriver webdriver;
	private static Random random = new Random();
	// 生成1~6和1~10的两个随机数
	private static int a = random.nextInt(5);
	private static int b = random.nextInt(13);
	

	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webdriver = driver;
		HotelMaintainRoomAllotPage.getWebDriver(webdriver);
	}

	// 库存房态管理：“批量”编辑房态，点击“批量编辑”并传值
	// 此处参数赋值需要再调整，灵活传参
	// 已改进
	@Test
	public static void excuteEditAll_Allot(String noOfAllotedNo,
			String cutOffDay, String allotType) throws Exception {

		// 点击“批量编辑” button
		HotelMaintainRoomAllotPage.getEditAll_AllotElement().click();
		Utils.waitForElement(3, webdriver, "script");
		HotelMaintainRoomAllotPage.getEditAll_AllotElement_Cancle().click();
		Utils.waitForElement(3, webdriver, "script");
		HotelMaintainRoomAllotPage.getEditAll_AllotElement().click();
		Utils.waitForElement(3, webdriver, "script");
		// get 页面所有房型对应的保留房的编辑框element
		eList = HotelMaintainRoomAllotPage.getNoOfAllotedNoElement();
		// 循环逐一对页面所有房型对应：保留房、cutOffDay、售完规则传值
		for (int i = 0; i < eList.size(); i++) {
			// 对保留房的编辑框element传值
			eList.get(i).clear();
			eList.get(i).sendKeys(noOfAllotedNo);
			// get 页面房型对应的cutOffDay的编辑框element并传值
			HotelMaintainRoomAllotPage.getCutoffDayElement().get(i).clear();
			HotelMaintainRoomAllotPage.getCutoffDayElement().get(i)
					.sendKeys(cutOffDay);
			// get 页面房型对应的售完规则的编辑框element并传值
			element = HotelMaintainRoomAllotPage.getAllotTypeSoldOutElement()
					.get(i);
			selectAllotType = new Select(element);
			selectAllotType.selectByValue(allotType);
			// 避免所有房型的参数值一致，修改每次循环的参数值
			// 已改进
			noOfAllotedNo = Integer
					.toString(Integer.parseInt(noOfAllotedNo) + 5*i);
			cutOffDay = Integer.toString(Integer.parseInt(cutOffDay) + 1*i);
			String atype[] = {"FREESALE","ON_REQUEST","FREESALE"};
			for(int j=0; j<atype.length; j++)
			{
				if(atype[j].equals(allotType)){
					if(j == 0)
					{
						allotType = atype[j+1];
					}
					else{
						allotType = atype[j-1];
					}
				}
			}
		}
		Log.info("Edit All Allot button is clicked, edit noOfAllotedNo, cutOffDay and allotTypeSoldOut");
	}

	// 库存房态管理：点击“批量编辑”,"保存"
	@Test
	public static void excuteEditAll_Allot_Save() throws Exception {

		HotelMaintainRoomAllotPage.getEditAll_AllotElement_Save().click();
		Log.info("EditAll_Save Allot button is clicked, noOfAllotedNo, cutOffDay and allotTypeSoldOut is saved");
	}

	// 库存房态管理：点击“批量编辑”,"取消"
	@Test
	public static void excuteEditAll_Allot_Cancle() throws Exception {

		HotelMaintainRoomAllotPage.getEditAll_AllotElement_Cancle().click();
		Log.info("EditAll_Cancle Allot button is clicked, edit is cancled");
	}

	// 库存房态管理："单个"编辑房量，点击“编辑”
	@Test
	public static void excuteEditAllot(String noOfAllotedNo, String cutOffDay,
			String allotType) throws Exception {

		// get 页面所有房型对应的编辑框element
		eList = HotelMaintainRoomAllotPage.getEditAllotElement();
		// 循环逐一点击页面所有房型对应的编辑按钮：并对保留房、cutOffDay、售完规则传值
		for (int i = 0; i < eList.size(); i++) {
			// 点击房型对应的编辑按钮
			eList.get(i).click();
			Utils.waitForElement(3, webdriver, "script");
			// get 页面房型对应的保留房的编辑框element并传值
			HotelMaintainRoomAllotPage.getNoOfAllotedNoElement().get(i).clear();
			HotelMaintainRoomAllotPage.getNoOfAllotedNoElement().get(i)
					.sendKeys(noOfAllotedNo);
			// get 页面房型对应的cutOffDay的编辑框element并传值
			HotelMaintainRoomAllotPage.getCutoffDayElement().get(i).clear();
			HotelMaintainRoomAllotPage.getCutoffDayElement().get(i)
					.sendKeys(cutOffDay);
			// get 页面房型对应的售完规则的编辑框element并传值
			element = HotelMaintainRoomAllotPage.getAllotTypeSoldOutElement()
					.get(i);
			selectAllotType = new Select(element);
			selectAllotType.selectByValue(allotType);
		}
		Log.info("Edit Allot button is clicked, edit noOfAllotedNo, cutOffDay and allotTypeSoldOut");
	}

	// 库存房态管理：点击“编辑”,"保存"编辑
	@Test
	public static void excuteEditAllot_Save() throws Exception {

		HotelMaintainRoomAllotPage.getEditAllot_Save().click();
		Log.info("Save edit Allot btn is click");
	}

	// 库存房态管理：点击“编辑”,"取消"编辑
	@Test
	public static void excuteEditAllot_Cancle() throws Exception {

		HotelMaintainRoomAllotPage.getEditAllot_Cancle().click();
		Log.info("Cancle edit Allot btn is click");
	}

	// 每日库存管理："选择房型"
	//***************选择房型应该采用参数传递的方式比较好，需要再优化(参考每日价格的房型选择)****************
	@Test
	public static void excuteDailyEdit_RoomType() throws Exception {

		// get "选择房型" 下拉框的所有选项(即所有房型)
		List options = HotelMaintainRoomAllotPage
				.getDailyEdit_RoomTypeElement().getOptions();
		// 循环依次选择下拉框的值
		for (int i = 0; i < options.size(); i++) {
			HotelMaintainRoomAllotPage.getDailyEdit_RoomTypeElement()
					.selectByValue(options.get(i).toString());
		}
	}

	// 每日库存管理："修改"
	@Test
	public static void excuteDailyEdit_RoomStorageBtn() throws Exception {

		Thread.sleep(2000);
		HotelMaintainRoomAllotPage.getDailyEdit_RoomStorageBtnElement().click();
		Log.info("Edit_RoomStorage_button is clicked, edit RoomStatus、AddAllot、CloseRoom");
	}

	// 每日库存管理：点击"修改"，“保存”修改
	@Test
	public static void excuteDailyEdit_RoomStorageBtn_Save() throws Exception {

		HotelMaintainRoomAllotPage.getDailyEdit_RoomStorageBtnElement_Save()
				.click();
		Log.info("Edit_RoomStorage_button_Save is clicked, Save RoomStatus、AddAllot、CloseRoom");
	}
	
	// 每日库存管理：点击"修改"，“取消”修改
	@Test
	public static void excuteDailyEdit_RoomStorageBtn_Cancle() throws Exception {

		HotelMaintainRoomAllotPage.getDailyEdit_RoomStorageBtnElement_Cancle()
				.click();
		Log.info("Edit_RoomStorage_button_Cancle is clicked, Cancle edit RoomStatus、AddAllot、CloseRoom");
	}
	
	// 每日库存管理：点击“修改”后，编辑 添加剩余 库存
	@Test
	public static void excuteDailyEdit_AddAllot(String addAllot)
			throws Exception {

		// get 页面所有房型每一天对应的 “添加剩余” 的编辑框element
		eList = HotelMaintainRoomAllotPage.getDailyEdit_AddAllotElement();
		// 循环逐一对页面所有“添加剩余”传值
		for (int i = 0; i < eList.size(); i++) {
			// 对“添加剩余”传值
			eList.get(i).clear();
			eList.get(i).sendKeys(addAllot);
			// 避免所有房型每一天的 添加剩余 值一致，修改每次循环的参数值
			addAllot = Integer.toString(Integer.parseInt(addAllot) + 1*i);
		}
		Log.info("Edit_RoomStorage_button is clicked, edit AddAllot");
	}
	
	// 每日库存管理：点击“修改”后，编辑 "售完房态"
	@Test
	public static void excuteDailyEdit_RoomStatus(String allottype) throws Exception{
		
		eList = HotelMaintainRoomAllotPage.getDailyEdit_RoomStatusElement();
		String atype[] = {"FREESALE","ON_REQUEST","FREESALE"};
		for(int i=0; i<eList.size(); i++)
		{
			if(a == i || b == i){
				element = eList.get(i);
				selectAllotType = new Select(element);
				selectAllotType.selectByValue(allottype);
				allottype = atype[i%3];
			}
		}
		
	}
	
	// 每日库存管理：点击“修改”后，编辑 “关房”
	@Test
	public static void excuteDailyEdit_CloseRoomElement() throws Exception {

		// get 页面所有房型每一天对应的 “关房” 的编辑框element
		eList = HotelMaintainRoomAllotPage.getDailyEdit_CloseRoomElement();
		// 随机指定某一天的“关放”状态为选中状态
		for (int i = 0; i < eList.size(); i++) {
			if (a == i) {
				eList.get(i).click();
				eList.get(i+1).click();
			}

		}
		Log.info("Edit_RoomStorage_button is clicked, edit CloseRoom");
	}

	@Test
	public static void excuteDailyRatePage() throws Exception {

		HotelMaintainRoomAllotPage.getDailrRatePageElement().click();
		Log.info("goto dailyRate page");
	}

}

package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.utility.Log;
import Hotel.OperatorHotel.PrepayHotel.pageObjects.HotelHomePage;;

public class HotelHomeAction {
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		HotelHomePage.getWebDriver(driver);
	}
	
	@Test
	public static void excuteHotelSearch() throws Exception{
		
		//Click HotelSearch menItem, goto HotelSearch Page
		HotelHomePage.getHotelSearchMenu().click();
		Log.info("HotelSearch menuItem is clicked, now enter into HotelSearch page");
	}
	
	@Test
	public static void excuteHotelMaintain() throws Exception{
		
		//Click HotelMaintain menItem, goto HotelMaintain Page
		HotelHomePage.getHotelMaintainMenu().click();
		Log.info("HotelMaintain menuItem is clicked, now enter into HotelMaintain page");
	}
	
	@Test
	public static void excuteOrderManage() throws Exception{
		
		//Click OrderManage menItem, goto OrderManage Page
		HotelHomePage.getOrderManageMenu().click();
		Log.info("OrderManage menuItem is clicked, now enter into OrderManage page");
	}
	
	@Test
	public static void excuteSalePricy() throws Exception{
		
		//Click SalePricy menItem, goto SalePricy Page
		HotelHomePage.getSalePricyMenu().click();
		Log.info("SalePricy menuItem is clicked, now enter into SalePricy page");
	}
	
	@Test
	public static void excuteHotelReport() throws Exception{
		
		//Click HotelReport menItem, goto HotelReport Page
		HotelHomePage.getHotelReportMenu().click();
		Log.info("HotelReport menuItem is clicked, now enter into HotelReport page");
	}
	
	@Test
	public static void excuteProductMaintain() throws Exception{
		
		//Click ProductMaintain menItem, goto ProductMaintain Page
		HotelHomePage.getProductMaintainMenu().click();
		Log.info("ProductMaintain menuItem is clicked, now enter into ProductMaintain page");
	}
}

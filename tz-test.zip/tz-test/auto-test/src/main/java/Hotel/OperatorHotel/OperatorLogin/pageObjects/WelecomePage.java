package Hotel.OperatorHotel.OperatorLogin.pageObjects;

import org.testng.annotations.Test;

import org.openqa.selenium.*;

import Hotel.OperatorHotel.OperatorLogin.utility.Log;

public class WelecomePage extends BaseClass{
	private static WebElement element;
	public static WebDriver driver;

	@Test
	public static void getWebDriver(WebDriver webdriver) throws Exception {

		driver = webdriver;
	}
	
	public WelecomePage(WebDriver driver){
		super(driver);
	}

	// get Hotel menuItem element
	@Test
	public static WebElement getHotelMenu() throws Exception {
		try {
			element = driver.findElement(By.cssSelector("a[item='酒店']"));
			Log.info("Hotel Menu item is found on the Wlecome Page");
		} catch (Exception e) {
			Log.error("********Hotel Menu item is not found on the Wlecome Page********");
		}
		return element;
	}

	// get DomesticFlight menuItem element
	@Test
	public static WebElement getDomesticFlightMenu() throws Exception {
		try {
			element = driver.findElement(By.cssSelector("a[item='国内机票']"));
			Log.info("DomesticFlight Menu item is found on the Wlecome Page");
		} catch (Exception e) {
			Log.error("********DomesticFlight Menu item is not found on the Wlecome Page********");
		}
		return element;
	}
	
	// get InternationalFlight menuItem element
	@Test
	public static WebElement getInternationalFlightMenu() throws Exception {
		try {
			element = driver.findElement(By.cssSelector("a[item='国际机票']"));
			Log.info("InternationalFlight Menu item is found on the Wlecome Page");
		} catch (Exception e) {
			Log.error("********InternationalFlight Menu item is not found on the Wlecome Page********");
		}
		return element;
	}

	// get Additional menuItem element
	@Test
	public static WebElement getAdditionalMenu() throws Exception {
		try {
			element = driver.findElement(By.cssSelector("a[item='保险']"));
			Log.info("Additional Menu item is found on the Wlecome Page");
		} catch (Exception e) {
			Log.error("********Additional Menu item is not found on the Wlecome Page********");
		}
		return element;
	}
	
	
	
	
	
	
}

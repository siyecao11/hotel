package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.pageObjects.OrderManageAdjustmentOrderAuditPage;
import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class OrderManageAdjustmentOrderAuditAction {

	private static WebDriver webdriver;

	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webdriver = driver;
		OrderManageAdjustmentOrderAuditPage.getWebDriver(webdriver);
	}
	
	//"确认调账" Action
	@Test
	public static void excuteAdjustmentOrderConfirmBtn() throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getAdjustmentOrderConfirmBtnElement().click();
		Log.info("AdjustmentOrderConfirmBtn btn is clicked");
	}
	
	//"取消调账" Action
	@Test
	public static void excuteAdjustmentOrderCancleBtn() throws Exception{
		
		OrderManageAdjustmentOrderAuditPage.getAdjustmentOrderCancleBtnElement().click();
		Log.info("AdjustmentOrderCancleBtn btn is clicked");
	}
	
	//审核确认(确认调账)：填写酒店确认码&&结算周期 的Action 调用公用的模块
	//所有的审核模块都可以调用
	//OrderManage_AuditOrder_Action类中
	
	//"留账金额" 编辑btn Action
	@Test
	public static void excuteLiuZhang() throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getLiuZhangElement().click();
		Log.info("LiuZhang btn is clicked");
	}
	
	// "留账金额" -- 留账金额  输入框  Action
	@Test
	public static void excuteResFeeForPop(String resFeeForPop) throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getResFeeForPopElement().sendKeys(resFeeForPop);
		Log.info("ResFeeForPop btn is clicked");
	}
	
	// "留账金额" -- 酒店/供应商确认人  Action
	@Test
	public static void excuteResContactForPop(String resContactForPop) throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getResContactForPopElement().sendKeys(resContactForPop);
		Log.info("ResContactForPop btn is clicked");
	}
	
	//"留账金额" -- 留账有效期  Action
	@Test
	public static void excuteResValidDateForPop() throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getResValidDateForPopElement().click();
		Log.info("ResValidDateForPop btn is clicked");
	}
	
	//"留账金额" -- 留账有效期  -- 时间插件  Action
	@Test
	public static void excuteTime() throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getTimeElement().click();
		Log.info("Time btn is clicked");
	}
	
	// "留账金额" -- 备注  Action
	@Test
	public static void excuteResRemarkForPop(String resRemarkForPop) throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getResRemarkForPopElement().sendKeys(resRemarkForPop);
		Log.info("resRemarkForPop btn is clicked");
	}
	
	// "留账金额" -- 确定保存Btn  Action
	@Test
	public static void excuteConfirmReservationBtn() throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getConfirmReservationBtnElement().click();
		Log.info("ConfirmReservationBtn btn is clicked");
	}
	
	// "留账金额" -- 留账保存后，核对本单挂账提醒  Action
	@Test
	public static void excuteComformSettlement() throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getComformSettlementElement().click();
		Log.info("ComformSettlement btn is clicked");
	}
	
	// 删除留账信息 “删除”  Action
	@Test
	public static void excuteResDeleteBtn() throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getResDeleteBtnElement().click();
		Log.info("ResDeleteBtn btn is clicked");
	}
	
	//  "挂账金额"  Action
	@Test
	public static void excuteSettleOrderFeeYuan(String settleOrderFeeYuan) throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getSettleOrderFeeYuanElement().clear();
		OrderManageAdjustmentOrderAuditPage.getSettleOrderFeeYuanElement().sendKeys(settleOrderFeeYuan);
		Log.info("settleOrderFeeYuan btn is clicked");
	}
	
	//  "挂账备注" Action
	@Test
	public static void excuteSettleRemark(String settleRemark) throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getSettleRemarkElement().sendKeys(settleRemark);
		Log.info("SettleRemark btn is clicked");
	}
	
	//  "取消调账原因" Action
	@Test
	public static void excuteCancelRemark() throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getCancelRemarkElement().sendKeys("调账错误，取消调账");
		Log.info("CancelRemark btn is clicked");
	}
	
	//  "取消调账原因" 保存 Action
	@Test
	public static void excuteCancelOrderSave() throws Exception {
		
		OrderManageAdjustmentOrderAuditPage.getCancelOrderSaveElement().click();
		Log.info("CancelOrderSaveElement is clicked");
	}
}

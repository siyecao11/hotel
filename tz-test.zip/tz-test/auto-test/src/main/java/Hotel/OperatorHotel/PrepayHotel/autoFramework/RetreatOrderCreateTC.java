package Hotel.OperatorHotel.PrepayHotel.autoFramework;

import org.testng.annotations.Test;

public class RetreatOrderCreateTC {
  @Test
  public void f() {
  }
}

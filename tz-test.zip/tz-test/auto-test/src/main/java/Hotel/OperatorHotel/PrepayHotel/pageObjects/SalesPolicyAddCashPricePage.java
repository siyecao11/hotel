package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import java.util.List;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.OperatorLogin.utility.Log;


public class SalesPolicyAddCashPricePage {
	public static WebElement element;
	public static WebDriver driver;
	public static List<WebElement> elementList = new ArrayList<WebElement>();
	
	@Test
	public static void getWebDriver(WebDriver webdriver) throws Exception{
		driver = webdriver;
	}
	@Test//定位规则名称
	public static WebElement getPolicyName() throws Exception{
		try{
			element = driver.findElement(By.name("policyName"));
			Log.info("policyName is found on the AddCashPrice Page");
		}catch(Exception e){
			Log.error("policyName is not found on the AddCashPrice Page");
		}
		return element;
	}
	//定位有效期起始日期
		@Test
		public static WebElement getValidStartDate() throws Exception{
			try{
				element = driver.findElement(By.name("validStartDate"));
				JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
				jsExecutor.executeScript("var setDate=document.getElementsByName(\"validStartDate\")[0];setDate.removeAttribute('readonly');");
				element.clear();
				Log.info("validStartDate is found on the AddCashPrice Page");
			}catch( Exception e){
				Log.error("validStartDate is not found on the AddCashPrice Page");
			}
			return element;
		}
		//定位有效期结束日期
		@Test
		public static WebElement getValidEndDate() throws Exception{
			try{
				element = driver.findElement(By.name("validEndDate"));
				JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
				jsExecutor.executeScript("var setDate=document.getElementsByName(\"validEndDate\")[0];setDate.removeAttribute('readonly');");
				element.clear();
				Log.info("validEndDate is found on the AddCashPrice Page");
			}catch( Exception e){
				Log.error("validEndDate is not found on the AddCashPrice Page");
			}
			return element;
		}
		
		//定位不需要的星期
		@Test
		public static List<WebElement> getUnCheckedWeekDay() throws Exception{
			try{
				String unChekced = "dayBit_2,dayBit_3";//用例传入参数：不需要的星期ID，以","隔开；
				String idArray[] = unChekced.split(",");
				if(idArray.length > 0){
					for(int i = 0;i < idArray.length ; i++){
						element = driver.findElement(By.id(idArray[i]));
						elementList.add(element);
					}
				Log.info("UnCheckedWeekDay is found on the AddCashPrice page");
				}
			}catch( Exception e){
				Log.error("UnCheckedWeekDay is not found on the AddCashPrice Page");
			}
			return elementList;
		}
		//定位客户返佣输入框
		@Test
		public static WebElement getFormularNumber() throws Exception{
			try{
				element = driver.findElement(By.cssSelector("input[id='priceFormularNumber']"));
				Log.info("FormularNumber is found on the AddCashPrice Page");
			}catch(Exception e){
				Log.error("FormularNumber is not found on the AddCashPrice Page");
			}
			return element;
		}
		//定位客户设置
		@Test
		public static WebElement getCustomerSet() throws Exception{
			try{
				String customerSet = new String();
				customerSet = "radio_customerSet_CUSTOMER";//用例传入参数，参数为客户/客户组的id
				element = driver.findElement(By.id(customerSet));
				Log.info("CustomerSet is found on the AddCashPrice Page");
			}catch(Exception e){
				Log.error("CustomerSet is not found on the AddCashPrice Page");
			}
			return element;
		}
		//定位切换客户确认框
		@Test
		public static WebElement getConfirmBtn() throws Exception{
			try{
				element = driver.findElement(By.className("ok-confirm-button"));
				Log.info("ConfirmBtn is found on the AddCashPrice Page");
			}catch(Exception e){
				Log.error("ConfirmBtn is not found on the AddCashPrice Page");
			}
			return element;
		}
		//定位客户名称输入框
		@Test
		public static WebElement getCustomerName() throws Exception{
			try{
				element = driver.findElement(By.id("search_customerName"));
				Log.info("CustomerName is found on the AddCashPrice Page");
			}catch(Exception e){
				Log.error("CustomerName is not found on the AddCashPrice Page");
			}
			return element;
		}
		//定位查询客户按钮
		@Test
		public static WebElement getSearchCustomer() throws Exception{
			try{
				element = driver.findElement(By.cssSelector("a[href='javascript:submitCustomerSearchForm();']"));
				Log.info("SearchCustomer is found on the AddCashPrice Page");
			}catch(Exception e){
				Log.error("SearchCustomer is not found on the AddCashPrice Page");
			}
			return element;
		}
		//定位选中客户单选框
		@Test
		public static WebElement getCheckCustomer() throws Exception{
			try{
				element = driver.findElement(By.id("checkedLeftAllCustomer"));
				Log.info("CheckCustomer is found on the AddCashPrice Page");
			}catch(Exception e){
				Log.error("CheckCustomer is not found on the AddCashPrice Page");
			}
			return element;
		}
		//定位发布售价政策
		@Test
		public static WebElement getImportBtn() throws Exception{
			try{
				element = driver.findElement(By.xpath("//*[@id='mainContent']/div[2]/div[3]/a"));
				Log.info("ImportBtn is found on the AddCashPrice Page");
			}catch(Exception e){
				Log.error("ImportBtn is not found on the AddCashPrice Page");
			}
			return element;
		}
		
		//点击售价规则名，进入新增规则详情页
		public static WebElement rulesDetils() throws Exception{
			try{
				element = driver.findElement(By.xpath("html/body/div[3]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[3]"));
				Log.info("NewRules is found on the AddPrePayPrice Page");
			}catch(Exception e){
				Log.error("NewRules is not found on the AddprePayPrice Page");
			}
			return element;
		}	
		//获取规则名称
		public static WebElement getRuleName() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[3]/div[1]/table/tbody/tr[1]/td[2]"));
				Log.info("RulesName is found on the RuleDetail Page");
			}catch(Exception e){
				Log.error("RulesName is not found on the RuleDetail Page");
			}
			return element;
		}	
		//获取规则有效期
		public static WebElement getRulesTime() throws Exception{
			try{
				element = driver.findElement(By.xpath("html/body/div[3]/div[2]/div/div/div[3]/div/table/tbody/tr[2]/td[2]"));
				Log.info("RulesTime is found on the RuleDetail Page");
			}catch(Exception e){
				Log.error("RulesTime is not found on the RuleDetail Page");
			}
			return element;
		}	
		
		//点击返回按钮
		public static WebElement backButton() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[2]/div[1]/button"));
				Log.info("backButton is found on the RuleDetail Page");
		}catch(Exception e){
			Log.error("backButton is not found on the RuleDetail Page");
		}
			return element;
		}
		
		
}

package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class OrderManageAdjustmentOrderCompletePage {

	public static WebDriver driver;
	private static WebElement element;
	private static Select selectNum;
	
	@Test
	public static void getWebDriver(WebDriver webdriver) {
		
		driver = webdriver;
		
	}
	
	//调账单 完成页面
	
	//Location "创建调账" btn元素
	@Test
	public static WebElement getAdjustmentOrderCreateBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("adjustment_operator_view_order"));
			Log.info("AdjustmentOrderCreateBtn elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("AdjustmentOrderCreateBtn elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "创建变更单" btn元素
	@Test
	public static WebElement getEndorseOrderCreateBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("operator_view_endorse_order"));
			Log.info("EndorseOrderC reateBtn elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("EndorseOrderCreateBtn elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "创建退订" btn元素
	@Test
	public static WebElement getRefundOrderCreateBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("operator_view_refund_order"));
			Log.info("RefunOrderCreateBtn elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("RefunOrderCreateBtn elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "修改订单" btn元素
	@Test
	public static WebElement getModifyOrderCreateBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("adjustment_operator_modify_order"));
			Log.info("ModifyOrderCreateBtn elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("ModifyOrderCreateBtn elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
}

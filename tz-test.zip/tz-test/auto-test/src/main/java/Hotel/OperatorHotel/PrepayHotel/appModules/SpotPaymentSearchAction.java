package Hotel.OperatorHotel.PrepayHotel.appModules;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import Hotel.OperatorHotel.OperatorLogin.utility.Log;
import Hotel.OperatorHotel.PrepayHotel.pageObjects.SpotPaymentSearchPage;

public class SpotPaymentSearchAction
{
	public static WebDriver driver;
	public static Select select;
	public static String option;
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		SpotPaymentSearchPage.getdriver(driver);
	}
	//点击现付标签
	@Test
	public static void spotPayment() throws Exception{
		try{
			SpotPaymentSearchPage.getSpotPayment().click();
		}catch(Exception e){
			Log.error("SpotPayment is not clicked");
		}
	} 
	//点击客户图标按钮
	@Test
	public static void customerButton() throws Exception{
		try{
			SpotPaymentSearchPage.getCustomerButton().click();
		}catch(Exception e){
			Log.error("customerButton is not clicked");
		}
	}
	//客户简称输入框
		public static void customerName(String customerName) throws Exception{
			try{
				SpotPaymentSearchPage.getCustomerName().sendKeys(customerName);
			}catch(Exception e){
				Log.error("CustomerName is not writed");
			}
		}
		//搜索按钮
		public static void customerSearch() throws Exception{
			try{
				SpotPaymentSearchPage.getCustomerSearch().click();
			}catch(Exception e){
				Log.error("CustomerSearch is not clicked");
			}
		}
		//选择客户
		public static void customer() throws Exception{
			try{
				SpotPaymentSearchPage.getCustomer().click();
			}catch(Exception e){
				Log.error("Customer is not clicked");
			}
		}
		//城市输入框
		public static void city(String city) throws Exception{
			try{
				SpotPaymentSearchPage.getCity().click();
				SpotPaymentSearchPage.getCityClick().click();
			}catch(Exception e){
				Log.error("City is not not writed");
			}
		}

		//入住时间输入框
		public static void checkinDate(String checkinDate) throws Exception{
			try{
				SpotPaymentSearchPage.getCheckinDate().clear();
				SpotPaymentSearchPage.getCheckinDate().sendKeys(checkinDate);
			}catch(Exception e){
				Log.error("CheckinDate is not writed");
			}
		}
		
		//离店时间输入框
		public static void checkoutDate(String checkoutDate) throws Exception{
			try{
				SpotPaymentSearchPage.getCheckoutDate().clear();
				SpotPaymentSearchPage.getCheckoutDate().sendKeys(checkoutDate);
			}catch(Exception e){
				Log.error("CheckoutDate is not writed");
			}
		}
		
		//酒店名称输入框
		public static void hotelName(String hotelName) throws Exception{
			try{
				SpotPaymentSearchPage.getHotelName().sendKeys(hotelName);
			}catch(Exception e){
				Log.error("HotelName is not writed");
			}
		}
		
		//查询按钮
		public static void searchButton() throws Exception{
			try{
				SpotPaymentSearchPage.getSearchButton().click();
			}catch(Exception e){
				Log.error("SearchButton is not clicked");
			}
		}
		
		//预定按钮
		public static void orderButton() throws Exception{
			try{
				SpotPaymentSearchPage.getOrderButton().click();
			}catch(Exception e){
				Log.error("OrderButton is not clicked");
			}
		}
	
	
	
}

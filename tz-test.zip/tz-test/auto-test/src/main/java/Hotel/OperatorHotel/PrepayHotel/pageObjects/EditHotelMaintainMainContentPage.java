package Hotel.OperatorHotel.PrepayHotel.pageObjects;


import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import Hotel.OperatorHotel.OperatorLogin.utility.*;

public class EditHotelMaintainMainContentPage extends BaseClass{

	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	public static String option;
	
	public EditHotelMaintainMainContentPage(WebDriver driver){
		super(driver);
	}
	
	public static void getDriver(WebDriver webdriver) throws Exception{
		driver = webdriver;
	}
	
	//签约经理
	@Test
	public static WebElement SignManager() throws Exception{
		try{
		 element = driver.findElement(By.cssSelector("select[id='signManager']"));
		}catch(Exception e){
			Log.error("********manager_select_checkbox is not found on the maincontent Page********");
		}
		return element;
	}
	/*WebElement element = driver.findElement(By.cssSelector("select[name='select']"));
	Select select = new Select(element);
	select.selectByValue("opel");
	select.selectByIndex(2);
	select.selectByVisibleText("Opel");*/
	
	//编辑酒店基本信息按钮
	@Test
	public static WebElement EditButton() throws Exception{
		try{
			driver.switchTo().defaultContent();
	        element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[4]/div[2]/a"));
		}catch (Exception e){
			Log.error("********edit_button is not found on the maincontent Page********");
		}
		return element;
	}
	
	//酒店名称输入框
	@Test
	public static WebElement editHotelName() throws Exception{
		try{
			
			//WebElement Iframe = driver.findElement(By.xpath("/html/body/div[6]/div[2]/iframe"));
			WebElement Iframe = driver.findElement(By.cssSelector("iframe[class='k-content-frame']"));
			driver.switchTo().frame(Iframe);
			element = driver.findElement(By.id("name"));	
		}catch (Exception e){
		Log.error("********Hotel_Name_Input is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//排序输入框
	@Test
	public static WebElement editDisplayOrder() throws Exception{
		try{//WebElement Iframe = driver.findElement(By.xpath("/html/body/div[6]/div[2]/iframe"));
			//driver.switchTo().frame(Iframe);
			element = driver.findElement(By.name("displayOrder"));	
		}catch (Exception e){
		Log.error("********Sort_Inout is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//推荐酒店勾选
	@Test
	public static WebElement editIsRecommend() throws Exception{
		try{
			element = driver.findElement(By.id("isRecommend"));	
		}catch (Exception e){
		Log.error("********Recommend_Hotel is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//连锁品牌
	@Test
	public static String getBrandSelect() throws Exception{
		try{
			Select oselect =new Select(driver.findElement(By.cssSelector("select[name='chainBrand.chainBrandId']")));
			elements = oselect.getOptions();
			int listSize = elements.size();
			for(int i=0;i<listSize;i++)
			{
				if(oselect.getOptions().get(i).getAttribute("selected")==null){
					continue;
				}
				else{
					option = oselect.getOptions().get(i).getText();
					break;
				}
			}
		}catch (Exception e){
		Log.error("********BrandSelect is not found on the maincontent Page********");
		}
	return option;
	}
	
	
	//酒店类型
	@Test
	public static String getHotelStyle() throws Exception{
		try{
			Select oselect =new Select(driver.findElement(By.cssSelector("select[name='category.code']")));
			elements = oselect.getOptions();
			int listSize = elements.size();
			for(int i=0;i<listSize;i++)
			{
				if(oselect.getOptions().get(i).getAttribute("selected")==null){
					continue;
				}
				else{
					option = oselect.getOptions().get(i).getText();
					break;
				}
			}
		}catch (Exception e){
		Log.error("********HotelStyle is not found on the maincontent Page********");
		}
	 return option;
	}
	
	
	//酒店星级
	@Test
	public static String getHotelStar() throws Exception{
		try{
			Select oselect =new Select(driver.findElement(By.cssSelector("select[name='rating']")));
			elements = oselect.getOptions();
			int listSize = elements.size();
			for(int i=0;i<listSize;i++)
			{
				if(oselect.getOptions().get(i).getAttribute("selected")==null){
					continue;
				}
				else{
					option = oselect.getOptions().get(i).getText();
					break;
				}
			}
		}catch (Exception e){
		Log.error("********HotelStar is not found on the maincontent Page********");
		}
	 return option;
	}
	
	//酒店大区
	@Test
	public static String getRegion() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[id='region']"));
			String regionId = element.getAttribute("currentvalue");
			Select oselect =new Select(driver.findElement(By.cssSelector("select[id='region']")));
			elements = oselect.getOptions();
			int listSize = elements.size();
			for(int i=0;i<listSize;i++)
			{
				if(oselect.getOptions().get(i).getAttribute("value").equals(regionId)){
					option = oselect.getOptions().get(i).getText();
					System.out.println(option);
					break;
				}
			}
		}catch (Exception e){
		Log.error("********Region is not found on the maincontent Page********");
		}
	 return option;
	}
	
	//ʡ酒店省
	@Test
	public static String getProvince() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[id='province']"));
			String provinceId = element.getAttribute("currentvalue");
			Select oselect =new Select(driver.findElement(By.cssSelector("select[id='province']")));
			elements = oselect.getOptions();
			int listSize = elements.size();
			for(int i=0;i<listSize;i++)
			{
				if(oselect.getOptions().get(i).getAttribute("value").equals(provinceId)){
					option = oselect.getOptions().get(i).getText();
					break;
				}
			}
		}catch (Exception e){
		Log.error("********Province is not found on the maincontent Page********");
		}
	 return option;
	}
	
	//酒店地址城市
	@Test
	public static String getCity() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[id='city']"));
			String cityId = element.getAttribute("currentvalue");
			Select oselect =new Select(driver.findElement(By.cssSelector("select[id='city']")));
			elements = oselect.getOptions();
			int listSize = elements.size();
			for(int i=0;i<listSize;i++)
			{
				if(oselect.getOptions().get(i).getAttribute("value").equals(cityId)){
					option = oselect.getOptions().get(i).getText();
					break;
				}
			}
		}catch (Exception e){
		Log.error("********City is not found on the maincontent Page********");
		}
	 return option;
	}
	
	
	//酒店地址行政区
	@Test
	public static String getDistrict() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[id='district']"));
			String districtId = element.getAttribute("currentvalue");
			Select oselect =new Select(driver.findElement(By.cssSelector("select[id='district']")));
			elements = oselect.getOptions();
			int listSize = elements.size();
			for(int i=0;i<listSize;i++)
			{
				if(oselect.getOptions().get(i).getAttribute("value").equals(districtId)){
					option = oselect.getOptions().get(i).getText();
					break;
				}
			}
		}catch (Exception e){
		Log.error("********District is not found on the maincontent Page********");
		}
	 return option;
	}
	
	//酒店地址商业区
	@Test
	public static WebElement editCommercial() throws Exception{
		try{
			element = driver.findElement(By.id("commercial"));
		}catch (Exception e){
		Log.error("********Commercial is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	@Test
	public static WebElement editSelectCommercial() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='location-layer-1']/ul/li[1]"));
		}catch (Exception e){
		Log.error("********SelectCommercial is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//酒店地址ַ
	
	@Test
	public static WebElement editHotelAddress() throws Exception{
		try{
			element = driver.findElement(By.id("address"));
		}catch (Exception e){
		Log.error("********HotelAddress is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//纬度
	@Test
	public static WebElement editLatitude() throws Exception{
		try{
			element = driver.findElement(By.name("hotelLocation.latitude"));
		}catch (Exception e){
		Log.error("********Latitude is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//经度
	@Test
	public static WebElement editLongitude() throws Exception{
		try{
			element = driver.findElement(By.name("hotelLocation.longitude"));
		}catch (Exception e){
		Log.error("********Longitude is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//酒店电话
	
	@Test
	public static WebElement editMainPhone() throws Exception{
		try{
			element = driver.findElement(By.name("mainPhone"));
		}catch (Exception e){
		Log.error("********Mainphone is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//酒店网址
	
	@Test
	public static WebElement editWebsite() throws Exception{
		try{
			element = driver.findElement(By.name("website"));
		}catch (Exception e){
		Log.error("********Website is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//酒店电子邮箱
	@Test
	public static WebElement editEmail() throws Exception{
		try{
			element = driver.findElement(By.name("email"));
		}catch (Exception e){
		Log.error("********Email is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//开业时间
	
	@Test
	public static WebElement editOpenDate() throws Exception{
		try{
			element = driver.findElement(By.name("openDate"));
		}catch (Exception e){
		Log.error("********OpenDate is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//装修时间   renovationDate
	
	@Test
	public static WebElement editRenovationDate() throws Exception{
		try{
			element = driver.findElement(By.name("renovationDate"));
		}catch (Exception e){
		Log.error("********RenovationDate is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	
	//楼层数  storey
	@Test
	public static WebElement editStorey() throws Exception{
		try{
			element = driver.findElement(By.name("storey"));
		}catch (Exception e){
		Log.error("********Storey is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//房间数   noOfRoom
	@Test
	public static WebElement editNoofRoom() throws Exception{
		try{
			element = driver.findElement(By.name("noOfRoom"));
		}catch (Exception e){
		Log.error("********NoofRoom is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//备注 summary
	
	@Test
	public static WebElement editSummary() throws Exception{
		try{
			element = driver.findElement(By.name("summary"));
		}catch (Exception e){
		Log.error("********Summary is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//保存酒店信息  .//*[@id='updateBaseInfoForm']/div[2]/a[1]
	
	@Test
	public static WebElement editSaveButton() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("class='button_1_2 submitForm'"));
		}catch (Exception e){
		Log.error("********Save_button is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//取消保存酒店信息
	@Test
	public static WebElement editCancleSave_button() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='updateBaseInfoForm']/div[2]/a[2]"));
		}catch (Exception e){
		Log.error("********CancleSave_button is not found on the maincontent Page********");
		}
	 return element;
	}
	
	/********************************************************************************************/
	
	
	//签约经理保存按钮
	@Test
	public static WebElement editManagerSaveButton() throws Exception {
		try{
			element = driver.findElement(By.xpath(".//*[@id='signManagerAddForm']/div[3]/a"));
		}catch (Exception e){
			Log.error("********ManagerSaveButton is not found on the maincontent Page********");
		}
		return element;
	}
	
	/********************************************************************************************/
	
	
	
	
	
	
	//编辑酒店照片按钮
	
	@Test
	public static WebElement editHotelPhotoButton() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[2]/a"));
		}catch (Exception e){
			Log.error("********Edit_HotelPhoto_Button is not found on the maincontent Page********");
		}
		return element;
	}
	
	//上传照片
	@Test
	public static WebElement editAddPhoto() throws Exception{
		try{
			WebElement Iframe = driver.findElement(By.cssSelector("class='k-content-frame'"));
			driver.switchTo().frame(Iframe);
			((JavascriptExecutor) driver).executeScript("document.getElementById(\"defaultPhoto\").type ='file';");
			 element =driver.findElement(By.id("defaultPhoto"));
		}catch (Exception e){
			Log.error("********AddPhoto is not found on the maincontent Page********");
		}
		return element;
	}

	//保存照片
	@Test
	public static WebElement editSubmitphoto() throws Exception{
		try{
			element = driver.findElement(By.id("submit")) ;
		}catch (Exception e){
			Log.error("********Submitphoto is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	/********************************************************************************************/
	
	
	
	//编辑酒店规定
	@Test
	public static WebElement editHotelRulesButton() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[6]/div[2]/a"));
		}catch (Exception e){
			Log.error("********EditHotelRulesButton is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	
	//选择宾客类型
	@Test//中宾
	public static WebElement editGuestTypeCheckbox1() throws Exception{
		try{
			//WebElement Iframe = driver.findElement(By.xpath("/html/body/div[9]/div[2]/iframe"));
			WebElement Iframe = driver.findElement(By.cssSelector("iframe[class='k-content-frame']"));
			driver.switchTo().frame(Iframe);
			element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/label/input[1]"));
		}catch (Exception e){
			Log.error("********GuestTypeCheckbox1 is not found on the maincontent Page********");
		}
		return element;
	}
	
	@Test//港澳台
	public static WebElement editGuestTypeCheckbox2() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/label/input[2]"));
		}catch (Exception e){
			Log.error("********GuestTypeCheckbox2 is not found on the maincontent Page********");
		}
		return element;
	}
	
	@Test//外宾
	public static WebElement editGuestTypeCheckbox3() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/label/input[3]"));
		}catch (Exception e){
			Log.error("********GuestTypeCheckbox3 is not found on the maincontent Page********");
		}
		return element;
	}
	//备注ע guestremark
	@Test
	public static WebElement editGuestremark() throws Exception{
		try{
			WebElement Iframe = driver.findElement(By.cssSelector("iframe[class='k-content-frame']"));
			driver.switchTo().frame(Iframe);
			element =driver.findElement(By.name("guestRemark"));
		}catch (Exception e){
			Log.error("********Guestremark is not found on the maincontent Page********");
		}
		return element;
	}

	//儿童年龄标准 
	@Test
	public static String getAgeSelect() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/select[1]"));
			Select oselect = new Select(element);
			elements = oselect.getOptions();
			int listNumber = elements.size();
			for(int i=0;i<listNumber;i++)
			{
				if(elements.get(i).getAttribute("selected")=="")
				{
					option = elements.get(i).getText();
					break;
				}
				else
				{
					 continue;
				}
			}
		}catch (Exception e){
			Log.error("********AgeSelect is not found on the maincontent Page********");
		}
		return option;
	}
	
	//儿童身高标准
	@Test
	public static String getHegihtSelect() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/select[2]"));
			Select oselect = new Select(element);
			elements = oselect.getOptions();
			int listNumber = elements.size();
			for(int i=0;i<listNumber;i++)
			{
				if(elements.get(i).getAttribute("selected")=="")
				{
					option = elements.get(i).getText();
					break;
				}
				else
				{
					 continue;
				}
			}
		}catch (Exception e){
			Log.error("********HegihtSelect is not found on the maincontent Page********");
		}
		return option;
	}
	
	//可带宠物
	@Test
	public static List<WebElement> editPetAllowed() throws Exception{
		try{
			 elements = driver.findElements(By.name("isPetAllowed"));
		}catch (Exception e){
			Log.error("********PetAllowed is not found on the maincontent Page********");
		}
		return elements;
	}
	//入住时间
	@Test
	public static String getCheckinTime() throws Exception{
		try{
			WebElement Iframe = driver.findElement(By.cssSelector("iframe[class='k-content-frame']"));
			driver.switchTo().frame(Iframe);
			element = driver.findElement(By.xpath(".//*[@id='updateTermForm']/table/tbody/tr[4]/td[2]/select[1]"));
			Select oselect = new Select(element);
			elements = oselect.getOptions();
			int listNumber = elements.size();
			for(int i=0;i<listNumber;i++)
			{
				if(elements.get(i).getAttribute("selected")=="")
				{
					option = elements.get(i).getText();
					break;
				}
				else
				{
					 continue;
				}
			}
		}catch (Exception e){
		Log.error("********CheckinTime is not found on the maincontent Page********");
		}
		return option;
	}
	
	//退房时间
	@Test
	public static String getCheckoutTime() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='updateTermForm']/table/tbody/tr[4]/td[2]/select[1]"));
			Select oselect = new Select(element);
			elements = oselect.getOptions();
			int listNumber = elements.size();
			for(int i=0;i<listNumber;i++)
			{
				if(elements.get(i).getAttribute("selected")=="")
				{
					option = elements.get(i).getText();
					break;
				}
				else
				{
					 continue;
				}
			}
		}catch (Exception e){
		Log.error("********CheckoutTime is not found on the maincontent Page********");
		}
		return option;
	}
	
	
	
	//变更取消
	@Test//days
	public static String editCheckinDay() throws Exception{
		try{
			option = driver.findElement(By.id("checkinDays")).getAttribute("value");
		}catch (Exception e){
			Log.error("********CheckinDay is not found on the maincontent Page********");
		}
		return option;
	}
	@Test//points
	public static String editCheckinPoints() throws Exception{
		try{
			option = driver.findElement(By.id("checkinPoints")).getAttribute("value");
		}catch(Exception e){
			Log.error("********checkinPoints is not found on the maincontent Page********");
		}
		return option;
	}
	
	//全部房费
	@Test
	public static String getCancelTerms() throws Exception{
		try{
			element =driver.findElement(By.id("cancelTerms"));
			String cancelTerms = element.getAttribute("defaultvalue");
			Select oselect = new Select(element.findElement(By.id("cancelTerms")));
			elements = oselect.getOptions();
			int listNumber = elements.size();
			for (int i=0;i<listNumber;i++)
			{
				if(elements.get(i).getAttribute("value").equals(cancelTerms))
				{
					option = elements.get(i).getText();
				}
			}
		}catch(Exception e){
			Log.error("********CancelTerms is not found on the maincontent Page********");
		}
		return option;
	}
	
	//添加按钮
	@Test
	public static WebElement editAddrulesButton() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("class='otherbutton'"));
		}catch(Exception e){
			Log.error("********AddrulesButton is not found on the maincontent Page********");
		}
		return element;
	}
	
	//保存规定
	@Test
	public static WebElement editSaveRulesButton() throws Exception{
		try{
			element =driver.findElement(By.xpath("/html/body/form/div/a[1]"));
		}catch (Exception e){
			Log.error("********SaveRulesButton is not found on the maincontent Page********");
		}
		return element;
	}
	
	/********************************************************************************************/
	
	
	//编辑服务设施
	
	
	//编辑酒店服务设施按钮
	@Test
	public static WebElement editServerFacility() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/div[3]/div[2]/div[8]/div[2]/a"));
		}catch (Exception e){
			Log.error("********EditServerFacility is not found on the maincontent Page********");
		}
		return element;
	} 
	
	//酒店服务设施选择项集合
	
	@Test
	public static List<WebElement> editBusinessCenter() throws Exception{
		try{
			WebElement Iframe = driver.findElement(By.xpath("/html/body/div[9]/div[2]/iframe"));
			driver.switchTo().frame(Iframe);
			
			elements = driver.findElements(By.name("facilityId"));
			
			//element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/ul/li[1]/label/input"));
		}catch (Exception e){
			Log.error("********BusinessCenter is not found on the maincontent Page********");
		}
		return elements;
	}
	
	//酒店设施保存按钮
	@Test
	public static WebElement editSaveBusinessCenter() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("class='button_1_2 submitForm'"));
		}catch (Exception e){
			Log.error("********SaveBusinessCenter is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	
	
	
	
	
	/********************************************************************************************/
	//编辑酒店备注
	@Test
	public static WebElement editHotelRemark() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/div[3]/div[2]/div[9]/div[2]/a"));
		}catch (Exception e){
			Log.error("********EditHotelRemark is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	//内部备注
	@Test
	public static WebElement PrivateRemark() throws Exception{
		try{
			WebElement Iframe = driver.findElement(By.xpath("/html/body/div[9]/div[2]/iframe"));
			driver.switchTo().frame(Iframe);
			element = driver.findElement(By.name("privateRemark"));
		}catch (Exception e){
			Log.error("********PrivateRemark is not found on the maincontent Page********");
		}
		return element;
	}
	
	//外部备注
	@Test
	public static WebElement PublicRemark() throws Exception{
		try{
			element = driver.findElement(By.name("publicRemark"));
		}catch (Exception e){
			Log.error("********PublicRemark is not found on the maincontent Page********");
		}
		return element;
	}
	
	//备注保存按钮 
	@Test
	public static WebElement SaveRemarkButton() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/div/a[1]"));
		}catch (Exception e){
			Log.error("********SaveRemarkButton is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	
	
	
	/********************************************************************************************/
	//跳转到供应商信息页面
	@Test
	public static WebElement ProviderButton() throws Exception{
		try{
			driver.switchTo().defaultContent();
			element = driver.findElement(By.id("contract"));
		}catch (Exception e){
			Log.error("********ProviderButton is not found on the maincontent Page********");
		}
		return element;
	}
	
	
		
}

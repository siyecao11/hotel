package Hotel.OperatorHotel.PrepayHotel.appModules;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.databene.commons.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.OperatorLogin.utility.Log;
import Hotel.OperatorHotel.PrepayHotel.pageObjects.SalesPolicyAddPrePayPricePage;
import Hotel.OperatorHotel.PrepayHotel.utility.Assertion;
import Hotel.OperatorHotel.PrepayHotel.utility.ExcelAction;

//添加预付售价酒店的操作
public class SalesPolicyAddPrePayPriceAction {
	
	private static List<WebElement> elementList = new ArrayList<WebElement>();
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception{
		SalesPolicyAddPrePayPricePage.getWebDriver(driver);
	}
	
	@Test//输入规则名称
	public static void inputPolicyName(String name) throws Exception{
	//	String name = new String();
	//	name = "tllruler";
		SalesPolicyAddPrePayPricePage.getPolicyName().sendKeys(name);
		Log.info(" ***********PolicyName is writed ***********");
	}
	
	@Test//输入有效期开始日期
	public static void inputValidStartDate(String beginTime) throws Exception{
		//String date = new String();
		//date = "2015-01-01";
		SalesPolicyAddPrePayPricePage.getValidStartDate().sendKeys(beginTime);
		Log.info(" ***********ValidStartDate is writed ***********");
	}
	
	@Test//输入有效期结束日期
	public static void inputValidEndDate(String overTime) throws Exception{
		//String date = new String();
		//date = "2017-01-01";
		SalesPolicyAddPrePayPricePage.getValidEndDate().sendKeys(overTime);
		Log.info(" ***********ValidEndDate is writed ***********");
	}
	
	@Test//反选星期
	public static void clickUnCheckedWeekDay() throws Exception{
		List<WebElement> elementList =  SalesPolicyAddPrePayPricePage.getUnCheckedWeekDay();
		if(CollectionUtils.isNotEmpty(elementList)){
			for(WebElement element : elementList){
				element.click();
			}
		}
		Log.info(" ***********unchecked weekday is clicked ***********");
	}
	
	@Test //选择供应商
	public static void selectSupplier(String slelctSupplierType) throws Exception{
		WebElement element = SalesPolicyAddPrePayPricePage.getSelectSupplier();
		//String supplierType = "自签酒店";//用例传入参数：自签酒店，GTA售价，大都市，锦江之星
		Select oSelect = new Select(element);
		oSelect.selectByVisibleText(slelctSupplierType);
		Log.info(" ***********HotelSetting is selected ***********");
	}
	@Test//酒店位置，默认按照城市
	public static void selectHotelSetting(String hotelArea) throws Exception{
		//String hotelArea = "3";//用例传入参数：0/1/2/3/4/5/
		if(StringUtils.isNotBlank(hotelArea)){
			elementList = SalesPolicyAddPrePayPricePage.getHotelSetting();
			elementList.get(Integer.parseInt(hotelArea)).click();//
			Log.info(" ***********HotelSetting is setted ***********");
		}
	}
	
	@Test//输入酒店名称
	public static void inputHotelName(String hotelName1) throws Exception{
		//String hotelName = "锦江之星";//用例传入参数，要剔除的酒店
		if(StringUtils.isNotBlank(hotelName1)){
			SalesPolicyAddPrePayPricePage.getHotelName().sendKeys(hotelName1);
			Log.info(" ***********HotelName is selected ***********");
		}
	}
	
	@Test//点击查询酒店名称
	public static void clickHotelHref(String hotelName2) throws Exception{
		//String hotelName = "锦江之星";//用例传入参数，要剔除的酒店
		if(StringUtils.isNotBlank(hotelName2)){
			SalesPolicyAddPrePayPricePage.getHotelHref().click(); 
			Log.info(" ***********HotelHref is cliked ***********");
		}
	}
	@Test//选中查询出来的酒店
	public static void selectRemoveHotel(String supplierType) throws Exception{
		//String supplierType = "自签酒店";//用例传入参数：自签酒店，GTA售价，大都市，锦江之星
		if(supplierType=="自签酒店"){
			SalesPolicyAddPrePayPricePage.getRemoveHotel().click();
			Log.info(" ***********RemoveHotel is cliked ***********");
		}
	}
	@Test//选中底价
	public static void clickFloorPrice() throws Exception{
		SalesPolicyAddPrePayPricePage.getFloorPrice().click();
		Log.info(" ***********FloorPrice is cliked ***********");
	}
	@Test//输入底价
	public static void inputFloorPrice(String floorPrice) throws Exception{
		SalesPolicyAddPrePayPricePage.getFloorPriceInput().sendKeys(floorPrice);//用例传入参数：底价
		Log.info(" ***********FloorPrice is writed ***********");
	}
	@Test//选中加价
	public static void clickPlusPrice() throws Exception{
		SalesPolicyAddPrePayPricePage.getPlusPrice().click();;
		Log.info(" ***********PlusPrice is cliked ***********");
	}
	@Test//输入加价
	public static void inputPlusPrice(String plusPrice) throws Exception{
		SalesPolicyAddPrePayPricePage.getPlusPriceInput().sendKeys(plusPrice);//用例传入参数:加多少价格
		Log.info(" ***********PlusPrice is writed ***********");
	}
	@Test//点击加价公式的添加按钮
	public static void clickPlusPriceHref() throws Exception{
		SalesPolicyAddPrePayPricePage.getPlusPriceHref().click();
		Log.info("***********PlusPriceHref is clicked ***********");
	}
	@Test //选择政策规定：房态
	public static void seletRoomStatus(String roomStatus) throws Exception{
		WebElement element = SalesPolicyAddPrePayPricePage.getRoomStatus();
		//String roomStatus = new String();
		//roomStatus = "系统房态"; //用例传入参数：系统房态，待确认
		Select oSelect = new Select(element);
		oSelect.selectByVisibleText(roomStatus);
		Log.info("***********RoomStatus is clicked ***********");
	}
	@Test //选择变更/取消
	public static void selectPolicyTerm(String policyTerm) throws Exception{
		//String policyTerm = new String();
		//policyTerm = "CHANGE_NOT_ALLLOW";//用例传入参数：CHANGE_NOT_ALLLOW 或 system
		elementList = SalesPolicyAddPrePayPricePage.getPolicyTerm();
		if(policyTerm=="system"){
			elementList.get(0).click();
		}else{
			elementList.get(1).click();
		}
		Log.info("***********PolicyTerm is selected ***********");
	}
	@Test //选择客户设置
	public static void selectCustomerSet() throws Exception{
		SalesPolicyAddPrePayPricePage.getCustomerSet().click();
		Log.info("***********CustomerSet is selected ***********");
	}
	@Test //点击确认切换按钮
	public static void clickConfirmBtn() throws Exception{
		SalesPolicyAddPrePayPricePage.getConfirmBtn().click();
		Log.info("***********ConfirmBtn is selected ***********");
	}
	@Test //输入客户名称
	public static void inputCustomerName(String customerName) throws Exception{
		//String customerName = new String();
		//customerName = "tll";
		SalesPolicyAddPrePayPricePage.getCustomerName().sendKeys(customerName);//用例传入参数：客户名称
		Log.info("***********CustomerName is writed***********");
	}
	@Test //点击查询客户按钮
	public static void clickSearchCustomer() throws Exception{
		SalesPolicyAddPrePayPricePage.getSearchCustomer().click();
		Log.info("***********SearchCustomer is clicked***********");
	}
	@Test //选中查询出来的全部客户
	public static void clickCheckCustomer() throws Exception{
		SalesPolicyAddPrePayPricePage.getCheckCustomer().click();
		Log.info("***********CheckCustomer is clicked***********");
	}
	@Test //点击发布售价按钮
	public static void clickImportBtn() throws Exception{
		SalesPolicyAddPrePayPricePage.getImportBtn().click();
		Log.info("***********ImportBtn is clicked***********");
	}
	@Test//进入售价规则详情页
	public static void clickRuleName() throws Exception{
		SalesPolicyAddPrePayPricePage.rulesDetils().click();
		Log.info("***********ruleName is clicked***********");
	}
	@Test //比较规则名称
	public static void rulesName() throws Exception{
		String rulename = SalesPolicyAddPrePayPricePage.getRuleName().getText();
		String erulename = ExcelAction.getValue("SalesPolicy.xls", "name");
		Assertion.verifyEquals(rulename, erulename,"***********ruleName is same***********");
	}
	@Test//比较规则有效期
	public static void rulesTime() throws Exception{
		String Totaltime = SalesPolicyAddPrePayPricePage.getRulesTime().getText();
		String Starttime = Totaltime.substring(0, 10);
		System.out.println(Totaltime+"-----------"+Starttime);
		String Endtime = Totaltime.substring(13,23);
		System.out.println(Totaltime+"-----------"+Endtime);
		String eStarttime = ExcelAction.getValue("SalesPolicy.xls", "beginTime");
		String eEndtime = ExcelAction.getValue("SalesPolicy.xls", "endTime");
		Assertion.verifyEquals(Starttime, eStarttime, "***********StartTime is same***********");
		Assertion.verifyEquals(Endtime, eEndtime, "***********Endtime is same***********");
	}
	@Test//比较供应商类型
	public static void supplierType() throws Exception{
		String supplierType = SalesPolicyAddPrePayPricePage.getRulesType().getText();
		String eSupplierType = ExcelAction.getValue("SalesPolicy.xls", "supplierType");
		System.out.println(supplierType+"-----------"+eSupplierType);
		Assertion.verifyEquals(supplierType, eSupplierType, "***********SupplierType is same***********");
	}
	@Test//比较底价正确性
	public static void price() throws Exception{
		String Price = SalesPolicyAddPrePayPricePage.getBasePrice().getText();
		String BasePrice = Price.substring(7, 9);
		String PlusPrice = Price.substring(11, 13);
		System.out.println(BasePrice+"-----------"+PlusPrice);
		String eBasePrice = ExcelAction.getValue("SalesPolicy.xls", "floorPrice");
		String ePlusPrice = ExcelAction.getValue("SalesPolicy.xls", "plusPrice");
		Assertion.verifyEquals(BasePrice, eBasePrice, "***********BasePrice is same***********");
		Assertion.verifyEquals(PlusPrice, ePlusPrice, "***********PlusPrice is same***********");
	}
	@Test//点击返回按钮
	public static void back() throws Exception{
		SalesPolicyAddPrePayPricePage.backButton().click();
		Log.info("***********ruleName is clicked***********");
	}
}

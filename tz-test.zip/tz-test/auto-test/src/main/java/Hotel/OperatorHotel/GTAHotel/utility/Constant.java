package Hotel.OperatorHotel.GTAHotel.utility;

public class Constant {

	//GTA订单管理页面
	public static final String gtaHotelOrderManageURL = "http://order.hotel.op3.tdxinfo.com/tops-front-operator-hotel-order/order/hotel/gta/GTAHotelOrderSearch";
}

package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.pageObjects.HotelMaintainDailyRatePage;
import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class HotelCommitAuditAction {

	private static WebDriver webdriver;
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webdriver = driver;
		HotelMaintainDailyRatePage.getWebDriver(webdriver);
	}
	
	//提交审核Action
	@Test
	public static void excuteCommitAudit() throws Exception{
		
		HotelMaintainDailyRatePage.getCommitAuditElement().click();
		Log.info("CommitAudit btn is clicked");
	}
	
	//“关闭”Action
	@Test
	public static void excuteCloseCommitAudit() throws Exception{
		
		HotelMaintainDailyRatePage.getCloseCommitAuditElement().click();
		Log.info("Close CommitAudit btn is clicked");
	}
}

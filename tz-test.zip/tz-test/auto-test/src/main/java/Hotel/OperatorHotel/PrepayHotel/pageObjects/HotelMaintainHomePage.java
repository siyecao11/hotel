package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import org.openqa.selenium.*;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.utility.Constant;
import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class HotelMaintainHomePage {

	public static WebDriver driver;
	private static WebElement element;

	@Test
	public static void getWebDriver(WebDriver webdriver) throws Exception {

		driver = webdriver;
	}

	@Test
	public static WebElement getAddHotelButton() throws Exception {

		try {
			element = driver.findElement(By.className("jdwh-btn-a"));
			Log.info("AddHotel Button is found on hotelMaintain Page");
		} catch (Exception e) {
			Log.error("********AddHotel Button is not found on hotelMaintain Page********");
		}
		return element;
	}

	@Test
	public static WebElement getSearchHotelButton() throws Exception {

		try {
			element = driver.findElement(By.id("searchButton"));
			Log.info("SearchHotel Button is found on hotelMaintain Page");
		} catch (Exception e) {
			Log.error("********SearchHotel Button is not found on hotelMaintain Page********");
		}
		return element;
	}

	@Test
	public static WebElement getAddHotelIndex() throws Exception {

		try {
			element = driver.findElement(By
					.xpath("//*[@id='hotelListForm']/table/tbody/tr[2]/td[2]"));
			Log.info("AddHotelIndex Button is found on hotelMaintain Page");
		} catch (Exception e) {
			Log.error("********AddHotelIndex Button is not found on hotelMaintain Page********");
		}
		return element;
	}

	@Test
	// 获取酒店选中的checkbox
	public static WebElement getHotelNameTextBoxElement() throws Exception {

		try {
			element = driver.findElement(By.id("hotelName"));
			Log.info("HotelNameTextBox is found on hotelMaintain Page");
		} catch (Exception e) {
			Log.info("HotelNameTextBox is not found on hotelMaintain Page");
		}
		return element;
	}

	@Test
	// 获取酒店选中的checkbox
	public static WebElement getCheckBoxElement() throws Exception {

		try {
			element = driver.findElement(By
					.cssSelector("input[name='hotelIds']"));
			Log.info("Hotel checkBox is found on hotelMaintain Page");
		} catch (Exception e) {
			Log.info("Hotel checkBox is not found on hotelMaintain Page");
		}
		return element;
	}

	@Test
	// 获取“解挂”元素
	public static WebElement getJieguaElement() throws Exception {

		try {
			element = driver.findElement(By.id("jiegua"));
			Log.info("jiegua element is found on hotelMaintain Page");
		} catch (Exception e) {
			Log.info("jiegua element is not found on hotelMaintain Page");
		}
		return element;
	}

	@Test
	// 获取“挂起”元素
	public static WebElement getGuaqiElement() throws Exception {

		try {
			element = driver.findElement(By.id("guaqi"));
			Log.info("guaqi element is found on hotelMaintain Page");
		} catch (Exception e) {
			Log.info("guaqi element is not found on hotelMaintain Page");
		}
		return element;
	}
	
	@Test
	// 获取挂起 确认按钮
	public static WebElement getGuaqiConformBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='confirmGuaqiWindow']/div/a"));
			Log.info("confirm btn element is found on hotelMaintain Page");
		}catch (Exception e){
			Log.info("confirm btn element is not found on hotelMaintain Page");
		}
		return element;
	}
	
	@Test
	// 获取挂起 取消按钮
	public static WebElement getGuaqiCancleBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='confirmGuaqiWindow']/div/a[2]"));
			Log.info("cancle btn element is found on hotelMaintain Page");
		}catch (Exception e){
			Log.info("cacle btn element is not found on hotelMaintain Page");
		}
		return element;
	}
	
	@Test
	// 获取解挂 确认按钮
	public static WebElement getJieguaConformBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='confirmJieguaWindow']/div/a"));
			Log.info("confirm btn element is found on hotelMaintain Page");
		}catch (Exception e){
			Log.info("confirm btn element is not found on hotelMaintain Page");
		}
		return element;
	}
	
	@Test
	// 获取解挂 取消按钮
	public static WebElement getJieguaCancleBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='confirmJieguaWindow']/div/a[2]"));
			Log.info("cancle btn element is found on hotelMaintain Page");
		}catch (Exception e){
			Log.info("cacle btn element is not found on hotelMaintain Page");
		}
		return element;
	}
}

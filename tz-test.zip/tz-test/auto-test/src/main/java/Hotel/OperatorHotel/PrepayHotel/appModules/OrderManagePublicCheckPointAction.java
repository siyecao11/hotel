package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.pageObjects.*;

public class OrderManagePublicCheckPointAction {

	private static WebDriver webdriver;

	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webdriver = driver;
		OrderManagePublicCheckPointPage.getWebDriver(webdriver);
	}
	
	//订单页 验证点元素集Action
	//订单页面公用：正常单、变更单、调账单、退订单
	/**
	 * get 采购商备注内容
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excutePurchaseRemark() throws Exception{
		
		String purchaseRemark = OrderManagePublicCheckPointPage.getPurchaseRemark().getText();
		return purchaseRemark;
	}
	
	/**
	 * get 内部备注内容
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteInternalRemark() throws Exception{
		
		String internalRemark = OrderManagePublicCheckPointPage.getInternalRemark().getText();
		return internalRemark;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 酒店所在城市
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoCityName() throws Exception{
		
		String hotelDetailBoCityName = OrderManagePublicCheckPointPage.getHotelDetailBoCityName().getAttribute("value").toString();
		return hotelDetailBoCityName;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 酒店名称
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoHotelName() throws Exception{
		
		String hotelDetailBoHotelName = OrderManagePublicCheckPointPage.getHotelDetailBoHotelName().getText();
		return hotelDetailBoHotelName;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 酒店地址
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoHotelAddress() throws Exception{
		
		String hotelDetailBoHotelAddress = OrderManagePublicCheckPointPage.getHotelDetailBoHotelAddress().getText();
		return hotelDetailBoHotelAddress;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 酒店房型
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoRoomCat() throws Exception{
		
		String hotelDetailBoRoomCat = OrderManagePublicCheckPointPage.getHotelDetailBoRoomCat().getAttribute("value").toString();
		return hotelDetailBoRoomCat;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 酒店电话
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoMainPhone() throws Exception{
		
		String hotelDetailBoMainPhone = OrderManagePublicCheckPointPage.getHotelDetailBoMainPhone().getAttribute("value").toString();
		return hotelDetailBoMainPhone;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 酒店床型
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoBedType() throws Exception{
		
		String hotelDetailBoBedType = OrderManagePublicCheckPointPage.getHotelDetailBoBedType().getAttribute("value").toString();
		return hotelDetailBoBedType;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 入住人数
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoRoomerNo() throws Exception{
		
		String hotelDetailBoRoomerNo = OrderManagePublicCheckPointPage.getHotelDetailBoRoomerNo().getAttribute("value").toString();
		return hotelDetailBoRoomerNo;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 价格计划
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoBookingclassName() throws Exception{
		
		String hotelDetailBoBookingclassName = OrderManagePublicCheckPointPage.getHotelDetailBoBookingclassName().getAttribute("value").toString();
		return hotelDetailBoBookingclassName;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 礼包信息
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoGiftPkg() throws Exception{
		
		String hotelDetailBoGiftPkg = OrderManagePublicCheckPointPage.getHotelDetailBoGiftPkg().getAttribute("value").toString();
		return hotelDetailBoGiftPkg;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 入住日期
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoCheckinDate() throws Exception{
		
		String hotelDetailBoCheckinDate = OrderManagePublicCheckPointPage.getHotelDetailBoCheckinDate().getText();
		return hotelDetailBoCheckinDate;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 离店日期
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoCheckoutDate() throws Exception{
		
		String hotelDetailBoCheckoutDate = OrderManagePublicCheckPointPage.getHotelDetailBoCheckoutDate().getText();
		return hotelDetailBoCheckoutDate;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 间数
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoRoomNo() throws Exception{
		
		String hotelDetailBoRoomNo = OrderManagePublicCheckPointPage.getHotelDetailBoRoomNo().getAttribute("value").toString();
		return hotelDetailBoRoomNo;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 夜数
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoNightNo() throws Exception{
		
		String hotelDetailBoNightNo = OrderManagePublicCheckPointPage.getHotelDetailBoNightNo().getAttribute("value").toString();
		return hotelDetailBoNightNo;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 政策收入
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excutePolicyFeeYuan() throws Exception{
		
		String policyFeeYuan = OrderManagePublicCheckPointPage.getPolicyFeeYuan().getAttribute("value").toString();
		return policyFeeYuan;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 底价
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteBasicFeeYuan() throws Exception{
		
		String basicFeeYuan = OrderManagePublicCheckPointPage.getBasicFeeYuan().getAttribute("value").toString();
		return basicFeeYuan;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 小计底价
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteTotalBasicFeeYuan() throws Exception{
		
		String totalBasicFeeYuan = OrderManagePublicCheckPointPage.getTotalBasicFeeYuan().getText();
		return totalBasicFeeYuan;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 卖价
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSellingFeeYuan() throws Exception{
		
		String sellingFeeYuan = OrderManagePublicCheckPointPage.getSellingFeeYuan().getAttribute("value").toString();
		return sellingFeeYuan;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 小计卖价
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteTotalSellingFeeYuan() throws Exception{
		
		String totalSellingFeeYuan = OrderManagePublicCheckPointPage.getTotalSellingFeeYuan().getText();
		return totalSellingFeeYuan;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 加价
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteMarkupFeeYuan() throws Exception{
		
		String markupFeeYuan = OrderManagePublicCheckPointPage.getMarkupFeeYuan().getAttribute("value").toString();
		return markupFeeYuan;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 小计加价
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteTotalMarkupFeeYuan() throws Exception{
		
		String totalMarkupFeeYuan = OrderManagePublicCheckPointPage.getTotalMarkupFeeYuan().getText();
		return totalMarkupFeeYuan;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 每日合计
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteDailyTotal() throws Exception{
		
		String dailyTotal = OrderManagePublicCheckPointPage.getDailyTotal().getText();
		return dailyTotal;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 合计
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHeJi() throws Exception{
		
		String heJi = OrderManagePublicCheckPointPage.getHeJi().getText();
		return heJi;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 修改价格说明备注
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excutePriceChangeRemark() throws Exception{
		
		String priceChangeRemark = OrderManagePublicCheckPointPage.getPriceChangeRemark().getText();
		return priceChangeRemark;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 备注说明
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoRemark() throws Exception{
		
		String hotelDetailBoRemark = OrderManagePublicCheckPointPage.getHotelDetailBoRemark().getText();
		return hotelDetailBoRemark;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 订单金额 -- 实际收入
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteOrderTotalShow() throws Exception{
		
		String orderTotalShow = OrderManagePublicCheckPointPage.getOrderTotalShow().getAttribute("value").toString();
		return orderTotalShow;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 订单金额 -- 政策成本
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteTotalBasicFeeYuanShow() throws Exception{
		
		String TotalBasicFeeYuanShow = OrderManagePublicCheckPointPage.getTotalBasicFeeYuanShow().getAttribute("value").toString();
		return TotalBasicFeeYuanShow;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 订单金额 -- 加价
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteTotalMarkupFeeYuanShow() throws Exception{
		
		String totalMarkupFeeYuanShow = OrderManagePublicCheckPointPage.getTotalMarkupFeeYuanShow().getAttribute("value").toString();
		return totalMarkupFeeYuanShow;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 订单金额 -- 手续费
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteOrderProcedureFeeYuan() throws Exception{
		
		String orderProcedureFeeYuan = OrderManagePublicCheckPointPage.getOrderProcedureFeeYuan().getAttribute("value").toString();
		return orderProcedureFeeYuan;
	}
	
	/**
	 * get 预订产品 -- 产品信息 -- 本单挂账 -- 实际成本
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteActualCost() throws Exception{
		
		String actualCost = OrderManagePublicCheckPointPage.getActualCost().getText();
		return actualCost;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 本单挂账 -- 挂账金额
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSettleOrderFeeYuan() throws Exception{
		
		String settleOrderFeeYuan = OrderManagePublicCheckPointPage.getSettleOrderFeeYuan().getAttribute("value").toString();
		return settleOrderFeeYuan;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 本单挂账 -- 留账金额
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteReservationFeeYuanShow() throws Exception{
		
		String ReservationFeeYuanShow = OrderManagePublicCheckPointPage.getReservationFeeYuanShow().getAttribute("value").toString();
		return ReservationFeeYuanShow;
	}
	
	/**
	 * get 预订产品 -- 费用明细 -- 本单挂账 -- 挂账备注
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSettleRemark() throws Exception{
		
		String settleRemark = OrderManagePublicCheckPointPage.getSettleRemark().getAttribute("value").toString();
		return settleRemark;
	}
	
	/**
	 * get 预订产品 -- 酒店规定 -- 宾客备注
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoGuestRemark() throws Exception{
		
		String hotelDetailBoGuestRemark = OrderManagePublicCheckPointPage.getHotelDetailBoGuestRemark().getText();
		return hotelDetailBoGuestRemark;
	}
	
	/**
	 * get 预订产品 -- 酒店规定 -- 入住时间
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoCheckinProvision() throws Exception{
		
		String hotelDetailBoCheckinProvision = OrderManagePublicCheckPointPage.getHotelDetailBoCheckinProvision().getText();
		return hotelDetailBoCheckinProvision;
	}
	
	/**
	 * get 预订产品 -- 酒店规定 -- 退房时间
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoCheckoutProvision() throws Exception{
		
		String hotelDetailBoCheckoutProvision = OrderManagePublicCheckPointPage.getHotelDetailBoCheckoutProvision().getText();
		return hotelDetailBoCheckoutProvision;
	}
	
	/**
	 * get 预订产品 -- 酒店规定 -- 取消\变更
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteHotelDetailBoCancleProvision() throws Exception{
		
		String hotelDetailBoCancleProvision = OrderManagePublicCheckPointPage.getHotelDetailBoCancleProvision().getText();
		return hotelDetailBoCancleProvision;
	}
	
	/**
	 * get 预订产品 -- 供应商信息 -- 姓名
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSupplierBookingcontact() throws Exception{
		
		String supplierBookingcontact = OrderManagePublicCheckPointPage.getSupplierBookingcontact().getAttribute("value").toString();
		return supplierBookingcontact;
	}
	
	/**
	 * get 预订产品 --供应商信息 -- 手机
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSupplierMobileno() throws Exception{
		
		String supplierMobileno = OrderManagePublicCheckPointPage.getSupplierMobileno().getAttribute("value").toString();
		return supplierMobileno;
	}
	
	/**
	 * get 预订产品 -- 供应商信息 -- 传真
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSupplierFax() throws Exception{
		
		String supplierFax = OrderManagePublicCheckPointPage.getSupplierFax().getAttribute("value").toString();
		return supplierFax;
	}
	
	/**
	 * get 预订产品 -- 供应商信息 -- 座机
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSupplierTelephone() throws Exception{
		
		String supplierTelephone = OrderManagePublicCheckPointPage.getSupplierTelephone().getAttribute("value").toString();
		return supplierTelephone;
	}
	
	/**
	 * get 预订产品 -- 供应商信息 -- Email
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSupplierEmail() throws Exception{
		
		String supplierEmail = OrderManagePublicCheckPointPage.getSupplierEmail().getAttribute("value").toString();
		return supplierEmail;
	}
	
	/**
	 * get 预订产品 -- 供应商信息 -- 传真接收时间
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSupplierWorkTime() throws Exception{
		
		String supplierWorkTime = OrderManagePublicCheckPointPage.getSupplierWorkTime().getAttribute("value").toString();
		return supplierWorkTime;
	}
	
	/**
	 * get 预订产品 --供应商信息 -- 供应商名称
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSupplierSuppilerName() throws Exception{
		
		String supplierSuppilerName = OrderManagePublicCheckPointPage.getSupplierSuppilerName().getAttribute("value").toString();
		return supplierSuppilerName;
	}
	
	/**
	 * get 预订产品 -- 供应商信息 -- 开户银行
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSupplierBankName() throws Exception{
		
		String SupplierBankName = OrderManagePublicCheckPointPage.getSupplierBankName().getAttribute("value").toString();
		return SupplierBankName;
	}
	
	/**
	 * get 预订产品 -- 供应商信息 -- 开户名
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSupplierAccountName() throws Exception{
		
		String SupplierAccountName = OrderManagePublicCheckPointPage.getSupplierAccountName().getAttribute("value").toString();
		return SupplierAccountName;
	}
	
	/**
	 * get 预订产品 -- 供应商信息 -- 账号
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteSupplierAccountNo() throws Exception{
		
		String supplierAccountNo = OrderManagePublicCheckPointPage.getSupplierAccountNo().getAttribute("value").toString();
		return supplierAccountNo;
	}
	
	/**
	 * 订单 -- 获取当前订单的状态
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	@Test
	public static String excuteOrderStatus() throws Exception{
		
		String orderStatus = OrderManagePublicCheckPointPage.getOrderStatus().getText();
		return orderStatus;
	}
}

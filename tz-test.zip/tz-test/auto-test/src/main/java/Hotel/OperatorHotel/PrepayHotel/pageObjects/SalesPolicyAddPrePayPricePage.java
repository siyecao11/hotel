package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.OperatorLogin.utility.Log;

//添加预付售价酒店的页面元素

public class SalesPolicyAddPrePayPricePage {
  
	private static WebElement element;
	private static List<WebElement> elementList = new ArrayList<WebElement>();
	public static WebDriver driver;
	
	@Test
	public static void getWebDriver(WebDriver webdriver) throws Exception{
		
		driver = webdriver;
	}
	//定位规则名称
	@Test
	public static WebElement getPolicyName() throws Exception{
		try{
			element = driver.findElement(By.name("policyName"));
			Log.info("policyName is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("policyName is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//定位有效期起始日期
	@Test
	public static WebElement getValidStartDate() throws Exception{
		try{
			element = driver.findElement(By.name("validStartDate"));
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"validStartDate\")[0];setDate.removeAttribute('readonly');");
			element.clear();
			Log.info("validStartDate is found on the AddPrePayPrice Page");
		}catch( Exception e){
			Log.error("validStartDate is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//定位有效期结束日期
	@Test
	public static WebElement getValidEndDate() throws Exception{
		try{
			element = driver.findElement(By.name("validEndDate"));
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"validEndDate\")[0];setDate.removeAttribute('readonly');");
			element.clear();
			Log.info("validEndDate is found on the AddPrePayPrice Page");
		}catch( Exception e){
			Log.error("validEndDate is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	
	//定位不需要的星期
	@Test
	public static List<WebElement> getUnCheckedWeekDay() throws Exception{
		try{
			String unChekced = "dayBit_2,dayBit_3";//用例传入参数：不需要的星期ID，以","隔开；
			String idArray[] = unChekced.split(",");
			if(idArray.length > 0){
				for(int i = 0;i < idArray.length ; i++){
					element = driver.findElement(By.id(idArray[i]));
					elementList.add(element);
				}
			Log.info("UnCheckedWeekDay is found on the AddPrePayPrice Page");
			}
		}catch( Exception e){
			Log.error("UnCheckedWeekDay is not found on the AddPrePayPrice Page");
		}
		return elementList;
	}
	
	//定位选择供应商
	@Test
	public static WebElement getSelectSupplier() throws Exception{
		try{
			element = driver.findElement(By.id("salesPolicySelectAdd"));
			Log.info("SelectSupplier is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("SelectSupplier is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//定位酒店位置
	@Test
	public static List<WebElement> getHotelSetting() throws Exception{
		try{	
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setClass=document.getElementsByName(\"wx\")[0].attributes['class'].nodeValue = '';");//去掉class属性
			jsExecutor.executeScript("var setClass=document.getElementsByName(\"wx\")[1].attributes['class'].nodeValue = '';");
			jsExecutor.executeScript("var setClass=document.getElementsByName(\"wx\")[2].attributes['class'].nodeValue = '';");
			jsExecutor.executeScript("var setClass=document.getElementsByName(\"wx\")[3].attributes['class'].nodeValue = '';");
			jsExecutor.executeScript("var setClass=document.getElementsByName(\"wx\")[4].attributes['class'].nodeValue = '';");
			jsExecutor.executeScript("var setClass=document.getElementsByName(\"wx\")[5].attributes['class'].nodeValue = '';");
			elementList = driver.findElements(By.name("wx"));
			Log.info("HotelSetting is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("HotelSetting is not found on the AddPrePayPrice Page");
		}
		return elementList;
	}
	//定位酒店名称，预备查询
	@Test
	public static WebElement getHotelName() throws Exception{
		try{
			element = driver.findElement(By.id("search_hotelName"));
			Log.info("HotelName is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("HotelSetting is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//定位查询酒店名称控件
	@Test
	public static WebElement getHotelHref() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/div[3]/div[2]/div/div/div[3]/div[4]/div/div[3]/div[1]/a"));
			Log.info("HotelHref is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("HotelName is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//选中要排除的酒店
	@Test
	public static WebElement getRemoveHotel() throws Exception{
		try{
			element = driver.findElement(By.id("checkedLeftAllHotel"));
			Log.info("RemoveHotel is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("RemoveHotel is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//定位底价radio，需传入用例中radio的ID值，ID是什么就选中哪一种底价并进行设置
	@Test
	public static WebElement getFloorPrice() throws Exception{
		try{
			String radioId = new String();
			radioId = "greaterThanEqual";//此处需传入用例中的radio id值
			element = driver.findElement(By.id(radioId));
			Log.info("FloorPrice is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("FloorPrice is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//定位底价输入框
	@Test
	public static WebElement getFloorPriceInput() throws Exception{
		try{
			String radioId = new String();
			radioId = "greaterThanEqual";//此处需传入用例中的radio id值
			element = driver.findElement(By.cssSelector("#" + radioId + "+ input" ));
			Log.info("FloorPriceInput is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("FloorPriceInput is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//定位加价radio，需传入用例中radio的ID值，ID是什么就选中哪一种底价并进行设置
	@Test
	public static WebElement getPlusPrice() throws Exception{
		try{
			String radioId = new String();
			radioId = "markupPercent";
			element = driver.findElement(By.id(radioId));
			Log.info("PlusPrice is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("PlusPrice is not found on the AddPrePayPrice Page");
		}
		return element;		
	}
	//定位加价输入框
	@Test
	public static WebElement getPlusPriceInput() throws Exception{
		try{
			String radioId = new String();
			radioId = "markupPercent";
			element = driver.findElement(By.cssSelector("#" + radioId + "+ input"));
			Log.info("PlusPriceInput is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("PlusPriceInput is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//定位加价公式的添加按钮
	@Test
	public static WebElement getPlusPriceHref() throws Exception{
		try{
			element = driver.findElement(By.id("addFareFormula"));
			Log.info("PlusPriceHref is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("PlusPriceHref is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//定位政策规定：房态
	@Test
	public static WebElement getRoomStatus() throws Exception{
		try{
			element = driver.findElement(By.id("roomCatStatus"));
			Log.info("RoomStatus is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("RoomStatus is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//定位政策规定：变更/取消
	@Test
	public static List<WebElement> getPolicyTerm() throws Exception{
		try{
			elementList = driver.findElements(By.name("policyTerm_cancel"));
			Log.info("PolicyTerm is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("PolicyTerm is not found on the AddPrePayPrice Page");
		}
		return elementList;
	}
	//定位客户设置
	@Test
	public static WebElement getCustomerSet() throws Exception{
		try{
			String customerSet = new String();
			customerSet = "radio_customerSet_CUSTOMER";//用例传入参数，参数为客户/客户组的id
			element = driver.findElement(By.id(customerSet));
			Log.info("CustomerSet is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("CustomerSet is not found on the AddPrePayPrice Page");
		}
		return element;
	}
	//定位切换客户确认框
	@Test
	public static WebElement getConfirmBtn() throws Exception{
		try{
			element = driver.findElement(By.className("ok-confirm-button"));
			Log.info("ConfirmBtn is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("ConfirmBtn is not found on the AddprePayPrice Page");
		}
		return element;
	}
	//定位客户名称输入框
	@Test
	public static WebElement getCustomerName() throws Exception{
		try{
			element = driver.findElement(By.id("search_customerName"));
			Log.info("CustomerName is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("CustomerName is not found on the AddprePayPrice Page");
		}
		return element;
	}
	//定位查询客户按钮
	@Test
	public static WebElement getSearchCustomer() throws Exception{
		try{
			element = driver.findElement(By.xpath("//*[@id='unexcludeCustomerContainer']/div[1]/a"));
			Log.info("SearchCustomer is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("SearchCustomer is not found on the AddprePayPrice Page");
		}
		return element;
	}
	//定位选中客户单选框
	@Test
	public static WebElement getCheckCustomer() throws Exception{
		try{
			element = driver.findElement(By.id("checkedLeftAllCustomer"));
			Log.info("CheckCustomer is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("CheckCustomer is not found on the AddprePayPrice Page");
		}
		return element;
	}
	//定位发布售价政策
	@Test
	public static WebElement getImportBtn() throws Exception{
		try{
			element = driver.findElement(By.xpath("//*[@id='mainContent']/div[2]/div[3]/a"));
			Log.info("ImportBtn is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("ImportBtn is not found on the AddprePayPrice Page");
		}
		return element;
	}	
	//点击售价规则名，进入新增规则详情页
	public static WebElement rulesDetils() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[3]/div[2]/div[3]/div[2]/div[2]/table/tbody/tr[1]/td[3]"));
			Log.info("NewRules is found on the AddPrePayPrice Page");
		}catch(Exception e){
			Log.error("NewRules is not found on the AddprePayPrice Page");
		}
		return element;
	}	
	//获取规则名称
	public static WebElement getRuleName() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[3]/div[1]/table/tbody/tr[1]/td[2]"));
			Log.info("RulesName is found on the RuleDetail Page");
		}catch(Exception e){
			Log.error("RulesName is not found on the RuleDetail Page");
		}
		return element;
	}	
	//获取规则有效期
	public static WebElement getRulesTime() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[3]/div[1]/table/tbody/tr[2]/td[2]"));
			Log.info("RulesTime is found on the RuleDetail Page");
		}catch(Exception e){
			Log.error("RulesTime is not found on the RuleDetail Page");
		}
		return element;
	}	
	//获取规则供应商类型
	public static WebElement getRulesType() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[3]/div[1]/table/tbody/tr[2]/td[5]"));
			Log.info("RulesType is found on the RuleDetail Page");
		}catch(Exception e){
			Log.error("RulesType is not found on the RuleDetail Page");
		}
		return element;
	}	
	//获取底价
	public static WebElement getBasePrice() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[4]/div[1]/div[2]/span"));
			Log.info("BasePrice is found on the RuleDetail Page");
		}catch(Exception e){
			Log.error("BasePrice is not found on the RuleDetail Page");
		}
		return element;
	}	
	
	//点击返回按钮
	public static WebElement backButton() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[2]/div[1]/button"));
			Log.info("backButton is found on the RuleDetail Page");
	}catch(Exception e){
		Log.error("backButton is not found on the RuleDetail Page");
	}
		return element;
	}
	
	
	
	
	
	
}

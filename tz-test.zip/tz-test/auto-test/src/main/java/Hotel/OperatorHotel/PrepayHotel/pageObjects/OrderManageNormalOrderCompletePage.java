package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.OperatorLogin.utility.Log;

public class OrderManageNormalOrderCompletePage {

	public static WebDriver driver;
	private static WebElement element;
	private static List<WebElement> elementList;

	// 正常单完成页

	public static void GetDriver(WebDriver webdriver) {

		driver = webdriver;
	}

	// 正常单完成 -- 创建变更单 -- 按钮
	public static WebElement CreatEndorseOrder() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath("/html/body/div[3]/div[2]/form/div/div[1]/div[2]/div[3]/a[6]/span[2]"));
			Log.info("CreatEndorseOrder is found in the AuditOrderComplete Page.");
		} catch (Exception e) {
			Log.error("CreatEndorseOrder is not found in the AuditOrderComplete Page.");
		}
		return element;
	}

	/**
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	// 正常单完成 -- 创建调账单 -- 按钮
	public static WebElement CreatAdjustmentOrder() throws Exception {
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='adjustment_operator_view_order']/span[2]"));
			Log.info("CreatAdjustmentOrder is found in the AuditOrderComplete Page.");
		} catch (Exception e) {
			Log.error("CreatAdjustmentOrder is not found in the AuditOrderComplete Page.");
		}
		return element;
	}

	// **********************************点击创建 --退订单--弹出窗口
	// Start*******************************
	// 正常单完成 -- 创建退订单 -- 按钮
	public static WebElement CreatRetreatOrder() throws Exception {
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='operator_view_refund_order']/span[2]"));
			Log.info("CreatRetreatOrder is found in the AuditOrderComplete Page.");
		} catch (Exception e) {
			Log.error("CreatRetreatOrder is not found in the AuditOrderComplete Page.");
		}
		return element;
	}

	// 获取退订提示页面，扣除全部房费、首晚房费、全退、调前离店
	// 获取扣除全部房费页面元素 radioBtn
	@Test
	public static WebElement getRetreat_CHANGEALL() throws Exception {

		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='refundWindow']/table/tbody/tr[1]/td[1]/label/input"));
			Log.info("Retreat_CHANGEALL element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error("Retreat_CHANGEALL element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

	// 获取扣除首晚房费页面元素 radioBtn
	@Test
	public static WebElement getRetreat_CHANGEFIRST() throws Exception {

		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='refundWindow']/table/tbody/tr[2]/td[1]/label/input"));
			Log.info("Retreat_CHANGEFIRST element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error("Retreat_CHANGEFIRST element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

	// 获取扣除全部房费页面元素 radioBtn
	@Test
	public static WebElement getRetreat_CHANGENONE() throws Exception {

		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='refundWindow']/table/tbody/tr[3]/td[1]/label/input"));
			Log.info("Retreat_CHANGENONE element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error("Retreat_CHANGENONE element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

	// 获取提前离店页面元素 radioBtn
	@Test
	public static WebElement getRetreat_EARLYCHECKOUT() throws Exception {

		try {
			element = driver.findElement(By.xpath(".//*[@id='refundWindow']/table/tbody/tr[4]/td[1]/label/input"));
			Log.info("Retreat_EARLYCHECKOUT element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error("Retreat_EARLYCHECKOUT element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

	// 获取提前离店的离店时间 多选checkbox以input获取
	@Test
	public static List<WebElement> getRetreat_EARLYCHECKOUT_RefundDate()
			throws Exception {

		try {
			try {
				element = driver.findElement(By.xpath(".//*[@id='tqld']"));
				Log.info(" EARLYCHECKOUT_RefundDate element is found in Retreat_Save Page");
			} catch (Exception e) {
				Log.error("EARLYCHECKOUT_RefundDate element is not found in OrderManage_RetreatOrder Page");
			}
			elementList = element.findElements(By.tagName("input"));
			Log.info(elementList
					+ " EARLYCHECKOUT_RefundDate elements is found in Retreat_Save Page");
		} catch (Exception e) {
			Log.error("EARLYCHECKOUT_RefundDate elements is not found in OrderManage_RetreatOrder Page");
		}
		return elementList;
	}

	// 保存退订条件 Btn
	@Test
	public static WebElement getRetreat_Save() throws Exception {

		try {
			element = driver.findElement(By.id("refund_save"));
			Log.info("Retreat_Save element is found in Retreat_Save Page");
		} catch (Exception e) {
			Log.error("Retreat_Save element is not found in Retreat_Save Page");
		}
		return element;
	}

	// 取取消退订条件 Btn
	@Test
	public static WebElement getRetreat_Cancel() throws Exception {

		try {
			element = driver.findElement(By.id("refund_cancel"));
			Log.info(element
					+ " Retreat_Save element is found in Retreat_Save Page");
		} catch (Exception e) {
			Log.error("Retreat_Save element is not found in Retreat_Save Page");
		}
		return element;
	}

	// ***********************************点击创建 --退订单--弹窗 End
	// ********************************

	// ***********************************点击创建 --变更单-- 后页面弹出窗口 Start
	// ********************************

	// 点击修改日期按钮
	public static WebElement DateButton() throws Exception {
		try {
			WebElement Iframe = driver.findElement(By
					.xpath("/html/body/div[10]/div[1]/iframe"));
			driver.switchTo().frame(Iframe);
			element = driver.findElement(By.id("change_date"));
			Log.info("DateButton is found in the AuditOrderComplete Page.");
		} catch (Exception e) {
			Log.error("DateButton is not found in the AuditOrderComplete Page.");
		}
		return element;
	}

	// 点击入住时间选择框
	public static WebElement CheckinDate() throws Exception {
		try {
			element = driver.findElement(By.id("checkinDate"));
			Log.info("CheckinDate is found in the AuditOrderComplete Page.");
		} catch (Exception e) {
			Log.error("CheckinDate is not found in the AuditOrderComplete Page.");
		}
		return element;
	}

	// 点击选择入住时间
	public static WebElement SetCheckinDate(String endorseCheckinDate) throws Exception {
		try {
			element = driver.findElement(By.linkText(endorseCheckinDate));//"14"
			Log.info("CheckinDate is found in the AuditOrderComplete Page.");
		} catch (Exception e) {
			Log.error("CheckinDate is not found in the AuditOrderComplete Page.");
		}
		return element;
	}

	// 点击离店时间选择框
	public static WebElement CheckoutDate() throws Exception {
		try {
			element = driver.findElement(By.id("checkoutDate"));
			Log.info("CheckinDate is found in the AuditOrderComplete Page.");
		} catch (Exception e) {
			Log.error("CheckinDate is not found in the AuditOrderComplete Page.");
		}
		return element;
	}

	// 点击选择离店时间
	public static WebElement SetCheckoutDate(String endorseCheckoutDate) throws Exception {
		try {
			element = driver.findElement(By.linkText(endorseCheckoutDate));//"15"
			Log.info("CheckoutDate is found in the AuditOrderComplete Page.");
		} catch (Exception e) {
			Log.error("CheckoutDate is not found in the AuditOrderComplete Page.");
		}
		return element;
	}

	// 选择间数
	public static WebElement RoomNo() throws Exception {
		try {
			element = driver.findElement(By.xpath("/html/body/div[4]/div[2]/form/ul/li[3]/label/span/span/span[1]"));
			Log.info("RoomNo is found in the AuditOrderComplete Page.");
		} catch (Exception e) {
			Log.error("RoomNo is not found in the AuditOrderComplete Page.");
		}
		return element;
	}

	// 点击确定按钮
	public static WebElement SaveDate() throws Exception {
		try {
			element = driver.findElement(By.xpath("/html/body/div[4]/div[2]/form/ul/li[4]/a[1]/span[2]"));
			Log.info("SaveDate is found in the AuditOrderComplete Page.");
		} catch (Exception e) {
			Log.error("SaveDate is not found in the AuditOrderComplete Page.");
		}
		return element;
	}

	// 点击预定按钮
	public static WebElement Booking(String BookHotelId) throws Exception {
		try {
			element = driver.findElement(By.id(BookHotelId));
			Log.info("Booking is found in the AuditOrderComplete Page.");
		} catch (Exception e) {
			Log.error("Booking is not found in the AuditOrderComplete Page.");
		}
		return element;
	}

	// ***********************************点击创建 --变更单-- 后页面弹出窗口 End
	// ********************************

}

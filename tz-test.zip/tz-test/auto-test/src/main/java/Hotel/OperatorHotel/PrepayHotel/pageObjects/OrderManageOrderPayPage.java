package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Hotel.OperatorHotel.OperatorLogin.utility.Log;

public class OrderManageOrderPayPage extends BaseClass{

	public static WebDriver driver; 
	private static WebElement element;
	public OrderManageOrderPayPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public static void GetDriver(WebDriver webdriver){
		driver = webdriver;
	}
	
	public static WebElement OrderId() throws Exception{
		try {
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[4]/div[1]/span[2]"));
			Log.error("*************OrderId is found in the OrderPay Page************");	
		}catch (Exception e){
			Log.error("*************OrderId is not found in the OrderPay Page************");
		}
		return element;
	}
	
	
}

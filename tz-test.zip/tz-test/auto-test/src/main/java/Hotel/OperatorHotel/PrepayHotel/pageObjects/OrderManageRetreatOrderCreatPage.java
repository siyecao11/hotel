package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class OrderManageRetreatOrderCreatPage {
	
	public static WebDriver driver;
	private static WebElement element;
	
	//创建退订单
	public static void GetDriver(WebDriver webdriver) {

		driver = webdriver;
	}
	
	// ********************创建退订单*********************
	// 获取酒店创建退订单页面元素
	@Test
	public static WebElement getCreat_RetreatOrder_Link() throws Exception {

		// getConfirmBooking_Link().click();
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='operator_create_refund_order']/span[2]"));
			Log.info(" Creat_RetreatOrder_Link element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error(" Creat_RetreatOrder_Link element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

}

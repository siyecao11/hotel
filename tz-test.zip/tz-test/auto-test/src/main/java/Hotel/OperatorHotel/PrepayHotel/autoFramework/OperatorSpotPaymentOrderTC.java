package Hotel.OperatorHotel.PrepayHotel.autoFramework;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.testng.annotations.Test;
import Hotel.OperatorHotel.PrepayHotel.testCase.SpotPayment;


public class OperatorSpotPaymentOrderTC extends FeedTest{
	@Test(dataProvider = "feeder")
	@Source("SpotPayment_Data.xls")
  public static void spotPaymentOrder(String username,String password,String customerName,String city,
			String checkinDate,String checkoutDate,String hotelName,String roomnum,String chineseName,
			String englishName,String confrimType,String contactName,String mobileNum,String telePhone,
			String email) throws Exception{
		SpotPayment.spotPaymentSearch(username, password, customerName, city, checkinDate, checkoutDate, hotelName, roomnum, chineseName, englishName, confrimType, contactName, mobileNum, telePhone, email);
	//	SpotPaymentCheckPoint.SpotPaymentCheck();  
  }
}

package Hotel.OperatorHotel.GTAHotel.autoFramework;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.GTAHotel.testCase.OrderManageOrderList;
import Hotel.OperatorHotel.GTAHotel.testCase.PointGTAOrderList;

public class OrderManageOrderListTC extends FeedTest{

	public static WebDriver driver;
	
	@Test(dataProvider = "feeder", priority = 20)
	@Source("LoginInfo_TestData.xls")
	public static void orderDetail(String username, String password) throws Exception
	{
		PointGTAOrderList.pointSearchHotel(username, password);
		driver = PointGTAOrderList.currentDriver;
		OrderManageOrderList.orderDeteil(Hotel.PurchaserHotel.GTAHotel.utility.Constant.gtaOrderId, driver);
	}
	
}

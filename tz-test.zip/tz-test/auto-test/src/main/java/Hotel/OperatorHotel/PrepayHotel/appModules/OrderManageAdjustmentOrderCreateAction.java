package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.pageObjects.OrderManageAdjustmentOrderCreatePage;
import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class OrderManageAdjustmentOrderCreateAction {

	private static WebDriver webdriver;

	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webdriver = driver;
		OrderManageAdjustmentOrderCreatePage.getWebDriver(webdriver);
	}
	
	// 触发“创建调账单” Action
	// 进入调账审核页
	@Test
	public static void excuteCreateAdjustmentOrderBtn() throws Exception{
		
		OrderManageAdjustmentOrderCreatePage.getCreateAdjustmentOrderBtnElement().click();
		Log.info("CreateAdjustmentOrderBtn is clicked, goto adjustmentOrder audit page");
	}
	
	// 触发“修改价格” Action
	// 修改低价和卖价
	@Test
	public static void excuteModifyPrice() throws Exception{
		
		OrderManageAdjustmentOrderCreatePage.getModifyPriceElement().click();
		Log.info("ModifyPrice is clicked, ready to modify basicFeeYuan and sellingFeeYuan");
	}
	
	// 修改低价和卖价 -- 确认Action
	@Test
	public static void excuteSaveCostBtn() throws Exception{
		
		OrderManageAdjustmentOrderCreatePage.getSaveCostBtnElement().click();
		Log.info("SaveCostBtn is clicked");
	}
	
	// 修改低价和卖价 -- 取消Action
	@Test
	public static void excuteCancleCostBtn() throws Exception{
		
		OrderManageAdjustmentOrderCreatePage.getCancleCostBtnElement().click();
		Log.info("CancleCostBtn is clicked");
	}
	
	// 修改低价和卖价 -- 确认 -- 修改价格原因Action
	@Test
	public static void excuteModifyRemark() throws Exception{
		
		OrderManageAdjustmentOrderCreatePage.getModifyRemarkElement().sendKeys("修改价格Test 保存");
		Log.info("ModifyRemark is edited");
	}
	
	// 修改低价和卖价 -- 确认 -- 修改价格原因  -- 确认保存Action
	@Test
	public static void excuteModifyRemarkWindow_Save() throws Exception{
		
		OrderManageAdjustmentOrderCreatePage.getModifyRemarkWindow_SaveElement().click();
		Log.info("ModifyRemarkWindow_Save is Clicked");
	}
	
	// 修改低价和卖价 -- 确认 -- 修改价格原因  -- 取消保存Action
	@Test
	public static void excuteModifyRemarkWindow_Cancle() throws Exception{
		
		OrderManageAdjustmentOrderCreatePage.getModifyRemarkWindow_CancelElement().click();
		Log.info("ModifyRemarkWindow_Cancle is Clicked");
	}
	
	// “手续费” 修改Action
	@Test
	public static void excuteOrderProcedureFeeYuan(String procedureFeeYuan) throws Exception{
		
		OrderManageAdjustmentOrderCreatePage.getOrderProcedureFeeYuanElement().click();
		OrderManageAdjustmentOrderCreatePage.getOrderProcedureFeeYuanElement().clear();
		OrderManageAdjustmentOrderCreatePage.getOrderProcedureFeeYuanElement().sendKeys(procedureFeeYuan);
		Log.info("ModifyPrice is clicked, ready to modify borderProcedureFeeYuan");
	}
	
}

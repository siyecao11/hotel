package Hotel.OperatorHotel.PrepayHotel.appModules;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.pageObjects.OrderManageRetreatOrderCreatPage;

public class OrderManageRetreatOrderCreatAction {

	public static void transmitDriver(WebDriver driver) throws Exception {

		OrderManageRetreatOrderCreatPage.GetDriver(driver);
	}

	// Click创建退订单，
	public static void excute_RetreatCreat_Link() throws Exception {

		OrderManageRetreatOrderCreatPage.getCreat_RetreatOrder_Link().click();
	}


  
}

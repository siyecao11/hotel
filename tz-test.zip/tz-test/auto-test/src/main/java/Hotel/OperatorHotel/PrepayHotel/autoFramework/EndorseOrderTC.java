package Hotel.OperatorHotel.PrepayHotel.autoFramework;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.testCase.*;
import Hotel.OperatorHotel.PrepayHotel.utility.Constant;

public class EndorseOrderTC extends FeedTest{

	public static WebDriver driver;
	public static String orderType;
	public static String orderId;
	
	//从正常单获取Driver
	@Test(priority = 9, groups ={"正常单变更取消流程", "正常单变更确认流程", "正常单变更后调账确认流程","正常单变更后变更确认流程","正常单变更后变更再调账确认流程"})
	public static void getNormalOrderTCDriver() throws Exception{
		
		orderType = "normal";
		driver = NormalOrderTC.driver;
	}
	
	//从调账单获取Driver
	@Test(priority = 9, groups ={"正常单调账后变更确认流程"})
	public static void getAdjustmentOrderTCDriver() throws Exception{
		
		orderType = "adjustment";
		driver = AdjustmentOrderTC.driver;
	}
	
	//从变更单获取Driver
	@Test(priority = 9, groups ={"正常单变更后再次变更流程"})
	public static void getEndorseOrderTCDriver() throws Exception{
		
		orderType = "endorse";
		driver = EndorseOrderTC.driver;
	}
	
	@Test(dataProvider = "feeder", priority = 10, groups ={"正常单变更确认流程", "正常单变更后调账确认流程","正常单变更后变更确认流程","正常单变更后变更再调账确认流程"})
	@Source("EndorseOrder_TestData.xls")
	public static void endorseOrder(String endorseCheckinDate,String endorseCheckoutDate,String endorseRoomNo) throws Exception{
		
/*		PointSearchHotel.pointSearchHotel(username, password);
		driver = PointSearchHotel.currentDriver;
		BookingHotel.searchBooking(driver, customerName, checkinDate, checkoutDate, roomNo, addPrice);
		//创建正常单
		OrderManageNormalOrder.NormalOrder_ContractInfo(name,checkinDate, addPrice, checkoutDate);*/
		
		driver.get(Constant.orderManageURL);
		Thread.sleep(2000);
		//于订单列表页查找指定ID的订单（上一步骤中创建的正常订单）
		//并跳转到订单详情页
		//判断是在哪类订单基础上做变更
		if(orderType.equals("normal")){
			
			orderId = Constant.NormalOrderId;
		}else if(orderType.equals("endorse")){
			
			orderId = Constant.EndorseOrderId;
		}else if(orderType.equals("adjustment")){
			
			orderId = Constant.adjustmentOrderId;
		}
		OrderManageEndorseOrder.orderDetail(orderId, driver);
		
		//创建变更单
		OrderManageEndorseOrder.endorseOrderCreate(endorseCheckinDate,endorseCheckoutDate,endorseRoomNo,driver);
		
		//于订单列表页查找指定ID的订单（上一步骤中创建的正常订单）
		//并跳转到订单详情页
		OrderManageEndorseOrder.orderDetail(Constant.EndorseOrderId, driver);
		//确认变更 -- 变更审核
		OrderManageEndorseOrder.endorseOrderAuditOrderCodeSettle(driver);
	}
	
	@Test(dataProvider = "feeder", priority = 10, groups ={"正常单变更取消流程"})
	@Source("EndorseOrder_TestData.xls")
	public static void endorseOrderCancle(String endorseCheckinDate,String endorseCheckoutDate,String endorseRoomNo) throws Exception{
		
		driver.get(Constant.orderManageURL);
		Thread.sleep(2000);
		//于订单列表页查找指定ID的订单（上一步骤中创建的正常订单）
		//并跳转到订单详情页
		//判断是在哪类订单基础上做变更
		if(orderType.equals("normal")){
			
			orderId = Constant.NormalOrderId;
		}else if(orderType.equals("endorse")){
			
			orderId = Constant.EndorseOrderId;
		}else if(orderType.equals("adjustment")){
			
			orderId = Constant.adjustmentOrderId;
		}
		OrderManageEndorseOrder.orderDetail(orderId, driver);
		
		//创建变更单
		OrderManageEndorseOrder.endorseOrderCreate(endorseCheckinDate,endorseCheckoutDate,endorseRoomNo,driver);
		
		//于订单列表页查找指定ID的订单（上一步骤中创建的正常订单）
		//并跳转到订单详情页
		OrderManageEndorseOrder.orderDetail(Constant.EndorseOrderId, driver);
		//取消变更
		OrderManageEndorseOrder.endorseOrderAuditOrderCancle(driver);
	}
}

package Hotel.OperatorHotel.PrepayHotel.autoFramework;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.testCase.*;
import Hotel.OperatorHotel.PrepayHotel.utility.Constant;

public class AdjustmentOrderTC extends FeedTest{

	public static WebDriver driver;
	public static String orderType;
	public static String orderId;
	//从正常单获取Driver
	@Test(priority = 9, groups ={"正常单调账取消流程","正常单调账确认流程"})
	public static void getNormalOrderTCDriver() throws Exception{
		
		orderType = "normal";
		driver = NormalOrderTC.driver;
	}
	
	//从变更单获取Driver
	@Test(priority = 9, groups ={"正常单变更后调账确认流程","正常单变更后变更再调账确认流程"})
	public static void getEndorseOrderTCDriver() throws Exception{
		
		orderType = "endorse";
		driver = EndorseOrderTC.driver;
	}
	
	//从退订单获取Driver
	@Test(priority = 9, groups ={""})
	public static void getrRetreatOrderTCDriver() throws Exception{
		
		orderType = "retreat";
		driver = RetreatOrderTC.driver;
	}

	@Test(priority = 10, groups ={"正常单调账取消流程","正常单变更后调账取消流程"})
	//@Source("AdjustmentOrder_TestData.xls")
	public static void adjustmentOrderCancle() throws Exception{	
		
		/* 如果需要在调账单的TC中单独创建一个正常单，然后在此基础上再创建调账单的话，需要单独传参	
		 * public static void adjustmentOrderCancle(String username, String password,String customerName,String checkinDate,String checkoutDate,int roomNo,String name,int addPrice) throws Exception{	
		PointSearchHotel.pointSearchHotel(username, password);
		driver = PointSearchHotel.currentDriver;
		BookingHotel.searchBooking(driver, customerName, checkinDate, checkoutDate, roomNo, addPrice);
		//创建正常单
		OrderManageNormalOrder.NormalOrder_ContractInfo(name,checkinDate, addPrice, checkoutDate);*/
		
		driver.get(Constant.orderManageURL);
		Thread.sleep(2000);
		//于订单列表页查找指定ID的订单（上一步骤中创建的正常订单）
		//并跳转到订单详情页
		//判断是在哪类订单基础上做调账
		if(orderType.equals("normal")){
			
			orderId = Constant.NormalOrderId;
		}else if(orderType.equals("endorse")){
			
			orderId = Constant.EndorseOrderId;
		}else if(orderType.equals("retreat")){
			
			orderId = Constant.RetreatOrderId;
		}
		OrderManageAdjustmentOrder.orderDetail(orderId, driver);
		
		//调账单 --创建 调账单 Case
		OrderManageAdjustmentOrder.adjustmentOrderCreateOrder(driver);
		
		//于订单列表页查找指定ID的订单（上一步骤中创建的调账订单）
		//并跳转到订单详情页
		OrderManageAdjustmentOrder.orderDetail(Constant.adjustmentOrderId, driver);
		
		// 调账单 -- 取消调账
		OrderManageAdjustmentOrder.adjustmentOrderAuditOrderCancle(driver);
		
	}
	
	@Test(priority = 11, groups ={"正常单调账确认流程","正常单变更后调账确认流程","正常单变更后变更再调账确认流程"})
	//@Source("AdjustmentOrder_TestData.xls")
	public static void adjustmentOrder() throws Exception{	
		
		driver.get(Constant.orderManageURL);
		Thread.sleep(2000);
		//于订单列表页查找指定ID的订单（上一步骤中创建的正常订单）
		//并跳转到订单详情页
		//判断是在哪类订单基础上做调账
		if(orderType.equals("normal")){
			
			orderId = Constant.NormalOrderId;
		}else if(orderType.equals("endorse")){
			
			orderId = Constant.EndorseOrderId;
		}else if(orderType.equals("retreat")){
			
			orderId = Constant.RetreatOrderId;
		}
		OrderManageAdjustmentOrder.orderDetail(orderId, driver);
		//调账单 --创建 调账单 Case
		OrderManageAdjustmentOrder.adjustmentOrderCreateOrder(driver);
		//于订单列表页查找指定ID的订单（上一步骤中创建的调账订单）
		//并跳转到订单详情页
		OrderManageAdjustmentOrder.orderDetail(Constant.adjustmentOrderId, driver);
		// 调账单 --审核 调账单 Case
		OrderManageAdjustmentOrder.adjustmentOrderAuditOrder();
		// 确认调账 -- 调账审核：酒店确认码&&结算提醒设置
		OrderManageAdjustmentOrder.adjustmentOrderAuditOrderCodeSettle();
		
	}
	
}

package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.pageObjects.*;
import Hotel.OperatorHotel.PrepayHotel.utility.Log;


public class HotelMaintainHomeAction {
	
	public static WebDriver currentDriver;
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		currentDriver = driver;
		HotelMaintainHomePage.getWebDriver(driver);
	}
	
	@Test
	public static void executeAddHotel() throws Exception{
		
		//click addHotel button, goto hotelInfo edit page
		HotelMaintainHomePage.getAddHotelButton().click();
		Log.info("AddHotel button is clicked, now enter into hotelInfo added page");
	}
	
	@Test
	public static void executeSearchHotel() throws Exception{
		
		//click SearchHotel button, goto hotelInfo edit page
		HotelMaintainHomePage.getSearchHotelButton().click();
		Log.info("SearchHotel button is clicked, now enter into hotelInfo added page");
	}
	
	@Test
	public static void executeSelectHotelIndex() throws Exception{
		
		//Select hotel, goto hotelInfo edit page
		HotelMaintainHomePage.getAddHotelIndex().click();
		Log.info("hotel is selected, now enter into hotelInfo added page");
	}
	
	@Test
	public static void excuteHotelNameTextBox(String hotelName) throws Exception{
		
		//input hotel name, select hotel
		HotelMaintainHomePage.getHotelNameTextBoxElement().clear();
		HotelMaintainHomePage.getHotelNameTextBoxElement().sendKeys(hotelName);
		Log.info("hotel name is inputed, ready to search hotel");
	}
	
	@Test
	public static void excuteHotelCheckBox() throws Exception{
		
		//input hotel name, select hotel
		HotelMaintainHomePage.getCheckBoxElement().click();
		Log.info("hotel checkbox is selected");
	}
	
	@Test
	public static void excuteJieguaButton() throws Exception{
		
		//input hotel name, select hotel
		HotelMaintainHomePage.getJieguaElement().click();
		Log.info("jiegua button is clicked");
	}
	
	@Test
	public static void excuteGuaqiButton() throws Exception{
		
		//input hotel name, select hotel
		HotelMaintainHomePage.getGuaqiElement().click();
		Log.info("Guaqi button is clicked");
	}
	
	@Test
	public static void excuteGuaqiConfirmBtn() throws Exception{
		
		//确认 挂起 操作
		//HotelMaintainHomePage.getGuaqiConformBtnElement().click();
		JavascriptExecutor js = (JavascriptExecutor) currentDriver;
		js.executeScript("arguments[0].click();",HotelMaintainHomePage.getGuaqiConformBtnElement());
	}
	
	@Test
	public static void excuteGuaqiCancleBtn() throws Exception{
		
		//取消 挂起 操作
		HotelMaintainHomePage.getGuaqiCancleBtnElement().click();
	}
	
	@Test
	public static void excuteJieguaConfirmBtn() throws Exception{
		
		//确认 解挂 操作
		HotelMaintainHomePage.getJieguaConformBtnElement().click();
	}
	
	@Test
	public static void excuteJieguaCancleBtn() throws Exception{
		
		//取消 解挂 操作
		HotelMaintainHomePage.getJieguaCancleBtnElement().click();
	}
}

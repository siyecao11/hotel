package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Hotel.OperatorHotel.OperatorLogin.utility.Log;

public class SpotPaymentCreateOrderPage
{
	public static WebElement element;
	private static WebDriver driver;
	public static void getDriver(WebDriver webdriver)  throws Exception{
		driver = webdriver;
	}
	//住房客人人数
	public static WebElement getRoomNum() throws Exception{
		try{
			element = driver.findElement(By.id("roomNumber"));
		}catch (Exception e){
			Log.error("RoomNum is not found in the SpotPaymentOrder Page.");
		}
		return element;
	}
	//住房客人中文名称
	public static WebElement getCustomerCname() throws Exception{
		try{
			element = driver.findElement(By.id("name1"));
		}catch (Exception e){
			Log.error("Customername is not found in the SpotPaymentOrder Page.");
		}
		return element;
	}
	//住房客人英文名称
	public static WebElement getCustomerEname() throws Exception{
		try{
			element = driver.findElement(By.id("name2"));
		}catch (Exception e){
			Log.error("Customername is not found in the SpotPaymentOrder Page.");
		}
		return element;
	}
	//酒店备注：尽量大床
	public static WebElement getQueenBed() throws Exception{
		try{
			element = driver.findElement(By.id("purchaseRemark1"));
		}catch (Exception e){
			Log.error("QueenBed is not found in the SpotPaymentOrder Page.");
		}
		return element;
	}
	
	//酒店备注：尽量双床
		public static WebElement getTwinBeds() throws Exception{
			try{
				element = driver.findElement(By.id("purchaseRemark2"));
			}catch (Exception e){
				Log.error("TwinBeds is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}
	//酒店备注：尽量无烟
		public static WebElement getNoSmoke() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='RemarkCheckbox']/label[3]/input"));
			}catch (Exception e){
				Log.error("NoSmoke is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}
		
	//酒店备注：尽量高楼层
		public static WebElement getHighRise() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='RemarkCheckbox']/label[4]/input"));
			}catch (Exception e){
				Log.error("HighRise is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}
	//酒店备注：尽量相邻
		public static WebElement getAdjacent() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='RemarkCheckbox']/label[5]/input"));
			}catch (Exception e){
				Log.error("Adjacent is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}
			
	//酒店备注：尽量原房续住
		public static WebElement getContinue() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='RemarkCheckbox']/label[6]/input"));
			}catch (Exception e){
				Log.error("Adjacent is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}
	//到店时间：23:00 前
		public static WebElement getArriveTime() throws Exception{
			try{
				element = driver.findElement(By.id("startName1"));
			}catch (Exception e){
				Log.error("ArriveTime is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}
		
		//到店时间：23:00 后
		public static WebElement getArriveTimes() throws Exception{
			try{
				element = driver.findElement(By.id("startName2"));
			}catch (Exception e){
				Log.error("ArriveTime is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}
		//确认方式
		public static WebElement getConfrimType() throws Exception{
			try{
				element = driver.findElement(By.id("confirmType"));
			}catch (Exception e){
				Log.error("ConfrimType is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}
	//联系人姓名输入框
		public static WebElement getContactName() throws Exception{
			try{
				element = driver.findElement(By.id("contactName"));
			}catch (Exception e){
				Log.error("ContactName is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}	
	//手机号码输入框
		public static WebElement getMobileNum() throws Exception{
			try{
				element = driver.findElement(By.id("mobileno"));
			}catch (Exception e){
				Log.error("MobileNum is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}	
	//固定电话输入框
		public static WebElement getTelephoneNum() throws Exception{
			try{
				element = driver.findElement(By.id("telephone"));
			}catch (Exception e){
				Log.error("TelephoneNum is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}	
	
	//email输入框
		public static WebElement getEmail() throws Exception{
			try{
				element = driver.findElement(By.id("email"));
			}catch (Exception e){
				Log.error("Email is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}		
	//创建订单按钮
		public static WebElement getCreateOrderButton() throws Exception{
			try{
				element = driver.findElement(By.id("selfHotelOrder"));
			}catch (Exception e){
				Log.error("CreateOrderButton is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}		
	//获取订单号
		public static WebElement getOrderId() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[2]/div/div[2]/p[1]/a"));
			}catch (Exception e){
				Log.error("OrderId is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}		
		
	//订单列表按钮
		public static WebElement getOrderList() throws Exception{
			try{
				element = driver.findElement(By.id("top_menu_1_submenu_2"));
			}catch (Exception e){
				Log.error("OrderList is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}	
	//现付酒店订单标签
		
		public static WebElement getSpotPaymentOrder() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='orderForm']/div[1]/div[1]/a[2]"));
			}catch (Exception e){
				Log.error("SpotPaymentOrder is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}	
	//订单号输入框
		
		public static WebElement getOrderNum() throws Exception{
			try{
				element = driver.findElement(By.id("orderNo"));
			}catch (Exception e){
				Log.error("OrderNum is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}	
		
	//查询按钮
		public static WebElement getOrderSearch() throws Exception{
			try{
				element = driver.findElement(By.id("orderFormSubmit"));
			}catch (Exception e){
				Log.error("OrderSearch is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}	
	//
	//订单号
		public static WebElement getOrderNumber() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div[1]/table/tbody/tr/td[4]/a"));
			}catch (Exception e){
				Log.error("OrderNumber is not found in the SpotPaymentOrder Page.");
			}
			return element;
		}	
		
	//客户姓名
		public static WebElement getCustomerName() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[3]/table/tbody/tr[2]/td[2]"));
			}catch(Exception e){
				Log.error("CustomerName is not found in the SpotPaymentOrder Page");
			}
			return element;
		}
	//入住时间
		public static WebElement getCheckinTime() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[6]/div[2]/table/tbody/tr[4]/td[2]"));
			}catch(Exception e){
				Log.error("CheckinTime is not found in the SpotPaymentOrder Page");
			}
			return element;
		}
	//离店时间
		public static WebElement getCheckoutTime() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[6]/div[2]/table/tbody/tr[4]/td[4]"));
			}catch(Exception e){
				Log.error("CheckoutTime is not found in the SpotPaymentOrder Page");
			}
			return element;
		}
	//酒店名称
		public static WebElement getHotelName() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[6]/div[2]/table/tbody/tr[1]/td[6]"));
			}catch(Exception e){
				Log.error("HotelName is not found in the SpotPaymentOrder Page");
			}
			return element;
		}
	//旅客名称
		public static WebElement getCustomersName() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[9]/table/tbody/tr/td[3]"));
			}catch(Exception e){
				Log.error("CustomersName is not found in the SpotPaymentOrder Page");
			}
			return element;
		}
	//联系人姓名
		public static WebElement getcontactName() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[10]/table/tbody/tr/td[1]"));
			}catch(Exception e){
				Log.error("ContactName is not found in the SpotPaymentOrder Page");
			}
			return element;
		}
	//联系人手机
		public static WebElement getMobilePhone() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[10]/table/tbody/tr/td[2]"));
			}catch(Exception e){
				Log.error("MobilePhone is not found in the SpotPaymentOrder Page");
			}
			return element;
		}
	//联系人电话
		public static WebElement getTelePhone() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[10]/table/tbody/tr/td[3]"));
			}catch(Exception e){
				Log.error("TelePhone is not found in the SpotPaymentOrder Page");
			}
			return element;
		}
	//联系人邮箱
		public static WebElement getemail() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[10]/table/tbody/tr/td[5]"));
			}catch(Exception e){
				Log.error("Email is not found in the SpotPaymentOrder Page");
			}
			return element;
		}
		
		
		
		
		
		
		
}

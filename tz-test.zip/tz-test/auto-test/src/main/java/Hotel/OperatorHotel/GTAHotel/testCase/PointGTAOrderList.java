package Hotel.OperatorHotel.GTAHotel.testCase;

import org.openqa.selenium.WebDriver;

import Hotel.OperatorHotel.GTAHotel.appModules.OrderManageOrderListAction;
import Hotel.OperatorHotel.OperatorLogin.testCase.LoginTC;
import Hotel.OperatorHotel.OperatorLogin.utility.Utils;
import Hotel.OperatorHotel.PrepayHotel.appModules.HotelHomeAction;
import Hotel.OperatorHotel.GTAHotel.utility.Constant;

public class PointGTAOrderList {

	public static WebDriver currentDriver;
	
	public static void pointSearchHotel(String username, String password) throws Exception {
		//Login system
		LoginTC.login(username, password);
		
		//fetch WebDriver
		currentDriver = LoginTC.driver;
		
		//location hotel Search page
		Utils.waitForElement(5, currentDriver, "page");
		HotelHomeAction.transmitDriver(currentDriver);
		//currentDriver.get(Constant.hotelMaintainURL);
		HotelHomeAction.excuteOrderManage();
		
		currentDriver.get(Constant.gtaHotelOrderManageURL);
		//goto prepay hotel search page
		Utils.waitForElement(5, currentDriver, "page");
		OrderManageOrderListAction.transmitDriver(currentDriver);
		
	}
}

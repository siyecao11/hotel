package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import java.sql.Array;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class OrderManageRetreatOrderPage {

	public static WebDriver driver;
	private static WebElement element;
	private static List<WebElement> elementList;
	private static List<Select> selectList;
	private static Select oSelection;
	private static List<WebElement> chkBx_PeriodTime;

	// private static List<Select> selectNumList;

	@Test
	public static void getWebDriver(WebDriver webdriver) {

		driver = webdriver;

	}

	// **********获取弹窗选择退订信息**************
	// 获取酒店创建退订单页面元素
	@Test
	public static WebElement getView_RetreatOrder_Link() throws Exception {

		// getConfirmBooking_Link().click();
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='operator_view_refund_order']/span[2]"));
			Log.info(element
					+ " Creat_RetreatOrder_Link element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error(element
					+ " Creat_RetreatOrder_Link element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

	// ***************获取退订提示页面，扣除全部房费、首晚房费、全退、调前离店*****************
	// 获取扣除全部房费页面元素
	@Test
	public static WebElement getRetreat_CHANGEALL() throws Exception {

		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='refundWindow']/table/tbody/tr[1]/td[1]/label/input"));
			Log.info(element.getAttribute("value")
					+ " AddRate element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error("AddRate element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

	// 获取扣除首晚房费页面元素
	@Test
	public static WebElement getRetreat_CHANGEFIRST() throws Exception {

		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='refundWindow']/table/tbody/tr[2]/td[1]/label/input"));
			Log.info(element.getAttribute("value")
					+ " AddRate element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error("AddRate element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

	// 获取扣除全部房费页面元素
	@Test
	public static WebElement getRetreat_CHANGENONE() throws Exception {

		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='refundWindow']/table/tbody/tr[3]/td[1]/label/input"));
			Log.info(element.getAttribute("value")
					+ " AddRate element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error("AddRate element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

	// 获取提前离店页面元素
	@Test
	public static WebElement getRetreat_EARLYCHECKOUT() throws Exception {

		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='refundWindow']/table/tbody/tr[4]/td[1]/label/input"));
			Log.info(element.getAttribute("value")
					+ " AddRate element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error("AddRate element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

	// 获取提前离店的离店时间页面元素
	@Test
	public static List<WebElement> getRetreat_EARLYCHECKOUT_RefundDate()
			throws Exception {

		try {
			try {
				element = driver.findElement(By.xpath(".//*[@id='tqld']"));

				Log.info(" EARLYCHECKOUT_RefundDate element is found in Retreat_Save Page");
			} catch (Exception e) {
				Log.error("EARLYCHECKOUT_RefundDate element is not found in OrderManage_RetreatOrder Page");
			}
			elementList = element.findElements(By.tagName("input"));
			Log.info(elementList
					+ " EARLYCHECKOUT_RefundDate elements is found in Retreat_Save Page");
		} catch (Exception e) {
			Log.error("EARLYCHECKOUT_RefundDate elements is not found in OrderManage_RetreatOrder Page");
		}
		return elementList;
	}

	// 获取保存退订条件页面元素
	@Test
	public static WebElement getRetreat_Save() throws Exception {

		try {
			element = driver.findElement(By.id("refund_save"));
			Log.info(element
					+ " Retreat_Save element is found in Retreat_Save Page");
		} catch (Exception e) {
			Log.error("Retreat_Save element is not found in Retreat_Save Page");
		}
		return element;
	}

	// ********************创建退订单*********************
	// 获取酒店创建退订单页面元素
	@Test
	public static WebElement getCreat_RetreatOrder_Link() throws Exception {

		// getConfirmBooking_Link().click();
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='operator_create_refund_order']/span[2]"));
			Log.info(" Creat_RetreatOrder_Link element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error(" Creat_RetreatOrder_Link element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

	// *********************获取确认退订单页面元素***********************
	//
	@Test
	public static WebElement getConfirm_RetreatOrder_Link() throws Exception {

		// getConfirmBooking_Link().click();
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='operator_confirm_refund_order']/span[2]"));
			Log.info(" Creat_RetreatOrder_Link element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error(" Creat_RetreatOrder_Link element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}

	// 获取订单审核页面元素，有酒店确认码
	@Test
	public static List<WebElement> getConfirmBooking_ConfirmID1()
			throws Exception {

		try {
			try {
				element = driver.findElement(By
						.xpath(".//*[@id='confirmBookingPopWin']/div[1]"));
				Log.info(element
						+ " Confirm_Order element is found in OrderManage_RetreatOrder Page");
			} catch (Exception e) {
				Log.error("Confirm_Order element is not found in OrderManage_RetreatOrder Page");
			}
			elementList = element.findElements(By.tagName("input"));
			Log.info("Confirm_Order elements is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error("Confirm_Order elements is not found in OrderManage_RetreatOrder Page");
		}
		return elementList;
	}
	//获取酒店确认预订页面元素
	@Test
	public static WebElement getConfirmBooking_Link() throws Exception{
		
			//getConfirmBooking_Link().click();
		try{
			element = driver.findElement(By.xpath(".//*[@id='operator_confirm_refund_order']/span[2]"));
		Log.info(element+" ConfirmBooking_Link element is found in OrderManage_RetreatOrder Page");
		}catch (Exception e){
			Log.error(element+" ConfirmBooking_Link element is not found in OrderManage_RetreatOrder Page");
		}			
		return element;
	}
	// 获取订单审核页面元素，有酒店确认码
	@Test
	public static WebElement getConfirmBooking_ConfirmID2() throws Exception {

		try {

			element = driver
					.findElement(By
							.xpath(".//*[@id='confirmBookingPopWin']/div[2]/label/input"));
			Log.info("Confirm_Order element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("Confirm_Order element is not found in OrderManage_RetreatOrder Page");
		}

		return element;
	}

	// 获取保存确认预订页面元素
	@Test
	public static WebElement getConfirmBooking_Save() throws Exception {

		try {
			element = driver.findElement(By.id("confirmBooking_save"));
			Log.info("ConfirmBooking_Save element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error("ConfirmBooking_Save element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}
	//***************获取修改结算提醒页面，弹出结算提醒窗口*****************
	//获取现结页面元素
	//获取订单审核页面元素，有酒店确认码
	@Test
	public static List<WebElement> getCount_NOW_SETTLE() throws Exception{
		
		try{
			try{
			element = driver.findElement(By.xpath(".//*[@id='checkoutContainer']/div[1]"));
			Log.info(element+" Confirm_Order element is found in OrderManage_RetreatOrder Page");
		}catch (Exception e){
			Log.error("Confirm_Order element is not found in OrderManage_RetreatOrder Page");
		}	
			elementList = element.findElements(By.tagName("input"));
			Log.info("Confirm_Order elements is found in OrderManage_RetreatOrder Page");
		}catch (Exception e){
			Log.error("Confirm_Order elements is not found in OrderManage_RetreatOrder Page");
		}	
		return elementList;
	}
	
	//获取周结页面元素
	@Test
	public static WebElement getCount_WEEK_SETTLE() throws Exception{
				
		try{
			element = driver.findElement(By.xpath(".//*[@id='checkoutContainer']/div[2]/label[1]/input"));
			Log.info(element.getAttribute("value")+" AddRate element is found in OrderManage_RetreatOrder Page");
		}catch (Exception e){
			Log.error("AddRate element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}
		
	
	//获取半月结页面元素
	@Test
	public static WebElement getCount_HALF_MONTH_SETTLE() throws Exception{
				
		try{
			element = driver.findElement(By.xpath(".//*[@id='checkoutContainer']/div[2]/label[2]/input"));
			Log.info(element.getAttribute("value")+" AddRate element is found in Order_AuditOrder_Page");
		}catch (Exception e){
			Log.error("AddRate element is not found in Order_AuditOrder_Page");
		}
		return element;
	}
		
	
	//获取月结页面元素
	@Test
	public static WebElement getCount_MONTH_SETTLE() throws Exception{
				
		try{
			element = driver.findElement(By.xpath(".//*[@id='checkoutContainer']/div[2]/label[3]/input"));
			Log.info(element.getAttribute("value")+" AddRate element is found in Order_AuditOrder_Page");
		}catch (Exception e){
			Log.error("AddRate element is not found in Order_AuditOrder_Page");
		}
		return element;
	}
		
	
	//获取保存确认预订页面元素
	@Test
	public static WebElement getCount_Save() throws Exception{
				
		try{
			element = driver.findElement(By.id("saveSettle"));
			Log.info("CountReminder element is found in Order_AuditOrder_Page");
		}catch (Exception e){
			Log.error("CountReminder element is not found in Order_AuditOrder_Page");
		}
		return element;
	}
	
	
	
}

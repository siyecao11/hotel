/*
 * 酒店维护/新建酒店/供应商信息页面
 * 王琪琪
 * 2015/08/10
 * */

package Hotel.OperatorHotel.PrepayHotel.appModules;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.OperatorLogin.utility.Log;
import Hotel.OperatorHotel.PrepayHotel.pageObjects.EditHotelMaintainProviderMessage;
import Hotel.OperatorHotel.PrepayHotel.pageObjects.HotelMaintainProviderMessagePage;
import Hotel.OperatorHotel.PrepayHotel.utility.Assertion;
import Hotel.OperatorHotel.PrepayHotel.utility.ExcelAction;


public class HotelMaintainProviderMessageAction {
	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	public static String option;
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		HotelMaintainProviderMessagePage.getDriver(driver);
		EditHotelMaintainProviderMessage.getDriver(driver);
	}
	//编辑合同按钮
	@Test
	public static void EditContract() throws Exception{
		HotelMaintainProviderMessagePage.EditContract().click();
		Log.info("***************EditContract has clicked***************");
	}
	//合同起始时间
	@Test
	public static void SetContractStartTime(String beginTime) throws Exception{
		HotelMaintainProviderMessagePage.ContractStartTime().clear();
		HotelMaintainProviderMessagePage.ContractStartTime().sendKeys(beginTime);
		Log.info("***************SetContractStartTime has writed***************");
	}
	
	//合同结束时间
	@Test
	public static void SetContractEndTime(String endTime) throws Exception{
		HotelMaintainProviderMessagePage.ContractEndTime().clear();
		HotelMaintainProviderMessagePage.ContractEndTime().sendKeys(endTime);
		Log.info("***************SetContractEndTime has writed***************");
	}
	
	//到期前提醒时间设置
	@Test
	public static void RemindTime(String RemindTime) throws Exception{
		Select remindtime = new Select(HotelMaintainProviderMessagePage.RemindTime());
		remindtime.selectByVisibleText(RemindTime);
		Log.info("***************RemindTime has selected***************");
	}
    //供应商类型选择
	@Test
	public static void Supplier(String Supplier) throws Exception{
		Select remindtime = new Select(HotelMaintainProviderMessagePage.Supplier());
		remindtime.selectByVisibleText(Supplier);
		Log.info("***************Supplier has selected***************");
	}
	//供应商类型名称
	@Test
	public static void SupplierName(String SupplierName) throws Exception{
		HotelMaintainProviderMessagePage.SupplierName().sendKeys(SupplierName);
		Log.info("***************SupplierName has writed***************");
	}
    //=供应商类型备注
	@Test
	public static void SupplierRemark(String SupplierRemark) throws Exception{
		HotelMaintainProviderMessagePage.SupplierRemark().sendKeys(SupplierRemark);
		Log.info("***************SupplierRemark has writed***************");
	}
	
    //供应商实体选择
	@Test
	public static void SupplierEntity(String SupplierEntity) throws Exception{
		Select remindtime = new Select(HotelMaintainProviderMessagePage.SupplierEntity());
		remindtime.selectByVisibleText(SupplierEntity);
		Log.info("***************SupplierEntity has selected***************");
	}
	//供应商实体结算提醒选择
	@Test
	public static void SupplierSettlePeriod(String SupplierSettlePeriod) throws Exception{
		Select remindtime = new Select(HotelMaintainProviderMessagePage.SupplierSettlePeriod());
		remindtime.selectByVisibleText(SupplierSettlePeriod);
		Log.info("***************SupplierSettlePeriod has selected***************");
	}
	//收款账户名
	@Test
	public static void AccountName(String AccountName) throws Exception{
		HotelMaintainProviderMessagePage.AccountName().sendKeys(AccountName);
		Log.info("***************AccountName has writed***************");
	}
    //开户银行
	@Test
	public static void BankName(String BankName) throws Exception{
		HotelMaintainProviderMessagePage.BankName().sendKeys(BankName);
		Log.info("***************BankName has writed***************");
	}
	//银行卡号
	@Test
	public static void BankNumber(String BankNumber) throws Exception{
		HotelMaintainProviderMessagePage.BankNumber().sendKeys(BankNumber);
		Log.info("***************BankNumber has writed***************");
	}
	//保存合同信息
	@Test
	public static void SaveContract() throws Exception{
		HotelMaintainProviderMessagePage.SaveContract().click();
		Log.info("***************SaveContract has clicked***************");
	}
	
	//联系人添加
/*****************************************************************************************************/	
	
	//点击添加联系人
	@Test
	public static void AddContact() throws Exception{
		HotelMaintainProviderMessagePage.AddContact().click();
		Log.info("***************AddContact has clicked***************");
	}
	//联系人姓名
	@Test
	public static void ContactName(String ContactName) throws Exception{
		HotelMaintainProviderMessagePage.ContactName().sendKeys(ContactName);
		Log.info("***************ContactName has writed***************");
	}
	//手机
	@Test
	public static void ContactMobilephone(String ContactMobilephone) throws Exception{
		HotelMaintainProviderMessagePage.ContactMobilephone().sendKeys(ContactMobilephone);
		Log.info("***************ContactMobilephone has writed***************");
	}
	
	//传真
	@Test
	public static void ContactFox(String ContactFox) throws Exception{
		HotelMaintainProviderMessagePage.ContactFox().sendKeys(ContactFox);
		Log.info("***************ContactFox has writed***************");
	}
	
	//座机
	@Test
	public static void ContactOfficePhone(String ContactOfficePhone) throws Exception{
		HotelMaintainProviderMessagePage.ContactOfficePhone().sendKeys(ContactOfficePhone);
		Log.info("***************ContactOfficePhone has writed***************");
	}
	//电子邮箱
	@Test
	public static void ContactEmail(String ContactEmail) throws Exception{
		HotelMaintainProviderMessagePage.ContactEmail().sendKeys(ContactEmail);
		Log.info("***************ContactEmail has writed***************");
	}
	
	//传真接收时间开始时间
	@Test
	public static void WorkingHoursBegin(String WorkingHoursBegin) throws Exception{
		HotelMaintainProviderMessagePage.WorkingHoursBegin().clear();
		HotelMaintainProviderMessagePage.WorkingHoursBegin().sendKeys(WorkingHoursBegin);
		Log.info("***************WorkingHoursBegin has writed***************");
	}
	//传真接收时间结束时间
	@Test
	public static void WorkingHoursEnd(String WorkingHoursEnd) throws Exception{
		HotelMaintainProviderMessagePage.WorkingHoursEnd().clear();
		HotelMaintainProviderMessagePage.WorkingHoursEnd().sendKeys(WorkingHoursEnd);
		Log.info("***************WorkingHoursEnd has writed***************");
	}
	//部门选择
	@Test
	public static void Dept(String Dept) throws Exception{
		Select dept = new Select(HotelMaintainProviderMessagePage.Dept());
		dept.selectByVisibleText(Dept);
		Log.info("***************Dept has selected***************");
	}
	//备注填写ע
	@Test
	public static void ContactRemark(String ContactRemark) throws Exception{
		HotelMaintainProviderMessagePage.ContactRemark().sendKeys(ContactRemark);
		Log.info("***************ContactRemark has writed***************");
	}
	//保存联系人
	@Test
	public static void SaveContact() throws Exception{
		HotelMaintainProviderMessagePage.SaveContact().click();;
		Log.info("***************SaveContact has clicked***************");
	}
	//跳转酒店房型页面
	@Test
	public static void HotelHomeStyle() throws Exception{
		HotelMaintainProviderMessagePage.HotelHomeStyle().click();;
		Log.info("***************HotelHomeStyle has clicked***************");
	}
	
	

	/********************************************************************************************/
	//添加供应商基本信息页面的断言
	//点击编辑合同按钮
	//编辑合同按钮
		@Test
		public static void assertEditContract() throws Exception{
			EditHotelMaintainProviderMessage.editContact().click();
			Log.info("***************EditContract has clicked***************");
		}
		
		//比较合同起始时间一致性
		@Test
		public static void assertSetContractStartTime() throws Exception{
			String pageStartTime = EditHotelMaintainProviderMessage.editContractStartTime().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "beginTime", pageStartTime);
			String StartTime = ExcelAction.getValue("AddHotel_TestData.xls", "beginTime");
			Assertion.verifyEquals(pageStartTime, StartTime,"ContractStartTime is right");
		}
		
		//比较合同结束时间一致性
		@Test
		public static void assertSetContractEndTime() throws Exception{
			String pageEndTime = EditHotelMaintainProviderMessage.editContractEndTime().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "endTime", pageEndTime);
			String endTime = ExcelAction.getValue("AddHotel_TestData.xls", "endTime");
			Assertion.verifyEquals(pageEndTime, endTime, "ContractEndTime is right");
		}
		
		//比较到期前提醒时间设置一致性
		@Test
		public static void assertRemindTime() throws Exception{
			String pageRemindTime = EditHotelMaintainProviderMessage.editRemindTime().getText();
			ExcelAction.setValue("ActualValue.xls", "RemindTime", pageRemindTime);
			String remindTime = ExcelAction.getValue("AddHotel_TestData.xls", "RemindTime");
			Assertion.verifyEquals(pageRemindTime, remindTime, "RemindTime is right");
		}
	    //比较供应商类型选择一致性
		@Test
		public static void assertSupplier() throws Exception{
			WebElement supplier = EditHotelMaintainProviderMessage.editSupplier();
			Select oselect = new Select(supplier);
			String supplierValue = supplier.getAttribute("defaultvalue");
			elements = oselect.getOptions();
			int listNumber = elements.size();
			for(int i=0;i<listNumber;i++)
			{
				if(oselect.getOptions().get(i).getAttribute("value").equals(supplierValue)){
					option = oselect.getOptions().get(i).getText();
					break;
				}
			}
			ExcelAction.setValue("ActualValue.xls", "supplier", option);
			String remindTime = ExcelAction.getValue("AddHotel_TestData.xls", "supplier");
			Assertion.verifyEquals(option, remindTime, "Supplier is right");
		}
		//比较供应商类型名称一致性
		@Test
		public static void assertSupplierName() throws Exception{
			String pageSupplierName = EditHotelMaintainProviderMessage.editSupplierName().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "supplierName", pageSupplierName);
			String supplierName = ExcelAction.getValue("AddHotel_TestData.xls", "supplierName");
			Assertion.verifyEquals(pageSupplierName, supplierName, "SupplierName is right");
		}
	    //比较供应商类型备注一致性
		@Test
		public static void assertSupplierRemark() throws Exception{
			String pageSupplierRemark = EditHotelMaintainProviderMessage.editSupplierRemark().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "supplierRemark", pageSupplierRemark);
			String supplierRemark = ExcelAction.getValue("AddHotel_TestData.xls", "supplierRemark");
			Assertion.verifyEquals(pageSupplierRemark, supplierRemark, "SupplierRemark is right");
		}
		
	    //比较供应商实体选择一致性
		@Test
		public static void assertSupplierEntity() throws Exception{
			WebElement pageSupplierEntity = EditHotelMaintainProviderMessage.editSupplierEntity();
			Select oselect = new Select(pageSupplierEntity);
			String supplier = pageSupplierEntity.getAttribute("defaultvalue");
			System.out.println(supplier);
			elements = oselect.getOptions();
			int listNumber = elements.size();
			System.out.println(listNumber);
			for(int i=0;i<listNumber;i++)
			{
				if(oselect.getOptions().get(i).getAttribute("value").equals(supplier)){
					option = oselect.getOptions().get(i).getText();
					System.out.println(option);
					break;
				}
			}
			ExcelAction.setValue("ActualValue.xls", "supplierEntity", option);
			String supplierEntity = ExcelAction.getValue("AddHotel_TestData.xls", "supplierEntity");
			Assertion.verifyEquals(option, supplierEntity, "SupplierEntity is right");
		}
		//比较收款账户名一致性
		@Test
		public static void assertAccountName() throws Exception{
			String pageAccountName = EditHotelMaintainProviderMessage.editAccountName().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "sccountName", pageAccountName);
			String accountName = ExcelAction.getValue("AddHotel_TestData.xls", "sccountName");
			Assertion.verifyEquals(pageAccountName, accountName, "AccountName is right");
		}
	    //比较开户银行一致性
		@Test
		public static void assertBankName() throws Exception{
			String pageBankName = EditHotelMaintainProviderMessage.editBankName().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "bankName", pageBankName);
			String bankName = ExcelAction.getValue("AddHotel_TestData.xls", "bankName");
			Assertion.verifyEquals(pageBankName, bankName, "BankName is right");
		}
		//比较银行卡号一致性
		@Test
		public static void assertBankNumber() throws Exception{
			String pageBankNumber = EditHotelMaintainProviderMessage.editBankNumber().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "bankNumber", pageBankNumber);
			String bankNumber = ExcelAction.getValue("AddHotel_TestData.xls", "bankNumber");
			Assertion.verifyEquals(pageBankNumber, bankNumber, "BankNumber is right");
		}
		//保存合同信息
		@Test
		public static void assertSaveContract() throws Exception{
			EditHotelMaintainProviderMessage.editSaveContact().click();
			Log.info("***************SaveContract has clicked***************");
		}
		
		//联系人信息验证
	/*****************************************************************************************************/	
		
		//点击添加联系人
		@Test
		public static void assertAddContact() throws Exception{
			HotelMaintainProviderMessagePage.EditContact().click();
			Log.info("***************EditContact has clicked***************");
		}
		//比较联系人姓名一致性
		@Test
		public static void assertContactName() throws Exception{
			String pageContactName = EditHotelMaintainProviderMessage.editContactName().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "contactName", pageContactName);
			String contactName = ExcelAction.getValue("AddHotel_TestData.xls", "contactName");
			Assertion.verifyEquals(pageContactName, contactName, "ContactName is right");
		}
		//比较手机号码一致性
		@Test
		public static void assertContactMobilephone() throws Exception{
			String pageContactMobilephone = EditHotelMaintainProviderMessage.editContactMobilephone().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "contactMobilephone", pageContactMobilephone);
			String contactName = ExcelAction.getValue("AddHotel_TestData.xls", "contactMobilephone");
			Assertion.verifyEquals(pageContactMobilephone, contactName, "ContactMobilephone is right");
		}
		
		//比较传真号码一致性
		@Test
		public static void assertContactFox() throws Exception{
			String pageContactFox = EditHotelMaintainProviderMessage.editContactFox().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "contactFox", pageContactFox);
			String contactFox = ExcelAction.getValue("AddHotel_TestData.xls", "contactFox");
			Assertion.verifyEquals(pageContactFox, contactFox, "ContactFox is right");
		}
		
		//比较座机号码一致性
		@Test
		public static void assertContactOfficePhone() throws Exception{
			String pageContactOfficePhone = EditHotelMaintainProviderMessage.editContactOfficePhone().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "contactOfficePhone", pageContactOfficePhone);
			String contactOfficePhone = ExcelAction.getValue("AddHotel_TestData.xls", "contactOfficePhone");
			Assertion.verifyEquals(pageContactOfficePhone, contactOfficePhone, "ContactOfficePhone is right");
		}
		//比较电子邮箱号码一致性
		@Test
		public static void assertContactEmail() throws Exception{
			String pageContactEmail = EditHotelMaintainProviderMessage.editContactEmail().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "contactEmail", pageContactEmail);
			String contactEmail = ExcelAction.getValue("AddHotel_TestData.xls", "contactEmail");
			Assertion.verifyEquals(pageContactEmail, contactEmail, "ContactEmail is right");
		}
		
		//比较传真接收时间开始时间一致性
		@Test
		public static void assertWorkingHoursBegin() throws Exception{
			String pageWorkingHoursBegin = EditHotelMaintainProviderMessage.editWorkingHoursBegin().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "workingHoursBegin", pageWorkingHoursBegin);
			String workingHoursBegin = ExcelAction.getValue("AddHotel_TestData.xls", "workingHoursBegin");
			Assertion.verifyEquals(pageWorkingHoursBegin, workingHoursBegin, "WorkingHoursBegin is right");
		}
		//比较传真接收时间结束时间一致性
		@Test
		public static void assertWorkingHoursEnd() throws Exception{
			String pageWorkingHoursEnd = EditHotelMaintainProviderMessage.editWorkingHoursEnd().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "workingHoursEnd", pageWorkingHoursEnd);
			String workingHoursEnd = ExcelAction.getValue("AddHotel_TestData.xls", "workingHoursEnd");
			Assertion.verifyEquals(pageWorkingHoursEnd, workingHoursEnd, "WorkingHoursEnd is right");
		}
		//比较部门选择的一致性
		@Test
		public static void assertDept() throws Exception{
			String pageDept = EditHotelMaintainProviderMessage.editDept().getText();
			ExcelAction.setValue("ActualValue.xls", "dept", pageDept);
			String dept = ExcelAction.getValue("AddHotel_TestData.xls", "dept");
			Assertion.verifyEquals(pageDept, dept, "Dept is right");
		}
		//备注填写ע
		@Test
		public static void assertContactRemark() throws Exception{
			String pageContactRemark = EditHotelMaintainProviderMessage.editContactRemark().getAttribute("value");
			ExcelAction.setValue("ActualValue.xls", "contactRemark", pageContactRemark);
			String contactRemark = ExcelAction.getValue("AddHotel_TestData.xls", "contactRemark");
			Assertion.verifyEquals(pageContactRemark, contactRemark, "ContactRemark is right");
		}
		//保存联系人
		@Test
		public static void assertSaveContact() throws Exception{
			HotelMaintainProviderMessagePage.SaveContact().click();;
			Log.info("***************SaveContact has clicked***************");
		}
	
}

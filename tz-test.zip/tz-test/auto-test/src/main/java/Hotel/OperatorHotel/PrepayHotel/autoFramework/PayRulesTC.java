package Hotel.OperatorHotel.PrepayHotel.autoFramework;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.testng.annotations.Test;
import Hotel.OperatorHotel.PrepayHotel.testCase.SalesPolicyAddCashPrice;
import Hotel.OperatorHotel.PrepayHotel.testCase.SalesPolicyAddPrePayPrice;


public class PayRulesTC extends FeedTest{
	@Test(dataProvider = "feeder")
	@Source("SalesPolicy.xls")
	public static void Rules(String userName,String password,String name,String beginTime,String overTime,String supplierType,String hotelArea,
			String hotelName1,String hotelName2,String slelctSupplierType,String floorPrice,String plusPrice,
			String supplierTypess,String policyTerm,String customerName,String ruleName,String startDate,String endDate,
			String number,String customerNames,String ruleNames,String id,String status,String userType,String searchUser,
			String startCreateTime,String endCreateTime,String customerGroup,String policyAddType,String cityName,String hotelNames,
			String customerNamess)throws Exception {
		//创建预付售价规则
		SalesPolicyAddPrePayPrice.loginTest(userName, password, name, beginTime, overTime, supplierType, hotelArea, hotelName1, hotelName2, slelctSupplierType, floorPrice, plusPrice, supplierTypess, policyTerm, customerName);
		//检查预付售价规则
		SalesPolicyAddPrePayPrice.assertPrePayPrice();
		//创建现付售价规则
		SalesPolicyAddCashPrice.loginTest(ruleName, startDate, endDate, number, customerNames, ruleNames, id, status, userType, searchUser, startCreateTime, endCreateTime, customerGroup, policyAddType, cityName, hotelNames, customerNamess);
		//检查现付售价规则
		SalesPolicyAddCashPrice.assertCashPrice();
	}
}

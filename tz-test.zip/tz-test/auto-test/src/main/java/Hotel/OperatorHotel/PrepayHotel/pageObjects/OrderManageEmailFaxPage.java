package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Hotel.OperatorHotel.PrepayHotel.utility.Log;

//发送酒店传真、邮件页面(客户确认单、酒店入住单等)
public class OrderManageEmailFaxPage {

	public static WebDriver driver;

	private static WebElement element;
	
	public static void getWebDriver(WebDriver webdriver) {

		driver = webdriver;

	}
	
	//Location 发送电邮 按钮
	public static WebElement getSendEmailBtn() throws Exception{
		
		try {
			element = driver.findElement(By.id("btn_sendEmail"));
			Log.info("btn_sendEmail element is found in sendEmailFax Page");
		} catch (Exception e) {
			Log.error("btn_sendEmail element is not found in sendEmailFax Page");
		}
		return element;
	}
	
	//Location 订单号
	public static WebElement getOrderId() throws Exception{
		
		try {
			element = driver.findElement(By.xpath("//*[@id='orderInfo']/li"));
			Log.info(" orderId element is found in sendEmailFax Page");
		} catch (Exception e) {
			Log.error("orderId element is not found in sendEmailFax Page");
		}
		return element;
	}
	
	//location 发送日期
	public static WebElement getSendDate() throws Exception{
		
		try {
			element = driver.findElement(By.xpath("//*[@id='orderInfo']/li[2]"));
			Log.info(" SendDate element is found in sendEmailFax Page");
		} catch (Exception e) {
			Log.error("SendDate element is not found in sendEmailFax Page");
		}
		return element;
	}
	
	//Location 酒店名称
	public static WebElement getHotelName() throws Exception{
		
		try {
			element = driver.findElement(By.xpath("//*[@class='infoContainer']/div[2]/table/tbody/tr/td[1]"));
			Log.info(" hotelname element is found in sendEmailFax Page");
		} catch (Exception e) {
			Log.error("hotelname element is not found in sendEmailFax Page");
		}
		return element;
	}
	
	//Location 酒店房型
	public static WebElement getHotelRoomcat() throws Exception{
		
		try {
			element = driver.findElement(By.xpath("//*[@class='infoContainer']/div[2]/table/tbody/tr/td[2]"));
			Log.info(" HotelRoomcat element is found in sendEmailFax Page");
		} catch (Exception e) {
			Log.error("hotelname element is not found in sendEmailFax Page");
		}
		return element;
	}
	
	//Location 酒店地址
	public static WebElement getHotelAddress() throws Exception{
		
		try {
			element = driver.findElement(By.xpath("//*[@class='infoContainer']/div[2]/table/tbody/tr/td[3]"));
			Log.info(" HotelAddress element is found in sendEmailFax Page");
		} catch (Exception e) {
			Log.error("HotelAddress element is not found in sendEmailFax Page");
		}
		return element;
	}
	
	//Location 酒店入住日期
	public static WebElement getCheckinDate() throws Exception{
		
		try {
			element = driver.findElement(By.xpath("//*[@class='infoContainer']/div[2]/table/tbody/tr[2]/td"));
			Log.info(" CheckinDate element is found in sendEmailFax Page");
		} catch (Exception e) {
			Log.error("CheckinDate element is not found in sendEmailFax Page");
		}
		return element;
	}
	
	//Location 酒店退房日期
	public static WebElement getCheckoutDate() throws Exception{
		
		try {
			element = driver.findElement(By.xpath("//*[@class='infoContainer']/div[2]/table/tbody/tr[3]/td"));
			Log.info("CheckoutDate element is found in sendEmailFax Page");
		} catch (Exception e) {
			Log.error("CheckoutDate element is not found in sendEmailFax Page");
		}
		return element;
	}
	
	//Location 酒店礼包
	public static WebElement getGiftPackage() throws Exception{
		
		try {
			element = driver.findElement(By.xpath("//*[@class='infoContainer']/div[3]/div/span"));
			Log.info("GiftPackage element is found in sendEmailFax Page");
		} catch (Exception e) {
			Log.error("GiftPackage element is not found in sendEmailFax Page");
		}
		return element;
	}
	
	//Location 酒店规定
	public static WebElement getHotelRules() throws Exception{
		
		try {
			element = driver.findElement(By.xpath("//*[@id='rules']/li[5]"));
			Log.info("HotelRules element is found in sendEmailFax Page");
		} catch (Exception e) {
			Log.error("HotelRules element is not found in sendEmailFax Page");
		}
		return element;
	}

}

package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class SpotPaymentSearchPage
{
	public static WebDriver driver;
	private static WebElement element;
	public static void getdriver(WebDriver webdriver)
	{
		driver = webdriver;
	}
	//现付预定按钮
	public static WebElement getSpotPayment() throws Exception{
		try{
			element = driver.findElement(By.id("self"));
		}catch(Exception e){
			Log.error("SpotPayment is not found in the SpotPayment Page");
		}
		return element;
	}
	//选择客户按钮
	public static WebElement getCustomerButton() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[3]/div[2]/form/div/div[1]/div/a"));
		}catch(Exception e){
			Log.error("CustomerButton is not found in the SpotPayment Page");
		} 
		return element;
	}
	
	//客户简称输入框
	public static WebElement getCustomerName() throws Exception{
		try{
			element = driver.findElement(By.name("shortName"));
		}catch(Exception e){
			Log.error("CustomerName is not found in the SpotPayment Page");
		}
		return element;
	}
	//搜索按钮
	public static WebElement getCustomerSearch() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[8]/div[2]/div[1]/table/tbody/tr[1]/td[3]/button"));
		}catch(Exception e){
			Log.error("CustomerSearch is not found in the SpotPayment Page");
		}
		return element;
	}
	//选择客户
	public static WebElement getCustomer() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[8]/div[2]/div[2]/div/table/tbody/tr/td[1]"));
		}catch(Exception e){
			Log.error("Customer is not found in the SpotPayment Page");
		}
		return element;
	}
	//城市输入框
	public static WebElement getCity() throws Exception{
		try{
			element = driver.findElement(By.id("city"));
		}catch(Exception e){
			Log.error("City is not found in the SpotPayment Page");
		}
		return element;
	}
	//选择北京
	public static WebElement getCityClick() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[11]/div/div[1]/ul/li[2]"));
		}catch(Exception e){
			Log.error("City is not found in the SpotPayment Page");
		}
		return element;
	}
	
	//入住时间输入框
	public static WebElement getCheckinDate() throws Exception{
		try{
			element = driver.findElement(By.id("checkinDate"));
		}catch(Exception e){
			Log.error("CheckinDate is not found in the SpotPayment Page");
		}
		return element;
	}
	
	//离店时间输入框
	public static WebElement getCheckoutDate() throws Exception{
		try{
			element = driver.findElement(By.id("checkoutDate"));
		}catch(Exception e){
			Log.error("CheckoutDate is not found in the SpotPayment Page");
		}
		return element;
	}
	
	//酒店名称输入框
	public static WebElement getHotelName() throws Exception{
		try{
			element = driver.findElement(By.id("keywords"));
		}catch(Exception e){
			Log.error("HotelName is not found in the SpotPayment Page");
		}
		return element;
	}
	
	//查询按钮
	public static WebElement getSearchButton() throws Exception{
		try{
			element = driver.findElement(By.id("btn_search"));
		}catch(Exception e){
			Log.error("SearchButton is not found in the SpotPayment Page");
		}
		return element;
	}
	
	//预定按钮
	public static WebElement getOrderButton() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='sortResultPage']/div[3]/div/div[2]/div[1]/table/tbody/tr[1]/td[9]/div[1]/a/span[2]"));
		}catch(Exception e){
			Log.error("OrderButton is not found in the SpotPayment Page");
		}
		return element;
	}
	
	
	
	
	
}

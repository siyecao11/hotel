package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.WebDriver;


import Hotel.OperatorHotel.PrepayHotel.utility.Log;

import Hotel.OperatorHotel.PrepayHotel.pageObjects.OrderManageNormalOrderCreatePage;
/*
 * 
 * 正常订单创建页面控制层
 * 
 * */
public class OrderManageNormalOrderCreateAction {

	public static void transmitDriver (WebDriver driver)throws Exception{
		OrderManageNormalOrderCreatePage.GetDriver(driver);
	}
	
	//填写客人信息
	
	public static void Customer(String CustomerName) throws Exception{
		OrderManageNormalOrderCreatePage.Customer().sendKeys(CustomerName);
		Log.info("***************Customer is writed***************");
	}
	
	//点击创建订单按钮
	public static void CreateOrder() throws Exception{
		OrderManageNormalOrderCreatePage.CreateOrder().click();
		Log.info("***************CreateOrder is clicked***************");
	}
	
	
}

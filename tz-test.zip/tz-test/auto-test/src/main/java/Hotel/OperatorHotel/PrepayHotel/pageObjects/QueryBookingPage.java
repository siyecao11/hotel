package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Hotel.OperatorHotel.OperatorLogin.utility.Log;

public class QueryBookingPage extends BaseClass{
	
	public static WebDriver driver;
	private static WebElement element;
	private static List<WebElement> elementList;
	
	public QueryBookingPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public static void GetDriver(WebDriver webdriver){
		driver = webdriver;
	}
	
	
	//预付酒店标签
	public static WebElement Booking() throws Exception{
		try{
			element= driver.findElement(By.id("booking"));
		}catch (Exception e){
			Log.error("Booking is not found in the HotelSearch Page.");
		}
		return element;
	}
	//现付酒店标签
	public static WebElement Paying() throws Exception {
		try{
			element = driver.findElement(By.id("self"));
		}catch (Exception e){
			Log.error("Paying is not found in the HotelSearch Page.");
		}
		return element;
	}
	//选择客户按钮
	public static WebElement CustomerSearch() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='searchForm']/div/div[1]/div/a"));
		}catch (Exception e){
			Log.error("CustomerSearch is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//客户简称输入框
	public static WebElement CustomerName() throws Exception{
		try{
			element = driver.findElement(By.name("shortName"));
		}catch (Exception e){
			Log.error("CustomerName is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//搜索客户按钮
	public static WebElement SearchCustomer() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[7]/div[2]/div[1]/table/tbody/tr[1]/td[3]/button"));
		}catch (Exception e){
			Log.error("SearchCustomer is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//客户列表
	public static WebElement SelectCustomer() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[7]/div[2]/div[2]/div/table/tbody/tr/td[1]"));
		}catch (Exception e){
			Log.error("SelectCustomer is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//城市输入框
	public static WebElement City() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/div/div[2]/div[1]/span/span/input"));
		}catch (Exception e){
			Log.error("City is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//选择城市列表
	public static WebElement SelectCity() throws Exception{
		try{
			//杭州element = driver.findElement(By.xpath("//div[@id='gn-tabstrip-1']/ul/li[6]"));
			element = driver.findElement(By.xpath(".//*[@id='gn-tabstrip-1']/ul/li[6]"));//上海
		}catch (Exception e){
			Log.error("SelectCity is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//入住时间输入框
	public static WebElement CheckinDate() throws Exception{
		try{
			element = driver.findElement(By.id("checkinDate"));
		}catch (Exception e){
			Log.error("CheckinDate is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//离店时间输入框
	public static WebElement CheckoutDate() throws Exception{
		try{
			element = driver.findElement(By.id("checkoutDate"));
		}catch (Exception e){
			Log.error("CheckinDate is not found in the HotelSearch Page.");
		}
		return element;
	}
	//酒店位置输入框
	public static WebElement Location() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/div/div[2]/div[1]/input[3]"));
		}catch (Exception e){
			Log.error("Location is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//酒店名称输入框
	public static WebElement HotelName() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='hotelName']"));
		}catch (Exception e){
			Log.error("HotelName is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//酒店间数选择
	public static WebElement RoomNo() throws Exception {
		try{
			element =driver.findElement(By.id("roomNo"));				
		}catch (Exception e){
			Log.error("RoomNo is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//搜索酒店按钮
	public static WebElement SearchHotel() throws Exception{
		try{
			element = driver.findElement(By.id("btn_search"));
		}catch(Exception e){
			Log.error("RoomNo is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//目标酒店的展开全部价格
	public static WebElement AllPrice() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='showAllPrice'][@hotelid='54378b27e4b00231855c1f78']/a"));
		}catch (Exception e){
			Log.error("AllPrice is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//单一搜索酒店，展开全部价格
	public static WebElement singleAllPrice() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("a[class='allPriceToggle']"));
		}catch (Exception e){
			Log.error("AllPrice is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//预定按钮
	public static WebElement Reserve(String BookHotelId) throws Exception{
		try{
			//element = driver.findElement(By.xpath(".//*[@id='54378b27e4b00231855c1f78_5437925fe4b00231855c1f8b_543793bee4b00231855c1f91']"));
			element = driver.findElement(By.id(BookHotelId));
			Log.info("Reserve is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("Reserve is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//HotelListIterm 信息Element
	//酒店搜索结果列表中的酒店名称(单个酒店是搜索)
	public static WebElement hotelListName() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("div[class='hotelName']"));
			Log.info("hotelName is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("hotelName is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//HotelListIterm 信息Element
	//酒店搜索结果列表中的酒店名称(多酒店是搜索)
	public static List<WebElement> hotelListNameList() throws Exception{
		
		try{
			elementList = driver.findElements(By.cssSelector("div[class='hotelName']"));
			Log.info("hotelNamelist is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("hotelNamelist is not found in the HotelSearch Page.");
		}
		return elementList;
	}
	
	//酒店搜索结果列表中 的酒店地址
	public static WebElement hotelListAddress() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("div[class='hotelAddress']"));
			Log.info("hotelAddress is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("hotelAddress is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//酒店搜索结果列表中 的宾客类型
	public static WebElement hotelCustomerStyle() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@class='hotelTextInfo']/div[5]"));
			Log.info("hotelCustomerStyle is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("hotelCustomerStyle is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//酒店搜索结果列表中 的内部备注
	public static WebElement hotelInnerRemarks() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@class='hotelTextInfo']/div[6]"));
			Log.info("hotelInnerRemarks is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("hotelInnerRemarks is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//酒店搜索结果列表中 的外部备注
	public static WebElement hotelOuterRemarks() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@class='hotelTextInfo']/div[7]"));
			Log.info("hotelOuterRemarks is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("hotelOuterRemarks is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//酒店搜索结果列表中 的展开全部价格
	public static WebElement hotelAllPriceToggle() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[class='allPriceToggle']"));
			Log.info("hotelAllPriceToggle is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("hotelOuterRemarks is not found in the HotelSearch Page.");
		}
		return element;
	}
	
	//酒店搜索结果列表中 的酒店房型
	public static List<WebElement> hotelRoomCat() throws Exception{
		
		try{
			elementList = driver.findElements(By.cssSelector("td[class='roomStyle']"));
			Log.info("hotelOuterRemarks is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("hotelOuterRemarks is not found in the HotelSearch Page.");
		}
		return elementList;
	}
	
	//酒店房型的BookingClass所匹配的政策ID
	public static WebElement polyicID() throws Exception{
		
		try{
			element = driver.findElement(By.name("_policy_id"));
			Log.info("polyic id is found in the HotelSearch Page");
		}catch (Exception e){
			Log.error("polyic id is not found in the HotelSearch Page");
		}
		return element;
	}
	
	//单一搜索酒店，获取酒店房型下的所有BookingClass的名称
	public static List<WebElement> bookingClassNames() throws Exception{
		
		try{
			elementList = driver.findElements(By.xpath(".//*[@class='hotelRoomdetail']/td"));
			Log.info("bookingClassName is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("bookingClassName is not found in the HotelSearch Page.");
		}
		return elementList;
	}
	
	//单一搜索酒店，获取酒店房型下的所有BookingClass对应的 底价
	public static List<WebElement> basePrices() throws Exception{
		try{
			elementList = driver.findElements(By.xpath(".//*[@class='hotelRoomdetail']/td[6]"));
			Log.info("basePrice is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("basePrice is not found in the HotelSearch Page.");
		}
		return elementList;
	}
	
	//单一搜索酒店，获取酒店房型下的所有BookingClass对应的 加价
	public static List<WebElement> addPrices() throws Exception{
		try{
			elementList = driver.findElements(By.xpath(".//*[@class='hotelRoomdetail']/td[7]"));
			Log.info("addPrice is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("addPrice is not found in the HotelSearch Page.");
		}
		return elementList;
	}
	
	//单一搜索酒店，获取酒店房型下的所有BookingClass对应的 卖价
	public static List<WebElement> sellPrices() throws Exception{
		try{
			elementList = driver.findElements(By.xpath(".//*[@class='hotelRoomdetail']/td[8]/span/span"));
			Log.info("sellPrice is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("sellPrice is not found in the HotelSearch Page.");
		}
		return elementList;
	}
	
	//单一搜索酒店，获取酒店房型下的所有BookingClass对应的 匹配政策
	public static List<WebElement> policyId() throws Exception{
		try{
			elementList = driver.findElements(By.xpath(".//*[@class='hotelRoomdetail']/td[8]/span/input"));
			Log.info("policyId is found in the HotelSearch Page.");
		}catch (Exception e){
			Log.error("policyId is not found in the HotelSearch Page.");
		}
		return elementList;
	}
}

package Hotel.OperatorHotel.PrepayHotel.autoFramework;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.testCase.BookingHotel;
import Hotel.OperatorHotel.PrepayHotel.testCase.OrderManageNormalOrder;
import Hotel.OperatorHotel.PrepayHotel.testCase.OrderManagerPublicCheckPoint;
import Hotel.OperatorHotel.PrepayHotel.testCase.PointSearchHotel;

@Listeners({ Hotel.OperatorHotel.PrepayHotel.utility.AssertionListener.class })
public class NormalOrderTC extends FeedTest {

	public static WebDriver driver;

	@Test(dataProvider = "feeder", groups={"正常单取消流程"})
	@Source("NormalOrder_TestData.xls")
	public static void normalOrder(String username, String password,
			String customerName, String checkinDate, String checkoutDate,
			int roomNo, String name, int addPrice) throws Exception {

		PointSearchHotel.pointSearchHotel(username, password);
		driver = PointSearchHotel.currentDriver;
		BookingHotel.searchBooking(driver, customerName, checkinDate,checkoutDate, roomNo, addPrice);

		// 创建正常单+取消訂單
		OrderManageNormalOrder.NormalOrderCancle(name, checkinDate,addPrice, checkoutDate);

	}

	@Test(dataProvider = "feeder", groups={"正常单确认流程","正常单调账取消流程","正常单调账确认流程","正常单变更取消流程","正常单变更确认流程","正常单变更后调账确认流程","正常单调账确认流程","正常单变更后变更确认流程","正常单退订确认流程","正常单变更后变更再调账确认流程","正常单退订取消流程"})
	@Source("NormalOrder_TestData.xls")
	public static void normalOrderCancle(String username, String password,
			String customerName, String checkinDate, String checkoutDate,
			int roomNo, String name, int addPrice) throws Exception {
		
		PointSearchHotel.pointSearchHotel(username, password);
		driver = PointSearchHotel.currentDriver;
		BookingHotel.searchBooking(driver, customerName, checkinDate,checkoutDate, roomNo, addPrice);

		// 创建正常单+審核
		OrderManageNormalOrder.NormalOrder_ContractInfo(name, checkinDate,addPrice, checkoutDate);

	}
	
	@Test(dataProvider = "feeder", groups={"正常支付失败再次支付流程"})
	@Source("NormalOrder_TestData.xls")
	public static void normalOrderPayFailed(String username, String password,
			String customerName, String checkinDate, String checkoutDate,
			int roomNo, String name, int addPrice) throws Exception {

		PointSearchHotel.pointSearchHotel(username, password);
		driver = PointSearchHotel.currentDriver;
		BookingHotel.searchBooking(driver, customerName, checkinDate,checkoutDate, roomNo, addPrice);

		// 创建正常单+取消訂單
		OrderManageNormalOrder.NormalOrderPayFailed(name, checkinDate,addPrice, checkoutDate);

	}
}

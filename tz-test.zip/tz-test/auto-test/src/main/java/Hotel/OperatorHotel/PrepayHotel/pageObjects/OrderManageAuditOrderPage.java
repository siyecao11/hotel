package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import java.sql.Array;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class OrderManageAuditOrderPage {
	
	public static WebDriver driver;
	private static WebElement element;
	private static List<WebElement> elementList;
	private static List<Select> selectList;
	private static Select oSelection;
	private static List<WebElement> chkBx_PeriodTime;
	//private static List<Select> selectNumList;
	
	//*******************公用审核页面********************
	//正常单、退订单、
	@Test
	public static void getWebDriver(WebDriver webdriver) {
		
		driver = webdriver;
		
	}
	

	// ******************************酒店确认码 弹层元素Location Start
	// ************************************
@Test
	public static WebElement getConfirmBooking_Link() throws Exception{
		
			//getConfirmBooking_Link().click();
		try{									   
			element = driver.findElement(By.xpath(".//*[@id='operator_confirm_refund_order']/span[2]"));
		Log.info(element+" ConfirmBooking_Link element is found in Order_AuditOrder Page");
		}catch (Exception e){
			Log.error(element+" ConfirmBooking_Link element is not found in Order_AuditOrder Page");
		}			
		return element;
	}
	

	
	
	//获取订单审核页面元素，有酒店确认码
	@Test
	public static List<WebElement> getConfirmBooking_ConfirmID1() throws Exception{
		
		try{
			try{
			element = driver.findElement(By.xpath(".//*[@id='confirmBookingPopWin']/div[1]"));
			Log.info(element+" Confirm_Order element is found in BookingClass Page");
		}catch (Exception e){
			Log.error("Confirm_Order element is not found in BookingClass Page");
		}	
			elementList = element.findElements(By.tagName("input"));
			Log.info("Confirm_Order elements is found in Order_AuditOrder Page");
		}catch (Exception e){
			Log.error("Confirm_Order elements is not found in Order_AuditOrder Page");
		}	
		return elementList;
	}
	
	//获取订单审核页面元素，有酒店确认码
		@Test
		public static WebElement getConfirmBooking_ConfirmID2() throws Exception{
			
			try{
				
				element = driver.findElement(By.xpath(".//*[@id='confirmBookingPopWin']/div[2]/label/input"));
				Log.info("Confirm_Order element is found in BookingClass Page");
			}catch (Exception e){
				Log.error("Confirm_Order element is not found in Order_AuditOrder Page");
			}	
				
			return element;
		}
		
	//酒店有确认码页面所有元素
	@Test
	public static List<WebElement> getConfirmBooking_ConfirmIDAll() throws Exception{
		
			//getConfirmBooking_Link().click();
		try{
			elementList = driver.findElements(By.tagName("input"));
		Log.info("Confirm_ID elements is found in BookingClass Page");
		}catch (Exception e){
			Log.error("Confirm_ID elements is not found in Order_AuditOrder Page");
		}			
		return elementList;
	}
	
	//获取保存确认预订页面元素
	@Test
	public static WebElement getConfirmBooking_Save() throws Exception{
				
		try{
			element = driver.findElement(By.id("confirmBooking_save"));
			Log.info("ConfirmBooking_Save element is found in Order_AuditOrder Page");
		}catch (Exception e){
			Log.error("ConfirmBooking_Save element is not found in Order_AuditOrder_Page");
		}
		return element;
	}
		


	
	//获取取消确认预订页面元素
	@Test
	public static WebElement getConfirmBooking_Cancel() throws Exception{
				
		try{
			element = driver.findElement(By.id("confirmBooking_cancel"));
			Log.info("ConfirmBooking_Cancel element is found in Order_AuditOrder_Page");
		}catch (Exception e){
			Log.error("ConfirmBooking_Cancel element is not found in Order_AuditOrder_Page");
		}
		return element;
	}
		
	//***************获取修改结算提醒页面，弹出结算提醒窗口*****************
	//获取现结页面元素
	//获取订单审核页面元素，有酒店确认码
	@Test
	public static List<WebElement> getCount_NOW_SETTLE() throws Exception{
		
		try{
			try{
			element = driver.findElement(By.xpath(".//*[@id='checkoutContainer']/div[1]"));
			Log.info(element+" Confirm_Order element is found in BookingClass Page");
		}catch (Exception e){
			Log.error("Confirm_Order element is not found in Order_AuditOrder_Page");
		}	
			elementList = element.findElements(By.tagName("input"));
			Log.info("Confirm_Order elements is found in BookingClass Page");
		}catch (Exception e){
			Log.error("Confirm_Order elements is not found in Order_AuditOrder_Page");
		}	
		return elementList;
	}
	
	//获取周结页面元素
	@Test
	public static WebElement getCount_WEEK_SETTLE() throws Exception{
				
		try{
			element = driver.findElement(By.xpath(".//*[@id='checkoutContainer']/div[2]/label[1]/input"));
			Log.info(element.getAttribute("value")+" AddRate element is found in Order_AuditOrder_Page");
		}catch (Exception e){
			Log.error("AddRate element is not found in Order_AuditOrder_Page");
		}
		return element;
	}
		
	
	//获取半月结页面元素
	@Test
	public static WebElement getCount_HALF_MONTH_SETTLE() throws Exception{
				
		try{
			element = driver.findElement(By.xpath(".//*[@id='checkoutContainer']/div[2]/label[2]/input"));
			Log.info(element.getAttribute("value")+" AddRate element is found in Order_AuditOrder_Page");
		}catch (Exception e){
			Log.error("AddRate element is not found in Order_AuditOrder_Page");
		}
		return element;
	}
		
	
	//获取月结页面元素
	@Test
	public static WebElement getCount_MONTH_SETTLE() throws Exception{
				
		try{
			element = driver.findElement(By.xpath(".//*[@id='checkoutContainer']/div[2]/label[3]/input"));
			Log.info(element.getAttribute("value")+" AddRate element is found in Order_AuditOrder_Page");
		}catch (Exception e){
			Log.error("AddRate element is not found in Order_AuditOrder_Page");
		}
		return element;
	}
		
	
	//获取保存确认预订页面元素
	@Test
	public static WebElement getCount_Save() throws Exception{
				
		try{
			element = driver.findElement(By.id("saveSettle"));
			Log.info("CountReminder element is found in Order_AuditOrder_Page");
		}catch (Exception e){
			Log.error("CountReminder element is not found in Order_AuditOrder_Page");
		}
		return element;
	}
/*		
	
	//获取取消确认预订页面元素
	@Test
	public static WebElement geAddRate() throws Exception{
				
		try{
			element = driver.findElement(By.id("addRate"));
			Log.info("AddRate element is found in Order_AuditOrder_Page");
		}catch (Exception e){
			Log.error("AddRate element is not found in BookingClass Page");
		}
		return element;
	}
*/	
}
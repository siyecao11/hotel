package Hotel.OperatorHotel.OperatorLogin.utility;

import org.testng.annotations.Test;
import org.apache.log4j.Logger;

public class Log {
	//Initialize Log4j logs
	private static Logger logger = Logger.getLogger(Log.class);
	
	// This is to print log for the beginning of the test case, as we usually run so many test cases as a test suite
	public static void startTestCase(String sTestCaseName){
	    Log.info("****************************************************************************************");
	    Log.info("****************************************************************************************");
	    Log.info("$$$$$$$$$$$$$$$$$$$$$                 "+sTestCaseName+ "       $$$$$$$$$$$$$$$$$$$$$$$$$");
	    Log.info("****************************************************************************************");
	    Log.info("****************************************************************************************");
	    }
	 
	//This is to print log for the ending of the test case
	public static void endTestCase(String sTestCaseName){
	    Log.info("XXXXXXXXXXXXXXXXXXXXXXX             "+"-E---N---D-"+"             XXXXXXXXXXXXXXXXXXXXXX");
	    Log.info("X");
	    Log.info("X");
	    Log.info("X");
	    Log.info("X");
	    }
	
	//log.info("info")
	@Test
	public static void info(String infoMessage) {
		logger.info(infoMessage);
	}
	
	//log.error("error")
	@Test
	public static void error(String infoMessage){
		logger.error(infoMessage);
	}
	
	//log.warn("warn")
	@Test
	public static void warn(String infoMessage){
		logger.warn(infoMessage);
	}
}

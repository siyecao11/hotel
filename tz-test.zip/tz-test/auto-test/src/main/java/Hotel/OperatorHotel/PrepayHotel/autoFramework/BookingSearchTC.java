package Hotel.OperatorHotel.PrepayHotel.autoFramework;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.PrepayHotel.testCase.*;

public class BookingSearchTC extends FeedTest{

	public static WebDriver driver;
	
	@Test(dataProvider = "feeder", priority = 20, groups={"查询"})
	@Source("BookingSearch_TestData.xls")
	public static void bookingSearch(String username, String password,String customerName,String checkinDate,String checkoutDate,int roomNo,int addPrice) throws Exception{
		
		PointSearchHotel.pointSearchHotel(username, password);
		driver = PointSearchHotel.currentDriver;
		BookingHotel.searchBooking(driver, customerName, checkinDate, checkoutDate, roomNo,addPrice);
	}
	
	@AfterClass
	public static void afterClass() throws Exception{
		
		driver.close();
	}
}




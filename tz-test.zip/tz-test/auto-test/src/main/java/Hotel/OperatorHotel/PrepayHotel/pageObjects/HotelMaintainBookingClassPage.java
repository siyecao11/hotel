package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.Test;
import org.openqa.selenium.JavascriptExecutor;

import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class HotelMaintainBookingClassPage {

	public static WebDriver driver;
	private static WebElement element;
	private static List<WebElement> elementList;
	private static Select oSelection;
	private static List<WebElement> chkBx_PeriodTime;

	// private static List<Select> selectNumList;

	@Test
	public static void getWebDriver(WebDriver webdriver) {

		driver = webdriver;

	}

	// Location

	// 获取酒店房型名称元素
	@Test
	public static Select getRoomCat() throws Exception {
		try {
			oSelection = new Select(driver.findElement(By
					.xpath(".//*[@id='roomCatSelect']")));
			// selectList = oSelection.getOptions();
			Log.info("RoomCat element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("RoomCat element is not found in BookingClass Page");
		}
		return oSelection;
	}

	// 获取编辑价格计划链接元素
	@Test
	public static WebElement getEditBookingClass() throws Exception {

		try {
			element = driver.findElement(By
					.xpath(".//*[@id='mainContent']/div[5]/div/div/div/div/a"));
			Log.info("AddRoomType element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("AddRoomType element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取价格名称页面元素
	@Test
	public static WebElement getPriceName() throws Exception {

		try {
			element = driver.findElement(By.id("name"));
			Log.info("PriceName element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("PriceName element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取价格说明/礼包备注页面元素
	@Test
	public static WebElement getRemarks() throws Exception {

		try {
			element = driver.findElement(By.name("remarks"));
			Log.info("Remarks element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("Remarks element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取普通预定页面元素
	@Test
	public static WebElement getOrdinary() throws Exception {

		try {
			element = driver.findElement(By.id("ORDINARY"));
			Log.info("Ordinary element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("Ordinary element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取连住N晚起页面元素
	@Test
	public static List<WebElement> getAdvance() throws Exception {

		try {
			try {

				// element = driver.findElement(By.id("ADVANCE"));
				element = driver.findElement(By.id("ADVANCE_tr"));
				Log.info("ADVANCE_tr element is  found in BookingClass Page");
			} catch (Exception e) {
				Log.error("ADVANCE_tr element is not found in BookingClass Page");
			}
			elementList = element.findElements(By.tagName("input"));
			Log.info("ADVANCE_tr elements is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("ADVANCE_tr elements is not found in BookingClass Page");
		}
		return elementList;
	}

	// 获取提前且连住N晚起页面元素
	@Test
	public static List<WebElement> getSucessive_Live() throws Exception {

		try {
			try {

				element = driver.findElement(By.id("SUCCESSIVE_LIVE_tr"));
				Log.info("SUCCESSIVE_LIVE_tr element is found in BookingClass Page");
			} catch (Exception e) {
				Log.error("SUCCESSIVE_LIVE_tr element is not found in BookingClass Page");
			}
			elementList = element.findElements(By.tagName("input"));
			Log.info("SUCCESSIVE_LIVE_tr elements is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("SUCCESSIVE_LIVE_tr elements is not found in BookingClass Page");
		}
		return elementList;
	}

	// 获取提前N天预定页面元素
	@Test
	public static List<WebElement> getAdvance_and_Live() throws Exception {

		try {

			try {

				element = driver.findElement(By
						.id("ADVANCE_AND_SUCCESSIVE_LIVE_tr"));
				Log.info("ADVANCE_AND_SUCCESSIVE_LIVE_tr element is found in BookingClass Page");
			} catch (Exception e) {
				Log.error("ADVANCE_AND_SUCCESSIVE_LIVE_tr element is not found in BookingClass Page");
			}

			elementList = element.findElements(By.tagName("input"));
			Log.info("ADVANCE_AND_SUCCESSIVE_LIVE_tr elements is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("ADVANCE_AND_SUCCESSIVE_LIVE_tr elements is not found in BookingClass Page");
		}
		return elementList;
	}

	// 获取编辑价格计划链接元素
	@Test
	public static WebElement geAddRate() throws Exception {

		try {
			element = driver.findElement(By.id("addRate"));
			Log.info("AddRate element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("AddRate element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取价格计划时段名称元素
	@Test
	public static WebElement getBkrate_Name() throws Exception {

		try {
			element = driver.findElement(By.name("bookingClassRates[0].name"));
			Log.info("Bkrate_Name_0 element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("Bkrate_Name_0 element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取价格计划时段价格元素
	@Test
	public static WebElement getBkrate_roomCost() throws Exception {

		try {
			element = driver.findElement(By
					.name("bookingClassRates[0].roomCost"));
			Log.info("Bkrate_roomCost_0 element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("Bkrate_roomCost_0 element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取时段开始时间
	@Test
	public static WebElement getStartDate() throws Exception {
		try {
			element = driver.findElement(By.id("startDate-0"));
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			 jsExecutor.executeScript("var setDate=document.getElementById(\"startDate-0\");setDate.removeAttribute('readonly');");		 
		/*	 
			driver.findElement(By.id("startDate-0")).click();
			element = driver.findElement(By
					.xpath(".//*[@id='ui-datepicker-div']/div[1]"));
			//element.findElement(By.linkText("15")).click();
			element.findElement(By.cssSelector("em.fastival.today")).click();
			*/
			Log.info("StartDate is found on the BookingClass Page");
		} catch (Exception e) {
			Log.error("StartDate is not found on the BookingClass Page");
		}
		return element;
	}

	// 获取时段开始时间
	@Test
	public static WebElement getEndDate() throws Exception {

		try {
			element = driver.findElement(By.id("endDate-0"));
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			 jsExecutor.executeScript("var setDate=document.getElementById(\"endDate-0\");setDate.removeAttribute('readonly');");
			 /*	 
			driver.findElement(By.id("endDate-0")).click();
			element = driver.findElement(By
					.xpath(".//*[@id='ui-datepicker-div']/div[2]"));
			element.findElement(By.linkText("30")).click();
			*/
			Log.info("EndDate is found on the BookingClass Page");
		} catch (Exception e) {
			Log.error("EndDate is not found on the BookingClass Page");
		}
		return element;
	}

	/*
	 * //获取时段开始时间
	 * 
	 * @Test public static List<WebElement> getStartDate() throws Exception{
	 * 
	 * try{ try{
	 * 
	 * driver.findElement(By.xpath(".//*[@id='startDate-0']")).click();; element
	 * = driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div[1]"));
	 * Log.info("StartDate element is found in BookingClass Page"); }catch
	 * (Exception e){
	 * Log.error("StartDate element is not found in BookingClass Page"); }
	 * elementList
	 * =element.findElements(By.cssSelector("input[data-month='7']"));
	 * Log.info("StartDate elements is found in BookingClass Page");
	 * }catch(Exception e){
	 * Log.error("StartDate elements is not found in BookingClass Page"); }
	 * return elementList; }
	 * 
	 * 
	 * 
	 * //获取时段结束时间
	 * 
	 * @Test public static WebElement getEndDate() throws Exception{
	 * 
	 * 
	 * try{ element =
	 * driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div[2]"));
	 * Log.info("EndDate element is found in BookingClass Page"); }catch
	 * (Exception e){
	 * Log.error("EndDate element is found in BookingClass Page"); } return
	 * element; }
	 */

	// 获取时段星期时间
	@Test
	public static List<WebElement> getPeriodTime() throws Exception {

		try {

			try {

				element = driver.findElement(By
						.xpath(".//*[@id='period_0']/ul/li[4]"));
				Log.info("PeriodTime element is found in BookingClass Page");
			} catch (Exception e) {
				Log.error("PeriodTime element is not found in BookingClass Page");
			}

			chkBx_PeriodTime = element.findElements(By
					.cssSelector("input[type='checkbox']"));
			// elementList = element.findElements(By.tagName("input"));
			Log.info("PeriodTime elements is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("PeriodTime elements is not found in BookingClass Page");
		}
		return chkBx_PeriodTime;
	}

	// 获取添加有效时段页面元素
	@Test
	public static WebElement getDate_list() throws Exception {

		try {
			element = driver.findElement(By.xpath(".//*[@id='date_list_0']/a"));
			Log.info("EndDate element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("EndDate element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取早餐份数页面元素
	@Test
	public static List<WebElement> getBreakFastName() throws Exception {
		try {
			Select oSelection = new Select(driver.findElement(By
					.name("bookingClassRates[0].complServices[0].component")));
			elementList = oSelection.getOptions();
			Log.info("BreakFastName list is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("BreakFastName list is not found in BookingClass Page");
		}
		return elementList;
	}

	// 获取是否包含早餐页面元素
	@Test
	public static WebElement getBookingClassRates_complServices1()
			throws Exception {
		try {
			element = driver
					.findElement(By
							.name("bookingClassRates[0].complServices[0].serviceDetail"));
			Log.info("BUFFET_BREAKFAST element is found in BookingClass Page");
			// element.click();
			// Log.info("PackagedSales has been clicked");
		} catch (Exception e) {
			Log.error("BUFFET_BREAKFAST element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取是否有宽带页面元素
	@Test
	public static WebElement getBookingClassRates_complServices2()
			throws Exception {
		try {
			element = driver
					.findElement(By
							.name("bookingClassRates[0].complServices[2].serviceDetail"));
			Log.info("BROADBAND element is found in BookingClass Page");
			// element.click();
			// Log.info("PackagedSales has been clicked");
		} catch (Exception e) {
			Log.error("BROADBAND element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取入住时间页面元素
	@Test
	public static List<WebElement> geBookingClassRates_checkinTime()
			throws Exception {
		try {
			Select oSelection = new Select(driver.findElement(By
					.name("bookingClassRates[0].term.checkinTime")));
			elementList = oSelection.getOptions();
			Log.info("BookingClassRates_checkinTime list is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("BookingClassRates_checkinTime list is not found in BookingClass Page");
		}
		return elementList;
	}

	// 获取退房时间页面元素
	@Test
	public static List<WebElement> geBookingClassRates_checkoutTime()
			throws Exception {
		try {
			Select oSelection = new Select(driver.findElement(By
					.name("bookingClassRates[0].term.checkoutTime")));
			elementList = oSelection.getOptions();
			Log.info("BookingClassRates_checkoutTime list is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("BookingClassRates_checkoutTime list is not found in BookingClass Page");
		}
		return elementList;
	}

	// 获取入住前几天页面元素
	@Test
	public static WebElement getCheckinDays() throws Exception {

		try {
			element = driver.findElement(By.id("checkinDays_0"));
			Log.info("CheckinDays element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("CheckinDays element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取入住前几点元素
	@Test
	public static WebElement getCheckInPoint() throws Exception {

		try {
			element = driver.findElement(By.id("checkInPoint_0"));
			Log.info("CheckInPoint element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("CheckInPoint element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取变更、取消扣除房费规则页面元素
	@Test
	public static List<WebElement> getCancelTerms() throws Exception {
		try {
			Select oSelection = new Select(driver.findElement(By
					.id("cancelTerms_0")));
			elementList = oSelection.getOptions();
			Log.info("CancelTerms list is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("CancelTerms list is not found in BookingClass Page");
		}
		return elementList;
	}

	// 保存页面元素获取
	@Test
	public static WebElement getSave_Button() throws Exception {
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='bkClass']/div/div[7]/a"));
			Log.info("Save_Button element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("Save_Button element is not found in BookingClass Page");
		}
		return element;
	}

	// get delete bookingClass element
	// To get bookingClass ID
	@Test
	public static WebElement getBookingClassDetail() throws Exception {
		try {
			element = driver.findElement(By
					.cssSelector("a[class='button_5 detailData']"));
			Log.info("BookingClassDetail element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("BookingClassDetail element is not found in BookingClass Page");
		}
		return element;
	}

	// get RoomAllotItem element
	// goto RoomAllot edit page
	@Test
	public static WebElement getRoomAllotItemElement() throws Exception {
		try {
			element = driver.findElement(By.id("allot"));
			Log.info("RoomAllotItem element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("RoomAllotItem element is not found in BookingClass Page");
		}
		return element;
	}
	
	

	//***************************************************************************************************************
		//**********************酒店房型  检查点元素定位***************************

	// 获取价格名称页面元素
	@Test
	public static WebElement geteEPriceName() throws Exception {

		try {
			element = driver.findElement(By.id("name"));
			Log.info("PriceName element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("PriceName element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取价格说明/礼包备注页面元素
	@Test
	public static WebElement getERemarks() throws Exception {

		try {
			element = driver.findElement(By.name("remarks"));
			Log.info("Remarks element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("Remarks element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取价格计划时段名称元素
	@Test
	public static WebElement getEBkrate_Name() throws Exception {

		try {
			element = driver.findElement(By.name("bookingClassRates[0].name"));
			Log.info("Bkrate_Name_0 element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("Bkrate_Name_0 element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取价格计划时段价格元素
	@Test
	public static WebElement getEBkrate_roomCost() throws Exception {

		try {
			element = driver.findElement(By
					.name("bookingClassRates[0].roomCost"));
			Log.info("Bkrate_roomCost_0 element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("Bkrate_roomCost_0 element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取时段开始时间
	@Test
	public static WebElement getEStartDate() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='date_list_0']/div/span[1]"));
			Log.info("StartDate is found on the BookingClass Page");
		} catch (Exception e) {
			Log.error("StartDate is not found on the BookingClass Page");
		}
		return element;
	}

	// 获取时段结束时间
	@Test
	public static WebElement getEEndDate() throws Exception {

		try {
			element = driver.findElement(By.xpath(".//*[@id='date_list_0']/div/span[2]"));
			Log.info("EndDate is found on the BookingClass Page");
		} catch (Exception e) {
			Log.error("EndDate is not found on the BookingClass Page");
		}
		return element;
	}
	

	// 获取早餐份数页面元素
	@Test
	public static WebElement getEBreakFastName() throws Exception {
		try {
			element = driver.findElement(By
					.name("bookingClassRates[0].complServices[0].component"));
			Log.info("BreakFastName is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("BreakFastName is not found in BookingClass Page");
		}
		return element;
	}

	// 获取是否包含早餐页面元素
	@Test
	public static WebElement getEBookingClassRates_complServices1() throws Exception {
		try {
			element = driver
					.findElement(By
							.name("bookingClassRates[0].complServices[0].serviceDetail"));
			Log.info("BUFFET_BREAKFAST element is found in BookingClass Page");
			// element.click();
			// Log.info("PackagedSales has been clicked");
		} catch (Exception e) {
			Log.error("BUFFET_BREAKFAST element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取是否有宽带页面元素
	@Test
	public static WebElement getEBookingClassRates_complServices2()
			throws Exception {
		try {
			element = driver
					.findElement(By
							.name("bookingClassRates[0].complServices[2].serviceDetail"));
			Log.info("BROADBAND element is found in BookingClass Page");
			// element.click();
			// Log.info("PackagedSales has been clicked");
		} catch (Exception e) {
			Log.error("BROADBAND element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取入住时间页面元素
	@Test
	public static WebElement getEBookingClassRates_checkinTime()
			throws Exception {
		try {
			element = driver.findElement(By
					.name("bookingClassRates[0].term.checkinTime"));
			Log.info("BookingClassRates_checkinTime list is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("BookingClassRates_checkinTime list is not found in BookingClass Page");
		}
		return element;
	}

	// 获取退房时间页面元素
	@Test
	public static WebElement getEBookingClassRates_checkoutTime()
			throws Exception {
		try {
			element = driver.findElement(By
					.name("bookingClassRates[0].term.checkoutTime"));
			Log.info("BookingClassRates_checkoutTime list is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("BookingClassRates_checkoutTime list is not found in BookingClass Page");
		}
		return element;
	}

	// 获取入住前几天页面元素
	@Test
	public static WebElement getECheckinDays() throws Exception {

		try {
			element = driver.findElement(By.id("checkinDays_0"));
			Log.info("CheckinDays element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("CheckinDays element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取入住前几点元素
	@Test
	public static WebElement getECheckInPoint() throws Exception {

		try {
			element = driver.findElement(By.id("checkInPoint_0"));
			Log.info("CheckInPoint element is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("CheckInPoint element is not found in BookingClass Page");
		}
		return element;
	}

	// 获取变更、取消扣除房费规则页面元素
	@Test
	public static WebElement getECancelTerms() throws Exception {
		try {
			element = driver.findElement(By
							.id("cancelTerms_0"));
			Log.info("CancelTerms list is found in BookingClass Page");
		} catch (Exception e) {
			Log.error("CancelTerms list is not found in BookingClass Page");
		}
		return element;
	}

	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import Hotel.OperatorHotel.OperatorLogin.utility.Log;
import Hotel.OperatorHotel.PrepayHotel.pageObjects.QueryBookingPage;

public class QueryBookingAction {

	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {

		QueryBookingPage.GetDriver(driver);
	}

	// 点击现付标签
	public static void Booking() throws Exception {
		QueryBookingPage.Booking().click();
		Log.info("***************Booking is clicked***************");
	}

	// 点击客户按钮
	public static void CustomerSearch() throws Exception {
		QueryBookingPage.CustomerSearch().click();
		Log.info("***************CustomerSearch is clicked***************");
	}

	// 填写客户简称
	public static void CustomerName(String CusAbbreviation) throws Exception {

		QueryBookingPage.CustomerName().sendKeys(CusAbbreviation);
		Log.info("***************CustomerName is writed***************");
	}

	// 点击搜索客户
	public static void SearchCustomer() throws Exception {
		QueryBookingPage.SearchCustomer().click();
		Log.info("***************SearchCustomer is clicked***************");
	}

	// 点击选择客户
	public static void SelectCustomer() throws Exception {
		QueryBookingPage.SelectCustomer().click();
		Log.info("***************SelectCustomer is clicked***************");
	}

	// 点击城市输入框
	public static void City() throws Exception {
		QueryBookingPage.City().click();
		Log.info("***************City is clicked***************");
	}

	// 选择城市
	public static void SelectCity() throws Exception {
		QueryBookingPage.SelectCity().click();
		Log.info("***************SelectCity is clicked***************");
	}

	// 填写入住时间
	public static void CheckinDate(String CheckinDate) throws Exception {
		QueryBookingPage.CheckinDate().clear();
		QueryBookingPage.CheckinDate().sendKeys(CheckinDate);
		Log.info("***************CheckinDate is writed***************");
	}

	// 填写出店时间
	public static void CheckoutDate(String CheckoutDate) throws Exception {
		QueryBookingPage.CheckoutDate().clear();
		QueryBookingPage.CheckoutDate().sendKeys(CheckoutDate);
		Log.info("***************CheckoutDate is writed***************");
	}

	// 填写酒店位置
	public static void Location(String Location) throws Exception {
		QueryBookingPage.Location().clear();
		QueryBookingPage.Location().sendKeys(Location);
		Log.info("***************Location is writed***************");
	}

	// 填写酒店名称
	public static void HotelName(String HotelName) throws Exception {
		QueryBookingPage.HotelName().clear();
		QueryBookingPage.HotelName().sendKeys(HotelName);
		Log.info("***************HotelName is writed***************");
	}

	// 选择间数
	public static void RoomNo(int RoomNo) throws Exception {
		Select roomno = new Select(QueryBookingPage.RoomNo());
		roomno.selectByIndex(RoomNo);
		Log.info("***************RoomNo is writed***************");
	}

	// 点击搜索按钮

	public static void SearchHotel() throws Exception {
		QueryBookingPage.SearchHotel().click();
		Log.info("***************SearchHotel is clicked***************");
	}

	// 点击展开目标酒店所有价格
	public static void AllPrice() throws Exception {
		QueryBookingPage.AllPrice().click();
		Log.info("***************AllPrice is clicked***************");
	}

	// 单一酒店查询，点击展开目标酒店所有价格
	public static void singleAllPrice() throws Exception {
		QueryBookingPage.singleAllPrice().click();
		Log.info("***************AllPrice is clicked***************");
	}

	// 点击预定按钮
	public static void Reserve(String BookHotelId) throws Exception {
		QueryBookingPage.Reserve(BookHotelId).click();

		Log.info("***************Reserve is clicked***************");
	}

	// 单一酒店查询，获取酒店房型下的所有BookingClass的名称
	public static String[] bookingClassNameAction() throws Exception{
		
		int listSize = QueryBookingPage.bookingClassNames().size();
		String[] bookingClassName = new String[listSize];
		for(int i=0; i<listSize; i++)
		{
			bookingClassName[i] = QueryBookingPage.bookingClassNames().get(i).getText();
		}
		return bookingClassName;
	}
	
	// 单一酒店查询，获取酒店房型下的所有BookingClass对应的底价
	public static String[] basePriceAction() throws Exception{
		
		int listSize = QueryBookingPage.basePrices().size();
		String[] basePrice = new String[listSize];
		for(int i=0; i<listSize; i++)
		{
			basePrice[i] = QueryBookingPage.basePrices().get(i).getText().substring(1);
		}
		return basePrice;
	}
	
	// 单一酒店查询，获取酒店房型下的所有BookingClass对应的加价
	public static String[] addPriceAction() throws Exception{
		
		int listSize = QueryBookingPage.addPrices().size();
		String[] addPrice = new String[listSize];
		for(int i=0; i<listSize; i++)
		{
			addPrice[i] = QueryBookingPage.addPrices().get(i).getText().substring(1);
		}
		return addPrice;
	}
	
	// 单一酒店查询，获取酒店房型下的所有BookingClass对应的卖价
	public static String[] sellPriceAction() throws Exception{
		
		int listSize = QueryBookingPage.sellPrices().size();
		String[] sellPrice = new String[listSize];
		for(int i=0; i<listSize; i++)
		{
			sellPrice[i] = QueryBookingPage.sellPrices().get(i).getText().substring(1);
		}
		return sellPrice;
	}	
	
	// 单一酒店查询，获取酒店房型下的所有BookingClass对应的 匹配政策
	public static String[] policyIdAction() throws Exception{
		
		int listSize = QueryBookingPage.policyId().size();
		String[] policyId = new String[listSize];
		for(int i=0; i<listSize; i++)
		{
			policyId[i] = QueryBookingPage.policyId().get(i).getAttribute("value");
		}
		return policyId;
	}
}

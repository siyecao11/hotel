package Hotel.OperatorHotel.OperatorLogin.appModules;

import org.testng.annotations.Test;
import Hotel.OperatorHotel.OperatorLogin.pageObjects.LoginPage;
import Hotel.OperatorHotel.OperatorLogin.utility.Log;
import org.openqa.selenium.WebDriver;

public class LoginAction{
	
	@Test
	public static void excute(String userName, String password, WebDriver driver) throws Exception{
		//s
		//传递WebDriver
		LoginPage.getDriver(driver);
		
		LoginPage.txt_UserNmae().sendKeys(userName);
		Log.info(userName + " is entered in UserName text box");
		
		LoginPage.txt_Password().sendKeys(password);
		Log.info(password + "is entered in Password text box"); 
		
		LoginPage.btn_LogIn().click();
		Log.info("Click action is performed on Submit button");
	}
}

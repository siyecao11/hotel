package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.WebDriver;

import Hotel.OperatorHotel.PrepayHotel.pageObjects.OrderManageEndorseOrderCreatePage;
import Hotel.OperatorHotel.PrepayHotel.utility.Log;

public class OrderManageEndorseOrderCreateAction {

	public static void transmitDriver(WebDriver driver) throws Exception{
		OrderManageEndorseOrderCreatePage.GetDriver(driver);
	}
	
	//点击创建变更单按钮
	public static void CreateEndorseOrder() throws Exception{
		OrderManageEndorseOrderCreatePage.CreateButton().click();
		Log.info("*************CreateEndorseOrder is clicked****************");
	}
	
}

package Hotel.OperatorHotel.GTAHotel.testCase;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import Hotel.OperatorHotel.GTAHotel.appModules.OrderManageOrderListAction;
import Hotel.OperatorHotel.OperatorLogin.utility.Utils;

public class OrderManageOrderList {

	public static WebDriver driver;
	
	public static void orderDeteil(String orderId, WebDriver webDriver) throws Exception{
		
		driver = webDriver;
		OrderManageOrderListAction.transmitDriver(webDriver);
		//输入GTA酒店的订单ID
		OrderManageOrderListAction.OrderIdInput(orderId);
		//查询指定订单
		OrderManageOrderListAction.SearchOrder();
		Utils.waitForElement(5, driver, "page");
		//点击进入订单详情页
		OrderManageOrderListAction.OrderClick();
		
	}
}

package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Hotel.OperatorHotel.PrepayHotel.utility.*;
/*
 * 正常订单创建页面元素定义
 * 
 * */

public class OrderManageNormalOrderCreatePage extends BaseClass{

	private static WebElement element;
	public static WebDriver driver;
	public OrderManageNormalOrderCreatePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public static void GetDriver(WebDriver webdriver){
		driver = webdriver;
	}
	
	//客人信息
	public static WebElement Customer() throws Exception{
		try{
			element = driver.findElement(By.name("hotelGuestBo[0].name"));
		}catch (Exception e){
			Log.error("****************Customer is not found in the CreateOrder page.****************");
		}
		return element;
	}
	//创建订单
	public static WebElement CreateOrder() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/div/div/div[2]/div[3]/a[3]/span[2]"));
		}catch (Exception e){
			Log.error("****************CreateOrder is not found in the CreateOrder page.***************");
		}
		return element;
	}
	
}

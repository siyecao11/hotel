package Hotel.OperatorHotel.PrepayHotel.appModules;

import org.openqa.selenium.WebDriver;

import Hotel.OperatorHotel.PrepayHotel.pageObjects.OrderManageOrderPayPage;
/*
 * 订单支付页面控制层
 * 
 * */
public class OrderManageOrderPayAction {

	public static void transmitDriver(WebDriver driver)throws Exception{
		OrderManageOrderPayPage.GetDriver(driver);
	}
	
	//获取支付页面订单Id
	public static String GetOrderId() throws Exception{
		String OrderId = OrderManageOrderPayPage.OrderId().getText();
		String tempStr = "";
		//去掉字符串开头结尾的空格
		OrderId.trim();
		//遍历得到订单号+OrderId
		for (int i = 0; i < OrderId.length(); i++) 
		{
            char  item =  OrderId.charAt(i);
            if(item == ' ')
            {
            	tempStr = OrderId.substring(i+1);
            }
		}
		String orderId = tempStr.substring(3);
		System.out.println(orderId);
		return orderId;
	}
	
		

	
	
	
	
}

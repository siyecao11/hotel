package Hotel.OperatorHotel.GTAHotel.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Hotel.OperatorHotel.OperatorLogin.utility.Log;

public class OrderManageOrderListPage {

	public static WebDriver driver;
	public static WebElement element;
	
	public static void getWebDriver(WebDriver webDriver){
		
		driver = webDriver;
	}
	
	//预付酒店订单页面订单号输入框
	public static WebElement OrderIdInput() throws Exception{
		try{
			element = driver.findElement(By.id("orderNo"));
			Log.info("****************OrderId is found in the OrderList page.****************");
		}catch (Exception e){
			Log.error("****************OrderId is not found in the OrderList page.****************");
		}
		return element;
	}
	
	//预付酒店订单页面搜索订单按钮
	public static WebElement SearchOrder() throws Exception{
		try{
			element = driver.findElement(By.id("orderFormSubmit"));
			Log.info("****************SearchOrder is found in the OrderList page.****************");
		}catch (Exception e){
			Log.error("****************SearchOrder is not found in the OrderList page.****************");
		}
		return element;
	}
	
	//点击目标订单号，跳转到审核页面
	public static WebElement OrderIdClick() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div[1]/table/tbody/tr/td[4	]/a"));
			Log.info("****************OrderIdClick is found in the OrderList page.****************");
		}catch (Exception e){
			Log.error("****************OrderIdClick is not found in the OrderList page.****************");
		}
		return element;
	}
}

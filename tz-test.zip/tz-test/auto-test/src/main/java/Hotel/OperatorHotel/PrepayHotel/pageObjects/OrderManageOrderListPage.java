package Hotel.OperatorHotel.PrepayHotel.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Hotel.OperatorHotel.OperatorLogin.utility.Log;
import Hotel.OperatorHotel.PrepayHotel.utility.Constant;
/*
 * 订单列表页面元素定义
 * 
 * */
public class OrderManageOrderListPage{

	public static WebDriver driver;
	private static WebElement element;

	public static void getDriver(WebDriver webdriver){
		
		driver = webdriver;
	}
	
	//预付酒店订单页面订单号输入框
		public static WebElement OrderIdInput() throws Exception{
			try{
				element = driver.findElement(By.id("orderNo"));
				Log.info("****************OrderId is found in the OrderList page.****************");
			}catch (Exception e){
				Log.error("****************OrderId is not found in the OrderList page.****************");
			}
			return element;
		}
		
		//预付酒店订单页面搜索订单按钮
		public static WebElement SearchOrder() throws Exception{
			try{
				element = driver.findElement(By.id("orderFormSubmit"));
				Log.info("****************SearchOrder is found in the OrderList page.****************");
			}catch (Exception e){
				Log.error("****************SearchOrder is not found in the OrderList page.****************");
			}
			return element;
		}
		
		//点击目标订单号，跳转到审核页面
		public static WebElement OrderIdClick() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div[1]/table/tbody/tr/td[5]/a"));
				Log.info("****************OrderIdClick is found in the OrderList page.****************");
			}catch (Exception e){
				Log.error("****************OrderIdClick is not found in the OrderList page.****************");
			}
			return element;
		}
		
		//get "订单管理" 菜单项标签
		public static WebElement getOrderManageMenu() throws Exception{
			
			try{
				element = driver.findElement(By.cssSelector("a[href=" + Constant.orderManageURL + "]"));
				Log.info("OrderManage Menu item is found on the HotelHome Page");
			}catch (Exception e){
				Log.error("********OrderManage Menu item is not found on the HotelHome Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 预付酒店订单 item
		public static WebElement getPrepayOrderMenu() throws Exception{
			
			String url = "/tops-front-operator-hotel-order/order/hotel/hotelSearch";
			try{
				element = driver.findElement(By.cssSelector("a[href=" + url + "]"));
				Log.info("PrepayOrder Menu item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********PrepayOrder Menu item is not found on the OrderManage Page********");
			}
			return element;
		}
		//********************现付酒店  订单管理***************************
		//get "订单管理" -- 现付酒店订单 item
		public static WebElement getSelpayOrderMenu() throws Exception{
			
			String url = "/tops-front-operator-hotel-order/order/hotel/selfpay/hotelOrderSearch";
			try{
				element = driver.findElement(By.cssSelector("a[href=" + url + "]"));
				Log.info("SelpayOrder Menu item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********SelpayOrder Menu item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//现付酒店订单页面订单号输入框
				public static WebElement CashOrderIdInput() throws Exception{
					try{
						element = driver.findElement(By.id("orderNo"));
						Log.info("****************OrderId is found in the OrderList page.****************");
					}catch (Exception e){
						Log.error("****************OrderId is not found in the OrderList page.****************");
					}
					return element;
				}
				
				//预付酒店订单页面搜索订单按钮
				public static WebElement CashSearchOrder() throws Exception{
					try{
						element = driver.findElement(By.id("orderFormSubmit"));
						Log.info("****************SearchOrder is found in the OrderList page.****************");
					}catch (Exception e){
						Log.error("****************SearchOrder is not found in the OrderList page.****************");
					}
					return element;
				}
				
				//点击目标订单号，跳转到受理页面
				public static WebElement CashOrderIdClick() throws Exception{
					try{
						element = driver.findElement(By.xpath(".//*[@id='flowOperation_0']/a/span"));
						Log.info("****************OrderIdClick is found in the OrderList page.****************");
					}catch (Exception e){
						Log.error("****************OrderIdClick is not found in the OrderList page.****************");
					}
					return element;
				}
				
		
		//get "订单管理" -- 订单受理员
		public static WebElement getOrderOperator() throws Exception{
			
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[2]"));
				Log.info("OrderOperator item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderOperator item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 订单客户名称
		public static WebElement getOrderKeHuName() throws Exception{
			
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[3]"));
				Log.info("OrderKeHuName item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderKeHuName item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 订单客户名称
		public static WebElement getOrderPayType() throws Exception{
			
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[4]"));
				Log.info("OrderPayType item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderPayType item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 订单号
		public static WebElement getOrderID() throws Exception{
			
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[5]"));
				Log.info("OrderID item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderID item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 是否推荐酒店
		public static WebElement getOrderTuiJianHotel() throws Exception{
			
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[6]"));
				Log.info("OrderTuiJianHotel item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderTuiJianHotel item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 酒店城市
		public static WebElement getOrderHotelCity() throws Exception{
			
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[7]"));
				Log.info("OrderHotelCity item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderHotelCity item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 酒店名称
		public static WebElement getOrderHotelName() throws Exception{
			
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[8]"));
				Log.info("OrderHotelCity item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderHotelCity item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 客人姓名
		public static WebElement getOrderCustomerName() throws Exception{
			
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[9]"));
				Log.info("OrderCustomerName item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderCustomerName item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 订单类型
		public static WebElement getOrderType() throws Exception{
			
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[10]"));
				Log.info("OrderType item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderType item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 订单来源
		public static WebElement getOrderSource() throws Exception{
			
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[11]"));
				Log.info("OrderSource item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderSource item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 预订日期
		public static WebElement getOrderBookingDate() throws Exception{
			
			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[12]"));
				Log.info("OrderBookingDate item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderBookingDate item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 入住、离店日期
		public static WebElement getOrderCheckInOutDate() throws Exception{

			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[13]"));
				Log.info("OrderCheckInOutDate item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderCheckInOutDate item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 订单金额
		public static WebElement getOrderFee() throws Exception{

			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[14]"));
				Log.info("OrderFee item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderFee item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 订单状态
		public static WebElement getOrderStatus() throws Exception{

			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[15]"));
				Log.info("OrderStatus item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderStatus item is not found on the OrderManage Page********");
			}
			return element;
		}
		
		//get "订单管理" -- 确认状态
		public static WebElement getOrderConfirmStatus() throws Exception{

			try{
				element = driver.findElement(By.xpath(".//*[@id='searchResultDiv']/div/table/tbody/tr/td[16]"));
				Log.info("OrderConfirmStatus item is found on the OrderManage Page");
			}catch (Exception e){
				Log.error("********OrderConfirmStatus item is not found on the OrderManage Page********");
			}
			return element;
		}
		
}

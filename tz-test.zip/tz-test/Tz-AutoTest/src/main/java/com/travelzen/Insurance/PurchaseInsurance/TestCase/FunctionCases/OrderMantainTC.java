package com.travelzen.Insurance.PurchaseInsurance.TestCase.FunctionCases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.travelzen.Login.PurchaseLogin.TestCase.FunctionCases.LoginPurchase;
import com.travelzen.Insurance.PurchaseInsurance.Utility.Utils.DataProviderApp;
import com.travelzen.Utility.Constants.Constants;
import com.travelzen.Utility.ScreenShot.RetryFail;
import com.travelzen.Utility.Utils.Utils;
import com.travelzen.Utility.DataDriver.*;
import com.travelzen.Insurance.PurchaseInsurance.AppModules.*;
import com.travelzen.Insurance.PurchaseInsurance.TestCase.CheckPoints.InsureOrderDetailCheckPoint;
import com.travelzen.Insurance.PurchaseInsurance.Utility.Constants.constants;

public class OrderMantainTC {

	public static WebDriver currentDriver;
	public static String orderId;
	public static String orderStatus;
	// 从正常单获取Driver

	@BeforeClass(alwaysRun = true)
	public static void beforeClass() {

	}

	@BeforeMethod(alwaysRun = true)
	public static void beforeMethod() {
		// 从登陆过去
		currentDriver = CreatOrderTC.currentDriver;
		Constants.classDriver = currentDriver;
	}

	@AfterMethod(alwaysRun = true)
	public static void afterMethod() {

		if (DataProviderApp.isLoginIncludeProcess.equalsIgnoreCase("false")) {
			currentDriver.close();
		}
	}

/*	// 订单详情页--循环等待订单状态--完成
	@Test
	public static void waitCompleteStatus() throws Exception {
		do {
			Thread.sleep(2000);
			currentDriver.navigate().refresh();
			orderStatus = OrderDetailAction.excutGetOrderStatusAction();
			System.out.print("订单状态是：" + orderStatus);
		} while (!(orderStatus.equals("完成")));

	}
*/	
	
	// 订单详情页--循环等待订单状态--完成
		@Test
		public static void waitCompleteStatus() throws Exception {
			do {
	
				orderStatus = OrderListAction.excutGetOrderStatusAction();
				System.out.print("订单状态是：" + orderStatus);
				currentDriver.navigate().refresh();
				Thread.sleep(1000);
				// 输入订单号
				OrderListAction.excutInputOrderId(orderId);
				Thread.sleep(1000);
				// 点击“搜索”，查询订单
				OrderListAction.excutOrderSearhAction();
				
			} while (!(orderStatus.equals("完成")));

		}

/*	// 订单详情页--循环等待订单状态--完成
	@Test
	public static void waitInsureFailStatus() throws Exception {
		do {
			Thread.sleep(2000);
			currentDriver.navigate().refresh();
			orderStatus = OrderDetailAction.excutGetOrderStatusAction();
			System.out.print("订单状态是：" + orderStatus);
		} while (!(orderStatus.equals("投保失败")));

	}
*/	
	// 订单详情页--循环等待订单状态--完成
		@Test
		public static void waitInsureFailStatus() throws Exception {
			do {
				
				orderStatus = OrderListAction.excutGetOrderStatusAction();
				System.out.print("订单状态是：" + orderStatus);
				currentDriver.navigate().refresh();
				Thread.sleep(1000);
				// 输入订单号
				OrderListAction.excutInputOrderId(orderId);
				Thread.sleep(1000);
				// 点击“搜索”，查询订单
				OrderListAction.excutOrderSearhAction();
				
			} while (!(orderStatus.equals("投保失败")));

		}


	// 打开订单管理--保险订单列表--查询订单
	@Test(priority = 30, groups = { "查询订单" })
	@Parameters("orderType")
	public static void searchOrder(String orderType) throws Exception {
		switch (orderType) {
		case "normalOrder":
			orderId = constants.NormalOrderId;
			break;
		case "surrenderOrder":
			orderId = constants.surenderOrderId;
			break;
		case "insureCancelOrder":
			orderId = constants.cancelInsureOrderId;
			break;
		}
		// 打开订单管理列表
		OrderListAction.transmitDriver(currentDriver);
		OrderListAction.excutOpenOrderManageAction();
		// 跳转到保险定单列表
		Thread.sleep(2000);
		OrderListAction.excutOpenInsuranceOrderAction();
		// System.out.println("要查询的订单号是："+orderId);
		// 输入订单号
		OrderListAction.excutInputOrderId(orderId);
		Thread.sleep(2000);
		// 点击“搜索”，查询订单
		OrderListAction.excutOrderSearhAction();
		Thread.sleep(2000);
		switch (orderType) {
		case "surrenderOrder":
			waitCompleteStatus();
			break;
		case "insureCancelOrder":
			waitInsureFailStatus();
			break;
		}
	}

	// 打开订单管理--保险订单列表--查询订单--跳转到订单详情页
	@Test(priority = 30, groups = { "查看订单详情" })
	@Parameters("orderType")
	public static void openOrderDetail(String orderType) throws Exception {
		// 搜索订单
		searchOrder(orderType);
		// 打开订单详情页
		// currentDriver.navigate().refresh();
		// System.out.print("查询的订单号是"+orderId);

		currentDriver
				.get("http://astore.op3.tdxinfo.com/tops-front-purchaser-additional/additional/insurance/orderDetail/detail?id="
						+ orderId);
		// OrderListAction.excutOrderIdLinkAction();
		// 传递driver到订单详情页
		OrderDetailAction.transmitDriver(currentDriver);
	/*	switch (orderType) {
		case "surrenderOrder":
			waitCompleteStatus();
			break;
		case "insureCancelOrder":
			waitInsureFailStatus();
			break;
		}
		*/
		// System.out.print("currentDriver url"+currentDriver.getCurrentUrl());
		// currentDriver.navigate().forward();
		// System.out.print("currentDriver url"+currentDriver.getCurrentUrl());
	}

	// *************************保险订单列表页 订单维护操作******************
	// 保险订单列表页--订单退保
	@Test(priority = 34, groups = {"列表页退保" },dataProvider = "insurance_surenderOrder",dataProviderClass = DataProviderApp.class)
	public static void listOrderSurrender(String name) throws Exception {
		// 点击退保
		OrderListAction.excutSurrenderAction();
		// 选中退保人
		OrderListAction.excutSurrenderChooseAction(name);
		// 提交退保
		OrderListAction.excutSurrenderSubmmitAction();
	}

	// 保险订单列表页--订单取消投保
	@Test(priority = 34, groups = {"列表页订单取消投保" },dataProvider = "insurance_cancelInsureOrder",dataProviderClass = DataProviderApp.class)
	public static void listInsureCancel(String name) throws Exception {
		// 点击取消投保
		OrderListAction.excutCancelInsureAction();
		// 选中取消投保人
		OrderListAction.excutCancelInsureChooseAction(name);
		// 提交取消投保
		OrderListAction.excutCancelInsureSubmmitAction();

	}

	// 保险订单列表页--订单投保
	@Test(priority = 34, groups = { "列表页投保" }, retryAnalyzer = RetryFail.class)
	public static void listInsure() throws Exception {
		// 点击投保
		OrderListAction.excutUnderWriteAction();

	}

	// 保险订单列表页--订单支付
	@Test(dataProvider = "insurance_payOrder", priority = 34, groups = {
			"列表页订单支付" }, dataProviderClass = DataProviderApp.class)
	public static void listOrderPay(String password) throws Exception {
		// 点击支付
		OrderListAction.excutOrderPayAction();
		// driver传递
		OrderPayAction.transmitDriver(currentDriver);
		// 输入支付密码，默认使用账户支付
		OrderPayAction.excutInputPasswordAction(password);
		// 确认付款
		OrderPayAction.excutPayAffirmAction();
	}

	// 保险订单列表页--订单取消
	@Test(priority = 34, groups = { "列表页订单取消" }, retryAnalyzer = RetryFail.class)
	public static void listOrderCancel() throws Exception {
		// 点击取消
		OrderListAction.excutCancelOrderAction();
		// 确认取消
		OrderListAction.excutCancelOrderConfirmAction();
	}

	// ****************订单详情页--订单维护操作***********************
	// 保险详情页--订单退保
	@Test(dataProvider = "insurance_surenderOrder", priority = 34, groups = {
			"详情页退保" }, dataProviderClass = DataProviderApp.class)
	public static void orderSurrender(String name) throws Exception {
		Thread.sleep(2000);
		// OrderDetailAction.excutOpenOrderManageAction();
		// OrderDetailAction.excutUnderWriteAction();

		Thread.sleep(2000);
		// 点击退保
		OrderDetailAction.excutSurrenderAction();
		// 选中退保人
		OrderDetailAction.excutSurrenderChooseAction(name);
		Thread.sleep(2000);
		// 提交退保
		OrderDetailAction.excutSurrenderSubmmitAction();
	}

	// 保险详情页--订单取消投保
	@Test(dataProvider = "insurance_cancelInsureOrder", priority = 34, groups = {
			"详情页取消投保" }, dataProviderClass = DataProviderApp.class)
	public static void insureCancel(String name) throws Exception {
		// System.out.print("driver value"+currentDriver);
		// System.out.print("driver value"+OrderDetailAction.webdriver);
		//OrderDetailAction.transmitDriver(currentDriver);
		Thread.sleep(2000);
		// OrderDetailAction.excutOpenOrderManageAction();
		// OrderDetailAction.excutUnderWriteAction();
		//System.out.print("当前的url是："+currentDriver.getCurrentUrl());
		// 点击取消投保
		OrderDetailAction.excutCancelInsureAction();
		// 选中取消投保人
		OrderDetailAction.excutCancelInsureChooseAction(name);
		// 提交取消投保
		OrderDetailAction.excutCancelInsureSubmmitAction();
	}

	// 保险详情页--订单投保
	@Test(priority = 34, groups = { "详情页投保" }, retryAnalyzer = RetryFail.class)
	public static void insure(String password) throws Exception {
		// 点击投保
		OrderDetailAction.excutUnderWriteAction();
	}

	// 保险详情页--订单支付
	@Test(dataProvider = "insurance_payOrder", priority = 34, groups = {
			"详情页订单支付" }, dataProviderClass = DataProviderApp.class, retryAnalyzer = RetryFail.class)
	public static void orderPay(String password) throws Exception {
		// 点击支付
		OrderDetailAction.excutOrderPayAction();
		// driver传递
		OrderPayAction.transmitDriver(currentDriver);
		// 输入支付密码，默认使用账户支付
		OrderPayAction.excutInputPasswordAction(password);
		// 确认付款
		OrderPayAction.excutPayAffirmAction();
	}

	// 保险详情页--订单取消
	@Test(priority = 34, groups = { "详情页订单取消" })
	public static void orderCancel() throws Exception {

		// OrderDetailAction.transmitDriver(currentDriver);
		Thread.sleep(1000);

		// System.out.println("currentDriver:"+currentDriver);
		// OrderDetailAction.excutOpenOrderManageAction();

		// 点击取消
		// OrderListAction.excutCancelOrderAction();
		//
		// OrderListAction.excutCancelOrderConfirmAction();
		OrderDetailAction.excutCancelOrderAction();
		Thread.sleep(2000);
		// 确认取消
		OrderDetailAction.excutCancelOrderConfirmAction();
		Thread.sleep(1000);

	}
	//订单详情页--信息检查
	
	@Test(priority = 33, groups = { "详情页信息检查" })
	public static void orderDetailCheckPoint() throws Exception {

		InsureOrderDetailCheckPoint.OrderDetails(currentDriver);
		

	}
	
}

package com.travelzen.Insurance.OperatorInsurance.AppModules;

import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.ProductManagePage;
import com.travelzen.Utility.LogCenter.Log;

/**
 * 产品管理页面 元素Action
 * @author Weixing.Yang
 *
 */
public class ProductManageAction {
	
	private static WebDriver webDriver;

	//传递当前Driver
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webDriver = driver;
		ProductManagePage.getDriver(webDriver);
	}
	
	//产品管理页面中 , 点击 “订单管理” 菜单
	public static void excuteOrderManageAction() throws Exception{
		
		ProductManagePage.getOrderManageElement().click();
		Log.info("点击 “订单管理” 菜单");
	}
	
	//产品管理页面中 , 点击 “产品管理” 菜单
	public static void excuteProductManageAction() throws Exception{
		
		ProductManagePage.getProductManageElement().click();
		Log.info("点击 “产品管理” 菜单");
	}
	
	//产品管理页面中 , 点击 “售价维护” 菜单
	public static void excuteSalePriceAction() throws Exception{
		
		ProductManagePage.getSalePriceElement().click();
		Log.info("点击 “售价维护” 菜单");
	}
	
	//产品管理页面中 , 点击 “新增产品” 按钮
	public static void excuteAddProductButtonAction() throws Exception{
		
		ProductManagePage.getAddProductButtonElement().click();
		Log.info("点击 “新增产品” 按钮");
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//产品名称
	public static String excuteProductNameAction(String productName) throws Exception{
		
		String pName = ProductManagePage.getProductNameElement(productName).getText();
		Log.info("“产品名称” 字段值：" + pName);
		return pName;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//点击“修改”按钮
	public static void excuteModifyProductAction() throws Exception{
		
		ProductManagePage.getModifyProductElement().click();
		Log.info("点击 “修改” 按钮");
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//点击“挂起”按钮
	public static void excuteDeleteProductAction() throws Exception{
		
		ProductManagePage.getDeleteProductElement().click();
		Log.info("点击 “挂起” 按钮");
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//保险公司名称
	public static String excuteCompanyNameAction() throws Exception{
		
		String pName = ProductManagePage.getCompanyNameElement().getText();
		Log.info("“保险公司名称” 字段值：" + pName);
		return pName;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//险种名称
	public static String excuteTypeNameAction() throws Exception{
		
		String pName = ProductManagePage.getTypeNameElement().getText();
		Log.info("“险种名称” 字段值：" + pName);
		return pName;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//险种编号
	public static String excuteTypeCodeAction() throws Exception{
		
		String pName = ProductManagePage.getTypeCodeElement().getText();
		Log.info("“险种编号” 字段值：" + pName);
		return pName;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//保险期限
	public static String excuteDeadlineAction() throws Exception{
		
		String pName = ProductManagePage.getDeadlineElement().getText();
		Log.info("“保险期限” 字段值：" + pName);
		return pName;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//最高保额(元)
	public static String excuteInsuranceAmountAction() throws Exception{
		
		String pName = ProductManagePage.getInsuranceAmountElement().getText();
		Log.info("“最高保额(元)” 字段值：" + pName);
		return pName;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//面价
	public static String excuteNormalPriceAction() throws Exception{
		
		String pName = ProductManagePage.getNormalPriceElement().getText();
		Log.info("“面价” 字段值：" + pName);
		return pName;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//底价
	public static String excuteUpsetPriceAction() throws Exception{
		
		String pName = ProductManagePage.getUpsetPriceElement().getText();
		Log.info("“底价” 字段值：" + pName);
		return pName;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//适用范围
	public static String excuteInsuranceScopeTemAction() throws Exception{
		
		String pName = ProductManagePage.getInsuranceScopeTemElement().getText();
		Log.info("“适用范围” 字段值：" + pName);
		return pName;
	}
}

package com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;
import com.travelzen.Utility.LogCenter.Log;

public class OrderManageRetreatOrderCompleteAction {



	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		OrderManageRetreatOrderCompletePage.getWebDriver(driver);
	}
	// Location 创建调账单，link
	@Test
	public static void excut_AdjustmentOrder_Click() throws Exception {

		OrderManageRetreatOrderCompletePage.getView_AdjustmentOrder_Link().click();
	}
	// Location 修改订单，link
	@Test
	public static void getModify_RetreatOrder_Link() throws Exception {

		OrderManageRetreatOrderCompletePage.getModify_RetreatOrder_Link().click();
		}
	
	
}

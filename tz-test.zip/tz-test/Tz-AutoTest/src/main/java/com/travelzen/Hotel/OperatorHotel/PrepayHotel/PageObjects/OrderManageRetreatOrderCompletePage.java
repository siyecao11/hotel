package com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.Log;

public class OrderManageRetreatOrderCompletePage {
	public static WebDriver driver;
	private static WebElement element;
	private static List<WebElement> elementList;
	private static List<Select> selectList;
	private static Select oSelection;
	private static List<WebElement> chkBx_PeriodTime;

	//退订单完成页面
	//创建调账单、修改订单

	@Test
	public static void getWebDriver(WebDriver webdriver) {

		driver = webdriver;
	}
	
	// Location 创建调账单，link
	@Test
	public static WebElement getView_AdjustmentOrder_Link() throws Exception {

		// getConfirmBooking_Link().click();
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='adjustment_operator_view_order']/span[2]"));
			Log.info("View_AdjustmentOrder_Link element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error( "View_AdjustmentOrder_Link element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}
	// Location 修改订单，link
	@Test
	public static WebElement getModify_RetreatOrder_Link() throws Exception {

		// getConfirmBooking_Link().click();
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='operator_modify_refund_order']/span[2]"));
			Log.info("View_AdjustmentOrder_Link element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error( "View_AdjustmentOrder_Link element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}
	
	
}

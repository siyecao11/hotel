package com.travelzen.Utility.ResultCollection;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.travelzen.Utility.Assertion.Assertion;

@Listeners({com.travelzen.Utility.Assertion.AssertionListener.class, com.travelzen.Utility.ResultCollection.CustomReporter.class })
//@Listeners({ com.travelzen.Utility.Assertion.AssertionListener.class })
public class Demo {

	@DataProvider
	public Object[][] dataProvider() {
		return new Object[][] { { 7 }, { 8} };
	}

	@Test(dataProvider = "dataProvider")
	public void testAssert1(int a) {
//		Assert.assertEquals(7, a);
		Assertion.verifyEquals(7, a);
	}

	@Test
	public void testAssert2() {
		Assert.assertEquals("2", "2");
//		Assertion.verifyEquals(2, 2);
	}
	
	@AfterClass
	public void showR() throws Exception{
		
		Report.showReport();
	}	
	
}

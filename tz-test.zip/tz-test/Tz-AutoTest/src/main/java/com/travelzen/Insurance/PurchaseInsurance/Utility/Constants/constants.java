package com.travelzen.Insurance.PurchaseInsurance.Utility.Constants;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import com.travelzen.Hotel.OperatorHotel.PrepayHotel.Utility.Constants.BookingHotel;
import com.travelzen.Utility.DataDriver.ExcelAction;
import com.travelzen.Utility.LogCenter.Log;
import com.travelzen.Utility.ResultCollection.Report;
public class constants {

	//保险订单管理URL
	public static final String OrderManageURL = "http://astore.op3.tdxinfo.com/tops-front-purchaser-additional/additional/insurance/order/orderSearch";

	//正常保单ID
	public static String NormalOrderId;
	//退保保单ID
	public static String surenderOrderId;
	//取消投保保单ID
	public static String cancelInsureOrderId;
	//
	public static String PolicyID;
	
}

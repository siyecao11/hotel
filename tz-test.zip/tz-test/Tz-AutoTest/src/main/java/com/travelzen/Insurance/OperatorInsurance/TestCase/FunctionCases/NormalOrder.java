package com.travelzen.Insurance.OperatorInsurance.TestCase.FunctionCases;
/**
 * author：qiqi.wang
 * */
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.travelzen.Insurance.OperatorInsurance.TestCase.CheckPoints.OrderDetailsCheckPoint;
import com.travelzen.Insurance.OperatorInsurance.TestCase.CheckPoints.OrderSearchCheckPoint;
import com.travelzen.Insurance.OperatorInsurance.TestCase.CheckPoints.PolicySearchCheckPoint;
import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.*;
import com.travelzen.Insurance.OperatorInsurance.Utility.Utils.DataProviderApp;
import com.travelzen.Insurance.OperatorInsurance.AppModules.CreateOrderAction;
import com.travelzen.Insurance.OperatorInsurance.AppModules.DraftOrderAction;
import com.travelzen.Insurance.OperatorInsurance.AppModules.OrderDetailAction;
import com.travelzen.Insurance.OperatorInsurance.AppModules.OrderManageAction;
import com.travelzen.Insurance.OperatorInsurance.AppModules.OrderPaymentAction;
import com.travelzen.Insurance.OperatorInsurance.AppModules.OrderSearchAction;
import com.travelzen.Insurance.OperatorInsurance.AppModules.PolicySearchAction;
import com.travelzen.Insurance.OperatorInsurance.AppModules.StayPaymentAction;
import com.travelzen.Login.OperatorLogin.TestCase.FunctionCases.LoginOperator;
import com.travelzen.Utility.Constants.Constants;
import com.travelzen.Utility.ScreenShot.RetryFail;
import com.travelzen.Utility.Utils.Utils;
@Listeners({com.travelzen.Utility.Assertion.AssertionListener.class, com.travelzen.Utility.ResultCollection.CustomReporter.class,com.travelzen.Utility.ScreenShot.ScreenShotListener.class,com.travelzen.Utility.ScreenShot.RetryListener.class})
public class NormalOrder {
	
	public static WebDriver currentDriver; 
	
	@BeforeClass(alwaysRun=true)
	public static void beforeClass(){
		currentDriver = LoginOperator.driver;
	}
	
	@BeforeMethod(alwaysRun=true)
	public static void beforeMethod(){
		Constants.classDriver= currentDriver;
		System.out.println("-----------"+Constants.classDriver);
	}
	
	//进入订单管理页面
	@Test(retryAnalyzer = RetryFail.class, priority = 2, groups = {"保险运营商正常单创建"})
	public void OrderManageInto() throws Exception{
		//进入保险的订单管理模块
		currentDriver.get(Constant.ORDERMANAGEURL);
	}
	
	//进入订单查询页面
	@Test(retryAnalyzer = RetryFail.class, priority = 3, groups = {"保险运营商正常单创建"})
	public void OrderSearchInto() throws Exception{
		OrderManageAction.transmitDriver(currentDriver);
		//点击订单查询，进入订单查询页面
		OrderManageAction.excuteOrderSearchLabel();
	}
	
	//进入创建订单页面
	@Test(retryAnalyzer = RetryFail.class, priority = 4, groups = {"保险运营商正常单创建"})
	public void CreateNormalOrderInto() throws Exception{
		//点击新建订单按钮，进入创建订单页面
		OrderSearchAction.transmitDriver(currentDriver);
		OrderSearchAction.excuteCreateOrderBtn();		
	}
	
	//创建订单
	@Test(dataProvider="NormalCreateOrder",retryAnalyzer = RetryFail.class, dataProviderClass = DataProviderApp.class, priority = 5, groups = {"保险运营商正常单创建"})
	public void CreateNormalOrder(String CustomerShortName,String InsuranceCoverage,String ProductName,String PersonNum,String StartDate,String CustomerName,String CustomerMobile,
			String IDType,String IDNum,String BirthDate,String Sex,String InsuranceNum) throws Exception{
		
		CreateOrderAction.transmitDriver(currentDriver);
		//点击客户窗口按钮
		CreateOrderAction.excuteCustomerNameBtn();
		Utils.waitForElement(2, currentDriver, "wait");
		//填写客户简称
		CreateOrderAction.excuteCustomerShortNameInput(CustomerShortName);
		Utils.waitForElement(1, currentDriver, "wait");
		//点击搜索客户按钮
		CreateOrderAction.excuteCustomerSearchBtn();
		Utils.waitForElement(2, currentDriver, "wait");
		//选择客户
		CreateOrderAction.excuteCustomerSelect();
		Utils.waitForElement(1, currentDriver, "wait");
		//选择保险范围
		CreateOrderAction.excuteInsuranceCoverageSelect(InsuranceCoverage);
		//点击搜索保险产品按钮
		CreateOrderAction.excuteInsuranceProductSearchBtn();
		Utils.waitForElement(1, currentDriver, "wait");
		//获取联系人姓名-存入常量
		CreateOrderAction.excuteConstactName();
		//获取联系人电话-存入常量
		CreateOrderAction.excuteConstactTel();
		//获取联系人手机号-存入常量
		CreateOrderAction.excuteConstactMobile();
		//选择保险产品
		CreateOrderAction.excuteInsuranceProductSelect(ProductName);
		//选择被保人数
		CreateOrderAction.excuteInsurancePersonNumSelect(PersonNum);
		//选择保险生效时间
		CreateOrderAction.excuteInsuranceStartDate(StartDate);
		//填写被保人姓名
		CreateOrderAction.excuteCustomerNameInput(CustomerName);
		//填写被保人手机号码
		CreateOrderAction.excuteCustomerMobileInput(CustomerMobile);
		//填写被保人证件类型
		CreateOrderAction.excuteIDTypeSelect(IDType);
		//填写被保人证件号码
		CreateOrderAction.excuteIDNumInput(IDNum);
		//填写被保人出生日期
		CreateOrderAction.excuteBirthDateInput(BirthDate);
		//填写被保人性别
		CreateOrderAction.excuteSexTypeSelect(Sex);
		//选择保险份数
		CreateOrderAction.excuteInsuranceNumSelect(InsuranceNum);
		//点击保存订单按钮
		CreateOrderAction.excuteSaveOrderBtn();		  
	}
	
	//订单草稿页面-提交订单
	@Test(retryAnalyzer = RetryFail.class, priority = 6, groups = {"保险运营商正常单创建"})
	public void SubmitNormalOrder() throws Exception{
		//点击提交订单按钮，进入待提交页面
		DraftOrderAction.transmitDriver(currentDriver);
		//点击提交订单按钮
		DraftOrderAction.excuteSubmitOrderBtn();
		//点击确认提交按钮
		DraftOrderAction.excuteConfirmSubmitOrderBtn();		
	}
	
	//订单待支付页面-支付
	@Test(retryAnalyzer = RetryFail.class, priority = 7, groups = {"保险运营商正常单创建"})
	public void StayPaymentOrder() throws Exception{
		//点击提交订单按钮，进入待支付页面
		StayPaymentAction.transmitDriver(currentDriver);
		StayPaymentAction.excutePayOrderBtn();
		StayPaymentAction.excuteConfirmPayOrderBtn();
	}
	
	//订单支付成功页面
	@Test(retryAnalyzer = RetryFail.class, priority = 8, groups = {"保险运营商正常单创建"})
	public void PaymentOrder() throws Exception{
		//进入支付成功页面，获取订单号和支付金额
		OrderPaymentAction.transmitDriver(currentDriver);
		OrderPaymentAction.excuteOrderId();
		OrderPaymentAction.excuteOrderPayment();
	}
	
	//搜索订单，进入订单详情页
	@Test(retryAnalyzer = RetryFail.class, priority = 9, groups = {"保险运营商正常单创建"})
	public void SearchOrder() throws Exception{
		//进入订单查询页面，以订单号查询订单
		currentDriver.get(Constant.ORDERMANAGEURL);
		OrderSearchAction.transmitDriver(currentDriver);
		//订单输入框中输入订单号
		OrderSearchAction.excuteInputOrderID(Constant.OperatorOrderId);
		//点击搜索按钮-搜索订单
		OrderSearchAction.excuteOrderSearch();
		//检查订单列表信息
		OrderSearchCheckPoint.OrderSearch(currentDriver);
		//点击订单号-进入订单详情页面
		OrderSearchAction.transmitDriver(currentDriver);
		OrderSearchAction.excuteOrderIDClick();
		
	}
	
	//订单详情页面
	@Test(priority = 10, groups = {"保险运营商正常单创建"})
	public void OrderDetail() throws Exception{
		OrderSearchAction.switchToWindow(currentDriver);
		OrderDetailAction.transmitDriver(currentDriver);
		//点击添加备注按钮
		OrderDetailAction.excuteAddOrderRemark();
		//添加客户备注
		OrderDetailAction.excuteAddCustomerRemark("客户备注测试");
		//添加内部备注
		OrderDetailAction.excuteAddInsideRemark("内部备注测试");
		//点击保存按钮
		OrderDetailAction.excuteSaveRemark();
		OrderDetailsCheckPoint.OrderDetails(currentDriver);
	}
	
		//订单管理页面
		@Test(retryAnalyzer = RetryFail.class, priority = 11,groups = {"保险运营商正常单创建"})
		public void PolicySearchInto() throws Exception{
			OrderManageAction.transmitDriver(currentDriver);
			//点击保单查询按钮，进入保单查询页面
			OrderManageAction.excutePolicySearchLabel();
			
		}
		
		//保单查询页面
		@Test(retryAnalyzer = RetryFail.class, priority = 12,groups = {"保险运营商正常单创建"})
		public void PolicySearch() throws Exception{
			PolicySearchAction.transmitDriver(currentDriver);
			//输入保单号
			Utils.waitForElement(2, currentDriver, "wait");
			PolicySearchAction.excutePolicyNumInput();
			//点击搜索按钮
			PolicySearchAction.excutePolicySearchBtn();
			//检查保单列表信息
			PolicySearchCheckPoint.OrderSearch(currentDriver);
			
		}
		
		
		
		
		
		
		
		
		
	
  }

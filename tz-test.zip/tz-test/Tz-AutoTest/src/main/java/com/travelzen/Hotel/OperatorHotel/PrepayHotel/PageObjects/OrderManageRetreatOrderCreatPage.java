package com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.Log;

public class OrderManageRetreatOrderCreatPage {
	
	public static WebDriver driver;
	private static WebElement element;
	
	//创建退订单
	public static void GetDriver(WebDriver webdriver) {

		driver = webdriver;
	}
	
	// ********************创建退订单*********************
	// 获取酒店创建退订单页面元素
	@Test
	public static WebElement getCreat_RetreatOrder_Link() throws Exception {

		// getConfirmBooking_Link().click();
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='operator_create_refund_order']/span[2]"));
			Log.info(" Creat_RetreatOrder_Link element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error(" Creat_RetreatOrder_Link element is not found in OrderManage_RetreatOrder Page");
		}
		return element;
	}
	// ********************创建退订单*********************
		// 获取酒店退订单页面订单号
		@Test
		public static WebElement getCreat_RetreatOrderId() throws Exception {

			// getConfirmBooking_Link().click();
			try {
				element = driver.findElement(By
						.xpath(".//*[@id='mainContent']/div[3]/div[5]/div[1]/div/span[2]"));
				Log.info(" Creat_RetreatOrder_ID element is found in OrderManage_RetreatOrder Page");
			} catch (Exception e) {
				Log.error(" Creat_RetreatOrder_ID element is not found in OrderManage_RetreatOrder Page");
			}
			return element;
		}

}

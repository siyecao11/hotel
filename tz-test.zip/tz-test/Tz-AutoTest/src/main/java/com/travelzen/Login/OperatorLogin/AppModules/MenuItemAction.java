package com.travelzen.Login.OperatorLogin.AppModules;

import org.testng.annotations.Test;

import com.travelzen.Login.OperatorLogin.PageObjects.WelecomePage;
import com.travelzen.Utility.LogCenter.Log;

import org.openqa.selenium.WebDriver;

public class MenuItemAction {
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		WelecomePage.getWebDriver(driver);
	}

	@Test
	public static void excuteHotel() throws Exception {
		
		//Click hotel menItem, goto hotel HomePage
		WelecomePage.getHotelMenu().click();
		Log.info(" Hotel menuItem is clicked, now enter into hotel page");
	}
	
	@Test
	public static void excuteDomesticFlight() throws Exception {
		
		//Click hotel menItem, goto DomesticFlight HomePage
		WelecomePage.getDomesticFlightMenu().click();
		Log.info(" DomesticFlight menuItem is clicked, now enter into hotel page");
	}
	
	@Test
	public static void excuteInternationalFlight() throws Exception {
		
		//Click hotel menItem, goto InternationalFlight HomePage
		WelecomePage.getInternationalFlightMenu().click();
		Log.info(" InternationalFlight menuItem is clicked, now enter into hotel page");
	}
	
	@Test
	public static void excuteAdditional() throws Exception {
		
		//Click hotel menItem, goto Additional HomePage
		WelecomePage.getAdditionalMenu().click();
		Log.info(" Additional menuItem is clicked, now enter into hotel page");
	}
	
	public static String getUserName() throws Exception{
		
		String username = "";
		//获取用户姓名信息
		System.out.println("TTTT:" + username);
		username = WelecomePage.getUserNameInfo().getText();
		System.out.println("AAAA:" + username);
		Log.info("用户姓名：" + username);
		return username;
	}
	
}

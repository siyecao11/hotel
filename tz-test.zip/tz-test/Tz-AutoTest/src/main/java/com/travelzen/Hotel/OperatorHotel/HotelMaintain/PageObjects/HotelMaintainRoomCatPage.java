package com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects;

import java.sql.Array;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.HotelMaintain.utility.Constants.*;
import com.travelzen.Utility.LogCenter.Log;

public class HotelMaintainRoomCatPage {

	public static WebDriver driver;
	private static WebElement element;
	private static List<WebElement> elementList;
	private static List<Select> selectList;
	private static Select oSelection;
	private static String value;

	// private static List<Select> selectNumList;

	@Test
	public static void getWebDriver(WebDriver webdriver) {

		driver = webdriver;

	}

	// Location  添加房型 element
	@Test
	public static WebElement getAddRoom_Type() throws Exception {

		try {
			element = driver.findElement(By.id("addroomtype"));
			Log.info("AddRoomType element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("AddRoomType element is not found in RoomCat Page");
		}
		return element;
	}

	// 添加房型弹窗
	// 获取打包产品信息
	@Test
	public static WebElement getPackagedSales() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_addRoomCat']/table/tbody/tr[1]/td/input"));
			Log.info("PackagedSales element is found in RoomCat Page");
			// element.click();
			// Log.info("PackagedSales has been clicked");
		} catch (Exception e) {
			Log.error("PackagedSales element is not found in RoomCat Page");
		}
		return element;
	}
	//获取房型名称 Name  text
	@Test
	public static WebElement getRoomName() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_addRoomCat']/table/tbody/tr[2]/td[1]/input"));
			Log.info("RoomName element is found in RoomCat Page");

		} catch (Exception e) {
			Log.error("RoomName element is not found in RoomCat Page");
		}
		return element;
	}
	
	//获取入住人数  CapaciyNo select
	@Test
	public static Select getCapaciyNo() throws Exception {
		try {
			oSelection = new Select(
					driver.findElement(By
							.xpath(".//*[@id='frm_addRoomCat']/table/tbody/tr[2]/td[2]/select")));
			// selectList = oSelection.getOptions();
			Log.info("CapaciyNo element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("CapaciyNo element is not found in RoomCat Page");
		}
		return oSelection;
	}
	//获取套内面积 InsideSpace text
	@Test
	public static WebElement getInsideSpace() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_addRoomCat']/table/tbody/tr[3]/td[1]/input"));
			Log.info("InsideSpace element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("InsideSpace element is not found in RoomCat Page");
		}
		return element;
	}
	//获取开始楼层 StartFloor text
	@Test
	public static WebElement getFloorNum1() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_addRoomCat']/table/tbody/tr[3]/td[2]/span/input[1]"));
			Log.info("FloorNum1 element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("FloorNum1 element is not found in RoomCat Page");
		}
		return element;
	}
	//获取结束楼层 EndFloor text
	@Test
	public static WebElement getFloorNum2() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_addRoomCat']/table/tbody/tr[3]/td[2]/span/input[2]"));
			Log.info("FloorNum2 element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("FloorNum2 element is not found in RoomCat Page");
		}
		return element;
	}
	//获取窗户信息 HotelWindow select
	@Test
	public static Select getHotelWindow() throws Exception {
		try {
			oSelection = new Select(
					driver.findElement(By
							.xpath(".//*[@id='frm_addRoomCat']/table/tbody/tr[3]/td[3]/select")));
			// elementList = oSelection.getOptions();
			Log.info("HotelWindow element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("HotelWindow element is not found in RoomCat Page");
		}
		return oSelection;
	}
	//获取床型 BedType RadioBtn 
	@Test
	public static WebElement getRoomBedType(String bedtype) throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_addRoomCat']/table/tbody/tr[4]/td/label["
									+ bedtype + "]/input"));
			Log.info("RoomBedType is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("RoomBedType is not found in RoomCat Page");
		}
		// return elementList;
		return element;
	}
	//获取床尺寸 BedSize select
	@Test
	public static Select getBedSize() throws Exception {
		try {
			
			driver.findElement(By
					.xpath(".//*[@id='sel_bedSize1']")).click();
			
			oSelection = new Select(driver.findElement(By
					.xpath(".//*[@id='sel_bedSize1']")));
			//elementList = oSelection.getOptions();
			Log.info("BedSize is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("BedSize is not found in RoomCat Page");
		}
		return oSelection;
	}
	//获取房间设施 RoomFacilities checkBox
	@Test
	public static WebElement getRoomFacilities(int fNum) throws Exception {
		try {
			// elementList =
			// driver.findElements(By.cssSelector("input[type='checkbox']"));
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_addRoomCat']/table/tbody/tr[6]/td/ul/li["
									+ fNum + "]/label/input"));
			Log.info("RoomFacilities list is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("RoomFacilities list is not found in RoomCat Page");
		}
		return element;
	}

	//获取房间备注 RoomRemark text
	@Test
	public static WebElement getRoomRemark() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_addRoomCat']/table/tbody/tr[9]/td/textarea"));
			Log.info("RoomRemark element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("RoomRemark element is not found in RoomCat Page");
		}
		return element;
	}
	//获取保存按钮 SaveButton Btn
	@Test
	public static WebElement getSaveButton() throws Exception {
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='frm_addRoomCat']/div/a[1]"));
			Log.info("SaveButton element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("SaveButton element is not found in RoomCat Page");
		}
		return element;
	}
	//获取取消按钮 CloseButton Btn
	@Test
	public static WebElement getCloseButton() throws Exception {
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='frm_addRoomCat']/div/a[2]"));
			Log.info("CloseButton element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("CloseButton element is not found in RoomCat Page");
		}
		return element;
	}
	// get delete roomCat element
	// To get roomCat ID
	@Test
	public static WebElement getDeletRoomCat() throws Exception {
		try {
			element = driver.findElement(By
					.cssSelector("a[id='deleteRoomCat-0']"));
			Log.info("DeletRoomCat element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("DeletRoomCat element is not found in RoomCat Page");
		}
		return element;
	}
	// get 编辑 房型 element
	// To get roomCat ID
	@Test
	public static WebElement getEditRoomCat() throws Exception {
		try {
			element = driver.findElement(By
					.id("editRoomCat-0"));
			Log.info("EditRoomCat element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("EditRoomCat element is not found in RoomCat Page");
		}
		return element;
	}


	// get BookingClassItem element
	// goto bookingClass edit page
	@Test
	public static WebElement getBookingClassItemElement() throws Exception {
		try {
			element = driver.findElement(By.id("bookingClass"));
			Log.info("BookingClassItem element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("BookingClassItem element is not found in RoomCat Page");
		}
		return element;
	}

	//***************************************************************************************************************
		//**********************酒店房型  检查点元素定位****************************
		//***************************************************************************************************************
	// 编辑房型弹窗
	// 获取打包产品信息
	@Test
	public static WebElement getEPackagedSales() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_editRoomCat_0']/div/table/tbody/tr[1]/td/input"));
			Log.info("Edit PackagedSales element is found in RoomCat Page");
			// element.click();
			// Log.info("PackagedSales has been clicked");
		} catch (Exception e) {
			Log.error("Edit PackagedSales element is not found in RoomCat Page");
		}
		return element;
	}
	//获取房型名称 Name  text
	@Test
	public static WebElement getERoomName() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_editRoomCat_0']/div/table/tbody/tr[2]/td[1]/input"));
			Log.info("Edit RoomName element is found in RoomCat Page");

		} catch (Exception e) {
			Log.error("Edit RoomName element is not found in RoomCat Page");
		}
		return element;
	}
	
	//获取入住人数  CapaciyNo select
	@Test
	public static WebElement getECapaciyNo() throws Exception {
		try {
			element =driver.findElement(By
							.xpath(".//*[@id='frm_editRoomCat_0']/div/table/tbody/tr[2]/td[2]/select"));
			// selectList = oSelection.getOptions();
			Log.info("Edit CapaciyNo element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("Edit CapaciyNo element is not found in RoomCat Page");
		}
		return element;
	}
	
	//获取套内面积 InsideSpace text
	@Test
	public static WebElement getEInsideSpace() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_editRoomCat_0']/div/table/tbody/tr[3]/td[1]/input"));
			Log.info("Edit InsideSpace element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("Edit InsideSpace element is not found in RoomCat Page");
		}
		return element;
	}
	//获取开始楼层 StartFloor text
	@Test
	public static WebElement getEFloorNum1() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_editRoomCat_0']/div/table/tbody/tr[3]/td[2]/span/input[1]"));
			Log.info("Edit FloorNum1 element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("Edit FloorNum1 element is not found in RoomCat Page");
		}
		return element;
	}
	//获取结束楼层 EndFloor text
	@Test
	public static WebElement getEFloorNum2() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_editRoomCat_0']/div/table/tbody/tr[3]/td[2]/span/input[2]"));
			Log.info("Edit FloorNum2 element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("Edit FloorNum2 element is not found in RoomCat Page");
		}
		return element;
	}
	//获取窗户信息 HotelWindow select
	@Test
	public static WebElement getEHotelWindow() throws Exception {
		try {
			element = driver.findElement(By
							.xpath(".//*[@id='frm_editRoomCat_0']/div/table/tbody/tr[3]/td[3]/select"));
			// elementList = oSelection.getOptions();
			Log.info("Edit HotelWindow element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("Edit HotelWindow element is not found in RoomCat Page");
		}
		return element;
	}
	//获取床型 BedType RadioBtn 
	@Test
	public  static String getERoomBedType() throws Exception {
		try {

			// Start the loop from first Check Box to last Check Boxe
			for(int i=0; i < 6 ; i++ ){
				// Store the Check Box name to the string variable, using 'Value' attribute
				element = driver.findElement(By.xpath(".//*[@id='frm_editRoomCat_0']/div/table/tbody/tr[4]/td/label["+i+"]/input"));
				Log.info("element is "+element);
				String sValue = element.getAttribute("checked");
				Log.info("sValue "+sValue);
				// Select the Check Box it the value of the Check Box is same what you are looking for
				if (sValue.equalsIgnoreCase("true")){
					//element =  elementList.get(i);
					value = Integer.toString(i+1);
					Log.info("Edit RoomCat RoomBedType value "+value+" is got");
				// This will take the execution out of for loop
				break;
				}
			}
		} catch (Exception e) {
			Log.error("Edit RoomBedType is not found in RoomCat Page");
		}
		// return elementList;
		 return value;
	}
	//获取房间设施 RoomFacilities checkBox
	@Test
	public static WebElement getERoomFacilities(int fNum) throws Exception {
		try {
			// elementList =
			// driver.findElements(By.cssSelector("input[type='checkbox']"));
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_editRoomCat_0']/div/table/tbody/tr[6]/td/ul/li["
									+ fNum + "]/label/input"));
			Log.info("Edit RoomFacilities list is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("Edit RoomFacilities list is not found in RoomCat Page");
		}
		return element;
	}

	//获取房间备注 RoomRemark text
	@Test
	public static WebElement getERoomRemark() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='frm_editRoomCat_0']/div/table/tbody/tr[9]/td/textarea"));
			Log.info("Edit RoomRemark element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("Edit RoomRemark element is not found in RoomCat Page");
		}
		return element;
	}
	 
	//获取取消按钮 CloseButton Btn
	@Test
	public static WebElement getECloseButton() throws Exception {
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='frm_editRoomCat_0']/div/div/a[2]"));
			Log.info("Edit QuitButton element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("Edit QuitButton element is not found in RoomCat Page");
		}
		return element;
	}
	// get delete roomCat element
	// To get roomCat ID
	@Test
	public static WebElement getEDeletRoomCat() throws Exception {
		try {
			element = driver.findElement(By
					.cssSelector("a[id='deleteRoomCat-0']"));
			Log.info("Edit DeletRoomCat element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("Edit DeletRoomCat element is not found in RoomCat Page");
		}
		return element;
	}

	// get 价格计划 tab 元素
	// goto bookingClass edit page
	@Test
	public static WebElement getEBookingClassItemElement() throws Exception {
		try {
			element = driver.findElement(By.id("bookingClass"));
			Log.info("Edit BookingClassItem element is found in RoomCat Page");
		} catch (Exception e) {
			Log.error("BookingClassItem element is not found in RoomCat Page");
		}
		return element;
	}
}

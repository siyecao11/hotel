package com.travelzen.Utility.Constants;

import org.openqa.selenium.WebDriver;

public class Constants {
	public static WebDriver classDriver;
	public static String PolicyID;
}

package com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.CheckPoints;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.*;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
import com.travelzen.Utility.Assertion.*;
import com.travelzen.Utility.DataDriver.*;


//@Listeners({Hotel.OperatorHotel.PrepayHotel.utility.AssertionListener.class})
public class BookingHotelCheckPoint {

	@Test(priority = 11)
	public static void bookingHotelCheckPoint() throws Exception{
		
		String[] aRoomCats = new String[10];
		int j = 0;
		String eHotelName = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "hotelName");
		BookingHotelAction.HotelName(eHotelName);
		BookingHotelAction.SearchHotel();
		String aHotelName = BookingHotelPage.hotelListName().getText();
		String aHotelAddress = BookingHotelPage.hotelListAddress().getText();
		String aCustomerType = BookingHotelPage.hotelCustomerStyle().getText().substring(6);
		String aInnerRemarks = BookingHotelPage.hotelInnerRemarks().getText().substring(6);
		String aOuterRemarks = BookingHotelPage.hotelOuterRemarks().getText().substring(6);
		//获取实际的匹配政策ID值
		String aPolyicID = BookingHotelPage.polyicID().getAttribute("value");
		
		for(int i=0; i< BookingHotelPage.hotelRoomCat().size(); i++)
		{
			if(!BookingHotelPage.hotelRoomCat().get(i).getText().isEmpty())
			{
				j++;
				aRoomCats[j] = BookingHotelPage.hotelRoomCat().get(i).getText();
			}
		}
		String alilang = BookingHotelPage.hotelOuterRemarks().getAttribute(aInnerRemarks);
		
		String ePloyicID = Constant.ployicId;
		
		Assertion.verifyEquals(aPolyicID, ePloyicID, "期望匹配政策ID为" + ePloyicID + ";实际匹配的政策ID为" + aPolyicID);
		
	}
	
	@Test(priority = 12)
	public static void bookingHotelGuaqiCheckPoint() throws Exception{
		
		String aHotelName;
		
		for(int i=0; i<BookingHotelPage.hotelListNameList().size(); i++)
		{
			aHotelName = BookingHotelPage.hotelListNameList().get(i).getText();
			if(aHotelName.equals("杭州陆羽山庄"))
			{
				Assertion.verifyEquals(1, 0, "杭州陆羽山庄 酒店已挂起，但仍出现在酒店搜索结果列表中");
				return;
			}
			System.out.println(aHotelName);
		}
		Assertion.verifyEquals(1, 1, "挂起的 杭州陆羽山庄 酒店不在酒店搜索结果列表中");
	}
	
	@Test(priority = 13)
	public static void bookingHotelPloyicCheckPoint() throws Exception{
		
		//获取酒店房型下的所有BookingClass的 底价、加价、卖价、政策ID
		String[] basePrice = BookingHotelAction.basePriceAction();
		//加价
		String[] addPrice = BookingHotelAction.addPriceAction();
		//卖价
		String[] sellPrice = BookingHotelAction.sellPriceAction();
		//匹配政策ID
		String[] policyId = BookingHotelAction.policyIdAction();
		//bookingClass名称
		String[] bookingClassName = BookingHotelAction.bookingClassNameAction();
		//模拟一个加价规则，以List数组形式存储
		ArrayList<String> arr = new ArrayList<String>();
		//arr.add("底价≤200 +20");
		//arr.add("200<底价<500 +30");
		//arr.add("底价≥500 %110");
		arr.add("不限 +120");
		String eleaddPrice = "", eladdPrice = "", ebeaddPrice = "", ebaddPrice = "", eaddPrice = "";
		String rule;
		String leKey = "0", lKey = "0", beKey = "0", bKey = "0", key = "0";
		int ruleNum = 1;
		
		for (int i = 0; i < arr.size(); i++) {
			for (int j = 0; j < arr.get(i).length(); j++) {
				
				char item = arr.get(i).charAt(j);
				
				if (item == ' ') {
					rule = arr.get(i).substring(0, j);
					System.out.println("************");
					System.out.println(rule);
					if (rule.startsWith("底价≤")) {
						leKey = rule.substring(3);
						eleaddPrice = arr.get(i).substring(j + 1);

					}else if (rule.startsWith("底价<")) {
						lKey = rule.substring(3);
						eladdPrice = arr.get(i).substring(j + 1);
						
					}else if (rule.startsWith("底价≥")) {
						beKey = rule.substring(3);
						ebeaddPrice = arr.get(i).substring(j + 1);
						
					}else if (rule.startsWith("底价>")) {
						bKey = rule.substring(3);
						ebaddPrice = arr.get(i).substring(j + 1);
						
					} else if (rule.startsWith("不限")) {
						key = "不限";
						eaddPrice = arr.get(i).substring(j + 1);
						System.out.println("*****"+ eaddPrice +"******");
					}
					// System.out.println(eaddPrice);
				}
			}
		}
		
		for(int i = 0; i < basePrice.length; i++)
		{
			if(key.equals("不限")){
				System.out.println("酒店的加价为：" + Integer.parseInt(eaddPrice.substring(1)));
				Assertion.verifyEquals(addPrice[i], eaddPrice.substring(1), "酒店的期望加价为：" + eaddPrice.substring(1) + ",但实际加价为：" + addPrice[i]);
				break;
			}
			if(leKey.length() > 0 && Integer.parseInt(basePrice[i]) <= Integer.parseInt(leKey))
			{
				ruleNum = 1;
				if(eleaddPrice.startsWith("+"))
				{
					System.out.println("酒店的政策加价为：" + Integer.parseInt(eleaddPrice.substring(1)));
					Assertion.verifyEquals(basePrice[i], eleaddPrice.substring(1), "酒店的期望加价为：" + eaddPrice.substring(1) + ",但实际加价为：" + addPrice[i]);
				}
				else if(eleaddPrice.startsWith("%"))
				{
					System.out.println("酒店的政策加价为：" + Integer.parseInt(eleaddPrice.substring(1))%1.2*Integer.parseInt(basePrice[i]));
					double ep = Integer.parseInt(eleaddPrice.substring(1))%1.2*Integer.parseInt(basePrice[i]);
					Assertion.verifyEquals(basePrice[i], ep, "酒店的期望加价为：" + ep + ",但实际加价为：" + addPrice[i]);
				}
			}
			if(bKey.length() > 0 && Integer.parseInt(basePrice[i]) > Integer.parseInt(bKey))
			{
				ruleNum = 2;
				if(ebaddPrice.startsWith("+"))
				{
					System.out.println("酒店的政策加价为：" + Integer.parseInt(ebaddPrice.substring(1)));
					Assertion.verifyEquals(basePrice[i], ebaddPrice.substring(1), "酒店的期望加价为：" + ebaddPrice.substring(1) + ",但实际加价为：" + addPrice[i]);
				}
				else if(ebaddPrice.startsWith("%"))
				{
					System.out.println("酒店的政策加价为：" + Integer.parseInt(ebaddPrice.substring(1))%1.2*Integer.parseInt(basePrice[i]));
					double ep = Integer.parseInt(ebaddPrice.substring(1))%1.2*Integer.parseInt(basePrice[i]);
					Assertion.verifyEquals(basePrice[i], ep, "酒店的期望加价为：" + ep + ",但实际加价为：" + addPrice[i]);
				}
			}
			if(policyId[i].equals(Constant.ployicId))
			{
				//匹配的政策ID校验
				System.out.println("酒店匹配政策ID为： " + policyId[i]);
				Assertion.verifyEquals(policyId[i], Constant.ployicId, "酒店的期望匹配政策为：" + Constant.ployicId + ",但实际匹配政策为：" + policyId[i]);
			}
			//if(bookingClassName[i])
			System.out.println(basePrice[i]);
			System.out.println(addPrice[i]);
			System.out.println(sellPrice[i]);
			System.out.println(policyId[i]);
		}
	}
}



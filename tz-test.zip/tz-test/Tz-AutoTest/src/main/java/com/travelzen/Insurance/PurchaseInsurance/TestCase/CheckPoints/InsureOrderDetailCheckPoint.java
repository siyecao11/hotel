package com.travelzen.Insurance.PurchaseInsurance.TestCase.CheckPoints;

import org.openqa.selenium.WebDriver;
import com.travelzen.Utility.Assertion.Assertion;
import com.travelzen.Utility.DataDriver.ExcelAction;
import com.travelzen.Utility.LogCenter.Log;
import com.travelzen.Utility.ScreenShot.RetryFail;
import com.travelzen.Utility.Utils.*;
import com.travelzen.Insurance.PurchaseInsurance.Utility.Constants.constants;
import com.travelzen.Insurance.PurchaseInsurance.AppModules.*;

public class InsureOrderDetailCheckPoint {

	public static String productExcelName = "Insurance/Datas/p_productInfo.xls";
	public static String OrderDetailsExcelName = "Insurance/Datas/p_ordertailCheckPoint.xls";

	public static void OrderDetails(WebDriver currentDriver) throws Exception {
		String num = ExcelAction.getValue(OrderDetailsExcelName, "num");
		OrderDetailAction.transmitDriver(currentDriver);
		// 检查订单详情中的产品信息和订单详情信息
		// 获取订单号
		String OrderID = OrderDetailAction.excutGetOrderIdAction();
		Log.info(OrderID);
		// 获取产品名称-文本
		String ProductName = OrderDetailAction.excutGetProductNameAction();
		// 获取险种编号-文本
		String ProductID = OrderDetailAction.excutGetInsuranceIdAction();
		// 获取保险险种-文本
		String InsuranceType = OrderDetailAction.excutGetInsuranceTypeAction();
		// 获取保险期限-文本
		String InsuranceDeadLine = OrderDetailAction.excutGetInsurancePeriodAction();
		// 点单详情页面-最高保额-文本
		String InsuranceAmount = OrderDetailAction.excutGetPolicyMaximumAction();
		// 获取保险面价-文本
		String InsuranceFacePrice = OrderDetailAction.excutGetFacePriceAction();
		// 获取保险费用-文本
		String InsuranceCash = OrderDetailAction.excutGetInsuranceFeeAction();
		// 获取保险适用范围-文本
		String InsuranceScope = OrderDetailAction.excutGetApplicationAction();
		// 获取被保人姓名-文本
		String RecognizeeName = OrderDetailAction.excutGetInsureeNameAction(num);
		// 获取被保人证件类型-文本
		String RecognizeeCardStyle = OrderDetailAction.excutGetInsureeDocTypeAction(num);
		// 获取被保人证件号码-文本
		String RecognizeeCardID = OrderDetailAction.excutGetInsureeDocCodeAction(num);
		// 获取被保人性别-文本
		String RecognizeeSex = OrderDetailAction.excutGetInsureeGenderAction(num);
		// 获取被保人出生日期-文本
		String RecognizeeBirthday = OrderDetailAction.excutGetInsureeBirthdayAction(num);
		// 获取被保人手机号码-文本
		String RecognizeeMobilePhone = OrderDetailAction.excutGetInsureeMobilePhoneNameAction(num);
		// 获取保险生效日期-文本
		String InsuranceStartDate = OrderDetailAction.excutGetEffectiveDateAction(num);
		// 获取保单号-文本
		String PolicyID = OrderDetailAction.excutGetInsurerOrderIdAction(num);
		constants.PolicyID = PolicyID;
		// 获取保险份数-文本
		String InsuranceNumber = OrderDetailAction.excutGetCopiesAction(num);
		// 获取投保状态-文本
		String OrderState = OrderDetailAction.excutGetInsureStatusAction(num);
		// 获取投保人姓名-文本
		String ApplicantName = OrderDetailAction.excutGetInsureNameAction(num);
		// 获取证件类型-文本
		String ApplicantCardStyle = OrderDetailAction.excutGetInsureDocTypeAction(num);
		// 获取证件号码-文本
		String ApplicantCardID = OrderDetailAction.excutGetInsureDocCodeAction(num);
		// 获取投保人手机号码-文本
		String ApplicantMobilePhone = OrderDetailAction.excutGetInsurePhoneAction(num);
		// 获取应收合计-文本
		String TotalCast = OrderDetailAction.excutGetTotalPriceAction();
		// 获取保险份数-文本
		String InsuranceNum = OrderDetailAction.excutGetInsureAmountAction();
		// 获取结算保险费用-文本
		String InsurancePrice = OrderDetailAction.excutGetInsurefeeNameAction();

		// 获取产品信息
		String eOrderID = constants.cancelInsureOrderId;
		Log.info(eOrderID);
		String eProductName = ExcelAction.getValue(productExcelName, "productName");
		String eProductID = ExcelAction.getValue(productExcelName, "productId");
		String eInsuranceType = ExcelAction.getValue(productExcelName, "insuranceType");
		String eInsuranceDeadLine = ExcelAction.getValue(productExcelName, "insuranceDeadLine");
		String eInsuranceAmount = ExcelAction.getValue(productExcelName, "insuranceAmount");
		String eInsuranceFacePrice = ExcelAction.getValue(productExcelName, "insuranceFacePrice");
		String eInsuranceFee = ExcelAction.getValue(productExcelName, "insuranceFaceFee");
		String eInsuranceScope = ExcelAction.getValue(productExcelName, "insuranceScope");
		/*System.out.println(
				"期望产品信息（1）：" + eProductName + "期望产品信息（2）：" + eProductID + "期望产品信息（3）：" + eInsuranceType + "期望产品信息（4）："
						+ eInsuranceDeadLine + "期望产品信息（5）：" + eInsuranceAmount + "期望产品信息（6）：" + eInsuranceFacePrice);
		*/
		// 被保人信息
		String eRecognizeeName = ExcelAction.getValue(OrderDetailsExcelName, "insureeName");
		String eRecognizeeCardStyle = ExcelAction.getValue(OrderDetailsExcelName, "docType");
		String eRecognizeeCardID = ExcelAction.getValue(OrderDetailsExcelName, "docCode");
		String eRecognizeeSex = ExcelAction.getValue(OrderDetailsExcelName, "gender");
		String eRecognizeeBirthday = ExcelAction.getValue(OrderDetailsExcelName, "birthDate");
		String eRecognizeeMobilePhone = ExcelAction.getValue(OrderDetailsExcelName, "mobelPhone");
		String eInsuranceStartDate = ExcelAction.getValue(OrderDetailsExcelName, "effectiveDate");
		String eInsuranceNumber = ExcelAction.getValue(OrderDetailsExcelName, "insuranceAmount");
		String eOrderState = ExcelAction.getValue(OrderDetailsExcelName, "insuranceOrderState");
		/*System.out.println("期望产品信息（1）：" + eRecognizeeName + "期望产品信息（2）：" + eRecognizeeCardStyle + "期望产品信息（3）"
				+ eRecognizeeCardID + "期望产品信息（4）：" + eRecognizeeSex + "期望产品信息（5）：" + eRecognizeeBirthday + "期望产品信息（6）："
				+ eRecognizeeMobilePhone + "期望产品信息（6）：" + eInsuranceStartDate + "期望产品信息（6）：" + eInsuranceStartDate
				+ "期望产品信息（6）：" + eInsuranceNumber + "期望产品信息（6）：" + eOrderState);
		*/
		// 投保人信息
		String eApplicantName = ExcelAction.getValue(OrderDetailsExcelName, "insureName");
		String eApplicantCardStyle = ExcelAction.getValue(OrderDetailsExcelName, "insureDocType");
		String eApplicantCardID = ExcelAction.getValue(OrderDetailsExcelName, "insureDocCode");
		String eApplicantMobilePhone = ExcelAction.getValue(OrderDetailsExcelName, "insurePhone");
		System.out.println("期望产品信息（1）" + eApplicantName + "期望产品信息（2）" + eApplicantCardStyle + "期望产品信息（3）"
				+ eApplicantCardID + "期望产品信息（4）" + eApplicantMobilePhone);
		//结算信息
		String eInsuranceNum = ExcelAction.getValue(OrderDetailsExcelName, "insuranceAmount");
		String eInsurancePrice = ExcelAction.getValue(productExcelName, "insuranceFacePrice");
		String eTotalCast = Integer.toString(Integer.parseInt(eInsuranceNum) * Integer.parseInt(eInsurancePrice));
		/*System.out.println("期望产品信息（1）:" + eInsuranceNum + "期望产品信息（2）：" + eInsurancePrice + "期望产品信息（3）："
				+ eTotalCast);
		System.out.println("期望产品信息（1）OrderID：" + OrderID + "期望产品信息（2）eOrderID：" + eOrderID); 
		*/
		//校验订单详情数据正确性
		Assertion.verifyEquals(OrderID, eOrderID);
		Assertion.verifyEquals(OrderID, eOrderID, "期望订单号：" + eOrderID + ";实际订单号:" + OrderID);
		Assertion.verifyEquals(ProductName, eProductName, "期望产品名称：" + eProductName + ";实际产品名称:" + ProductName);
		Assertion.verifyEquals(ProductID, eProductID, "期望产品编号：" + eProductID + ";实际产品编号:" + ProductID);
		Assertion.verifyEquals(InsuranceType, eInsuranceType, "期望保险类型：" + eInsuranceType + ";实际保险类型:" + InsuranceType);
		Assertion.verifyEquals(InsuranceDeadLine, eInsuranceDeadLine,
				"期望保险期限：" + eInsuranceDeadLine + ";实际保险期限:" + InsuranceDeadLine);
		Assertion.verifyEquals(InsuranceAmount, eInsuranceAmount,
				"期望保险最大保额：" + eInsuranceAmount + ";实际保险最大保额:" + eInsuranceAmount);
		Assertion.verifyEquals(InsuranceFacePrice, eInsuranceFacePrice,
				"期望保险面价：" + eInsuranceFacePrice + ";实际保险面价:" + InsuranceFacePrice);
		Assertion.verifyEquals(InsuranceCash, eInsuranceFee, "期望保险价格：" + eInsuranceFee + ";实际保险价格:" + InsuranceCash);
		Assertion.verifyEquals(InsuranceScope, eInsuranceScope,
				"期望保险适用范围：" + eInsuranceScope + ";实际保险适用范围:" + InsuranceScope);
		// 被保人信息校验
		Assertion.verifyEquals(RecognizeeName, eRecognizeeName,
				"期望被保人姓名：" + eRecognizeeName + ";实际被保人姓名:" + RecognizeeName);
		Assertion.verifyEquals(RecognizeeCardStyle, eRecognizeeCardStyle,
				"期望被保人证件类型：" + eRecognizeeCardStyle + ";实际被保人证件类型:" + RecognizeeCardStyle);
		Assertion.verifyEquals(RecognizeeCardID, eRecognizeeCardID,
				"期望被保人证件号码：" + eRecognizeeCardID + ";实际被保人证件号码:" + RecognizeeCardID);
		Assertion.verifyEquals(RecognizeeSex, eRecognizeeSex,
				"期望被保人性别：" + eRecognizeeSex + ";实际被保人性别:" + RecognizeeSex);
		Assertion.verifyEquals(RecognizeeBirthday, eRecognizeeBirthday,
				"期望被保人出生日期：" + eRecognizeeBirthday + ";实际被保人出生日期:" + RecognizeeBirthday);
		Assertion.verifyEquals(RecognizeeMobilePhone, eRecognizeeMobilePhone,
				"期望被保人手机号码：" + eRecognizeeMobilePhone + ";实际被保人手机号码:" + RecognizeeMobilePhone);
		Assertion.verifyEquals(InsuranceStartDate, eInsuranceStartDate,
				"期望保险生效日期：" + eInsuranceStartDate + ";实际保险生效日期:" + InsuranceStartDate);
		Assertion.verifyEquals(InsuranceNumber, eInsuranceNumber,
				"期望保险份数：" + eInsuranceNumber + ";实际保险份数:" + InsuranceNumber);
		Assertion.verifyEquals(OrderState, eOrderState, "期望保险保单状态：" + eOrderState + ";实际保险保单状态:" + OrderState);
		// 投保人信息校验
		Assertion.verifyEquals(ApplicantName, eApplicantName, "期望投保人姓名：" + eApplicantName + ";实际投保人姓名:" + OrderID);
		Assertion.verifyEquals(ApplicantCardStyle, eApplicantCardStyle,
				"期望投保人证件类型：" + eApplicantCardStyle + ";实际投保人证件类型:" + ApplicantCardStyle);
		Assertion.verifyEquals(ApplicantCardID, eApplicantCardID,
				"期望投保人证件号码：" + eApplicantCardID + ";实际投保人证件号码:" + ApplicantCardID);
		Assertion.verifyEquals(ApplicantMobilePhone, eApplicantMobilePhone,
				"期望投保人手机号码：" + eApplicantMobilePhone + ";实际投保人手机号码:" + ApplicantMobilePhone);
		Assertion.verifyEquals(TotalCast, eTotalCast, "期望保险总花费：" + eTotalCast + ";实际保险总花费:" + TotalCast);
		Assertion.verifyEquals(InsuranceNum, eInsuranceNum, "期望保险份数：" + eInsuranceNum + ";实际保险份数:" + InsuranceNum);
		Assertion.verifyEquals(InsurancePrice, eInsurancePrice,
				"期望保险单价：" + eInsurancePrice + ";实际保险单价:" + InsurancePrice);
		// 点击订单管理按钮
		// OrderDetailAction.excuteOrderManagement();

	}
}

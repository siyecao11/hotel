package com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.HotelMaintainAuditPage;
import com.travelzen.Utility.LogCenter.*;

public class HoetlMaintainAuditAction {
 
	private static WebDriver webdriver;
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webdriver = driver;
		HotelMaintainAuditPage.getWebDriver(webdriver);
	}
	
	//审核通过
	@Test
	public static void excuteAuditPass() throws Exception{
		
		HotelMaintainAuditPage.getAuditPassElement().click();
		Log.info("AuditPass btn is clicked");
	}
	
	//审核驳回
	@Test
	public static void excuteAuditFailed() throws Exception{
		
		HotelMaintainAuditPage.getAuditFailedElement().click();
		Log.info("AuditFailed btn is clicked");
	}
	
	//审核关闭
	@Test
	public static void excuteAuditClosed() throws Exception{
		
		HotelMaintainAuditPage.getAuditClosedElement().click();
		Log.info("AuditClosed btn is clicked");
	}
}

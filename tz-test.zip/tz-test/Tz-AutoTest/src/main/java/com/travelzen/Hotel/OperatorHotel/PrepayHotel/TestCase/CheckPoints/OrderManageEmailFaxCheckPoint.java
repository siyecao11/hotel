package com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.CheckPoints;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.*;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
import com.travelzen.Utility.Assertion.*;
import com.travelzen.Utility.DataDriver.*;

//酒店入住单、客户确认单CheckPoint
//@Listeners({Hotel.OperatorHotel.PrepayHotel.utility.AssertionListener.class})
public class OrderManageEmailFaxCheckPoint {

	public static WebDriver currentDriver;
	
	@Test
	public static void emaiFaxCheckPoint() throws Exception{
		
		OrderManageEmailFaxPage.getWebDriver(currentDriver);
		String ehotelName = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "hotelName");
		String ehotelAddress = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "hotelAddress");
		String echeckinDate = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "checkinDate");
		String echeckoutDate = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "checkoutDate");
		String ecalclePloicy = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "canclePloicy");
		Date dt=new Date();
	    SimpleDateFormat matter=new SimpleDateFormat("yyyy-MM-dd");
		String ebookingDate = matter.format(dt);
		String eOrderId = Constant.NormalOrderId;
		
		String bookingDate = OrderManageEmailFaxPage.getSendDate().getText();
		String abookingDate = bookingDate.substring(bookingDate.length()-10);
		String hotelName = OrderManageEmailFaxPage.getHotelName().getText();
		String tempStr = "";
		for (int i = 0; i < hotelName.length(); i++) 
		{
            char  item =  hotelName.charAt(i);
            if(item == ',')
            {
            	tempStr = hotelName.substring(i+1);
            }
		}
		String ahotelName = tempStr;
		String ahotelAddress = OrderManageEmailFaxPage.getHotelAddress().getText();
		String checkinDate = OrderManageEmailFaxPage.getCheckinDate().getText();
		String acheckinDate = checkinDate.substring(5, checkinDate.length()-3);
		String checkoutDate = OrderManageEmailFaxPage.getCheckoutDate().getText();
		String acheckoutDate = checkoutDate.substring(5, checkoutDate.length()-3);
		String acalclePloicy = OrderManageEmailFaxPage.getHotelRules().getText();
		System.out.println("A************** " + ahotelName +" *************** "+ahotelAddress);
		
		//邮件传真页中的 预订产品 酒店名称 断言
		Assertion.verifyEquals(ahotelName, ehotelName, "HotelName is " + ahotelName + " in actual");
		//邮件传真页中的 预订产品 酒店地址 断言
		Assertion.verifyEquals(ahotelAddress, ehotelAddress, "HotelAdress is " + ahotelAddress + " in actual");
		//邮件传真页中的预定日期 断言
		Assertion.verifyEquals(abookingDate, ebookingDate, "BookingDate is " + abookingDate + " in actual");
		//邮件传真中的入住日期 断言
		Assertion.verifyEquals(acheckinDate, echeckinDate, "CheckinDate is " + acheckinDate + " in actual");
		//邮件传真中的离店日期 断言
		Assertion.verifyEquals(acheckoutDate, echeckoutDate, "CheckoutDate is " + acheckoutDate + " in actual");
		//邮件传真中的取消变更规定
		Assertion.verifyEquals(acalclePloicy, ecalclePloicy, "CalclePloicy is " + acalclePloicy + " in actual");
		
		//发送邮件
		currentDriver.findElement(By.id("btn_sendEmail")).click();
		currentDriver.close();
	}
}

package com.travelzen.Insurance.OperatorInsurance.AppModules;
/**
 * author：qiqi.wang
 * */
import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.OrderManagePage;
import com.travelzen.Utility.LogCenter.Log;

public class OrderManageAction
{
	public static WebDriver webdriver;
	public static void transmitDriver(WebDriver driver) throws Exception{
		webdriver = driver;
		OrderManagePage.getDriver(webdriver);
	}

	//订单管理页面-订单查询-点击标签
	public static void excuteOrderSearchLabel() throws Exception{
		try{
			OrderManagePage.getOrderSearchElement().click();
			Log.info("订单管理页面“订单查询”，已点击。");
		}catch(Exception e){
			Log.error("订单管理页面“订单查询”，未点击。");
		}
	}
	

	//订单管理页面-订单查询-点击标签
	public static void excutePolicySearchLabel() throws Exception{
		try{
			OrderManagePage.getPolicySearchElement().click();
			Log.info("订单管理页面“保单查询”，已点击。");
		}catch(Exception e){
			Log.error("订单管理页面“保单查询”，未点击。");
		}
	}
	
	
}

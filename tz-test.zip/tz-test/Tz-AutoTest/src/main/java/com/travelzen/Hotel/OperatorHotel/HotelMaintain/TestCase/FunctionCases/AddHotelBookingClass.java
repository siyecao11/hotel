package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.FunctionCases;

import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.travelzen.Utility.Utils.*;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.*;

public class AddHotelBookingClass extends FeedTest{

	public static WebDriver currentDriver;

	//TestCase中的每一个Function都可以为其做一张参数表
	//对我们需要输入的值参数化
	
	//为房型添加 价格计划
	@Test(priority = 10)
	public static void BookingClass_EditBookingClass(String roomName,String priceName,
			   String remarks,String bookingCondtion,String periodName,String periodCost,String startDate,String endDate,String periodTime,String breakFastNum,String complServices1,
			   String complServices2,String bcheckinTime,String bcheckoutTime,String checkinDays,String checkInPoint,String bcancelTerms) throws Exception {
		
		currentDriver = AddHotelRoomCat.currentDriver;
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainBookingClassAction.transmitDriver(currentDriver);
		
		//HotelMaintainBookingClassAction.excutFUllBooking();
		//Thread.sleep(3000);
		HotelMaintainRoomCatAction.excute_BookingClassItem();
		Thread.sleep(1000);
		//HotelMaintainBookingClassAction.transmitDriver(driver);
		//获取要添加价格计划的房型
		HotelMaintainBookingClassAction.excute_get_RoomCat(roomName);
		//Thread.sleep(3000);
		//点击编辑房型价格计划
		HotelMaintainBookingClassAction.excute_edit_BookingClass();
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_input_PriceName(priceName);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_input_Remarks(remarks);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_select_BookingCondtion(bookingCondtion);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_AddRate();
		//Thread.sleep(3000);
		//时段名称
		HotelMaintainBookingClassAction.excute_input_PeriodName(periodName);
		//Thread.sleep(3000);
		//时段价格
		HotelMaintainBookingClassAction.excute_input_PeriodCost(periodCost);
		//Thread.sleep(3000);
		//有效时段
		HotelMaintainBookingClassAction.excute_input_StartDate(startDate);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_input_EndDate(endDate);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_input_PeriodTime(periodTime);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_add_Datelist();
		//Thread.sleep(3000);
		//包含服务
		HotelMaintainBookingClassAction.excute_select_BreakFastNum(breakFastNum);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_select_BookingClassRates_complServices1(complServices1);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_select_BookingClassRates_complServices2(complServices2);
		//Thread.sleep(3000);
		//修改规定
		HotelMaintainBookingClassAction.excute_select_checkinTime(bcheckinTime);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_select_checkoutTime(bcheckoutTime);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_input_CheckinDaysBefore(checkinDays);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_input_CheckInPointBefore(checkInPoint);
		//Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_select_CancelTerms(bcancelTerms);
		Thread.sleep(3000);
		HotelMaintainBookingClassAction.excute_Save();
		//Thread.sleep(3000);
	
	}
	
	
	//get 价格计划ID并储存在utility->Constant中
	//只能获取到第一个房型的ID，待改进
	@Test(priority = 11)
	public static void getHotelBookingClassID() throws Exception{
		
		Constant.bookingClassId = HotelMaintainBookingClassAction.excuteGetBookingClassId();
		System.out.println("****************RoomID:" + Constant.bookingClassId + "*********************");
	}
	
	//添加房型价格计划后，进入库存与房态编辑页
	@Test(priority = 12)
	public static void BookingClass_RoomAllot() throws Exception{
		
		//触发“库存与房态”Item，进入酒店库存与房态编辑页面
		HotelMaintainBookingClassAction.excute_RoomAllotItem();
		Thread.sleep(5000);
	}
}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.ProcessCases;

import org.testng.annotations.Test;
import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;

import com.travelzen.Utility.DataDriver.*;
import com.travelzen.Utility.Utils.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.FunctionCases.*;
import com.travelzen.Login.OperatorLogin.TestCase.FunctionCases.LoginTC;

public class AddHotelTC extends FeedTest{

	public static WebDriver currentDriver;
	public static int row;
	public static int column;
	
	@DataProvider(name = "bookingData")
    public static Object[][] BookingHotel() throws Exception{
		//Excel表格名称定义
		String excelName = "Hotel/AddHotel_TestData.xls";
		//列
		column = ExcelAction.excel_get_column(excelName);
		System.out.println("excel_get_column value is : " + column);
		//行
		row = ExcelAction.excel_get_rows(excelName);
		System.out.println("excel_get_rows value is : " + row);
		//定义二维数组
		Object[][] excelData = new Object[row][column];
		//获取功能测试或者非功能测试数据
    	excelData = ExcelAction.getFirstRow(excelName,row,column);   		
    	return excelData; 
    }
	
	@Test(dataProvider = "bookingData", priority =10, groups={"审核失败再次提交审核成功","提交审核成功","酒店挂起","酒店解挂"})
	public static void addHotel(String username, String password, String noOfAllotedNo,String cutOffDay, String allotType,
			String addAllot,String roomCost, String checkInTime, String checkOutTime, String checkInDay, String checkOutPoint,
			String CancleTerm,String PackageContent,String hotelName,String displayOrder,String brandSelect,String hotelStyle,
			String hotelStar,String region,String province,String city,String district,String hotelAdress,
			String latitude,String longitude,String mainPhone,String webSite,String email,String openDate,
			String renovationDate,String storey,String noofRoom,String summary,String guestRemark,String ageSelect,
			String heightSelect,String petAllowed,String checkinTime,String checkoutTime,String checkinDay,String checkinPoints,
			String cancelTerms,String breakerCharge,String netCharge,String businessCenter,String privateRemark,String publicRemark,
	        String selectManager,String beginTime,String endTime,String remindTime,String supplier,String supplierName,
	        String supplierRemark,String supplierEntity,String supplierSettleperiod,String accountName,String bankName,String bankNumber,
	        String contactName,String contactMobilephone,String contactFox,String contactOfficePhone,String contactEmail,String workingHoursBegin,
	        String workingHoursEnd,String dept,String contactRemark,String PacSal,String roomName,String capacityNo,
	        String insideSpace,String StartFloor,String EndFloor,String hotelWindow,String bedType,String bedSize,
	        String roomFacilities,String priceName,String remarks,String bookingCondtion,String periodName,String periodCost,
	        String startDate,String endDate,String periodTime,String breakFastNum,String complServices1,String complServices2,
	        String bcheckinTime,String bcheckoutTime,String checkinDays,String checkInPoint,String bcancelTerms) throws Exception{
		   

		PointAddHotel.pointAddHotel(username, password);
		//酒店签约信息
		AddHotelMainContent.MainContent_ManagerInfo();
		//酒店基本信息
		AddHotelMainContent.MainContent_BaseInfo(hotelName, displayOrder, brandSelect, hotelStyle,
				 hotelStar, region, province, city, district, hotelAdress, latitude,longitude,
				 mainPhone, webSite, email, openDate, renovationDate,storey, noofRoom, summary);
		//检查比较酒店基本信息的正确性
		AddHotelMainContent.assertMainContentHotelMessage();
		// get 酒店ID并储存在utility->Constant中
		AddHotelMainContent.getHotelID();
		//酒店照片
		AddHotelMainContent.MainContent_PhotoInfo();
		//酒店规定
		int petAllowed1 =  Integer.parseInt(petAllowed);
		AddHotelMainContent.MainContent_RuleInfo( guestRemark, ageSelect, heightSelect, petAllowed1, checkinTime,
				                                  checkoutTime, checkinDay, checkinPoints, cancelTerms);
		//检查比较酒店规定的正确性
		AddHotelMainContent.assertHotelRulesButton();
		//酒店服务费用
		AddHotelMainContent.MainContent_ServiceChargeInfo( breakerCharge, netCharge);
		//酒店服务设施
		int businessCenter1 =  Integer.parseInt(petAllowed);
		AddHotelMainContent.MainContent_ServerFacilityInfo(businessCenter1);
		//检查比较服务设施正确性
		//AddHotelMainContent.assertServerButton();
		//酒店备注
		AddHotelMainContent.MainContent_RemarkInfo( privateRemark, publicRemark);	
		//检查比较酒店备注
		AddHotelMainContent.assertEditHotelRemark();
		//酒店基本信息完成，进入供应商信息编辑页
		AddHotelMainContent.MainContent_ProviderInfo(selectManager);
		//供应商信息--合同信息
		AddHotelProviderMessage.ProviderMessage_ContractInfo(beginTime,endTime, remindTime, supplier, supplierName, supplierRemark,
				supplierEntity, supplierSettleperiod, accountName, bankName, bankNumber);
		//供应商信息--联系人信息
		AddHotelProviderMessage.ProviderMessage_ContactInfo( contactName, contactMobilephone, contactFox, 
				contactOfficePhone,contactEmail, workingHoursBegin, workingHoursEnd, dept, contactRemark);
		//对供应商基本信息进行验证
		AddHotelProviderMessage.assertEditContract();
		AddHotelProviderMessage.assertAddContact();
		
		
		
		//酒店供应商信息完成，进入酒店房型编辑页
		AddHotelProviderMessage.ProviderMessage_RoomCat();
		
		//*******酒店房型模块********
		//酒店房型房型编辑--添加酒店房型
		AddHotelRoomCat.RoomCat_AddRoomCat(PacSal, roomName, capacityNo, insideSpace, StartFloor, EndFloor,
				hotelWindow, bedType, bedSize, roomFacilities);
		//get 酒店房型ID并储存在utility->Constant中
		AddHotelRoomCat.getHotelRoomCatID();
		//添加酒店房型后进入价格计划编辑页面
		AddHotelRoomCat.RoomCat_BookingClass();
		//********价格计划模块**********
		//酒店房型价格计划--添加房型对应价格计划
		AddHotelBookingClass.BookingClass_EditBookingClass(roomName, priceName, remarks, bookingCondtion,
				periodName,periodCost,startDate,endDate,periodTime,breakFastNum, complServices1, complServices2, bcheckinTime, 
				bcheckoutTime, checkinDays, checkInPoint, bcancelTerms);
		//get 价格计划ID并储存在utility->Constant中
		AddHotelBookingClass.getHotelBookingClassID();
		//添加房型价格计划后，进入库存与房态编辑页
		AddHotelBookingClass.BookingClass_RoomAllot();
		
		// 批量编辑 库存房态
		AddHotelRoomAllot.RoomAllot_EditAllRoomAllot(noOfAllotedNo,cutOffDay,allotType);
		// 按房型编辑库存房态
		//AddHotelRoomAllot.RoomAllot_EditAllRoomAllotByRoomCat(noOfAllotedNo,cutOffDay,allotType);
		// 每日库存管理：修改每天房量房态
		AddHotelRoomAllot.RoomAllot_EditDailyRoomAllot();
		// 每日库存管理：修改每日的添加库存
		AddHotelRoomAllot.RoomAllot_EditDailyRoomAllot_AddAllot(addAllot);
		// 每日库存管理：修改每日的关房
		AddHotelRoomAllot.RoomAllot_EditDailyRoomAllot_CloseRoom();
		// 每日库存管理：修改每天--售完规则
		AddHotelRoomAllot.RoomAllot_EditDailyRoomAllot_RoomStatus(allotType);
		//添加库存与房态后，进入每日价格编辑页
		AddHotelRoomAllot.RoomAllot_DailyRate();
		
		//根据房型选择修改每日价格信息
		//选择需要修改的 房型
		AddHotelDailyRate.DailyRate_EditDailyRateByRoomCat();
		//为指定房型添加 礼包信息
		AddHotelDailyRate.DailyRate_ModifyGifPackage(PackageContent);
		//修改指定房型的每日价格信息
		//触发修改按钮
		AddHotelDailyRate.DailyRate_ModifyDailyRateBtn();
		//修改指定房型的每日价格
		AddHotelDailyRate.DailyRate_DailyPriceContainerEdit(roomCost);
		//修改指定房型的每日规定
		AddHotelDailyRate.DailyRate_DailyRuleContainerEdit(checkInTime, checkOutTime, checkInDay, checkOutPoint, CancleTerm);
		//保存修改的 每日价格信息
		AddHotelDailyRate.DailyRate_SaveModifyDailyRate();
		//酒店所有信息都完成编辑后，提交审核
		AddHotelDailyRate.Hotel_CommitAudit();
		
	}
	
	
	//酒店审核通过
	@Test(priority = 12, groups={"提交审核成功"})
	public static void AuditPass() throws Exception{
		
		//酒店提交后审核
		AddHotelAudit.auditHotelAudit();
		//酒店审核通过
		AddHotelAudit.auditAuditPass();
		
	}
	
	//酒店审核失败后再次审核，审核成功
	@Test(priority = 11, groups={"审核失败再次提交审核成功"})
	public static void reAuditFail() throws Exception{
		
		//酒店提交后审核
		AddHotelAudit.auditHotelAudit();
		//酒店审核通过
		AddHotelAudit.auditAuditFailed();
	}
	
	
	@Test(priority = 13, groups={"审核失败再次提交审核成功","提交审核成功"})
	public static void afterClass() throws Exception{
		
		//关闭当前窗口
		AddHotelAudit.quiteDriver();
	}

	
	@Test(priority = 14, groups={"酒店挂起"})
//	@Source("AddHotel_TestData.xls")
	public static void guaqi() throws Exception{
		
		LoginTC.login("yangweixing", "111111");
		//fetch WebDriver
		currentDriver = LoginTC.driver;
		Utils.waitForElement(5, currentDriver, "page");
		HotelHomeAction.transmitDriver(currentDriver);
		//currentDriver.get(Constant.hotelMaintainURL);
		HotelHomeAction.excuteHotelMaintain();
		
		//goto add hotel page, edit hotelInfo
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainHomeAction.transmitDriver(currentDriver);
		//挂起酒店
		AddHotelAudit.Guaqi("杭州陆羽山庄");
		currentDriver.close();
	}
	
	@Test(priority = 15, groups={"酒店解挂"})
//	@Source("AddHotel_TestData.xls")
	public static void jiegua() throws Exception{
		
		LoginTC.login("yangweixing", "111111");
		
		//fetch WebDriver
		currentDriver = LoginTC.driver;
		Utils.waitForElement(5, currentDriver, "page");
		HotelHomeAction.transmitDriver(currentDriver);
		//currentDriver.get(Constant.hotelMaintainURL);
		HotelHomeAction.excuteHotelMaintain();
		
		//goto add hotel page, edit hotelInfo
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainHomeAction.transmitDriver(currentDriver);
		//挂起酒店
		AddHotelAudit.Jiegua("杭州陆羽山庄");
		currentDriver.close();
	}
	
}

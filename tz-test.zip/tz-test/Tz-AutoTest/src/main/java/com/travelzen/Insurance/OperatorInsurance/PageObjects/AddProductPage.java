package com.travelzen.Insurance.OperatorInsurance.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Utility.LogCenter.Log;

/**
 * 添加保险产品页面 元素定位
 * @author Weixing.Yang
 *
 */
public class AddProductPage {

	public static WebDriver driver;
	private static WebElement element;
	private static Select select;
	private static List<WebElement> elementList;
		
	//获取当前页面的Driver
	public static void getDriver(WebDriver webDriver) {

		driver = webDriver;
	}
	
	//获取新增产品页面中 “提交” 按钮元素
	public static WebElement getSubmitAddButtonElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("submitAddButton"));
			Log.info("新增产品页面中 “提交” 按钮 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “提交” 按钮 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “返回” 按钮元素
	public static WebElement getReturnButtonElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("button[class='btns btn-return']"));
			Log.info("新增产品页面中 “返回” 按钮 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “返回” 按钮 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品名称” 输入框元素
	public static WebElement getProductNameElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("productName"));
			Log.info("新增产品页面中 “产品名称” 输入框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中  “产品名称” 输入框元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “保险公司名称” 选择框元素
	//Select options对应的value值有：TAIKANG、TAIPING、CPIC、NEUSOFT、PINGAN、PAMLYOU、CHINALIFE	
	public static Select getCompanyNameElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("companyName"));
			select = new Select(element);
			Log.info("新增产品页面中 “保险公司名称” 选择框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中  “保险公司名称” 选择框元素 没有找到");
		}
		return select;
	}
	
	//获取新增产品页面中 “保险期限” 输入框元素
	public static WebElement getDeadlineElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("deadline"));
			Log.info("新增产品页面中 “保险期限” 输入框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中  “保险期限” 输入框元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “最高保额” 输入框元素
	public static WebElement getInsuranceAmountElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("insuranceAmount"));
			Log.info("新增产品页面中 “最高保额” 输入框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中  “最高保额” 输入框元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 ”保险险种” 选择框元素
	//Select options对应的value值有： TRIFFIC_ACCIDENT、FLIGHT_DELAYS、TRAVEL_ACCIDENT、CRUISE_DELAYS
	public static Select getTypeNameElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("typeName"));
			select = new Select(element);
			Log.info("新增产品页面中 “保险险种” 选择框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中  “保险险种” 选择框元素 没有找到");
		}
		return select;
	}
	
	//获取新增产品页面中 “险种编号” 输入框元素
	public static WebElement getTypeCodeElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("typeCode"));
			Log.info("新增产品页面中 “险种编号” 输入框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中  “险种编号” 输入框元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” 单选框元素
	//Radio对象，页面中共有16个，value属性值为001~016
	//分别对应：太平明细 、太平洋明细 、泰康明细 、平安明细 、平安电子明细 、平安30元 、平安40元 、美亚畅游神州 
	//美亚万国游踪、人保邮轮 、美亚乐悠悠、 安盛卓越亚洲行 、人保境外旅游险 、平安境内旅游险 、畅行境外航意险 、畅行境内航意险
	//结果为一个List对象
	public static List<WebElement> getProductDetailElement() throws Exception{
		
		try{
			elementList = driver.findElements(By.name("securityDetailId"));
			Log.info("新增产品页面中 “产品明细” 单选框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中  “产品明细” 单选框元素 没有找到");
		}
		return elementList;
	}
	
	//获取新增产品页面中 “产品明细” - “太平明细” 元素
	public static WebElement getTPElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/001']"));
			Log.info("新增产品页面中 “产品明细” - “太平明细” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “太平明细” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “太平洋明细” 元素
	public static WebElement getTPYElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/002']"));
			Log.info("新增产品页面中 “产品明细” - “太平洋明细” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “太平洋明细” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “泰康明细” 元素
	public static WebElement getTKElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/003']"));
			Log.info("新增产品页面中 “产品明细” - “泰康明细” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “泰康明细” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “平安明细” 元素
	public static WebElement getPAElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/004']"));
			Log.info("新增产品页面中 “产品明细” - “平安明细” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “平安明细” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “平安电子明细” 元素
	public static WebElement getPADZElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/005']"));
			Log.info("新增产品页面中 “产品明细” - “平安电子明细” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “平安电子明细” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “平安30元” 元素
	public static WebElement getPASSElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/006']"));
			Log.info("新增产品页面中 “产品明细” - “平安30元” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “平安30元” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “平安40元” 元素
	public static WebElement getPAFSElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/007']"));
			Log.info("新增产品页面中 “产品明细” - “平安40元” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “平安40元” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “美亚畅游神州” 元素
	public static WebElement getMYCYElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/008']"));
			Log.info("新增产品页面中 “产品明细” - “美亚畅游神州” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “美亚畅游神州” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “美亚万国游踪” 元素
	public static WebElement getMYWGElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/009']"));
			Log.info("新增产品页面中 “产品明细” - “美亚万国游踪” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “美亚万国游踪” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “人保邮轮” 元素
	public static WebElement getRBYLElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/010']"));
			Log.info("新增产品页面中 “产品明细” - “人保邮轮” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “人保邮轮” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “美亚乐悠悠” 元素
	public static WebElement getMYLYYElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/011']"));
			Log.info("新增产品页面中 “产品明细” - “美亚乐悠悠” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “美亚乐悠悠” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “安盛卓越亚洲行” 元素
	public static WebElement getASZYElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/012']"));
			Log.info("新增产品页面中 “产品明细” - “安盛卓越亚洲行” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “安盛卓越亚洲行” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “人保境外旅游险” 元素
	public static WebElement getRBJWElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/013']"));
			Log.info("新增产品页面中 “产品明细” - “人保境外旅游险” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “人保境外旅游险” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “平安境内旅游险” 元素
	public static WebElement getPAJNElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/014']"));
			Log.info("新增产品页面中 “产品明细” - “平安境内旅游险” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “平安境内旅游险” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “畅行境外航意险” 元素
	public static WebElement getCXJWElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/015']"));
			Log.info("新增产品页面中 “产品明细” - “畅行境外航意险” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “畅行境外航意险” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “产品明细” - “畅行境内航意险” 元素
	public static WebElement getCXJNElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-additional/additional/insurance/product/detail/016']"));
			Log.info("新增产品页面中 “产品明细” - “畅行境内航意险” 元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “产品明细” - “畅行境内航意险” 元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “面价” 输入框元素
	public static WebElement getNormalPriceElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("normalPrice"));
			Log.info("新增产品页面中 “面价” 输入框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中  “面价” 输入框元素 没有找到");
		}
		return element;
	}	
	
	//获取新增产品页面中 “底价” 输入框元素
	public static WebElement getUpsetPriceElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("upsetPrice"));
			Log.info("新增产品页面中 “底价” 输入框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中  “底价” 输入框元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “最高投保份数”-“18周岁以上（含)” 输入框元素
	public static WebElement getAdultLimitNumElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("adultLimitNum"));
			Log.info("新增产品页面中“最高投保份数”-“18周岁以上（含)”  输入框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “最高投保份数”-“18周岁以上（含)”  输入框元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “最高投保份数”-“18周岁以下” 输入框元素
	public static WebElement getChildLimitNumElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("childLimitNum"));
			Log.info("新增产品页面中“最高投保份数”-“18周岁以下”  输入框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “最高投保份数”-“18周岁以下”  输入框元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “年龄限制”-“投保人”-“周岁（含）以上” 输入框元素
	public static WebElement getInsurerMinAgeLimitElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("insurerMinAgeLimit"));
			Log.info("新增产品页面中“年龄限制”-“投保人”-“周岁（含）以上”  输入框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “年龄限制”-“投保人”-“周岁（含）以上”  输入框元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “年龄限制”-“被投保人”-“至” 输入框元素
	public static WebElement getInsureeMinAgeLimitElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("insureeMinAgeLimit"));
			Log.info("新增产品页面中“年龄限制”-“被投保人”-“至”  输入框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “年龄限制”-“被投保人”-“至”  输入框元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “年龄限制”-“被投保人”-“周岁（含）” 输入框元素
	public static WebElement getInsureeMaxAgeLimitElement() throws Exception{
		
		try{
			element = driver.findElement(By.name("insureeMaxAgeLimit"));
			Log.info("新增产品页面中“年龄限制”-“被投保人”-“周岁（含）”  输入框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中 “年龄限制”-“被投保人”-“周岁（含）”  输入框元素 没有找到");
		}
		return element;
	}
	
	//获取新增产品页面中 “适用范围” 多选框元素
	//checkbox对象，页面中共有5个，value属性值为DOMESTIC_INSURANCE、INTERNATIONAL_INSURANCE、TRAVEL_INSURANCE、CRUISE_INSURANCE、FREEDRIVING_INSURANCE
	//结果为一个List对象
	public static List<WebElement> getScopeElement() throws Exception{
		
		try{
			elementList = driver.findElements(By.name("scope"));
			Log.info("新增产品页面中 “适用范围” 多选框元素 已找到");
		}catch (Exception e){
			Log.error("新增产品页面中  “适用范围” 多选框元素 没有找到");
		}
		return elementList;
	}
}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules;

import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Utility.Utils.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.HotelMaintainBookingClassPage;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.HotelMaintainRoomCatPage;
import com.travelzen.Utility.LogCenter.*;

public class HotelMaintainBookingClassAction {

	public static List<WebElement> rdBtn_BedType;
	public static List<WebElement> chBox_PeriodTime;
	public static List<WebElement> elementList;
	private static WebDriver webdriver;
	public static WebElement element;
	private static List list;

	// private static Select oselection;

	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {

		webdriver = driver;
		HotelMaintainBookingClassPage.getWebDriver(webdriver);
	}

/*	// 添加完整价格计划
	public static void excutFUllBooking() throws Exception {
		List<String> listBC = Arrays.asList("ADVANCE_AND_SUCCESSIVE_LIVE", "4",
				"21:00", "3");
		List<String> listPT = Arrays.asList("一", "二", "三", "四", "五", "六", "七");
		excute_get_RoomCat("家庭大床");
		excute_edit_BookingClass();
		excute_input_PriceName("家庭大床价格计划");
		excute_input_Remarks("1.家庭庭大床价床价");
		excute_select_BookingCondtion(listBC);
		excuteAddRate();
		excuteBkrateName("家庭大房第一个时段价格");
		excute_input_Bkrate_roomCost("598");
		excute_StartDate();
		excute_EndDate();
		excute_input_getPeriodTime(listPT);
		excuteDatelist();
		excute_select_BreakFastName("5份");
		excute_select_BookingClassRates_complServices1("yes");
		excute_select_BookingClassRates_complServices2("yes");
		excute_select_BookingClassRates_checkinTime("14:00之后");
		excute_select_BookingClassRates_checkoutTime("12:00之前");
		excute_input_CheckinDays("3");
		excute_input_CheckInPoint("4");
		excute_select_CancelTerms("全部房费");
		excute_Save();

	}

	
	 * //跳转到添加房型窗口
	 * 
	 * @Test public static void excuteLink_to_AddRoom()throws Exception {
	 * 
	 * HotelMaintain_BookingClass_Page.getAddRoom_Type().click();
	 * Utils.waitForElement(3, webdriver, "script"); }
	 * 
	 * @Test public static void excutePackaged_Sales(int PacSal)throws Exception
	 * {
	  
	 * //HotelMaintain_BookingClass_Page.getAddRoom_Type().click();
	  //Utils.waitForElement(3, webdriver, "script"); //获取机+酒打包产品信息
	  if(PacSal==1){
	  HotelMaintain_BookingClass_Page.getPackagedSales().click();
	 *Log.info("PackagedSales info has been input"); } }
	
	*/
	// 选中需要添加价格计划的房型
	@Test
	public static void excute_get_RoomCat(String roomCat) throws Exception {
		// 选择可入住人数
		Thread.sleep(1000);
		Log.info("RoomCat name " + roomCat + " has been got");
		Select oselection = HotelMaintainBookingClassPage.getRoomCat();
		List oSizeC = oselection.getOptions();
		int iSizeC = oSizeC.size();
		for (int i = 0; i < iSizeC; i++) {
			String sValueC = oselection.getOptions().get(i).getText();
			// 选中下拉列表元素
			if (sValueC.equals(roomCat)) {
				oselection.selectByIndex(i);
				break;
			}
		}
		Log.info("RoomCat name " + roomCat + " has been input");

	}

	// 跳转到编辑价格计划页面
	@Test
	public static void excute_edit_BookingClass() throws Exception {

		HotelMaintainBookingClassPage.getEditBookingClass().click();
		Log.info("Edit Booking Class Link has been clicked");
	}

	// 输入价格名称
	@Test
	public static void excute_input_PriceName(String priceName)
			throws Exception {

		HotelMaintainBookingClassPage.getPriceName().sendKeys(priceName);

		Log.info("RoomCat name " + priceName + " has been input");
	}

	// 输入价格说明/礼包备注
	@Test
	public static void excute_input_Remarks(String remarks) throws Exception {

		HotelMaintainBookingClassPage.getRemarks().sendKeys(remarks);

		Log.info("RoomCat name " + remarks + " has been input");
	}

	// 选择并输入预定条件
	@Test
	public static void excute_select_BookingCondtion(String string)
			throws Exception {
		// 选择预定要求，bookingRequirement
		// element = elementList.get(0).getAttribute("value")
		  String[] arrayStr =new String[]{};
	      arrayStr = string.split(",");
	      List<String> stringList = java.util.Arrays.asList(arrayStr);
		switch (stringList.get(0)) {
		case "ORDINARY":
			HotelMaintainBookingClassPage.getOrdinary().click();
			break;
		case "ADVANCE":
			excute_select_BookingAdvance(stringList);
			break;
		case "SUCCESSIVE_LIVE":
			excute_select_BookingSucessive_Live(stringList);
			break;
		case "ADVANCE_AND_SUCCESSIVE_LIVE":
			excute_select_BookingAdvance_and_Live(stringList);
			break;

		}

	}

	// 选择预定要求，bookingRequirement
	// 选择提前N天预定条件
	@Test
	public static void excute_select_BookingAdvance(List<String> stringList)
			throws Exception {

		elementList = HotelMaintainBookingClassPage.getAdvance();

		elementList.get(0).click();
		Log.info(elementList.size() + "elementList size");
		for (int i = 1; i < elementList.size(); i++) {
			if (i == 1)
				elementList.get(i).clear();
			elementList.get(i).sendKeys(stringList.get(i));
		}

	}

	// 选择连住N晚条件
	@Test
	public static void excute_select_BookingSucessive_Live(
			List<String> stringList) throws Exception {
		
	      
		elementList = HotelMaintainBookingClassPage.getAdvance();

		elementList.get(0).click();
		Log.info(elementList.size() + "elementList size");

		for (int i = 1; i < elementList.size(); i++) {
			elementList.get(i).clear();
			elementList.get(i).sendKeys(stringList.get(i));
		}

	}

	// 选择提前且连住N晚起预定条件
	@Test
	public static void excute_select_BookingAdvance_and_Live(
			List<String> stringList) throws Exception {
		
		elementList = HotelMaintainBookingClassPage.getAdvance_and_Live();

		elementList.get(0).click();
		Log.info(elementList.size() + "elementList size");
		for (int i = 1; i < elementList.size(); i++) {
			if (i == 1 || i == 3)
				elementList.get(i).clear();
			String tempS = stringList.get(i);
			// elementList.get(i).clear();
			Log.info(tempS + " stringList.get(i)");
			elementList.get(i).sendKeys(tempS);

		}
	}

	// 添加时段价格,跳转到时段价格编辑页面
	@Test
	public static void excute_AddRate() throws Exception {

		HotelMaintainBookingClassPage.geAddRate().click();
		Log.info("AddRate Booking Class Link has been clicked");
	}

	// 输入时段名称
	@Test
	public static void excute_input_PeriodName(String string) throws Exception {

		HotelMaintainBookingClassPage.getBkrate_Name().sendKeys(string);

		Log.info("RoomCat name " + string + " has been input");
	}

	// 输入时段价格
	@Test
	public static void excute_input_PeriodCost(String string)
			throws Exception {

		HotelMaintainBookingClassPage.getBkrate_roomCost().sendKeys(string);

		Log.info("RoomCat Cost " + string + " has been input");
	}

	// 输入有效时段开始时间
	@Test
	public static void excute_input_StartDate(String string) throws Exception {

		element = HotelMaintainBookingClassPage.getStartDate();
		
		element.click();
		
		element.sendKeys(string);
		

		Log.info("StartDate has been input");
	}

	// 输入有效时段结束时间
	@Test
	public static void excute_input_EndDate(String string) throws Exception {

		element = HotelMaintainBookingClassPage.getEndDate();
		//
		element.click();		
		element.sendKeys(string);

		Log.info("EndDate has been input : " + string);
	}

	/*
	 * //输入有效时段开始时间
	 * 
	 * @Test public static void excute_input_StartDat(String string)throws
	 * Exception {
	 * 
	 * for(int i=0;i<HotelMaintain_BookingClass_Page.getStartDate().size();i++){
	 * Log
	 * .info(HotelMaintain_BookingClass_Page.getStartDate().get(i).getAttribute
	 * ("day")+" is wanted");
	 * if(HotelMaintain_BookingClass_Page.getStartDate().get
	 * (i).getAttribute("day").equalsIgnoreCase(string)){
	 * 
	 * HotelMaintain_BookingClass_Page.getStartDate().get(i).click(); break; }
	 * 
	 * for(int i=0;i<HotelMaintain_BookingClass_Page.getStartDate().size();i++){
	 * HotelMaintain_BookingClass_Page
	 * .getStartDate().get(i).findElement(By.linkText(string)).click();
	 * Log.info("StartDat " +
	 * HotelMaintain_BookingClass_Page.getStartDate().get(
	 * i).findElement(By.linkText(string)) + " has been input"); break; }
	 * 
	 * Log.info("StartDat " + string + " has been input"); }
	 * 
	 * 
	 * //输入有效时段结束时间
	 * 
	 * @Test public static void excute_input_EndDate(String string)throws
	 * Exception {
	 * 
	 * HotelMaintain_BookingClass_Page.getEndDate().sendKeys(string);
	 * 
	 * Log.info("EndDate name " + string + " has been input"); }
	 */

	// 输入有效时段星期时间
	@Test
	public static void excute_input_PeriodTime(String string)
			throws Exception {
		
		 String[] arrayStr =new String[]{};
	      arrayStr = string.split(",");
	      List<String> stringList = java.util.Arrays.asList(arrayStr);
	      
		chBox_PeriodTime = HotelMaintainBookingClassPage.getPeriodTime();
		for (int i = 0; i < stringList.size(); i++) {
			// for(int j=0;j<chBox_PeriodTime.size();j++){
			// String string =
			// chBox_PeriodTime.get(j).findElement(By.id("dayBit-"+list.get(i)+"-0"));
			// Log.info("list.get(i) "+list.get(i));
			// Log.info("chBox_PeriodTime.get(j).getText() "+chBox_PeriodTime.get(j));
			if (stringList.get(i).equals("0")) {

				HotelMaintainBookingClassPage.getPeriodTime().get(i).click();

				// }

			}
			

		}
		Log.info("PeriodTime  has been input");
	}

	// 添加有效时段
	@Test
	public static void excute_add_Datelist() throws Exception {

		HotelMaintainBookingClassPage.getDate_list().click();
		Log.info("Date_list name has been input");
	}
	
	//*********包含服务*********
	// 选择早餐份数
	@Test
	public static void excute_select_BreakFastNum(String string)
			throws Exception {

		List<WebElement> selBrak = HotelMaintainBookingClassPage
				.getBreakFastName();

		for (int i = 0; i < selBrak.size(); i++) {

			if (selBrak.get(i).getText().equals(string)) {
				selBrak.get(i).click();
				break;
			}
		}
		Log.info("BreakFastName" + string + "has been input");

	}

	// 选择是否有早餐
	@Test
	public static void excute_select_BookingClassRates_complServices1(
			String string) throws Exception {

		if (string.equalsIgnoreCase("yes")) {
			HotelMaintainBookingClassPage
					.getBookingClassRates_complServices1().click();
			Log.info("BookingClassRates_complServices1 has been clicked");
		}
	}

	// 选择是否包含宽带
	@Test
	public static void excute_select_BookingClassRates_complServices2(
			String string) throws Exception {

		if (string.equalsIgnoreCase("yes")) {
			HotelMaintainBookingClassPage
					.getBookingClassRates_complServices2().click();
			Log.info("BookingClassRates_complServices2 has been clicked");
		}
	}
	//**********修改规定*************
	// 入住时间
	@Test
	public static void excute_select_checkinTime(String string)
			throws Exception {

		List<WebElement> selBrak = HotelMaintainBookingClassPage
				.geBookingClassRates_checkinTime();

		for (int i = 0; i < selBrak.size(); i++) {

			if (selBrak.get(i).getText().equals(string)) {
				selBrak.get(i).click();
				break;
			}
		}
		Log.info("BookingClassRates_checkinTime" + string + "has been select");

	}

	// 退房时间
	@Test
	public static void excute_select_checkoutTime(String string) 
			throws Exception {

		List<WebElement> selBrak = HotelMaintainBookingClassPage
				.geBookingClassRates_checkoutTime();

		for (int i = 0; i < selBrak.size(); i++) {

			if (selBrak.get(i).getText().equals(string)) {
				selBrak.get(i).click();
				break;
			}
		}
		Log.info("BookingClassRates_checkinTime" + string + "has been select");

	}

	// 输入入住前几天
	@Test
	public static void excute_input_CheckinDaysBefore(String string) throws Exception {

		// 清空输入框
		HotelMaintainBookingClassPage.getCheckinDays().clear();
		// 重新输入新数据
		HotelMaintainBookingClassPage.getCheckinDays().sendKeys(string);

		Log.info("CheckinDays " + string + " has been input");
	}

	// 输入入住前几点
	@Test
	public static void excute_input_CheckInPointBefore(String string)
			throws Exception {

		HotelMaintainBookingClassPage.getCheckInPoint().clear();

		HotelMaintainBookingClassPage.getCheckInPoint().sendKeys(string);

		Log.info("CheckInPoint " + string + " has been input");
	}

	// 退房花费
	@Test
	public static void excute_select_CancelTerms(String string)
			throws Exception {

		List<WebElement> selBrak = HotelMaintainBookingClassPage
				.getCancelTerms();

		for (int i = 0; i < selBrak.size(); i++) {

			if (selBrak.get(i).getText().equals(string)) {
				selBrak.get(i).click();
				break;
			}
		}
		Log.info("CancelTerms" + string + "has been select");

	}

	// 保存添加的时段价格
	@Test
	public static void excute_Save() throws Exception {
		HotelMaintainBookingClassPage.getSave_Button().click();
		Log.info("SaveButton has been input");
	}

	// get bookingClass ID
	@Test
	public static String excuteGetBookingClassId() throws Exception {

		String str = HotelMaintainBookingClassPage.getBookingClassDetail()
				.getAttribute("bcid");
		return str;
	}

	// goto roomAllot edit page
	@Test
	public static void excute_RoomAllotItem() throws Exception {
		HotelMaintainBookingClassPage.getRoomAllotItemElement().click();
		Log.info("RoomAllotItem has been clicked");
	}

}
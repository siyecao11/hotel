package com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.FunctionCases;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageEndorseOrderAuditAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageEndorseOrderCreateAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageNormalOrderAuditAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageNormalOrderCompleteAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageOrderListAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageOrderPayAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.Utility.Utils.dataProviderApp;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
import com.travelzen.Utility.Utils.Utils;

public class EndorseOrderOperator extends FeedTest{

	public static WebDriver driver;
	public static String orderType;
	public static String orderId;
	
	//从正常单获取Driver
	@Test(priority = 40, groups ={"正常单创建变更单","正常单变更取消流程", "正常单变更确认流程", "正常单变更后调账确认流程","正常单变更后变更确认流程","正常单变更后变更再调账确认流程"})
	public static void getNormalOrderTCDriver() throws Exception{
		
		orderType = "normal";
		driver = NormalOrderOperator.driver;
	}
	
	//从调账单获取Driver
	@Test(priority = 40, groups ={"正常单调账后变更确认流程"})
	public static void getAdjustmentOrderTCDriver() throws Exception{
		
		orderType = "adjustment";
		//driver = AdjustmentOrderTC.driver;
	}
	
	//从变更单获取Driver
	@Test(priority = 40, groups ={"正常单变更后再次变更流程"})
	public static void getEndorseOrderTCDriver() throws Exception{
		
		orderType = "endorse";
	 //	driver = EndorseOrderTC.driver;
	}
	
	@Test( priority = 41, groups ={"正常单创建变更单","正常单变更确认流程", "正常单变更后调账确认流程","正常单变更后变更确认流程","正常单变更后变更再调账确认流程"})
	public static void endorseOrderId() throws Exception{
		
/*		PointSearchHotel.pointSearchHotel(username, password);
		driver = PointSearchHotel.currentDriver;
		BookingHotel.searchBooking(driver, customerName, checkinDate, checkoutDate, roomNo, addPrice);
		//创建正常单
		OrderManageNormalOrder.NormalOrder_ContractInfo(name,checkinDate, addPrice, checkoutDate);*/
		
		driver.get(Constant.orderManageURL);
		Thread.sleep(2000);
		//于订单列表页查找指定ID的订单（上一步骤中创建的正常订单）
		//并跳转到订单详情页
		//判断是在哪类订单基础上做变更
		if(orderType.equals("normal")){
			
			orderId = Constant.NormalOrderId;
		}else if(orderType.equals("endorse")){
			
			orderId = Constant.EndorseOrderId;
		}else if(orderType.equals("adjustment")){
			
			orderId = Constant.adjustmentOrderId;
		}

	}
		
		//TestCase中的每一个Function都可以为其做一张参数表
		//对我们需要输入的值参数化
	//于订单列表页查找指定ID的订单（上一步骤中创建的订单）
	//并跳转到订单详情页
	@Test(priority = 42,groups ={"正常单创建变更单", "正常单变更后调账确认流程","正常单变更后变更确认流程","正常单变更后变更再调账确认流程"})
	public static void orderDetail() throws Exception{
		
		OrderManageOrderListAction.transmitDriver(driver);
		//根据订单ID查询出订单，点击进入订单详情页
		OrderManageOrderListAction.OrderIdInput(Constant.TempId);
		Thread.sleep(2000);
		OrderManageOrderListAction.SearchOrder();
		Thread.sleep(2000);
		OrderManageOrderListAction.OrderClick();
		Thread.sleep(2000);
	}	

		//变更单创建订单
	@Test( priority = 43,dataProvider = "EndorseOrder_TestData", dataProviderClass = dataProviderApp.class, groups ={"正常单创建变更单", "正常单变更后调账确认流程","正常单变更后变更确认流程","正常单变更后变更再调账确认流程"})
		public static void endorseOrderCreate(String endorseCheckinDate,String endorseCheckoutDate,String endorseRoomNo) throws Exception {

			Utils.waitForElement(5, driver, "page");
			OrderManageNormalOrderCompleteAction.transmitDriver(driver);
			//点击创建变更单按钮，页面弹出更改信息窗口
			OrderManageNormalOrderCompleteAction.CreateEndorseOrder();
			Thread.sleep(1000);
			//点击选择日期
			OrderManageNormalOrderCompleteAction.DateButton();
			Thread.sleep(1000);
			//点击入住时间输入框
			OrderManageNormalOrderCompleteAction.CheckinDate();
			Thread.sleep(1000);
			//选择入住时间
			OrderManageNormalOrderCompleteAction.SetCheckinDate(endorseCheckinDate);
			Thread.sleep(1000);
			//点击离店时间输入框
			OrderManageNormalOrderCompleteAction.CheckoutDate();
			Thread.sleep(1000);
			//选择离店时间输入框
			OrderManageNormalOrderCompleteAction.SetCheckoutDate(endorseCheckoutDate);
			Thread.sleep(1000);
			//设置房间数
			OrderManageNormalOrderCompleteAction.RoomNo(endorseRoomNo);
			Thread.sleep(1000);
			//点击保存按钮
			OrderManageNormalOrderCompleteAction.SaveButton();
			Thread.sleep(1000);
			OrderManageNormalOrderCompleteAction.transmitDriver(driver);
			Thread.sleep(1000);
			//点击预定按钮
			OrderManageNormalOrderCompleteAction.bookButton(Constant.bookHotelId);
			Thread.sleep(2000);
			//进入变更单创建页面
			OrderManageEndorseOrderCreateAction.transmitDriver(driver);
			//点击创建变更单按钮
			OrderManageEndorseOrderCreateAction.CreateEndorseOrder();
			Thread.sleep(2000);
			//页面跳转到支付页面
			//获取变更单的ID
			OrderManageOrderPayAction.transmitDriver(driver);
			Constant.EndorseOrderId = OrderManageOrderPayAction.GetOrderId();
			Constant.TempId = Constant.EndorseOrderId;
			System.out.println(Constant.TempId);
			Thread.sleep(3000);
			
		}
		
	@Test(priority = 43,groups ={"正常单变更确认流程","正常单变更取消流程", "正常单变更后调账确认流程","正常单变更后变更确认流程","正常单变更后变更再调账确认流程"})
	public static void endorseOrderDetail() throws Exception{
		
		OrderManageOrderListAction.transmitDriver(driver);
		//根据订单ID查询出订单，点击进入订单详情页
		OrderManageOrderListAction.OrderIdInput(Constant.TempId);
		Thread.sleep(2000);
		OrderManageOrderListAction.SearchOrder();
		Thread.sleep(2000);
		OrderManageOrderListAction.OrderClick();
		Thread.sleep(2000);
	}	
		
		// 确认变更 -- 变更审核：酒店确认码&&结算提醒设置
		@Test( priority = 45,groups ={"正常单变更确认流程", "正常单变更后调账确认流程","正常单变更后变更确认流程","正常单变更后变更再调账确认流程"})
		public static void endorseOrderAuditOrderCodeSettle() throws Exception{
			// = cdriver;
			//进入审核页面
			//点击确认变更按钮
			OrderManageEndorseOrderAuditAction.transmitDriver(driver);
			OrderManageEndorseOrderAuditAction.confirmEndrose();
			Thread.sleep(1000);
			//选择不需要酒店确认码
			OrderManageNormalOrderAuditAction.excute_ConfirmID2();
			Thread.sleep(1000);
			//保存酒店确认码
			OrderManageNormalOrderAuditAction.excute_Save_ConfirmID();
			Thread.sleep(1000);
			//选择周结
			OrderManageNormalOrderAuditAction.excute_WEEK_SETTLE();
			Thread.sleep(1000);
			//点击保存结算方式按钮
			OrderManageNormalOrderAuditAction.excute_Save_Count();
			//页面跳转到变更单完成页面
			Thread.sleep(5000);
		}
		
		// 取消便更
		@Test(priority = 45,groups ={"正常单变更取消流程", "正常单变更后调账确认流程","正常单变更后变更确认流程","正常单变更后变更再调账确认流程"})
		public static void  endorseOrderAuditOrderCancle() throws Exception{
			Utils.waitForElement(5, driver, "page");
			// 审核 调账单Driver传递
			OrderManageEndorseOrderAuditAction.transmitDriver(driver);
			OrderManageEndorseOrderAuditAction.cancelEndrose();
			Thread.sleep(2000);
			OrderManageEndorseOrderAuditAction.excuteCancelRemark();
			Thread.sleep(2000);
			OrderManageEndorseOrderAuditAction.excuteCancelOrderSave();
			Thread.sleep(2000);
		}
	}


package com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.addCustomerServiceRemarkPage;
import com.travelzen.Utility.LogCenter.Log;

public class addCostomerServiceRemarkAction {
	
	private static WebDriver webdriver;
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webdriver = driver;
		addCustomerServiceRemarkPage.getWebDriver(webdriver);
	}
	
	// 添加客服说明 -- 文本框--输入信息
	@Test
	public static void excuteSendLogContent(String string) throws Exception{
		
		addCustomerServiceRemarkPage.log_content().sendKeys(string);
		Log.info("LogContent text is written");
	}
	
	// click--添加客服说明--button
	@Test
	public static void excuteAddCustomerServiceBtn() throws Exception{
		
		addCustomerServiceRemarkPage.addCustomerService().click();
		Log.info("AddCustomerService Btn is clicked");
	}
	
	// 跳转--order manage--链接
	@Test
	public static void excuteGotoOrderManageBtn() throws Exception{
		
		addCustomerServiceRemarkPage.getOrderManageButton().click();
		Log.info("OrderManage Button is clicked");
	}
  

}

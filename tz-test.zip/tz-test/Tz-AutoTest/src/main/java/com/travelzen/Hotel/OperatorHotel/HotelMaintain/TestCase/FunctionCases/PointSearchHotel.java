package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.FunctionCases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.databene.feed4testng.FeedTest;
import org.databene.benerator.anno.*;

import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.BookingHotelAction;
import com.travelzen.Utility.Utils.*;
//import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.HotelMaintainHomeAction;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.HotelHomeAction;
import com.travelzen.Login.OperatorLogin.TestCase.FunctionCases.LoginTC;


public class PointSearchHotel extends FeedTest{

	public static WebDriver currentDriver;
	
	//TestCase中的每一个Function都可以为其做一张参数表
	//对我们需要输入的值参数化
	
	//这个Class是用于建立 AddHotel入口：完成在跳转到“添加酒店”之前的所有工作
	@Test(dataProvider = "feeder")
	@Source("LoginInfo_TestData.xls")
	public static void pointSearchHotel(String username, String password) throws Exception {
		//Login system
		LoginTC.login(username, password);
		
		//fetch WebDriver
		currentDriver = LoginTC.driver;
		
		//location hotel Search page
		Utils.waitForElement(5, currentDriver, "page");
		HotelHomeAction.transmitDriver(currentDriver);
		//currentDriver.get(Constant.hotelMaintainURL);
		HotelHomeAction.excuteHotelSearch();
		
		//goto prepay hotel search page
		Utils.waitForElement(5, currentDriver, "page");
		BookingHotelAction.transmitDriver(currentDriver);
		BookingHotelAction.Booking();
		
	}
	
}


package com.travelzen.Login.PurchaseLogin.AppModules;


import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.databene.feed4testng.FeedTest;

import com.travelzen.Login.PurchaseLogin.PageObjects.LoginPage;
import com.travelzen.Utility.LogCenter.Log;

public class LoginAction extends FeedTest{
	
private static WebDriver webdriver;
	
	//传递WebDriver	
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webdriver = driver;
		LoginPage.getWebDriver(webdriver);
	}
	
	//输入用户名
	public static void setUserNameValue(String username){
		
		try{
			LoginPage.txt_UserNmae().sendKeys(username);
			Log.info("输入用户名：" + username);
		}catch (Exception e){
			Log.info(e.getMessage());
		}
	}
	
	//获取输入后的值
	public static String getSetUserNameValue(){
		
		String uname = "";
		try{
			uname = LoginPage.txt_UserNmae().getAttribute("value");
			
		}catch (Exception e){
			Log.info(e.getMessage()); 
		}
		return uname;
	}
	
	//输入密码
	public static void setPasswordValue(String password){
		
		try{
			LoginPage.txt_Password().sendKeys(password);
			Log.info("输入密码：" + password);
		}catch (Exception e){
			Log.info(e.getMessage());
		}
	}
		
	//点击登录按钮
	public static void clickLogin(){
		
		try{
			LoginPage.btn_LogIn().click();
			Log.info("点击登录按钮");
		}catch (Exception e){
			Log.info(e.getMessage());
		}
	}
	
	//获取 登录Button的名称
	public static String getLoginBtnName(){
		
		String lName = "";
		try{
			lName = LoginPage.btn_LogIn().getAttribute("value");
		}catch (Exception e){
			Log.info(e.getMessage());
		}
		return lName;
	}
	
}

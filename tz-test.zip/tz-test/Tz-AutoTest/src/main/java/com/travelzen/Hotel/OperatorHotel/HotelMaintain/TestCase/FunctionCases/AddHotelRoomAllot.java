package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.FunctionCases;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import com.travelzen.Utility.Utils.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.*;
public class AddHotelRoomAllot extends FeedTest {

	public static WebDriver currentDriver;

	//TestCase中的每一个Function都可以为其做一张参数表
	//对我们需要输入的值参数化
	
	// 库存与房态：页面信息编辑Case
	// 待完成: 参数化工作需要
	// 批量编辑 库存房态
//	@Test(enabled = true, priority = 10, dataProvider = "feeder")
//	@Source("RoomAllot_TestData.xls")
	public static void RoomAllot_EditAllRoomAllot(String noOfAllotedNo,
			String cutOffDay, String allotType) throws Exception {

		currentDriver = AddHotelBookingClass.currentDriver;
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainRoomAllotAction.transmitDriver(currentDriver);
		// 批量编辑库存房态
		HotelMaintainRoomAllotAction.excuteEditAll_Allot(noOfAllotedNo, cutOffDay,
				allotType);
		HotelMaintainRoomAllotAction.excuteEditAll_Allot_Save();
	}

	// 按房型编辑库存房态
//	@Test(enabled = false, dataProvider = "feeder")
//	@Source("RoomAllot_TestData.xls")
	public static void RoomAllot_EditAllRoomAllotByRoomCat(String noOfAllotedNo,
			String cutOffDay, String allotType) throws Exception{
		
		 Utils.waitForElement(5, currentDriver, "page");
		 HotelMaintainRoomAllotAction.excuteEditAllot(noOfAllotedNo, cutOffDay, allotType);
		 HotelMaintainRoomAllotAction.excuteEditAllot_Save();
	}
	
	// 每日库存管理：修改每天房量房态
	@Test(priority = 11)
	public static void RoomAllot_EditDailyRoomAllot() throws Exception {

		// 每日库存管理--"修改" 每日的房量房态
		HotelMaintainRoomAllotAction.excuteDailyEdit_RoomStorageBtn();
		Utils.waitForElement(3, currentDriver, "script");
		Thread.sleep(2000);
	}
	
	// 每日库存管理：修改每日的添加库存
	@Test(priority = 12)
	public static void RoomAllot_EditDailyRoomAllot_AddAllot(String addAllot) throws Exception {

		// 每日库存管理--"修改" 每日的添加库存
		HotelMaintainRoomAllotAction.excuteDailyEdit_AddAllot(addAllot);
		Thread.sleep(2000);
	}
	
	// 每日库存管理：修改每日的关房
	@Test(priority = 13)
	public static void RoomAllot_EditDailyRoomAllot_CloseRoom() throws Exception {

		// 每日库存管理：修改每天房态--关房
		HotelMaintainRoomAllotAction.excuteDailyEdit_CloseRoomElement();
		Thread.sleep(2000);
	}

	// 每日库存管理：修改每天--售完规则
	@Test(priority = 14)
	public static void RoomAllot_EditDailyRoomAllot_RoomStatus(String allotType) throws Exception {

		// 每日库存管理：修改每天--售完规则
		HotelMaintainRoomAllotAction.excuteDailyEdit_RoomStatus(allotType);
		Thread.sleep(2000);
		//保存每天房量房态的修改
		HotelMaintainRoomAllotAction.excuteDailyEdit_RoomStorageBtn_Save();
	}
	
	//添加库存与房态后，进入每日价格编辑页
	@Test(priority = 15)
	public static void RoomAllot_DailyRate() throws Exception{
		
		//触发“每日价格”Item，进入酒店每日价格编辑页面
		//由“库存与房态”页面 进入 “每日价格”页面
		HotelMaintainRoomAllotAction.excuteDailyRatePage();
		Thread.sleep(5000);
	}
}
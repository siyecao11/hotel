package com.travelzen.Insurance.PurchaseInsurance.AppModules;

import java.util.List;
import java.util.Set;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.*;
import com.travelzen.Insurance.PurchaseInsurance.PageObjects.*;
//import System.Windows.

public class OrderDetailAction {

	private static WebElement element;
	private static List<WebElement> elementList;
	public static WebDriver webdriver;
	private static Select oSelection;
	public static String option;
	private static WebElement[][] elementTable;

	/*
	 * author xuemei.ren date 07/01/2016
	 */
	public static void transmitDriver(WebDriver currentDriver) throws Exception {

		webdriver = currentDriver;
		OrderDetailPage.getDriver(currentDriver);
	}

	public static void switchToWindow(WebDriver webdriver) {
		Set<String> handles = webdriver.getWindowHandles();
		handles.remove(webdriver.getWindowHandle());
		for (String handle : handles) {
			webdriver.switchTo().window(handle);

			if (webdriver.getCurrentUrl().contains(
					"http://astore.op3.tdxinfo.com/tops-front-purchaser-additional/additional/insurance/orderDetail/detail?id")) {

				break;
			}
		}
	}

	// 订单管理--打开订单管理
	public static void excutOpenOrderManageAction() throws Exception {
		// webdriver.navigate().refresh();
		OrderDetailPage.getOrderListElement().click();
		Log.info("打开订单管理");
	}

	// ***********************订单详情--订单信息 检查点校验-start**************
	// 订单详情--获取订单号
	public static String excutGetOrderIdAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getOrderIdElement().getText();
		Log.info("订单详情页，获取订单号："+string);
		return string;
	}

	// 订单详情--获取下单时间
	public static String excutGetOrderCreatDateAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getOrderCreatDateElement().getText();
		Log.info("订单详情页，获取下单时间："+string);
		return string;
	}

	// 订单详情--获取支付方式
	public static String excutGetPayTypeAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getPayTypeElement().getText();
		Log.info("订单详情页，获取支付方式："+string);
		return string;
	}
	// 订单详情--获取订单状态
		public static String excutGetOrderStatusAction() throws Exception {
			// webdriver.navigate().refresh();
			String string = OrderDetailPage.getOrderStatusElement().getText();
			Log.info("订单详情页，获取订单状态："+string);
			return string;
		}

	// 订单详情--获取产品名称
	public static String excutGetProductNameAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getProductNameElement().getText();
		Log.info("订单详情页，获取产品名称："+string);
		return string;
	}

	// 订单详情--获取产品险种编号
	public static String excutGetInsuranceIdAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsuranceIdElement().getText();
		Log.info("订单详情页，获取险种编号："+string);
		return string;
	}

	// 订单详情--获取产品保险险种
	public static String excutGetInsuranceTypeAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsuranceTypeElement().getText();
		Log.info("订单详情页，获取险种类型："+string);
		return string;
	}

	// 订单详情--获取产品 保险期限
	public static String excutGetInsurancePeriodAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsurancePeriodElement().getText();
		Log.info("订单详情页，获取保险期限："+string);
		return string;
	}

	// 订单详情--获取产品最高保额（元）
	public static String excutGetPolicyMaximumAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getPolicyMaximumElement().getText();
		Log.info("订单详情页，获取产品最高保额（元）："+string);
		return string;
	}

	// 订单详情--获取产品面价
	public static String excutGetFacePriceAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getFacePriceElement().getText();
		Log.info("订单详情页，获取产品面价："+string);
		return string;
	}

	// 订单详情--获取产品保险费用
	public static String excutGetInsuranceFeeAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsuranceFeeElement().getText();
		Log.info("订单详情页，获取产品保险费用："+string);
		return string;
	}

	// 订单详情--获取产品适用范围
	public static String excutGetApplicationAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getApplicationElement().getText();
		Log.info("订单详情页，获取产品适用范围："+string);
		return string;
	}

	// 订单详情--获取被保人姓名
	public static String excutGetInsureeNameAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsureeNameElement(num).getText();
		Log.info("订单详情页，获取被保人姓名："+string);
		return string;
	}

	// 订单详情--获取被保人证件类型
	public static String excutGetInsureeDocTypeAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsureeDocTypeElement(num).getText();
		Log.info("订单详情页，获取被保人证件类型："+string);
		return string;
	}

	// 订单详情--获取被保人证件号码
	public static String excutGetInsureeDocCodeAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsureeDocCodeElement(num).getText();
		Log.info("订单详情页，获取被保人证件号码："+string);
		return string;
	}

	// 订单详情--获取被保人性别
	public static String excutGetInsureeGenderAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsureeGenderElement(num).getText();
		Log.info("订单详情页，获取被保人性别："+string);
		return string;
	}

	// 订单详情--获取被保人出生日期
	public static String excutGetInsureeBirthdayAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsureeBirthdayElement(num).getText();
		Log.info("订单详情页，获取被保人出生日期："+string);
		return string;
	}

	// 订单详情--获取被保人手机号码
	public static String excutGetInsureeMobilePhoneNameAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsureeMobilePhoneElement(num).getText();
		Log.info("订单详情页，获取被保人手机号码："+string);
		return string;
	}

	// 订单详情--获取被保人保单生效日期
	public static String excutGetEffectiveDateAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getEffectiveDateElement(num).getText();
		Log.info("订单详情页，获取被保人保单生效日期："+string);
		return string;
	}

	// 订单详情--获取被保人保单号
	public static String excutGetInsurerOrderIdAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsurerOrderIdElement(num).getText();
		Log.info("订单详情页，获取被保人保单号："+string);
		return string;
	}

	// 订单详情--获取被保人保单份数
	public static String excutGetCopiesAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getCopiesElement(num).getText();
		Log.info("订单详情页，获取被保人保单份数："+string);
		return string;
	}

	// 订单详情--获取被保人投保状态
	public static String excutGetInsureStatusAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsureStatusElement(num).getText();
		Log.info("订单详情页，获取被保人投保状态："+string);
		return string;
	}

	// 订单详情--获取投保人姓名
	public static String excutGetInsureNameAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsureNameElement(num).getText();
		Log.info("订单详情页，获取投保人姓名："+string);
		return string;
	}

	// 订单详情--获取投保人证件类型
	public static String excutGetInsureDocTypeAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsureDocTypeElement(num).getText();
		Log.info("订单详情页，获取投保人证件类型："+string);
		return string;
	}

	// 订单详情--获取投保人证件号码
	public static String excutGetInsureDocCodeAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsureDocCodeElement(num).getText();
		Log.info("订单详情页，获取投保人证件号码："+string);
		return string;
	}

	// 订单详情--获取投保人手机号
	public static String excutGetInsurePhoneAction(String num) throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsurePhoneElement(num).getText();
		Log.info("订单详情页，获取投保人手机号："+string);
		return string;
	}

	// *****************结算备注*******************
	// 订单详情--获取保险数量
	public static String excutGetInsureAmountAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsureAmountElement().getText();
		Log.info("订单详情页，获取结算保险数量："+string);
		return string;
	}

	// 订单详情--获取保险费用
	public static String excutGetInsurefeeNameAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getInsurefeeElement().getText();
		Log.info("订单详情页，获取结算保险费用："+string);
		return string;
	}

	// 订单详情--获取应收合计
	public static String excutGetTotalPriceAction() throws Exception {
		// webdriver.navigate().refresh();
		String string = OrderDetailPage.getTotalPriceElement().getText();
		Log.info("订单详情页，获取应收合计："+string);
		return string;
	}

	// ***********************订单详情--退保-start**************
	// 订单详情--点击退保按钮
	public static void excutSurrenderAction() throws Exception {
		// OrderDetailPage.getAbortElement().sendKeys(keys.F5);
		// webdriver.navigate().refresh();
		// Thread.sleep(5000);
		// webdriver.navigate().refresh();
		// Thread.sleep(2000);
		OrderDetailPage.getAbortElement().click();
		Log.info("点击退保按钮");
	}

	// 保险订单列表--选中退保人
	public static void excutSurrenderChooseAction(String String) throws Exception {
		for (int i = 0; i < OrderDetailPage.getSurrenderAmountElement().size(); i++) {
			// System.out.print("保单人数是："+OrderDetailPage.getSurrenderAmountElement().size());
			String sValue = OrderDetailPage.getSurrenderNameElement(Integer.toString(i + 1)).getText();
			// System.out.print("退保人姓名是："+sValue);
			if (sValue.equalsIgnoreCase(String)) {
				OrderDetailPage.getSurrenderChooseElement(Integer.toString(i + 1)).click();
			}
		}
		Log.info("选中的退保人是：" + String);
	}

	// 保险订单列表--提交退保
	public static void excutSurrenderSubmmitAction() throws Exception {
		OrderDetailPage.getSurrenderSubmmitElement().click();
		Log.info("点击提交，提交退保");
	}

	// 保险订单列表--取消退保
	public static void excutSurrenderCancelAction() throws Exception {
		OrderDetailPage.getSurrenderCancelElement().click();
		Log.info("点击取消，取消退保");
	}

	// ***********************订单详情--取消投保-start**************
	// 保险订单列表--点击取消投保按钮
	public static void excutCancelInsureAction() throws Exception {
		OrderDetailPage.getCancelInsureClickElement().click();
		Log.info("点击取消投保按钮");
	}

	// 保险订单列表--选中取消投保人人
	public static void excutCancelInsureChooseAction(String String) throws Exception {
		for (int i = 0; i < OrderDetailPage.getCancelInsureAmountElement().size(); i++) {
			String sValue = OrderDetailPage.getCancelInsureNameElement(Integer.toString(i + 1)).getText();
			System.out.print("保单人员名称是：" + sValue);
			if (sValue.equalsIgnoreCase(String)) {
				OrderDetailPage.getCancelInsureChooseElement(Integer.toString(i + 1)).click();
			}
		}
		Log.info("选中的取消投保人是：" + String);
	}

	// 保险订单列表--提交退保
	public static void excutCancelInsureSubmmitAction() throws Exception {
		OrderDetailPage.getCancelInsureSubmmitElement().click();
		Log.info("点击提交，提交取消投保");
	}

	// 保险订单列表--取消退保
	public static void excutInsureCancelAction() throws Exception {
		OrderDetailPage.getInsureCancelElement().click();
		Log.info("点击取消，取消取消投保");
	}

	// ***********************订单列表--投保、支付、取消-start**************
	// 保险订单列表--投保
	public static void excutUnderWriteAction() throws Exception {
		OrderDetailPage.getUnderWriteElement().click();
		Log.info("点击投保，投保失败的订单重新投保");
	}

	// 保险订单列表--订单支付
	public static void excutOrderPayAction() throws Exception {
		OrderDetailPage.getOrderPayElement().click();
		Log.info("点击支付，跳转到订单支付页面");
	}

	// 保险订单列表--取消订单
	public static void excutCancelOrderAction() throws Exception {
		// webdriver.navigate().refresh();
		// Thread.sleep(2000);
		OrderDetailPage.getCancelOrderElement().click();
		Log.info("点击取消订单，订单取消");
	}

	// 保险订单列表--取消订单--确认取消
	public static void excutCancelOrderConfirmAction() throws Exception {
		OrderDetailPage.getCancelOrderConfirmElement().click();
		Log.info("点击确认，订单确认取消");
	}

	// 保险订单列表--取消订单--取消操作
	public static void excutCancelOrderQuitAction() throws Exception {
		OrderDetailPage.getCancelOrderQuitElement().click();
		Log.info("点击取消，订单取消放弃");
	}

}
package com.travelzen.Insurance.PurchaseInsurance.PageObjects;

import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.*;

public class CreatOrderPage {

	private static WebElement element;
	private static List<WebElement> elementList;
	public static WebDriver driver;
	private static Select oSelection;
	public static String option;
	private static WebElement[][] elementTable;

	/*
	 * author xuemei.ren date 07/01/2016
	 */
	public static void getDriver(WebDriver webdriver) throws Exception {
		driver = webdriver;
	}
	// **************************产品信息 start******************

	// **************************产品信息 start******************
	// 创建订单页面--保险生效日期--日历控件
	public static WebElement getEffectiveDateElement() throws Exception {
		try {
			element = driver.findElement(By.id("effectiveDate"));
			Log.info("保险生效日期在创建订单页面");
		} catch (Exception e) {
			Log.error("保险生效日期不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--保险生效日期--选中日期
	public static WebElement getEffectiveDateClickElement() throws Exception {
		try {
			element =
			driver.findElement(By.cssSelector("a.ui-state-default.ui-state-active"));
	/*		String selectStr1 = "a[day='";
			String selectStr2 = "']";
			String selectStr3 = selectStr1 + date + selectStr1;
			element = driver.findElement(By.cssSelector(selectStr3));
*/
			Log.info("保险生效日期日历时间在创建订单页面");
		} catch (Exception e) {
			Log.error("保险生效日期日历时间不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--保险有效截止日期--日期
	public static WebElement getEffectiveDatePeriodElement() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='endDateSpan']"));
			Log.info("保险生效时段在创建订单页面");
		} catch (Exception e) {
			Log.error("保险生效时段不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--输入常旅客--text
	public static WebElement getFFPClickElement() throws Exception {
		try {
			element = driver.findElement(By.id("ffc_input"));
			Log.info("EditAllAllot element is found in RoomAllot Page");
		} catch (Exception e) {
			Log.error("********manager_select_checkbox is not found on the maincontent Page********");
		}
		return element;
	}

	// 创建订单页面--选中常旅客--select
	public static WebElement getFFPElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("//html/body/div[10]/ul/li[1]/label/input"));
			Log.info("EditAllAllot element is found in RoomAllot Page");
		} catch (Exception e) {
			Log.error("********manager_select_checkbox is not found on the maincontent Page********");
		}
		return element;
	}

	// ********************创建订单页面--被保险人信息--start***************************
	// 创建订单页面--第number个被保险人信息--姓名--text
	public static WebElement getInsureeNameElement(String number) throws Exception {
		try {
			element = driver.findElement(By.name("policys[" + number + "].insureeName"));
			Log.info("被保险人姓名元素在创建订单页面");
		} catch (Exception e) {
			Log.error("被保险人姓名元素不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--第number个被保险人信息--电话--text
	public static WebElement getMobelPhoneElement(String number) throws Exception {
		try {
			element = driver.findElement(By.name("policys[" + number + "].mobelPhone"));
			Log.info("被保险人电话元素在创建订单页面");
		} catch (Exception e) {
			Log.error("被保险人电话元素不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--第number个被保险人信息--证件类型--select
	public static Select getDocTypeElements(String number) throws Exception {

		try {
			oSelection = new Select(driver.findElement(By.name("policys[" + number + "].docType")));
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			String nameString = "policys[" + number + "].docType";
			jsExecutor.executeScript("var removeAttri=document.getElementsByName(\'" + nameString
					+ "\')[0];removeAttri.removeAttribute('style');");

			Log.info("第1个被保险人证件类型下拉列表元素在创建订单页面");
		} catch (Exception e) {
			Log.error("第1个被保险人证件类型下拉列表元素不在创建订单页面");
		}
		return oSelection;
	}

	// 创建订单页面--第number个被保险人信息--证件号码--text
	public static WebElement getDocCodeElement(String number) throws Exception {
		try {
			element = driver.findElement(By.name("policys[" + number + "].docCode"));
			Log.info("证件号码元素在创建订单页面");
		} catch (Exception e) {
			Log.error("证件号码元素不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--第number个被保险人信息--出生日期--text
	public static WebElement getBirthDateElement(String number) throws Exception {
		try {
			element = driver.findElement(By.name("policys[" + number + "].birthDate"));
			Log.info("出生日期元素不在创建订单页面");
		} catch (Exception e) {
			Log.error("出生日期元素不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--第number个被保险人信息--性别--select
	public static Select getGenderElements(String number) throws Exception {

		try {
			oSelection = new Select(driver.findElement(By.name("policys[" + number + "].gender")));
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			String nameString = "policys[" + number + "].gender";
			jsExecutor.executeScript("var removeAttri=document.getElementsByName(\'" + nameString
					+ "\')[0];removeAttri.removeAttribute('style');");

			Log.info("第" + number + "个被保险人性别下拉列表元素在创建订单页面");
		} catch (Exception e) {
			Log.error("第" + number + "个被保险人性别下拉列表元素不在创建订单页面");
		}
		return oSelection;
	}

	// 创建订单页面--第number个被保险人信息--投保数量--select
	public static Select getInsuranceAmountElements(String number) throws Exception {

		try {
			oSelection = new Select(driver.findElement(By.name("policys[" + number + "].insuranceAmount")));
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			String nameString = "policys[" + number + "].insuranceAmount";
			jsExecutor.executeScript("var removeAttri=document.getElementsByName(\'" + nameString
					+ "\')[0];removeAttri.removeAttribute('style');");

			Log.info("第" + number + "个被保险人投保数量下拉列表元素在创建订单页面");
		} catch (Exception e) {
			Log.error("第" + number + "个被保险人投保数量下拉列表元素不在创建订单页面");
		}
		return oSelection;
	}

	// *******************************被保险人信息 -- end--**********************
	// *******************************投保人信息--start--************************
	// 创建订单页面--投保人信息--姓名--text
	public static WebElement getInsureNameElement() throws Exception {
		try {
			element = driver.findElement(By.name("policys[0].insurerName"));
			Log.info("投保人姓名元素在创建订单页面");
		} catch (Exception e) {
			Log.error("投保人姓名元素不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--投保人信息--电话--text
	public static WebElement getInsurerPhoneElement() throws Exception {
		try {
			element = driver.findElement(By.name("policys[0].insurerPhone"));
			Log.info("投保人电话元素在创建订单页面");
		} catch (Exception e) {
			Log.error("投保人电话元素不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--投保人信息--证件类型--select
	public static Select getInsurerDocTypeElements() throws Exception {

		try {
			oSelection = new Select(driver.findElement(By.name("policys[0].insurerDocType")));
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;

			// String nameString = "policys[" + number + "].insurerDocType";
			jsExecutor.executeScript(
					"var removeAttri=document.getElementsByName(\" policys[0].insurerDocType\")[0];removeAttri.removeAttribute('style');");

			Log.info("投保人证件类型下拉列表元素在创建订单页面");
		} catch (Exception e) {
			Log.error("投保人证件类型下拉列表元素不在创建订单页面");
		}
		return oSelection;
	}

	// 创建订单页面--投保人信息--证件号码--text
	public static WebElement getInsurerDocCodeElement() throws Exception {
		try {
			element = driver.findElement(By.name("policys[0].insurerDocCode"));
			Log.info("投保人证件号码元素在创建订单页面");
		} catch (Exception e) {
			Log.error("投保人证件号码元素不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--投保人信息--出生日期--text
	public static WebElement getInsurerBirthdayElement() throws Exception {
		try {
			element = driver.findElement(By.name("policys[0].insurerBirthDate"));
			Log.info("投保人出生日期元素在创建订单页面");
		} catch (Exception e) {
			Log.error("投保人出生日期元素不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--第number个人投保人信息--性别--select
	public static Select getInsurerGenderElements() throws Exception {

		try {
			oSelection = new Select(driver.findElement(By.name("policys[0].insurerGender")));
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			// String nameString = "policys[" + number + "].insurerGender";
			jsExecutor.executeScript(
					"var removeAttri=document.getElementsByName(\" policys[0].insurerGender\")[0];removeAttri.removeAttribute('style');");
			Log.info("投保人性别下拉列表元素在创建订单页面");
		} catch (Exception e) {
			Log.error("投保人性别下拉列表元素不在创建订单页面");
		}
		return oSelection;
	}

	// *******************************投保人信息--end--************************
	// 创建订单页面--新增投保人信息--click
	public static WebElement getAddElement() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='order-form']/div[4]/div[2]/a"));
			Log.info("新增投保人btn在创建订单页面");
		} catch (Exception e) {
			Log.error("新增投保人btn不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--删除第n个投保人--click
	public static WebElement getDelElement(String number) throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='order-form']/div[4]/div[2]/div[" + number + "]/a"));
			Log.info("删除投保人btn在创建订单页面");
		} catch (Exception e) {
			Log.error("删除投保人btn不在创建订单页面");
		}
		return element;
	}

	// *******************************订单金额--提交订单--start--*****************************
	// 创建订单页面--应收合计
	public static WebElement getTotalPriceSpanElement() throws Exception {
		try {
			element = driver.findElement(By.id("totalPriceSpan"));
			Log.info("应收合计页面元素在创建订单页面");
		} catch (Exception e) {
			Log.error("应收合计页面元素不在创建订单页面");
		}
		return element;
	}

	// 创建订单页面--提交订单--click btn
	public static WebElement getSubmitElement() throws Exception {
		try {
			element = driver.findElement(By.id("submitCreateButton"));
			Log.info("提交订单btn在创建订单页面");
		} catch (Exception e) {
			Log.error("提交订单btn不在创建订单页面");
		}
		return element;
	}

	// *******************************订单金额--提交订单--end--*****************************

}
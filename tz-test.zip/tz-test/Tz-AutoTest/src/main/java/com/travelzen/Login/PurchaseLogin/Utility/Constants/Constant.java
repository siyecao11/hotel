package com.travelzen.Login.PurchaseLogin.Utility.Constants;


public class Constant {
	
    public static final String OPLOGINURL = "http://member.op3.tdxinfo.com/tops-front-operator-member/facade/signin";
    public static final String PurchaserURL = "http://store.op3.tdxinfo.com/tops-front-purchaser/facade/signin";
    
}

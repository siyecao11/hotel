package com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.Log;
/*
 * 变更单审核页面
 * 
 * */
public class OrderManageEndorseOrderAuditPage {

	public static WebDriver driver;
	private static WebElement element;
	private static List<WebElement> elementList;
	
	public static void getDriver(WebDriver webdriver){
		driver = webdriver;
	}
	
	//取消变更按钮
	public static WebElement getCancelEndroseButton() throws Exception {
		try{
			element = driver.findElement(By.xpath(".//*[@id='operator_cancel_endorse_order']/span[2]"));
			Log.info("CancelEndroseButton is found in the EndorseOrder_Audit Page.");
		}catch (Exception e){
			Log.error("CancelEndroseButton is not found in the EndorseOrder_Audit Page.");
		}
		return element;	
	}
	
	//确认变更按钮
	public static WebElement getConfirmEndroseButton() throws Exception {
		try{
			element = driver.findElement(By.xpath(".//*[@id='operator_confirm_endorse_order']/span[2]"));
			Log.info("ConfirmEndroseButton is found in the EndorseOrder_Audit Page.");
		}catch (Exception e){
			Log.error("ConfirmEndroseButton is not found in the EndorseOrder_Audit Page.");
		}
		return element;	
	}
	
	//修改订单按钮
	public static WebElement getModifyEndroseButton() throws Exception {
		try{
			element = driver.findElement(By.xpath(".//*[@id='operator_modify_endorse_order']/span[2]"));
			Log.info("ModifyEndroseButton is found in the EndorseOrder_Audit Page.");
		}catch (Exception e){
			Log.error("ModifyEndroseButton is not found in the EndorseOrder_Audit Page.");
		}
		return element;	
	}

	//Location 取消便更--取消原因  元素
	@Test
	public static WebElement getCancelRemarkElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("cancelRemark"));
			Log.info("cancelRemark elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("cancelRemark elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location 取消变更--取消--保存 元素
	@Test
	public static WebElement getCancelOrderSaveElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("cancelOrderWindow_save"));
			Log.info("cancelOrderWindow_save elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("cancelOrderWindow_save elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
		
		//******************************酒店确认码 弹层元素Location  Start ************************************
		
		// Loaction 酒店确认码 Radio 元素
		// 同时Location 酒店确认码 Input 输入框元素
		@Test
		public static List<WebElement> getConfirmBooking_ConfirmID1() throws Exception{
			
			try{
				try{
					element = driver.findElement(By.xpath(".//*[@id='confirmBookingPopWin']/div[1]"));
					Log.info(element+" Confirm_Order element is found in BookingClass Page");
				}catch (Exception e){
					Log.error("Confirm_Order element is not found in BookingClass Page");
				}	
				elementList = element.findElements(By.tagName("input"));
				Log.info("Confirm_Order elements is found in Order_AuditOrder Page");
			}catch (Exception e){
				Log.error("Confirm_Order elements is not found in Order_AuditOrder Page");
			}	
			return elementList;
		}
		
		// Loaction 无酒店确认码 Radio 元素
		@Test
		public static WebElement getConfirmBooking_ConfirmID2() throws Exception{
			
			try{
				
				element = driver.findElement(By.xpath(".//*[@id='confirmBookingPopWin']/div[2]/label/input"));
				Log.info("Confirm_Order element is found in BookingClass Page");
			}catch (Exception e){
				Log.error("Confirm_Order element is not found in Order_AuditOrder Page");
			}	
				
			return element;
		}
		
		// Loaction 酒店确认码信息 -- 确认btn 元素
		@Test
		public static WebElement getConfirmBooking_Save() throws Exception{
					
			try{
				element = driver.findElement(By.id("confirmBooking_save"));
				Log.info("ConfirmBooking_Save element is found in Order_AuditOrder Page");
			}catch (Exception e){
				Log.error("ConfirmBooking_Save element is not found in Order_AuditOrder_Page");
			}
			return element;
		}
		
		// Loaction 酒店确认码信息 -- 取消btn 元素
		@Test
		public static WebElement getConfirmBooking_Cancel() throws Exception{
					
			try{
				element = driver.findElement(By.id("confirmBooking_cancel"));
				Log.info("ConfirmBooking_Cancel element is found in Order_AuditOrder_Page");
			}catch (Exception e){
				Log.error("ConfirmBooking_Cancel element is not found in Order_AuditOrder_Page");
			}
			return element;
		}
		
		//******************************酒店确认码 弹层元素Location  End   ************************************
		
		//*****************************结算修改提醒  弹层元素Location  Start ***********************************
		
		//Location 修改结算提醒 -- 现结元素
		//同时location “上午”“下午”选择框
		@Test
		public static List<WebElement> getCount_NOW_SETTLE() throws Exception{
			
			try{
				try{
				element = driver.findElement(By.xpath(".//*[@id='checkoutContainer']/div[1]"));
				Log.info(element+" Confirm_Order element is found in BookingClass Page");
			}catch (Exception e){
				Log.error("Confirm_Order element is not found in Order_AuditOrder_Page");
			}	
				elementList = element.findElements(By.tagName("input"));
				Log.info("Confirm_Order elements is found in BookingClass Page");
			}catch (Exception e){
				Log.error("Confirm_Order elements is not found in Order_AuditOrder_Page");
			}	
			return elementList;
		}
		
		// Location 修改结算提醒 -- 周结页面元素
		@Test
		public static WebElement getCount_WEEK_SETTLE() throws Exception {

			try {
				element = driver
						.findElement(By
								.xpath(".//*[@id='checkoutContainer']/div[2]/label[1]/input"));
				Log.info(element.getAttribute("value")
						+ " AddRate element is found in Order_AuditOrder_Page");
			} catch (Exception e) {
				Log.error("AddRate element is not found in Order_AuditOrder_Page");
			}
			return element;
		}

		// Location 修改结算提醒 -- 半月结页面元素
		@Test
		public static WebElement getCount_HALF_MONTH_SETTLE() throws Exception {

			try {
				element = driver
						.findElement(By
								.xpath(".//*[@id='checkoutContainer']/div[2]/label[2]/input"));
				Log.info(element.getAttribute("value")
						+ " AddRate element is found in Order_AuditOrder_Page");
			} catch (Exception e) {
				Log.error("AddRate element is not found in Order_AuditOrder_Page");
			}
			return element;
		}

		// Location 修改结算提醒 -- 月结页面元素
		@Test
		public static WebElement getCount_MONTH_SETTLE() throws Exception {

			try {
				element = driver
						.findElement(By
								.xpath(".//*[@id='checkoutContainer']/div[2]/label[3]/input"));
				Log.info(element.getAttribute("value")
						+ " AddRate element is found in Order_AuditOrder_Page");
			} catch (Exception e) {
				Log.error("AddRate element is not found in Order_AuditOrder_Page");
			}
			return element;
		}

		// Location 修改结算提醒 -- 保存 -- 预订页面元素
		@Test
		public static WebElement getCount_Save() throws Exception {

			try {
				element = driver.findElement(By.id("saveSettle"));
				Log.info("saveSettle element is found in Order_AuditOrder_Page");
			} catch (Exception e) {
				Log.error("saveSettle element is not found in Order_AuditOrder_Page");
			}
			return element;
		}
		
		// Location 修改结算提醒 -- 取消 -- 预订页面元素
		@Test
		public static WebElement getCount_Cancle() throws Exception{

			try {
				element = driver.findElement(By.id("cancelSettle"));
				Log.info("cancelSettle element is found in Order_AuditOrder_Page");
			} catch (Exception e) {
				Log.error("cancelSettle element is not found in Order_AuditOrder_Page");
			}
			return element;
		}

		//*****************************结算修改提醒  弹层元素Location  End   ***********************************

	
	
	
	
	
	
	
}

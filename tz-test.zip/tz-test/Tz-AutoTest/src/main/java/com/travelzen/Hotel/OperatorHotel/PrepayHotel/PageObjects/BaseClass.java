package com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;

public class BaseClass{
	
	public static WebDriver driver;
	
	@Test
	public BaseClass(WebDriver driver) {
		BaseClass.driver = driver;
		
	}
	
}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules;

import org.testng.annotations.Test;

import java.util.List;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Utility.Utils.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.HotelMaintainRoomCatPage;
import com.travelzen.Utility.Constants.*;
import com.travelzen.Utility.LogCenter.*;

public class HotelMaintainRoomCatAction {

	public static List<WebElement> rdBtn_BedType;
	private static WebDriver webdriver;
	public static WebElement element;

	// private static List oSize;
	// private static Select oselection;

	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {

		webdriver = driver;
		HotelMaintainRoomCatPage.getWebDriver(webdriver);
	}

	// 跳转到添加房型窗口
	@Test
	public static void excute_Click_AddRoom() throws Exception {

		HotelMaintainRoomCatPage.getAddRoom_Type().click();
		Utils.waitForElement(3, webdriver, "script");
	}

	// 选择 机加酒打包 click
	@Test
	public static void excute_Input_PackagedSales(String PacSal) throws Exception {
		// 获取机+酒打包产品信息
		if (PacSal.equals(PacSal)) {
			HotelMaintainRoomCatPage.getPackagedSales().click();
			Log.info("PackagedSales info has been input");
		}
	}

	// 填写 房间名称 input
	@Test
	public static void excute_Input_RoomName(String RoomName) throws Exception {
		// 获取机+酒打包产品信息
		HotelMaintainRoomCatPage.getRoomName().sendKeys(RoomName);
		Log.info("RoomName has been input");
	}

	// 选择入住人数 CapaciyNo select
	@Test
	public static void excute_Select_CapaciyNo(String capaciyNo)
			throws Exception {
		// 获取机+酒打包产品信息
		// 选择可入住人数
		Select oselection = HotelMaintainRoomCatPage.getCapaciyNo();
		List oSizeC = oselection.getOptions();
		int iSizeC = oSizeC.size();
		for (int i = 0; i < iSizeC; i++) {
			String sValueC = oselection.getOptions().get(i).getText();
			// 选中下拉列表元素
			if (sValueC.equals(capaciyNo)) {
				oselection.selectByIndex(i);
				break;
			}
		}
		Log.info("CapaciyNo" + capaciyNo + "has been input");
	}

	// 填写房间面积 InsideSpace
	@Test
	public static void excute_Input_InsideSpace(String insideSpace)
			throws Exception {
		HotelMaintainRoomCatPage.getInsideSpace().sendKeys(insideSpace);
		Log.info("InsideSpace has been input");
	}

	// 填写起始楼层 StartFloor
	@Test
	public static void excute_Input_StartFloor(String StartFloor)
			throws Exception {
		HotelMaintainRoomCatPage.getFloorNum1().sendKeys(StartFloor);
		Log.info("StartFloor has been input");
	}

	// 填写结束楼层 EndFloor
	@Test
	public static void excute_Input_EndFloor(String EndFloor) throws Exception {
		HotelMaintainRoomCatPage.getFloorNum2().sendKeys(EndFloor);
		Log.info("EndFloor has been input");
	}

	// 选择窗户类型 HotelWindow select
	@Test
	public static void excute_Select_HotelWindow(String hotelWindow)
			throws Exception {
		Select oselection = HotelMaintainRoomCatPage.getHotelWindow();
		List oSizeW = oselection.getOptions();
		int iSizeW = oSizeW.size();
		for (int i = 0; i < iSizeW; i++) {
			String sValueW = oselection.getOptions().get(i).getText();
			//Log.info("iSizeW" + sValueW + "has been selected");
			// 选中下拉列表元素
			if (sValueW.equals(hotelWindow)) {
				oselection.selectByIndex(i);
				break;
			}
			Log.info("hotelWindow" + hotelWindow + "has been selected");
		}
	

	}

	// 选择床型Select_BedType
	@Test
	public static void excute_Select_BedType(String bedType) throws Exception {

		element = HotelMaintainRoomCatPage.getRoomBedType(bedType);
		element.click();

		Log.info("BedType" + bedType + "has been selected");

	}
	// 选择床型尺寸 BedSize select
	@Test
	public static void excute_Select_BedSize(String bedSize)
			throws Exception {
		Select oselection = HotelMaintainRoomCatPage.getBedSize();
		//oselection.getFirstSelectedOption().click();
		List oSizeW = oselection.getOptions();
		Log.info("oSizeW" + oSizeW + "has been selected");
		int iSizeW = oSizeW.size();
		//oselection.selectByVisibleText(bedSize);
		
		//Log.info("iSizeW" + iSizeW + "has been selected");
		for (int i = 0; i < iSizeW; i++) {            
			//String sValueW = oselection.getOptions().get(i).getText();
			String sValueW = oselection.getOptions().get(i).getAttribute("value");
			Log.info("iSizeW" + sValueW + "has been selected");
			// 选中下拉列表元素
			if (sValueW.equals(bedSize)) {
				Log.info("sValueW equals BedSize");
				oselection.selectByValue(bedSize);
				//oselection.selectByIndex(i);
				break;
			}
		}
		Log.info("BedSize" + bedSize + "has been selected");

	}
	// 选择房间设施 RoomFacilities click
	@Test
	public static void excute_Select_RoomFacilities(String roomFacilities)
			throws Exception {	
		// 获取房间设施

	      String[] arrayStr =new String[]{};
	      arrayStr = roomFacilities.split(",");
	      List listFacilitieslist = java.util.Arrays.asList(arrayStr);
		//List<String>slist = Arrays.asList(listFacilitieslist);
		int lSize = listFacilitieslist.size();
		for (int i = 0; i < lSize; i++) {
			if (listFacilitieslist.get(i) != "0") {
				element = HotelMaintainRoomCatPage.getRoomFacilities(i + 1);
				element.click();
			}
		}
		Log.info("RoomFacilities has been selected");

	}
	//保存 Save
	@Test
	public static void excute_Save() throws Exception {
		HotelMaintainRoomCatPage.getSaveButton().click();
		Log.info("SaveButton has been input");
	}

	
/*	
	// 填写房型信息的必填项，房型名称、床型、
	@Test
	public static void excuteRoomType_Required(String RoomName,
			String capaciyNo, String hotelWindow, String bedType, List list)
			throws Exception {
		// public static void excuteRoomType_Required(String RoomName,String
		// capaciyNo,String hotelWindow)throws Exception {

		// HotelMaintain_BookingClass_Page.getAddRoom_Type().click();
		// Utils.waitForElement(3, webdriver, "script");
		// 获取机+酒打包产品信息
		// if(PacSal==1){
		// HotelMaintain_BookingClass_Page.getPackagedSales().click();
		// Log.info("PackagedSales info has been input");
		// }
		// 填写酒店房型名称
		HotelMaintainRoomCatPage.getRoomName().sendKeys(RoomName);
		Log.info("RoomName has been input");

		// 选择可入住人数
		Select oselection = HotelMaintainRoomCatPage.getCapaciyNo();
		List oSizeC = oselection.getOptions();
		int iSizeC = oSizeC.size();
		for (int i = 0; i < iSizeC; i++) {
			String sValueC = oselection.getOptions().get(i).getText();
			// 选中下拉列表元素
			if (sValueC.equals(capaciyNo)) {
				oselection.selectByIndex(i);
				break;
			}
		}
		Log.info("CapaciyNo" + capaciyNo + "has been input");

		// 选择窗户
		Select oselection2 = HotelMaintainRoomCatPage.getHotelWindow();
		List oSizeW = oselection2.getOptions();
		int iSizeW = oSizeW.size();
		for (int i = 0; i < iSizeW; i++) {
			String sValueW = oselection2.getOptions().get(i).getText();
			// 选中下拉列表元素
			if (sValueW.equals(hotelWindow)) {
				oselection2.selectByIndex(i);
				break;
			}
		}
		Log.info("hotelWindow" + hotelWindow + "has been input");

		
		element = HotelMaintainRoomCatPage.getRoomBedType(bedType);
		element.click();

		// 获取房间设施
		int lSize = list.size();
		for (int i = 0; i < lSize; i++) {
			if (list.get(i) != "0") {
				element = HotelMaintainRoomCatPage.getRoomFacilities(i + 1);
				element.click();
			}
		}

	}
	*/


	// get roomCat ID
	@Test
	public static String excuteGetRoomCatId() throws Exception {

		String str = HotelMaintainRoomCatPage.getDeletRoomCat().getAttribute(
				"rcid");
		return str;
	}

	// goto bookingClass edit page
	@Test
	public static void excute_BookingClassItem() throws Exception {
		HotelMaintainRoomCatPage.getBookingClassItemElement().click();
		Log.info("BookingClassItem has been clicked");
	}
	
	
	
}

package com.travelzen.Login.OperatorLogin.TestCase.FunctionCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;

import com.travelzen.Login.OperatorLogin.Utility.Utils.DataProviderApp;
import com.travelzen.Login.OperatorLogin.AppModules.LoginAction;
import com.travelzen.Login.OperatorLogin.AppModules.MenuItemAction;
import com.travelzen.Login.OperatorLogin.Utility.Constants.Constant;
import com.travelzen.Utility.Assertion.Assertion;
import com.travelzen.Utility.Constants.Constants;
import com.travelzen.Utility.LogCenter.Log;
import com.travelzen.Utility.ResultCollection.Report;
import com.travelzen.Utility.ScreenShot.RetryFail;
import com.travelzen.Utility.Utils.Utils;

import org.databene.feed4testng.FeedTest;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners({ com.travelzen.Utility.Assertion.AssertionListener.class,
		com.travelzen.Utility.ResultCollection.CustomReporter.class })
public class LoginOperator extends FeedTest {

	public static WebDriver driver;
	public static String actualValue = "aa";

	@BeforeClass(alwaysRun = true)
	public static void beforeClass() {

		// driver = new FirefoxDriver();
	}

	@BeforeMethod(alwaysRun = true)
	public static void beforeMethod() {

		System.setProperty("webdriver.firefox.bin", "C:/Program Files (x86)/Mozilla Firefox/firefox.exe");
		ProfilesIni pi = new ProfilesIni();
		FirefoxProfile profile = pi.getProfile("default");
		driver = new FirefoxDriver(profile);
		Constants.classDriver = driver;
	}

	@AfterMethod(alwaysRun = true)
	public static void afterMethod() {

		if (DataProviderApp.isLoginIncludeProcess.equalsIgnoreCase("false")) {
			driver.close();
		}
	}
	
	@Test(dataProvider = "longin_data", dataProviderClass = DataProviderApp.class, retryAnalyzer = RetryFail.class, priority = 1, groups = {"运营商登陆", "预付酒店查询", "正常单审核确认", "正常单创建", "正常单审核取消" ,"保险运营商创建"})
	public static void operatorLogin(String username, String password,
			String ename) throws Exception {

		// 打开运营商登陆页面
		driver.get(Constant.OPLOGINURL);
		// 输入用户名和密码，执行登陆
		LoginAction.transmitDriver(driver);
		// 传入用户信息，执行登录功能
		LoginAction.setUserNameValue(username);
		// 断言 输入是否成功
		Assertion.verifyEquals(LoginAction.getSetUserNameValue(), username);
		// 传入用户密码
		LoginAction.setPasswordValue(password);
		// 断言 登录button的名称
		Assertion.verifyEquals(LoginAction.getLoginBtnName(), "登  录");
		LoginAction.clickLogin();

		// 登录后页面跳转等待
		Utils.waitForElement(5, driver, "page");
		// 页面跳转，传递Driver
		MenuItemAction.transmitDriver(driver);
		// 断言登录是否成功
		// actualValue = MenuItemAction.getUserName();
		Log.info("Before: ***" + actualValue);
		actualValue = MenuItemAction.getUserName();
		Log.info("After: ***" + actualValue);
		String expectValue = ename;
		Assertion.verifyEquals(actualValue, expectValue);

	}
} 

package com.travelzen.Insurance.PurchaseInsurance.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.*;

public class OrderPayPage {
	private static WebElement element;
	private static List<WebElement> elementList;
	public static WebDriver driver;
	private static Select oSelection;
	public static String option;
	private static WebElement[][] elementTable;

	/*
	 * author xuemei.ren date 07/01/2016
	 */
	public static void getDriver(WebDriver webdriver) throws Exception {
		driver = webdriver;
	}

	// **************************产品信息 start******************
	// 订单支付页面--交易金额--text
	public static WebElement getActualAmountElement() throws Exception {
		try {
			element = driver.findElement(By.id("actualAmount"));
			Log.info("交易金额元素在支付页面");
		} catch (Exception e) {
			Log.error("交易金额元素不在支付页面");
		}
		return element;
	}

	// 订单支付页面--产品类型--text
	public static WebElement getProductTypeElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div/div[1]/table/tbody/tr/td[2]"));
			Log.info("产品类型元素在支付页面");
		} catch (Exception e) {
			Log.error("产品类型元素不在支付页面");
		}
		return element;
	}

	// 订单支付页面--获取订单号--link
	public static WebElement getOrderIdElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div/div[1]/table/tbody/tr/td[3]/a/span"));
			Log.info("订单号元素在支付页面");
		} catch (Exception e) {
			Log.error("订单号元素不在支付页面");
		}
		return element;
	}

	// **************************产品信息 end******************
	// 订单支付页面--支付密码--text
	public static WebElement getPasswordElement() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='password']"));
			Log.info("支付密码元素在支付页面");
		} catch (Exception e) {
			Log.error("支付密码元素不在支付页面");
		}
		return element;
	}

	// 订单支付页面--确认付款--text
	public static WebElement getPayAffirmElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div/div[2]/div/a/span[2]"));
			Log.info("确认付款元素在支付页面");
		} catch (Exception e) {
			Log.error("确认付款元素不在支付页面");
		}
		return element;
	}
	// **********************支付密码错误 start*************

	// 订单支付页面--确认付款--text
	public static WebElement getPayFalseElement() throws Exception {
		try {
			element = driver.findElement(By.className("adaptiveButton brightRed_btn ac-payAffirm"));
			Log.info("确认付款元素在支付页面");
		} catch (Exception e) {
			Log.error("确认付款元素不在支付页面");
		}
		return element;
	}

	// **********************支付密码错误 start*************

	// *******************支付后 start**********************

	// 订单支付页面--支付成功--text
	public static WebElement getPaySucessElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div/ul/li[1]"));
			Log.info("支付成功元素在支付后页面");
		} catch (Exception e) {
			Log.error("支付成功元素不在支付后页面");
		}
		return element;
	}
}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.FunctionCases;

import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import com.travelzen.Utility.Utils.*;
import com.travelzen.Utility.Constants.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.*;

public class AddHotelProviderMessage extends FeedTest{
	
	public static WebDriver currentDriver;
	
	//TestCase中的每一个Function都可以为其做一张参数表
	//对我们需要输入的值参数化
	
	//供应商信息--合同信息
	@Test(priority = 10)
	public static void ProviderMessage_ContractInfo(String beginTime,String endTime,
			String remindTime,String supplier,String supplierName,String supplierRemark,String supplierEntity,
			String supplierSettleperiod,String accountName,String bankName,String bankNumber
			) throws Exception {
		
		currentDriver = AddHotelMainContent.currentDriver;
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainProviderMessageAction.transmitDriver(currentDriver);
		//合同信息--“编辑自签合同”按钮触发
		Thread.sleep(2000);
		HotelMaintainProviderMessageAction.EditContract();
		Thread.sleep(1000);
		//合同信息--合同有效期--起始期
		HotelMaintainProviderMessageAction.SetContractStartTime(beginTime);
		Thread.sleep(1000);
		//合同信息--合同有效期--截止期
		HotelMaintainProviderMessageAction.SetContractEndTime(endTime);
		Thread.sleep(1000);
		//合同信息--合同有效期--到期提醒
		HotelMaintainProviderMessageAction.RemindTime(remindTime);//1
		Thread.sleep(1000);
		//合同信息--供应商类型
		HotelMaintainProviderMessageAction.Supplier(supplier);//1
		Thread.sleep(1000);
		//合同信息--供应商名称
		HotelMaintainProviderMessageAction.SupplierName(supplierName);//"王琪"
		Thread.sleep(1000);
		//合同信息--供应商备注
		HotelMaintainProviderMessageAction.SupplierRemark(supplierRemark);//"测试用例"
		Thread.sleep(1000);
		//合同信息--供应商实体
		HotelMaintainProviderMessageAction.SupplierEntity(supplierEntity);//1
		Thread.sleep(1000);
		//合同信息--结算提醒
		HotelMaintainProviderMessageAction.SupplierSettlePeriod(supplierSettleperiod);//1
		Thread.sleep(1000);
		//合同信息--收款账户名
		HotelMaintainProviderMessageAction.AccountName(accountName);//"王琪琪"
		Thread.sleep(1000);
		//合同信息--开户银行
		HotelMaintainProviderMessageAction.BankName(bankName);//"中国银行"
		Thread.sleep(1000);
		//合同信息--银行账号
		HotelMaintainProviderMessageAction.BankNumber(bankNumber);//"6222014569855698554"
		Thread.sleep(1000);
		//合同信息--保存合同信息
		HotelMaintainProviderMessageAction.SaveContract();
		Thread.sleep(5000);
	}
	
	//供应商信息--联系人信息
	@Test(priority = 11)
	public static void ProviderMessage_ContactInfo(
			String contactName,String contactMobilephone,String contactFox,String contactOfficePhone,
			String contactEmail,String workingHoursBegin,String workingHoursEnd,String dept,String contactRemark
			) throws Exception {
		
		//联系人信息--“添加联系人”按钮触发
		HotelMaintainProviderMessageAction.AddContact();
		Thread.sleep(1000);
		//联系人信息--联系人姓名
		HotelMaintainProviderMessageAction.ContactName(contactName);//"wangqiqi"
		Thread.sleep(1000);
		//联系人信息--联系人手机
		HotelMaintainProviderMessageAction.ContactMobilephone(contactMobilephone);//"13460303030"
		Thread.sleep(1000);
		//联系人信息--联系人传真
		HotelMaintainProviderMessageAction.ContactFox(contactFox);//"013-68597458"
		Thread.sleep(1000);
		//联系人信息--联系人座机
		HotelMaintainProviderMessageAction.ContactOfficePhone(contactOfficePhone);//"016-56984231"
		Thread.sleep(1000);
		//联系人信息--联系人Email
		HotelMaintainProviderMessageAction.ContactEmail(contactEmail);//"1016696@qq.com"
		Thread.sleep(1000);
		//联系人信息--传真接收开始时间
		
		HotelMaintainProviderMessageAction.WorkingHoursBegin(workingHoursBegin);//"10:00"
		Thread.sleep(1000);
		//联系人信息--传真接收截止时间
		HotelMaintainProviderMessageAction.WorkingHoursEnd(workingHoursEnd);//"18:00"
		Thread.sleep(1000);
		//联系人信息--联系人所在部门
		HotelMaintainProviderMessageAction.Dept(dept);//1
		Thread.sleep(1000);
		//联系人信息--联系人备注
		HotelMaintainProviderMessageAction.ContactRemark(contactRemark);//"测试用例"
		Thread.sleep(1000);
		//联系人信息--保存编辑信息
		HotelMaintainProviderMessageAction.SaveContact();
		Thread.sleep(2000);
	}

	//酒店供应商信息完成，进入酒店房型编辑页
	@Test(priority = 12)
	public static void ProviderMessage_RoomCat() throws Exception{
		
		//触发“酒店房型”Item，进入酒店房型编辑页面
		HotelMaintainProviderMessageAction.HotelHomeStyle();
		Thread.sleep(5000);
	}
	
	
	
	
	
	//酒店供应商信息断言验证
	@Test
	public static void assertEditContract() throws Exception{
		//点击供应商信息按钮
		HotelMaintainProviderMessageAction.assertEditContract();
		//比较合同起始时间一致性
		HotelMaintainProviderMessageAction.assertSetContractStartTime();
		//比较合同结束时间一致性
		HotelMaintainProviderMessageAction.assertSetContractEndTime();
		//比较到期前提醒时间设置一致性
		//HotelMaintainProviderMessageAction.assertRemindTime(); 
	    //比较供应商类型选择一致性
		HotelMaintainProviderMessageAction.assertSupplier();
		//比较供应商类型名称一致性
		//HotelMaintainProviderMessageAction.assertSupplierName();
	    //比较供应商类型备注一致性
		HotelMaintainProviderMessageAction.assertSupplierRemark();
	    //比较供应商实体选择一致性
		//HotelMaintainProviderMessageAction.assertSupplierEntity();
		//比较收款账户名一致性
		//HotelMaintainProviderMessageAction.assertAccountName();
	    //比较开户银行一致性
		HotelMaintainProviderMessageAction.assertBankName();
		//比较银行卡号一致性
		HotelMaintainProviderMessageAction.assertBankNumber();
		//保存合同信息
		HotelMaintainProviderMessageAction.assertSaveContract();
		}
	
	//比较联系人的信息一致性
	//点击添加联系人
	@Test
	public static void assertAddContact() throws Exception{
		//点击添加联系人按钮
		HotelMaintainProviderMessageAction.assertAddContact();
		//比较联系人姓名一致性
		HotelMaintainProviderMessageAction.assertContactName();
		//比较手机号码一致性
		HotelMaintainProviderMessageAction.assertContactMobilephone();
		//比较传真号码一致性
		HotelMaintainProviderMessageAction.assertContactFox();
		//比较座机号码一致性
		HotelMaintainProviderMessageAction.assertContactOfficePhone();
		//比较电子邮箱号码一致性
		HotelMaintainProviderMessageAction.assertContactEmail();
		//比较传真接收时间开始时间一致性
		HotelMaintainProviderMessageAction.assertWorkingHoursBegin();
		//比较传真接收时间结束时间一致性
		HotelMaintainProviderMessageAction.assertWorkingHoursEnd(); 
		//比较部门选择的一致性
		HotelMaintainProviderMessageAction.assertDept();
		//备注填写ע
		HotelMaintainProviderMessageAction.assertContactRemark();
		//保存联系人
		HotelMaintainProviderMessageAction.assertSaveContact();
	}
	
	
	
	
		
	}
	
	
	
	
	
	
	
	


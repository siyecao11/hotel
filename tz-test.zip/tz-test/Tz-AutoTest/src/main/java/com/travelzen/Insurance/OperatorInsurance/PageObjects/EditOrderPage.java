package com.travelzen.Insurance.OperatorInsurance.PageObjects;

/**
 * author：qiqi.wang
 * */
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Utility.LogCenter.Log;

public class EditOrderPage
{
	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	public static String option;

	public static void getDriver(WebDriver webdriver) throws Exception
	{
		driver = webdriver;
	}

	// 编辑订单页面-修改联系人姓名-输入框
	public static WebElement getContactNameInputElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.name("customerContactName"));
			Log.info("编辑订单页面“联系人姓名”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面“联系人姓名”输入框元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-修改联系电话-输入框
	public static WebElement getContactTelInputElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.name("customerContactTel"));
			Log.info("编辑订单页面“联系人电话”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面“联系人电话”输入框元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-修改联系人手机-输入框
	public static WebElement getContactMobilePhoneInputElement()
			throws Exception
	{
		try
		{
			element = driver.findElement(By.name("customerContactPhone"));
			Log.info("编辑订单页面“联系人手机”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面“联系人手机”输入框元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-选择保险生效日期-日期控件
	public static WebElement getInsuranceStartDateElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.id("dp1452309291121"));
			Log.info("编辑订单页面中“保险生效日期”控件元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“保险生效日期”控件元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-展示保险结束时间-文本
	public static WebElement getInsuranceEndDateElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.id("deadlineDate"));
			Log.info("编辑订单页面中“保险结束时间”文本元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“保险结束时间”文本元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-展示保险有效天数-文本
	public static WebElement getInsuranceDaysElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.id("insuranceDays"));
			Log.info("编辑订单页面中“保险有效天数”文本元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“保险有效天数”文本元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-填写被保人姓名-输入框
	public static WebElement getCustomerNameInputElement() throws Exception
	{
		try
		{
			element = driver.findElement(By
					.name("orderProducts[0].policys[0].insureeName"));
			Log.info("编辑订单页面中“被保人姓名”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“被保人姓名”输入框元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-填写被保人手机号码-输入框
	public static WebElement getCustomerMobileInputElement() throws Exception
	{
		try
		{
			element = driver.findElement(By
					.name("orderProducts[0].policys[0].mobelPhone"));
			Log.info("编辑订单页面中“被保人手机号码”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“被保人手机号码”输入框元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-选择证件类型-下拉框
	public static WebElement getIDTypeSelectElement() throws Exception
	{
		try
		{
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			jsExecutor
					.executeScript("var setDate=document.getElementsByName(\"orderProducts[0].policys[0].docType\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By
					.name("orderProducts[0].policys[0].docType"));
			Log.info("编辑订单页面中“证件类型”下拉框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“证件类型”下拉框元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-输入证件号码-输入框
	public static WebElement getIDNumInputElement() throws Exception
	{
		try
		{
			element = driver.findElement(By
					.name("orderProducts[0].policys[0].docCode"));
			Log.info("编辑订单页面中“证件号码”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“证件号码”输入框元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-选择出生日期-日期控件
	public static WebElement getBirthDateInputElement() throws Exception
	{
		try
		{
			element = driver.findElement(By
					.name("orderProducts[0].policys[0].birthDate"));
			Log.info("编辑订单页面中“被保人出生日期”选择框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“被保人出生日期”选择框元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-选择被保人性别-下拉框
	public static WebElement getSexTypeSelectElement()
	{
		try
		{
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			jsExecutor
					.executeScript("var setDate=document.getElementsByName(\"orderProducts[0].policys[0].gender\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By
					.name("orderProducts[0].policys[0].gender"));
			Log.info("编辑订单页面中“被保人性别”下拉框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“被保人性别”下拉框元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-选择保险份数-下拉框
	public static WebElement getInsuranceNumSelectElement()
	{
		try
		{
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			jsExecutor
					.executeScript("var setDate=document.getElementsByName(\"orderProducts[0].policys[0].insuranceAmount\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By
					.name("orderProducts[0].policys[0].insuranceAmount"));
			Log.info("编辑订单页面中“保险份数”选择框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“保险份数”选择框元素，未找到。");
		}
		return element;
	}
	
	//编辑订单页面-取消编辑-按钮
	public static WebElement getCancelEditButtonElement() throws Exception
	{
		try
		{
			element = driver.findElement(By
					.id("btn-cancel"));
			Log.info("编辑订单页面中“取消编辑”按钮元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“取消编辑”按钮元素，未找到。");
		}
		return element;
	}

	// 编辑订单页面-保存编辑-按钮
	public static WebElement getSaveEditButtonElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.id("btn-save"));
			Log.info("编辑订单页面中“保存编辑”按钮元素，已找到。");
		} catch (Exception e)
		{
			Log.error("编辑订单页面中“保存编辑”按钮元素，未找到。");
		}
		return element;
	}
	
	

}

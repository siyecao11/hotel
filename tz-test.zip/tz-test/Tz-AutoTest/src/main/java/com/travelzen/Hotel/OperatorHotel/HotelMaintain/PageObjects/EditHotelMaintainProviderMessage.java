package com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.*;

public class EditHotelMaintainProviderMessage extends BaseClass{
	
	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	public static String option;
	
	public EditHotelMaintainProviderMessage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	 
	public static void getDriver(WebDriver webdriver){
		driver = webdriver;
	}
    
	
	
	//编辑合同按钮
	@Test
	public static WebElement editContract() throws Exception{
		try{
			element = driver.findElement(By.id("addContract"));
		}catch (Exception e){
			Log.error("********EditContract is not found on the ProviderMessage Page********");
		}
		return element;
	}
	
	//合同开始时间
	@Test
	public static WebElement editContractStartTime() throws Exception{
		try{
			//((JavascriptExecutor) driver).executeScript("document.getElementByName(\"contractStartDate\").readOnly = false;");
			element = driver.findElement(By.name("contractStartDate"));
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"contractStartDate\")[0];setDate.removeAttribute('readonly');");
		}catch (Exception e){
			Log.error("********ContractStartTime is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	
	//合同结束时间
	@Test
	public static WebElement editContractEndTime() throws Exception{
		try{
			element = driver.findElement(By.name("contractEndDate"));
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"contractEndDate\")[0];setDate.removeAttribute('readonly');");
		}catch (Exception e){
			Log.error("********ContractEndTime is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
//到期提醒
	@Test
	public static WebElement editRemindTime() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='beforeDays']"));
		}catch (Exception e){
			Log.error("********RemindTime is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//供应商类型
	@Test
	public static WebElement editSupplier() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='supplier.supplierType']"));
			
		}catch (Exception e){
			Log.error("********Supplier is not found on the ProviderMessage Page********");
		}
		return element;
		}
	//供应商名称
	@Test
	public static WebElement editSupplierName() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='typeContent']"));
		}catch (Exception e){
			Log.error("********SupplierName is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//供应商备注ע
	@Test
	public static WebElement editSupplierRemark() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='typeRemark']"));
		}catch (Exception e){
			Log.error("********SupplierRemark is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//供应商实体
	@Test
	public static WebElement editSupplierEntity() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@name='supplier.supplierEntity']"));
		}catch (Exception e){
			Log.error("********SupplierEntity is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	
	
	
	//供应商结算提醒
	@Test
	public static WebElement editSupplierSettlePeriod() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@name='supplier.settlePeriod']"));
		}catch (Exception e){
			Log.error("********SupplierSettlePeriod is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	
	
	
	//收款人姓名
	@Test
	public static WebElement editAccountName() throws Exception{
		try{
			element = driver.findElement(By.name("supplier.accountInfos[0].accountName"));
		}catch (Exception e){
			Log.error("********AccountName is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//开户银行
	@Test
	public static WebElement editBankName() throws Exception{
		try{
			element = driver.findElement(By.name("supplier.accountInfos[0].openBank"));
		}catch (Exception e){
			Log.error("********BankName is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//开户账号
	@Test
	public static WebElement editBankNumber() throws Exception{
		try{
			element = driver.findElement(By.name("supplier.accountInfos[0].accountNo"));
		}catch (Exception e){
			Log.error("********BankNumber is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//保存合同
	@Test
	public static WebElement editSaveContract() throws Exception{
		try{
			driver.switchTo().defaultContent();
			element = driver.findElement(By.xpath("html/body/div[10]/div[2]/form/div/a[1]"));
		}catch (Exception e){
			Log.error("********SaveContract is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	/*****************************************************************************************************/	
	
	
	//修改联系人按钮
	@Test
	public static WebElement editContact() throws Exception{
		try{
			element = driver.findElement(By.id("editContact-0"));
		}catch (Exception e){
			Log.error("********editContact is not found on the ProviderMessage Page********");
		}
		return element;
	}
	
	//联系人姓名
	@Test
	public static WebElement editContactName() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='frmEditLinkman-0']/table/tbody/tr[1]/td[2]/input"));
	}catch (Exception e){
		Log.error("********ContactName is not found on the ProviderMessage Page********");
	}
		return element;
	}
	
	//联系人手机
	@Test
	public static WebElement editContactMobilephone() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='frmEditLinkman-0']/table/tbody/tr[1]/td[4]/input"));
		}catch (Exception e){
			Log.error("********ContactMobilephone is not found on the ProviderMessage Page********");
		}
		return element;
	}
	
	//联系人传真
	
	    @Test
		public static WebElement editContactFox() throws Exception{
			try{
				element =driver.findElement(By.xpath(".//*[@id='frmEditLinkman-0']/table/tbody/tr[1]/td[6]/input"));
			}catch (Exception e){
				Log.error("********ContactFox is not found on the ProviderMessage Page********");
			}
			return element;
		}
		
	//联系人办公室电话
		@Test
		public static WebElement editContactOfficePhone() throws Exception{
			try{
				element =driver.findElement(By.xpath(".//*[@id='frmEditLinkman-0']/table/tbody/tr[2]/td[2]/input"));
			}catch (Exception e){
				Log.error("********ContactOfficePhone is not found on the ProviderMessage Page********");
			}
			return element;
		}
	
	//联系人电子邮件
		@Test
		public static WebElement editContactEmail() throws Exception{
			try{
				element =driver.findElement(By.xpath(".//*[@id='frmEditLinkman-0']/table/tbody/tr[2]/td[4]/input"));
			}catch (Exception e){
				Log.error("********ContactEmail is not found on the ProviderMessage Page********");
			}
			return element;
		}
		
		
		
		
		
	//传真开始接受时间workingHours   /html/body/div[12]/div[2]/form/table/tbody/tr[3]/td[2]/label[8]/span/span/input
		
		@Test//开始时间
		public static WebElement editWorkingHoursBegin() throws Exception{
			try{
				element =driver.findElement(By.xpath("/html/body/div[12]/div[2]/form/table/tbody/tr[3]/td[2]/label[8]/span/span/input"));
			}catch (Exception e){
				Log.error("********WorkingHoursBegin is not found on the ProviderMessage Page********");
			}
			return element;
		}
	
		@Test//结束时间
		public static WebElement editWorkingHoursEnd() throws Exception{
			try{
				element =driver.findElement(By.xpath("/html/body/div[12]/div[2]/form/table/tbody/tr[3]/td[2]/label[9]/span/span/input"));
			}catch (Exception e){
				Log.error("********WorkingHoursEnd is not found on the ProviderMessage Page********");
			}
			return element;
		}
	
		//部门选择
	
	public static WebElement editDept() throws Exception{
		try{
			element =driver.findElement(By.name("dept"));
		}catch (Exception e){
			Log.error("********Dept is not found on the ProviderMessage Page********");
		}
		return element;
	} 
	
	
	
	
	//联系人备注
	
	public static WebElement editContactRemark() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='frmEditLinkman-0']/table/tbody/tr[5]/td[2]/input"));
		}catch (Exception e){
			Log.error("********ContratRemark is not found on the ProviderMessage Page********");
		}
		return element;
	}
	
	//保存联系人

	public static WebElement editSaveContact() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/div[12]/div[2]/form/div/a[1]"));
		}catch (Exception e){
			Log.error("********SaveContact is not found on the ProviderMessage Page********");
		}
		return element;
	}
	
	
	//跳转到酒店房型页面
	public static WebElement editHotelHomeStyle() throws Exception{
		try{
			element =driver.findElement(By.id("roomCat"));
		}catch (Exception e){
			Log.error("********HotelHomeStyle is not found on the ProviderMessage Page********");
		}
		return element;
	}
 	
	
	
	}
	
	
	
	
	
	
	
	
	

package com.travelzen.Insurance.PurchaseInsurance.AppModules;

import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.*;
import com.travelzen.Insurance.PurchaseInsurance.PageObjects.*;

public class OrderListAction {

	private static WebElement element;
	private static List<WebElement> elementList;
	public static WebDriver webdriver;
	private static Select oSelection;
	public static String option;
	private static WebElement[][] elementTable;

	/*
	 * author xuemei.ren date 07/01/2016
	 */
	@Test
	public static void transmitDriver(WebDriver currentDriver) throws Exception {

		webdriver = currentDriver;
		OrderListPage.getDriver(currentDriver);
	}

	// 订单管理--打开订单管理
	@Test
	public static void excutOpenOrderManageAction() throws Exception {
		OrderListPage.getOrderListElement().click();
		Log.info("打开订单管理");
	}

	// 订单管理--打开保险订单列表
	public static void excutOpenInsuranceOrderAction() throws Exception {
		OrderListPage.getInsuranceOrderListElement().click();
		Log.info("打开保险订单");
	}

	// ***********************订单列表--查询 start*****************************
	// 保险订单列表--获取订单编号
	public static void excutInputOrderId(String string) throws Exception {
		// CreatOrderPage.getInsureeNameElement(num).clear();
		OrderListPage.getOrderIdElement().sendKeys(string);
		Log.info("输入订单编号：" + string);
	}

	// 保险订单列表--输入操作开始日期
	public static void excutInputStartDateAction(String string) throws Exception {
		// CreatOrderPage.getInsureeNameElement(num).clear();
		OrderListPage.getStartDateElement().sendKeys(string);
		Log.info("操作开始日期：" + string);
	}

	// 保险订单列表--输入操作结束日期
	public static void excutInputEndDateAction(String string) throws Exception {
		// CreatOrderPage.getInsureeNameElement(num).clear();
		OrderListPage.getEndDateElement().sendKeys(string);
		Log.info("操作结束日期：" + string);
	}

	// 保险订单列表-订单状态
	public static void excutSelectOrderStatusAction(String string) throws Exception {
		// 点击订单状态选项
		OrderListPage.getOrderStatusClickElement().click();
		// 判断订单状态值对应下拉列表元素“value”的值
		Select oselection = OrderListPage.getOrderStatusSelectElement();
		for (int i = 0; i < oselection.getOptions().size(); i++) {
			String sValueC = oselection.getOptions().get(i).getText();
			System.out.println("订单状态值是： " + sValueC);
			// 选中下拉列表元素
			if (sValueC.equals(string)) {
				oselection.selectByIndex(i);
				break;
			}
		}
		Log.info("选择的订单状态是：" + string);
	}

	// 保险订单列表--保险产品
	public static void excutSelectInsreProductAction(String string) throws Exception {
		// 点击订单状态选项
		OrderListPage.getInsuranceProductElement().click();
		// 判断订单状态值对应下拉列表元素“value”的值
		Select oselection = OrderListPage.getInsuranceProductSelectElement();
		for (int i = 0; i < oselection.getOptions().size(); i++) {
			String sValueC = oselection.getOptions().get(i).getText();
			System.out.println("保险产品是： " + sValueC);
			// 选中下拉列表元素
			if (sValueC.equals(string)) {
				oselection.selectByIndex(i);
				break;
			}
		}
		Log.info("选择的保险产品是：" + string);
	}

	// 保险订单列表--搜索
	public static void excutOrderSearhAction() throws Exception {
		OrderListPage.getSearhElement().click();
		Log.info("点击搜索，获得查询结果");
	}

	// 保险订单列表--查看订单详情
	public static void excutOrderIdLinkAction() throws Exception {
		OrderListPage.getOrderIdLinkElement().click();
		Log.info("点击订单编号，跳转到订单详情页");
	}
	// ***********************订单列表--订单信息 检查点校验-start**************
	// 保险订单列表--查询结果--获取订单状态
	public static String excutGetOrderStatusAction() throws Exception {
		String string = OrderListPage.getOrderStatusElement().getText();
		Log.info("订单查询结果，获取订单状态");
		return string;
	}
	// ***********************订单列表--退保-start**************
	// 保险订单列表--点击退保按钮
	public static void excutSurrenderAction() throws Exception {
		OrderListPage.getSurrenderClickElement().click();
		Log.info("点击退保按钮");
	}

	// 保险订单列表--选中退保人
	public static void excutSurrenderChooseAction(String String) throws Exception {
		for (int i = 0; i < OrderListPage.getSurrenderAmountElement().size(); i++) {
			String sValue = OrderListPage.getSurrenderNameElement(Integer.toString(i)).getText();
			if (sValue.equalsIgnoreCase(String)) {
				OrderListPage.getSurrenderChooseElement(Integer.toString(i)).click();
			}
		}
		Log.info("选中的退保人是：" + String);
	}

	// 保险订单列表--提交退保
	public static void excutSurrenderSubmmitAction() throws Exception {
		OrderListPage.getSurrenderSubmmitElement().click();
		Log.info("点击提交，提交退保");
	}

	// 保险订单列表--取消退保
	public static void excutSurrenderCancelAction() throws Exception {
		OrderListPage.getSurrenderCancelElement().click();
		Log.info("点击取消，取消退保");
	}

	// ***********************订单列表--取消投保-start**************
	// 保险订单列表--点击取消投保按钮
	public static void excutCancelInsureAction() throws Exception {
		OrderListPage.getCancelInsureClickElement().click();
		Log.info("点击取消投保，投保失败订单取消投保");
	}

	// 保险订单列表--选中取消投保人
	public static void excutCancelInsureChooseAction(String String) throws Exception {
		for (int i = 0; i < OrderListPage.getCancelInsureAmountElement().size(); i++) {
			String sValue = OrderListPage.getCancelInsureNameElement(Integer.toString(i)).getText();
			System.out.print(sValue);
			if (sValue.equalsIgnoreCase(String)) {
				OrderListPage.getCancelInsureChooseElement(Integer.toString(i)).click();
			}
		}
		Log.info("选中的取消投保人是：" + String);
	}

	// 保险订单列表--提交退保
	public static void excutCancelInsureSubmmitAction() throws Exception {
		OrderListPage.getCancelInsureSubmmitElement().click();
		Log.info("点击提交，提交取消投保");
	}

	// 保险订单列表--取消退保
	public static void excutInsureCancelAction() throws Exception {
		OrderListPage.getInsureCancelElement().click();
		Log.info("点击取消，取消取消投保");
	}

	// ***********************订单列表--投保、支付、取消-start**************
	// 保险订单列表--投保
	public static void excutUnderWriteAction() throws Exception {
		OrderListPage.getUnderWriteElement().click();
		Log.info("点击投保，投保失败的订单重新投保");
	}

	// 保险订单列表--订单支付
	public static void excutOrderPayAction() throws Exception {
		OrderListPage.getOrderPayElement().click();
		Log.info("点击支付，跳转到订单支付页面");
	}

	// 保险订单列表--取消订单
	public static void excutCancelOrderAction() throws Exception {
		// CreatOrderPage.getInsureeNameElement(num).clear();
		OrderListPage.getCancelOrderElement().click();
		Log.info("点击取消订单，订单取消");
	}

	// 保险订单列表--取消订单--确认取消
	public static void excutCancelOrderConfirmAction() throws Exception {
		// CreatOrderPage.getInsureeNameElement(num).clear();
		OrderListPage.getCancelOrderConfirmElement().click();
		Log.info("点击取消订单，订单取消");
	}

	// 保险订单列表--取消订单--取消操作
	public static void excutCancelOrderQuitAction() throws Exception {
		// CreatOrderPage.getInsureeNameElement(num).clear();
		OrderListPage.getCancelOrderQuitElement().click();
		Log.info("点击取消订单，订单取消");
	}

}
package com.travelzen.Utility.ResultCollection;

import java.io.File;

//所有Case执行完成后（或一个Suit执行完成后），可以调用showReport()方法来调取生成 测试报告
//测试报告为TestNG生成报告,方法实现仅是调取打开该报告
public class Report {

	private static String filePath = System.getProperty("user.dir");

	public static void showReport() throws Exception {

		// String filePath =
		// "file:///C:/git/tz-test/auto-test/test-output/index.html";
		String reportPath = filePath + "/test-output/" + "index.html";
		File file = new File(reportPath);
		Runtime ce = Runtime.getRuntime();
		// System.out.println(file.getPath());
		// 直接用rt打开目标文件
		ce.exec("cmd   /c   start  " + file.getPath());

	}
}

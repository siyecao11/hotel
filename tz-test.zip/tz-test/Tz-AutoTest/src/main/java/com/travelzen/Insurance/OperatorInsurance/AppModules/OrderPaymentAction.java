package com.travelzen.Insurance.OperatorInsurance.AppModules;
/**
 * author：qiqi.wang
 * */
import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.OrderPaymentPage;
import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.Constant;
import com.travelzen.Utility.LogCenter.Log;

public class OrderPaymentAction
{
	public static WebDriver webdriver;
	public static void transmitDriver(WebDriver driver) throws Exception{
		webdriver = driver;
		OrderPaymentPage.getDriver(webdriver);
	}
	
	//获取订单号码
	public static void excuteOrderId() throws Exception{
		String orderID = OrderPaymentPage.getCustomerNameOrderIDElement().getText();
		int n = orderID.length();
		Constant.OperatorOrderId = orderID.substring(n-16, n);
		Log.info("订单编号已存入“Constant.OperatorOrderId”。"+Constant.OperatorOrderId);
	}
	
	//获取支付金额
	public static void excuteOrderPayment() throws Exception{
		String OrderPayment = OrderPaymentPage.getTotalPayElement().getText();
		Constant.OperatorOrderPay = OrderPayment;
		Log.info("订单支付金额已存入“Constant.OperatorOrderPay”。"+Constant.OperatorOrderPay);
	}
	
	
}

package com.travelzen.Insurance.OperatorInsurance.PageObjects;
/**
 * author：qiqi.wang
 * */
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Utility.LogCenter.Log;

public class OrderSearchPage
{
	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	public static String option;
	
	public static void getDriver(WebDriver webdriver) throws Exception{
		driver = webdriver;
	}
	
	//订单列表页面-订单号搜索条件-输入框
	public static WebElement getOrderNumberInputElement() throws Exception{
		try{
			element = driver.findElement(By.name("id"));
			Log.info("订单列表页面中“订单号”输入框元素，已找到。");
		}catch(Exception e){
			Log.error("订单列表页面中“订单号”输入框元素，未找到。");
		}
		return element;
	}
	//订单列表页面-选择保险产品-下拉框
	public static WebElement getInsuranceProductSelectElement() throws Exception{
		try{
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"saleName\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By.name("saleName"));
			Log.info("订单列表页面中“选择保险产品”下拉框元素，已找到。");
		}catch(Exception e){
			Log.error("订单列表页面中“选择保险产品”下拉框元素，未找到。");
		}
		return element;
	}
	
	//订单列表页面-选择创建日期起始日期-日期控件
	public static WebElement getStartDateInputElement() throws Exception{
		try{
			element = driver.findElement(By.name("startDate"));
			Log.info("订单列表页面中“创建日期起始日期”日期元素，已找到。");
		}catch (Exception e){
			Log.error("订单列表页面中“创建日期起始日期”日期元素，未找到。");
		}
		return element;
	}
	
	//订单列表页面-选择创建日期结束日期-日期控件
		public static WebElement getEndDateInputElement() throws Exception{
			try{
				element = driver.findElement(By.name("endDate"));
				Log.info("订单列表页面中“创建日期结束日期”日期元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“创建日期结束日期”日期元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-选择订单状态-下拉框
		public static WebElement getOrderStateSelectElement() throws Exception{
			try{
				JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
				jsExecutor.executeScript("var setDate=document.getElementsByName(\"state\")[0];setDate.removeAttribute('style');");
				element = driver.findElement(By.name("state"));
				Log.info("订单列表页面中“订单状态”下拉框元素，已找到。");
			}catch(Exception e){
				Log.error("订单列表页面中“订单状态”下拉框元素，未找到。");
			}
			return element;
		}
	//订单列表页面-选择收款状态-下拉框		
		public static WebElement getGatherStateSelectElement(){
			try{
				JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
				jsExecutor.executeScript("var setDate=document.getElementsByName(\"gatheringState\")[0];setDate.removeAttribute('style');");
				element = driver.findElement(By.name("gatheringState"));
				Log.info("订单列表页面中“收款状态”下拉框元素，已找到。");
			}catch(Exception e){
				Log.error("订单列表页面中“收款状态”下拉框元素，未找到。");
			}
			return element;
		}
	
	//订单列表页面-弹出客户名称弹框-按钮
		public static WebElement getCustomerNameButtonElement(){
			try{
				element = driver.findElement(By.className("btns btn-search ac-search-customer"));
				Log.info("订单列表页面中“客户名称”弹窗元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“客户名称”弹窗元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-输入客户简称-输入框	
		public static WebElement getCustomerShortNameInputElement() throws Exception{
			try{
				element = driver.findElement(By.name("shortName"));
				Log.info("订单列表页面中“客户简称”输入框元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“客户简称”输入框元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-客户搜索-按钮
		public static WebElement getCustomerSearchButtonElement() throws Exception{
			try{
				element = driver.findElement(By.id("randomid_774906090"));
				Log.info("订单列表页面中“客户搜索”按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“客户搜索”按钮元素，未找到。");
			}
			return element;
		}
	
	//订单列表页面-选择客户-文本
		public static WebElement getCustomerSelectElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='randomid_638451989']/tbody/tr/td[1]"));
				Log.info("订单列表页面中“选择客户”文本元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“选择客户”文本元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-弹出创建人弹窗-按钮
		public static WebElement getCreaterButtonElement() throws Exception{
			try{
				element = driver.findElement(By.className("btns btn-search ac-search-operateUser"));
				Log.info("订单列表页面中“创建人弹窗”按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“创建人弹窗”按钮元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-输入登录名-输入框
		public static WebElement getLoginNameInputElement() throws Exception{
			try{
				element = driver.findElement(By.name("username"));
				Log.info("订单列表页面中“登录名”输入框元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“登录名”输入框元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-创建人搜索-按钮
		public static WebElement getCreaterSearchButtonElement() throws Exception{
			try{
				element = driver.findElement(By.id("randomid_14631313"));
				Log.info("订单列表页面中“创建人搜索”按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“创建人搜索”按钮元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-创建人选择-文本
		public static WebElement getCreaterSelectElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='randomid_901224904']/tbody/tr/td[1]"));
				Log.info("订单列表页面中“创建人选择”文本元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“创建人选择”文本元素，未找到。");
			}
			return element;
		}
	
	//订单列表页面-选择建单平台-下拉框
		public static WebElement getPlatformSelectElement() throws Exception{
			try{
				JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
				jsExecutor.executeScript("var setDate=document.getElementsByName(\"platform\")[0];setDate.removeAttribute('style');");
				element = driver.findElement(By.name("platform"));
				Log.info("订单列表页面中“建单平台”下拉框元素，已找到。");
			}catch(Exception e){
				Log.error("订单列表页面中“建单平台”下拉框元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-投/退保开始日期-日期控件
		public static WebElement getInsuranceStartDateInputElement() throws Exception{
			try{
				element = driver.findElement(By.name("insureStartDate"));
				Log.info("订单列表页面中“投/退保开始时间”日期元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“投/退保开始时间”日期元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-投/退保结束日期-日期控件
		public static WebElement getInsuranceEndDateInputElement() throws Exception{
			try{
				element = driver.findElement(By.name("insureEndDate"));
				Log.info("订单列表页面中“投/退保结束时间”日期元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“投/退保结束时间”日期元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-订单来源选择:接口保险订单-选择按钮
		public static WebElement getApiInsuranceOrderElement() throws Exception{
			try{
				element = driver.findElement(By.cssSelector("value='API_INSURANCE'"));
				Log.info("订单列表页面中“订单来源：接口”选择按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“订单来源：接口”选择按钮元素，未找到。");
			}
			return element;
		}
	
	//订单列表页面-订单来源选择:独立保险订单-选择按钮
		public static WebElement getIndependentInsuranceOrderElement() throws Exception{
			try{
				element = driver.findElement(By.cssSelector("value='INDEPENDENT_INSURANCE'"));
				Log.info("订单列表页面中“订单来源：独立”选择按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“订单来源：独立”选择按钮元素，未找到。");
			}
			return element;
		}
	//订单列表页面-订单来源选择:机票保险订单-选择按钮
		public static WebElement getTicketInsuranceOrderElement() throws Exception{
			try{
				element = driver.findElement(By.cssSelector("value='TICKET_INSURANCE'"));
				Log.info("订单列表页面中“订单来源：机票”选择按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“订单来源：机票”选择按钮元素，未找到。");
			}
			return element;
		
		}
		
	//订单列表页面-订单类型选择：退票单-选择按钮	
		public static WebElement getRefundOrderElement() throws Exception{
			try{
				element = driver.findElement(By.cssSelector("value='REFUND_ORDER'"));
				Log.info("订单列表页面中“订单类型选择：退票单”选择按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“订单类型选择：退票单”选择按钮元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-订单类型选择：正常单-选择按钮	
		public static WebElement getNormalOrderElement() throws Exception{
			try{
				element = driver.findElement(By.cssSelector("value='NORMAL_ORDER'"));
				Log.info("订单列表页面中“订单类型选择：正常单”选择按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“订单类型选择：正常单”选择按钮元素，未找到。");
			}
			return element;
		}
	//订单列表页面-订单查询-按钮
		public static WebElement getSearchOrderButtonElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='btn-searh']/span[2]"));
				Log.info("订单列表页面中“订单查询”按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“订单查询”按钮元素，未找到。");
			}
			return element;
		}
	//订单列表页面-导出Excel-按钮
		public static WebElement getExportExcelButtonElement() throws Exception{
			try{
				element = driver.findElement(By.id("exportExcel"));
				Log.info("订单列表页面中“导出Excel”按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“导出Excel”按钮元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-受理订单-按钮
		public static WebElement getAcceptButtonElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr/td[1]/a"));
				Log.info("订单列表页面中“受理”按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“受理”按钮元素，已找到。");
			}
			return element;
		}
		
	//订单列表页面-订单状态展示-文本	
		public static WebElement getListOrderStateElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr/td[2]"));
				Log.info("订单列表页面中“订单状态”文本元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“订单状态”文本元素，未找到。");
			}
			return element;
		}
	
	//订单列表页面-订单号展示-文本
		public static WebElement getListOrderIDElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr/td[3]/a"));
				Log.info("订单列表页面中“订单号”文本元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“订单号”文本元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-客户名称展示-文本
		public static WebElement getListCustomerNameElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr/td[5]/span"));
				Log.info("订单列表页面中“客户名称”文本元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“客户名称”文本元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-产品名称展示-文本
		public static WebElement getListProductNameElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr/td[6]/span"));
				Log.info("订单列表页面中“产品名称”文本元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“产品名称”文本元素，未找到。");
			}
			return element;
		}
	
	//订单列表页面-期限展示-文本
		public static WebElement getListDeadlineElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr/td[7]"));
				Log.info("订单列表页面中“期限”文本元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“期限”文本元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-合计费用展示-文本
		public static WebElement getListTotalCastElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr/td[8]"));
				Log.info("订单列表页面中“合计费用”文本元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“合计费用”文本元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-生效日期展示-文本
		public static WebElement getListStartDateElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr/td[9]"));
				Log.info("订单列表页面中“生效日期”文本元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“生效日期”文本元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-截止日期展示-文本
		public static WebElement getListEndDateElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr/td[10]"));
				Log.info("订单列表页面中“截止日期”文本元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“截止日期”文本元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-创建日期展示-文本
		public static WebElement getListCreateDateElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr/td[11]"));
				Log.info("订单列表页面中“创建日期”文本元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“创建日期”文本元素，未找到。");
			}
			return element;
		}
		
	//订单列表页面-创建订单-按钮
		public static WebElement getCreateOrderButtonElement() throws Exception{
			try{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[2]/div[2]/button"));
				Log.info("订单列表页面中“创建订单”按钮元素，已找到。");
			}catch (Exception e){
				Log.error("订单列表页面中“创建订单”按钮元素，未找到。");
			}
			return element;
		}
		
	
		
}

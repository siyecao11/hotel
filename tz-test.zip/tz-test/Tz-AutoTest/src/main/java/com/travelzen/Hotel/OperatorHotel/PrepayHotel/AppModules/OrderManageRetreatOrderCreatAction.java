package com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;

public class OrderManageRetreatOrderCreatAction {

	public static void transmitDriver(WebDriver driver) throws Exception {

		OrderManageRetreatOrderCreatPage.GetDriver(driver);
	}

	// Click创建退订单，
	public static void excute_RetreatCreat_Link() throws Exception {

		OrderManageRetreatOrderCreatPage.getCreat_RetreatOrder_Link().click();
	}
	
	// 获取退订单订单号 --text
		public static String excute_RetreatCreat_id() throws Exception {

			String string = OrderManageRetreatOrderCreatPage.getCreat_RetreatOrderId().getText();
			return string;
		}

  
}

package com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.travelzen.Utility.LogCenter.Log;
/*变更单完成页面*/
public class OrderManageEndorseOrderCompletePage {

	public static WebDriver driver;
	private static WebElement element;
	
	public static void getDriver(WebDriver webdriver){
		driver = webdriver;
	}
	// 变更单完成  -- 创建变更单 -- 按钮
		public static WebElement creatEndorseOrder() throws Exception {
			try {
				element = driver.findElement(By.xpath(".//*[@id='operator_view_endorse_order']/span[2]"));
				Log.info("CreatEndorseOrder is found in the AuditOrderComplete Page.");
			} catch (Exception e) {
				Log.error("CreatEndorseOrder is not found in the AuditOrderComplete Page.");
			}
			return element;
		}

		// 变更单完成  -- 创建调账单 -- 按钮
		public static WebElement creatAdjustmentOrder() throws Exception {
			try {
				element = driver.findElement(By.xpath(".//*[@id='adjustment_operator_view_order']/span[2]"));
				Log.info("CreatAdjustmentOrder is found in the AuditOrderComplete Page.");
			} catch (Exception e) {
				Log.error("CreatAdjustmentOrder is not found in the AuditOrderComplete Page.");
			}
			return element;
		}

		// 变更单完成  -- 创建退订单 -- 按钮
		public static WebElement creatRetreatOrder() throws Exception {
			try {
				element = driver.findElement(By.xpath(".//*[@id='operator_view_refund_order']/span[2]"));
				Log.info("CreatRetreatOrder is found in the AuditOrderComplete Page.");
			} catch (Exception e) {
				Log.error("CreatRetreatOrder is not found in the AuditOrderComplete Page.");
			}
			return element;
		}

	
	
}

package com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.Log;

public class OrderManageAdjustmentOrderCreatePage {

	public static WebDriver driver;
	private static WebElement element;
	
	@Test
	public static void getWebDriver(WebDriver webdriver) {
		
		driver = webdriver;
		
	}
	
	//创建调账单页面
	//Location "创建调账单" btn元素
	@Test
	public static WebElement getCreateAdjustmentOrderBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("adjustment_operator_create_order"));
			Log.info("CreateAdjustmentOrder elements is found in CreateAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("CreateAdjustmentOrder elements is not found in CreateAdjustmentOrder Page");
		}
		return element;
	}
	
	
	//Location 费用明细中 "修改价格" 元素
	@Test
	public static WebElement getModifyPriceElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[class='button_5 btn_modifyCurrent']"));
			Log.info("ModifyPrice elements is found in CreateAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("ModifyPrice elements is not found in CreateAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location 费用明细中 "修改价格" -- 确认 元素
	@Test
	public static WebElement getSaveCostBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("btn_cost_save"));
			Log.info("btn_cost_save elements is found in CreateAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("btn_cost_save elements is not found in CreateAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location 费用明细中 "修改价格" -- 取消 元素
	@Test
	public static WebElement getCancleCostBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("btn_cost_cancel"));
			Log.info("btn_cost_cancel elements is found in CreateAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("btn_cost_cancel elements is not found in CreateAdjustmentOrder Page");
		}
		return element;
	}
	
	
	//底价和卖价元素框定位
	//待完善
	
	
	//Location 费用明细中 "修改价格" -- 确认 -- 修改价格原因 输入框 元素
	@Test
	public static WebElement getModifyRemarkElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("modifyRemark"));
			Log.info("modifyRemark elements is found in CreateAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("modifyRemark elements is not found in CreateAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location 费用明细中 "修改价格" -- 确认 -- 修改价格原因 -- 保存  元素
	@Test
	public static WebElement getModifyRemarkWindow_SaveElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("modifyRemarkWindow_save"));
			Log.info("modifyRemarkWindow_save elements is found in CreateAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("modifyRemarkWindow_save elements is not found in CreateAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location 费用明细中 "修改价格" -- 确认 -- 修改价格原因 -- 取消  元素
	@Test
	public static WebElement getModifyRemarkWindow_CancelElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("modifyRemarkWindow_cancel"));
			Log.info("modifyRemarkWindow_cancel elements is found in CreateAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("modifyRemarkWindow_cancel elements is not found in CreateAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location 订单金额中 "手续费" 元素
	@Test
	public static WebElement getOrderProcedureFeeYuanElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("orderProcedureFeeYuan"));
			Log.info("orderProcedureFeeYuan elements is found in CreateAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("orderProcedureFeeYuan elements is not found in CreateAdjustmentOrder Page");
		}
		return element;
	}
}

package com.travelzen.Insurance.OperatorInsurance.PageObjects;
/**
 * author：qiqi.wang
 * */
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.travelzen.Utility.LogCenter.Log;


public class DraftOrderPage
{
	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	public static String option;
	
	public static void getDriver(WebDriver webdriver) throws Exception{
		driver = webdriver;
	}
	
	//草稿订单页面-提交订单-按钮
	public static WebElement getSubmitOrderButtonElement() throws Exception{
		try{
			element = driver.findElement(By.id("btn-submit"));
			Log.info("草稿订单页面中“提交订单”按钮元素，已找到。");
		}catch (Exception e){
			Log.error("草稿订单页面中“提交订单”按钮元素，未找到。");
		}
		return element;
	}
	
	//草稿订单页面-修改订单-按钮
	public static WebElement getEditOrderButtonElement() throws Exception{
		try{
			element = driver.findElement(By.id("btn-edit-order"));
			Log.info("草稿订单页面中“修改订单”按钮元素，已找到。");
		}catch (Exception e){
			Log.error("草稿订单页面中“修改订单”按钮元素，未找到。");
		}
		return element;
	}
	
	//草稿订单页面-取消订单-按钮
	public static WebElement getCancelOrderButtonElement() throws Exception{
		try{
			element = driver.findElement(By.id("btn-cancel-order"));
			Log.info("草稿订单页面中“取消订单”按钮元素，已找到。");
		}catch (Exception e){
			Log.error("草稿订单页面中“取消订单”按钮元素，未找到。");
		}
		return element;
	}
	
	//草稿订单页面-确认提交-按钮
	public static WebElement getConfirmSubmitOrderButtonElement() throws Exception{
		try{
			element = driver.findElement(By.className("center"));
			Log.info("草稿订单页面中“确认提交订单”按钮元素，已找到。");
		}catch (Exception e){
			Log.error("草稿订单页面中“确认提交订单”按钮元素，未找到。");
		}
		return element;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.HotelMaintain.utility.Constants.*;
import com.travelzen.Utility.LogCenter.Log;

public class HotelMaintainRoomAllotPage {
	
	public static WebDriver driver;
	private static WebElement element;
	private static List<WebElement> elementList;
	private static Select selectNum;
	private static List<Select> selectNumList;
	
	@Test
	public static void getWebDriver(WebDriver webdriver) {
		
		driver = webdriver;
		
	}
	
	//Location 库存房态管理：批量编辑房量(库存) element
	@Test
	public static WebElement getEditAll_AllotElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("EditAllAllot"));
			Log.info("EditAllAllot element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("EditAllAllot element is not found in RoomAllot Page");
		}
		return element;
	}
	
	//Location 库存房态管理：批量编辑房量(库存)之保存 element
	@Test
	public static WebElement getEditAll_AllotElement_Save() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("button[onclick='batchEditAllot()']"));
			Log.info("EditAllAllot_Save element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("EditAllAllot_Save element is not found in RoomAllot Page");
		}
		return element;
	}
	
	//Location 库存房态管理：“批量”编辑房量(库存)之取消 element
	@Test
	public static WebElement getEditAll_AllotElement_Cancle() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("button[onclick='batchCancelAllot()']"));
			Log.info("EditAllAllot_Cancle element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("EditAllAllot_Cancle element is not found in RoomAllot Page");
		}
		return element;
	}
	
	//Location 库存房态管理： 保留房编辑
	//多个房型：返回所有的房型对应保留房编辑框元素
	@Test
	public static List<WebElement> getNoOfAllotedNoElement() throws Exception{
		
		try{
			elementList = driver.findElements(By.cssSelector("input[name='noOfAllotedNo']"));
			Log.info("All of noOfAllotedNo elements is found in RooAllot Page");
		}catch (Exception e){
			Log.error("noOfAllotedNo elements is not found in RooAllot Page");
		}
		return elementList;
	}
	
	//Location 库存房态管理： CutOffDay编辑
	//多个房型：返回所有的房型对应CutOffDay编辑框元素
	@Test
	public static List<WebElement> getCutoffDayElement() throws Exception{
		
		try{
			elementList = driver.findElements(By.cssSelector("input[name='cutoffDay']"));
			Log.info("All of cutoffDay elements is found in RooAllot Page");
		}catch (Exception e){
			Log.error("cutoffDay elements is not found in RooAllot Page");
		}
		return elementList;
	}
	
	//Location 库存房态管理： 售完规则编辑
	//多个房型：返回所有的房型对应售完规则编辑框元素
	@Test
	public static List<WebElement> getAllotTypeSoldOutElement() throws Exception{
		
		try{
			//get 页面所有房型对应的售完规则选择项
			elementList = driver.findElements(By.cssSelector("select[name='allotTypeSoldOut']"));
			Log.info("All of allotTypeSoldOut elements is found in RooAllot Page");
		}catch (Exception e){
			Log.error("AllotTypeSoldOut elements is not found in RooAllot Page");
		}
		return elementList;
	}
	
	//Location 库存房态管理：“单个”编辑房量(库存) element
	//多个房型：返回所有的房型对应编辑元素
	@Test
	public static  List<WebElement> getEditAllotElement() throws Exception{
		
		try{
			elementList = driver.findElements(By.cssSelector("a[class='last_td']"));
			Log.info("All of EditAllot elements is found in RooAllot Page");
		}catch (Exception e){
			Log.error("EditAllot elements is not found in RooAllot Page");
		}
		return elementList;
	}
	
	//Location 库存房态管理：“单个”编辑房量(库存),"保存" element
	@Test
	public static WebElement getEditAllot_Save() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("input[value='保存']"));
			Log.info("EditAllot save elements is found in RooAllot Page");
		}catch (Exception e){
			Log.error("EditAllot save elements is not found in RooAllot Page");
		}
		return element;
	}
	
	//Location 库存房态管理：“单个”编辑房量(库存),"取消" element
	@Test
	public static WebElement getEditAllot_Cancle() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("input[value='取消']"));
			Log.info("EditAllot cancle elements is found in RooAllot Page");
		}catch (Exception e){
			Log.error("EditAllot cancle elements is not found in RooAllot Page");
		}
		return element;
	}
	
	//Location 每日库存管理：“修改”库存按钮 element
	@Test
	public static WebElement getDailyEdit_RoomStorageBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("edit_room_storage"));
			Log.info("DailyEditRoomStorageBtn element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("DailyEditRoomStorageBtn element is not found in RoomAllot Page");
		}
		return element;
	}
	
	//Location 每日库存管理：“按时段修改”库存按钮 element
	@Test
	public static WebElement getDaily_BatchEditBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("batchEditBtn"));
			Log.info("DailyBatchEditBtn element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("DailyBatchEditBtn element is not found in RoomAllot Page");
		}
		return element;
	}
	
	//Location 每日库存管理：“修改” 之“保存”按钮 element
	@Test
	public static WebElement getDailyEdit_RoomStorageBtnElement_Save() throws Exception{
		
		try{
			element = driver.findElement(By.id("room_save"));
			Log.info("DailyEditRoomStorageBtn_Save element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("DailyEditRoomStorageBtn_Save element is not found in RoomAllot Page");
		}
		return element;
	}
	
	//Location 每日库存管理：“修改” 之“取消”按钮 element
	@Test
	public static WebElement getDailyEdit_RoomStorageBtnElement_Cancle() throws Exception{
		
		try{
			element = driver.findElement(By.id("room_cancel"));
			Log.info("DailyEditRoomStorageBtn_Cancle element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("DailyEditRoomStorageBtn_Cancle element is not found in RoomAllot Page");
		}
		return element;
	}
	
	//Location 每日库存管理："选择房型" Select 元素
	@Test
	public static Select getDailyEdit_RoomTypeElement() throws Exception{
		
		try{
			selectNum = new Select(driver.findElement(By.cssSelector("select[id='roomType']")));
			Log.info("RoomType Select element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("RoomType Select element is not found in RoomAllot Page");
		}
		return selectNum;
	}
	
	//Location 每日库存管理："开始日期"  element
	@Test
	public static WebElement getDailyEdit_StartDateElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("input[name='startDate']"));
			Log.info("startDate element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("startDate element is not found in RoomAllot Page");
		}
		return element;
	}
	
	//Location 每日库存管理："查询"  日期查询element
	@Test
	public static WebElement getDailyEdit_QueryElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[onclick='changeShowContents();']"));
			Log.info("Query element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("Query element is not found in RoomAllot Page");
		}
		return element;
	}
	
	//Location 每日库存管理："修改"->"关房" element
	@Test
	public static List<WebElement> getDailyEdit_CloseRoomElement() throws Exception{
		
		try{
			//若是有多个房型，则elementList的前0~6对应第一个房型，7~13对应第二个房型，以此类推
			elementList = driver.findElements(By.cssSelector("input[type='checkbox']"));
			Log.info("all close room element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("all close room element is not found in RoomAllot Page");
		}
		return elementList;
	}
	
	//Location 每日库存管理："修改"->"售完房态" element		CL、FS、OR
	@Test
	public static List<WebElement> getDailyEdit_RoomStatusElement() throws Exception{
		
		try{
			//若是有多个房型，则elementList的前0~6对应第一个房型，7~13对应第二个房型，以此类推
			elementList = driver.findElements(By.cssSelector("select[name='room_status']"));
			
			Log.info("all room status element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("all room status element is not found in RoomAllot Page");
		}
		return elementList;
	}
	
	//Location 每日库存管理："修改"->"添加剩余库存" element
	@Test
	public static List<WebElement> getDailyEdit_AddAllotElement() throws Exception{
		
		try{
			//若是有多个房型，则elementList的前0~6对应第一个房型，7~13对应第二个房型，以此类推
			elementList = driver.findElements(By.cssSelector("input[onchange='compareAndTickChkBox(this)']"));
			Log.info("all addallot element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("all addallot element is not found in RoomAllot Page");
		}
		return elementList;
	}
	
	//Location "每日价格"页面  element
	//库存与房态 信息编辑完成后，需要进入下一个编辑页面-"每日价格"页面
	@Test
	public static WebElement getDailrRatePageElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[id='dailyRate']"));
			Log.info("dailyRate element is found in RoomAllot Page");
		}catch (Exception e){
			Log.error("dailyRate element is not found in RoomAllot Page");
		}
		return element;
	}
}

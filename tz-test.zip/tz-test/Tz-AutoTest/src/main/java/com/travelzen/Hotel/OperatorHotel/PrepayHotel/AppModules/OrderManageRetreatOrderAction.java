package com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules;

import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Utility.LogCenter.Log;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;

public class OrderManageRetreatOrderAction {
	
	public static List<WebElement> rdBtn_BedType;
	public static List<WebElement> chBox_PeriodTime;
	public static List<WebElement> elementList;
	public static WebElement element;


	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {

		OrderManageRetreatOrderPage.getWebDriver(driver);
	}

	// 执行跳转到退订条件弹窗
	public static void excute_RetreatCondition_Link() throws Exception {

		OrderManageRetreatOrderPage.getView_RetreatOrder_Link().click();
	}

	
	// 选择并输入退订条件
	@Test
	public static void excute_select_RetreatCondition(List<String> stringList)
			throws Exception {
		// 选择预定要求，bookingRequirement
		// element = elementList.get(0).getAttribute("value")
		switch (stringList.get(0)) {
		case "CHANGEALL":
			OrderManageRetreatOrderPage.getRetreat_CHANGEALL().click();
			break;
		case "CHANGEFIRST":
			OrderManageRetreatOrderPage.getRetreat_CHANGEFIRST().click();
			break;
		case "CHANGENONE":
			OrderManageRetreatOrderPage.getRetreat_CHANGENONE().click();
			break;
		case "EARLYCHECKOUT":
			excute_Retreat_EARLYCHECKOUT(stringList);
			break;

		}

	}

	// ****************Switch分支条件***************88
	// 选择提前离店
	@Test
	public static void excute_Retreat_EARLYCHECKOUT(List<String> stringList) throws Exception {
		
		OrderManageRetreatOrderPage.getRetreat_EARLYCHECKOUT().click();  //选中单选按钮
		
		elementList = OrderManageRetreatOrderPage
				.getRetreat_EARLYCHECKOUT_RefundDate();

		Log.info(elementList.size() + "elementList size");
		for (int i = 0; i < elementList.size(); i++) {
				//elementList.get(i).clear();
			if(stringList.get(i+1).equalsIgnoreCase("1")) elementList.get(i).click();
		}

	}
	
	// 保存退订条件
	@Test
	public static void excute_Save_RetreatCondition() throws Exception {
		OrderManageRetreatOrderPage.getRetreat_Save().click();
		Log.info("RetreatCondition has been saved");

	}
	
	
	// **************酒店创建退订单页面，页面元素基本同订单确认预订*********************************
	// 点击创建退订单按钮，创建退订单
	public static void excute_Creat_RetreatOrder_Link() throws Exception {

		OrderManageRetreatOrderPage.getCreat_RetreatOrder_Link().click();
	}
	
	
	// **************酒店确认预定页，输入酒店确认码*********************************
	// 执行跳转到确认预订弹窗
	public static void excute_ConfirmBooking_Link() throws Exception {

		OrderManageRetreatOrderPage.getConfirmBooking_Link().click();
	}

	@Test
	public static void excute_input_ConfirmID(List<String> list)
			throws Exception {
		// 选择预定要求，bookingRequirement
		// element = elementList.get(0).getAttribute("value")

		switch (list.get(0)) {
		case "1":
			excute_ConfirmID1(list.get(1));
			break;
		case "0":
			excute_ConfirmID2();
			break;

		}

	}

	// 酒店有确认码
	@Test
	public static void excute_ConfirmID1(String string) throws Exception {

		elementList = OrderManageRetreatOrderPage.getConfirmBooking_ConfirmID1();

		elementList.get(0).click();
		elementList.get(1).clear();
		elementList.get(1).sendKeys(string);
		Log.info("ConfirmBooking_ConfirmID has been input");
	}

	// 酒店无确认码
	@Test
	public static void excute_ConfirmID2() throws Exception {

		OrderManageRetreatOrderPage.getConfirmBooking_ConfirmID2().click();
		Log.info("ConfirmBooking NO ConfirmID has been select");

	}

	// 保存酒店确认码信息
	@Test
	public static void excute_Save_ConfirmID() throws Exception {
		OrderManageRetreatOrderPage.getConfirmBooking_Save().click();
		Log.info("ConfirmID has been saved");

	}

	// ****************修改酒店结算方式提醒********************************
	// 选择并输入预定条件
	@Test
	public static void excute_change_CountReminder(List<String> stringList)
			throws Exception {
		// 选择预定要求，bookingRequirement
		// element = elementList.get(0).getAttribute("value")

		switch (stringList.get(0)) {
		case "NOW_SETTLE":excute_NOW_SETTLE(stringList);
			break;
		case "WEEK_SETTLE":excute_WEEK_SETTLE();
			break;
		case "HALF_MONTH_SETTLE":excute_HALF_MONTH_SETTLE();
			break;
		case "MONTH_SETTLE":excute_MONTH_SETTLE();
			break;

		}

	}

	// 现结方式
	//上午、下午时间是默认的，该选项没有写入传值
	@Test
	public static void excute_NOW_SETTLE(List<String> stringList) throws Exception {


		elementList = OrderManageRetreatOrderPage.getCount_NOW_SETTLE();
		
		//elementList.get(0).click();
		Log.info(elementList.size()+"elementList size");
		for(int i=1;i<elementList.size();i++){
			if(i==1) elementList.get(i).clear();
		elementList.get(i).sendKeys(stringList.get(i));
		}
		elementList.get(0).click();
		Log.info("NOW_SETTLE has been select");
	}

	// 周结方式
	@Test
	public static void excute_WEEK_SETTLE() throws Exception {

		OrderManageRetreatOrderPage.getCount_WEEK_SETTLE().click();
		Log.info("WEEK_SETTLE has been select");

	}

	// 半月结方式
	@Test
	public static void excute_HALF_MONTH_SETTLE() throws Exception {

		OrderManageRetreatOrderPage.getCount_HALF_MONTH_SETTLE().click();
		Log.info("HALF_MONTH_SETTLE has been select");

	}

	// 月结方式
	@Test
	public static void excute_MONTH_SETTLE() throws Exception {

		OrderManageRetreatOrderPage.getCount_MONTH_SETTLE().click();
		Log.info("MONTH_SETTLE  has been select");

	}
	

	// 保存酒店结算方式
	@Test
	public static void excute_Save_Count() throws Exception {
		OrderManageRetreatOrderPage.getCount_Save().click();
		Log.info("Count Reminder has been saved");

	}	
	
	

}

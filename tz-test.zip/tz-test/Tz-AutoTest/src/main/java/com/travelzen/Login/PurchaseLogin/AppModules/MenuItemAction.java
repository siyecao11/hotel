package com.travelzen.Login.PurchaseLogin.AppModules;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;

import com.travelzen.Login.PurchaseLogin.PageObjects.WelcomePage;
import com.travelzen.Utility.LogCenter.Log;

public class MenuItemAction {
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		WelcomePage.getWebDriver(driver);
	}

	@Test
	public static void excuteHotel() throws Exception {
		
		//Click hotel menItem, goto hotel HomePage
		WelcomePage.getHotelMenu().click();
		Log.info(" Hotel menuItem is clicked, now enter into hotel page");
	}
	
	@Test
	public static void excuteDomesticFlight() throws Exception {
		
		//Click hotel menItem, goto DomesticFlight HomePage
		WelcomePage.getDomesticFlightMenu().click();
		Log.info(" DomesticFlight menuItem is clicked, now enter into hotel page");
	}
	
	@Test
	public static void excuteInternationalFlight() throws Exception {
		
		//Click hotel menItem, goto InternationalFlight HomePage
		WelcomePage.getInternationalFlightMenu().click();
		Log.info(" InternationalFlight menuItem is clicked, now enter into hotel page");
	}
	
	@Test
	public static void excuteAdditional() throws Exception {
		
		//Click hotel menItem, goto Additional HomePage
		WelcomePage.getAdditionalMenu().click();
		Log.info(" Additional menuItem is clicked, now enter into hotel page");
	}
	
	@Test
	public static void Driver(WebDriver driver) throws Exception {
		
		WelcomePage.getWebDriver(driver);
	}
	
	
}

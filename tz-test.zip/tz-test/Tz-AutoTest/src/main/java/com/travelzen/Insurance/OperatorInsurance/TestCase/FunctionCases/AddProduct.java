package com.travelzen.Insurance.OperatorInsurance.TestCase.FunctionCases;

import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.travelzen.Insurance.OperatorInsurance.AppModules.AddProductAction;
import com.travelzen.Insurance.OperatorInsurance.AppModules.ProductManageAction;
import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.Constant;
import com.travelzen.Insurance.OperatorInsurance.Utility.Utils.DataProviderApp;
import com.travelzen.Login.OperatorLogin.TestCase.FunctionCases.LoginOperator;
import com.travelzen.Utility.Assertion.Assertion;
import com.travelzen.Utility.DataDriver.ExcelAction;
import com.travelzen.Utility.ResultCollection.Report;
import com.travelzen.Utility.ScreenShot.RetryFail;
import com.travelzen.Utility.Utils.Utils;

@Listeners({com.travelzen.Utility.Assertion.AssertionListener.class, com.travelzen.Utility.ResultCollection.CustomReporter.class, com.travelzen.Utility.ScreenShot.ScreenShotListener.class,com.travelzen.Utility.ScreenShot.RetryListener.class})
public class AddProduct {

	public static WebDriver currentDriver;
	public static String flag;
	
	//每次Suit运行完成后，退出Driver
	@AfterSuite(alwaysRun = true)
	public static void afterSuite() throws Exception{
		
		currentDriver.quit();
	}
	
	//每次Test运行完成后，关闭Driver
	@AfterTest(alwaysRun = true)
	public static void afterTest() throws Exception{
		
		currentDriver.close();
	}
	
	//初始化类，获取当前页面的Driver
	@BeforeClass(alwaysRun=true)
	public static void beforeClass(){
		
		currentDriver = LoginOperator.driver;

	}
	
	//初始化method，在每个方法执行前将页面指定到同一个地方（产品管理页面）
	@BeforeMethod(alwaysRun=true)
	public static void beforeMethod() throws Exception{
		
		//进入保险产品管理页面
		currentDriver.get(Constant.PRODUCTMANAGEURL);
		//传递Driver
		ProductManageAction.transmitDriver(currentDriver);
	}
	
	//新增保险产品信息
	@Test(dataProvider = "ProductDetail", retryAnalyzer = RetryFail.class, dataProviderClass = DataProviderApp.class, priority = 20, groups = {"新增产品"})
	public static void addEditProduct(String productName, String companyName, String deadline, String insuranceAmount, String typeName, String typeCode,
			String securityDetailId, String normalPrice, String upsetPrice, String adultLimitNum, String childLimitNum, String insurerMinAgeLimit, 
			String insureeMinAgeLimit, String insureeMaxAgeLimit, String scope) throws Exception{
			
		//点击“新增产品”按钮，进入新增产品页面
		ProductManageAction.excuteAddProductButtonAction();
		Utils.waitForElement(2, currentDriver, "page");
		//Assertion.verifyEquals("", "");
		//传递Driver
		AddProductAction.transmitDriver(currentDriver);
		//填写产品名称
		productName = productName + Integer.toString(new Random().nextInt(100)  );
		AddProductAction.excuteProductNameAction(productName);
		Utils.waitForElement(1, currentDriver, "wait");
		//选择保险公司名称
		AddProductAction.excuteCompanyNameAction(companyName);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写保险期限
		AddProductAction.excuteDeadlineAction(deadline);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写最高保额
		AddProductAction.excuteInsuranceAmountAction(insuranceAmount);
		Utils.waitForElement(1, currentDriver, "wait");
		//选择保险险种
		AddProductAction.excuteTypeNameAction(typeName);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写险种编号
		AddProductAction.excuteTypeCodeAction(typeCode);
		Utils.waitForElement(1, currentDriver, "wait");
		//选择产品明细
		AddProductAction.excuteProductDetailAction(securityDetailId);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写面价
		AddProductAction.excuteNormalPriceAction(normalPrice);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写底价
		AddProductAction.excuteUpsetPriceAction(upsetPrice);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写“最高投保份数”-“18周岁以上（含)” 份/人
		AddProductAction.excuteAdultLimitNumAction(adultLimitNum);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写“最高投保份数”-“18周岁以下” 份/人
		AddProductAction.excuteChildLimitNumAction(childLimitNum);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写“年龄限制”-“投保人”-“周岁（含）以上”
		AddProductAction.excuteInsurerMinAgeLimitAction(insurerMinAgeLimit);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写 “年龄限制”-“被投保人”-“至”
		AddProductAction.excuteInsureeMinAgeLimitAction(insureeMinAgeLimit);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写 “年龄限制”-“被投保人”-“周岁（含）”
		AddProductAction.excuteInsureeMaxAgeLimitAction(insureeMaxAgeLimit);
		Utils.waitForElement(1, currentDriver, "wait");
		//选择 适用范围
		AddProductAction.excuteScopeAction(scope);
		Utils.waitForElement(1, currentDriver, "wait");
		AddProductAction.excuteSubmitAddButtonAction();
		Utils.waitForElement(2, currentDriver, "wait");	
		
	}
	
	@Test(dataProvider = "ModifyProductDetail", retryAnalyzer = RetryFail.class, dataProviderClass = DataProviderApp.class, priority = 21, groups = {"修改产品"})
	public static void updataProductInfoTable(String productName, String companyName, String deadline, String insuranceAmount, String typeName, String typeCode,
			String securityDetailId, String normalPrice, String upsetPrice, String adultLimitNum, String childLimitNum, String insurerMinAgeLimit, 
			String insureeMinAgeLimit, String insureeMaxAgeLimit, String scope) throws Exception{
		
		//选择指定的修改的产品
		//指定的产品为保存的产品信息中的产品：ModifyProductDetail表中
		//String pName = ExcelAction.getValue("Insurance/Datas/KeepForProductInfo.xls", "productName");
		ProductManageAction.excuteProductNameAction(productName);
		//点击 “修改” 按钮，进入产品信息编辑页面
		ProductManageAction.excuteModifyProductAction();
		Utils.waitForElement(2, currentDriver, "page");	
		//Assertion.verifyEquals("", "");
		//传递Driver
		AddProductAction.transmitDriver(currentDriver);
		//填写产品名称
		AddProductAction.excuteProductNameAction(productName);
		Utils.waitForElement(1, currentDriver, "wait");
		//选择保险公司名称
		AddProductAction.excuteCompanyNameAction(companyName);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写保险期限
		AddProductAction.excuteDeadlineAction(deadline);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写最高保额
		AddProductAction.excuteInsuranceAmountAction(insuranceAmount);
		Utils.waitForElement(1, currentDriver, "wait");
		//选择保险险种
		AddProductAction.excuteTypeNameAction(typeName);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写险种编号
		AddProductAction.excuteTypeCodeAction(typeCode);
		Utils.waitForElement(1, currentDriver, "wait");
		//选择产品明细
		AddProductAction.excuteProductDetailAction(securityDetailId);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写面价
		AddProductAction.excuteNormalPriceAction(normalPrice);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写底价
		AddProductAction.excuteUpsetPriceAction(upsetPrice);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写“最高投保份数”-“18周岁以上（含)” 份/人
		AddProductAction.excuteAdultLimitNumAction(adultLimitNum);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写“最高投保份数”-“18周岁以下” 份/人
		AddProductAction.excuteChildLimitNumAction(childLimitNum);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写“年龄限制”-“投保人”-“周岁（含）以上”
		AddProductAction.excuteInsurerMinAgeLimitAction(insurerMinAgeLimit);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写 “年龄限制”-“被投保人”-“至”
		AddProductAction.excuteInsureeMinAgeLimitAction(insureeMinAgeLimit);
		Utils.waitForElement(1, currentDriver, "wait");
		//填写 “年龄限制”-“被投保人”-“周岁（含）”
		AddProductAction.excuteInsureeMaxAgeLimitAction(insureeMaxAgeLimit);
		Utils.waitForElement(1, currentDriver, "wait");
		//选择 适用范围
		AddProductAction.excuteScopeAction(scope);
		Utils.waitForElement(1, currentDriver, "wait");		
		AddProductAction.excuteSubmitAddButtonAction();
		Utils.waitForElement(2, currentDriver, "wait");	
	}
}

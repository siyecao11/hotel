package com.travelzen.Insurance.PurchaseInsurance.AppModules;

import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.HotelMaintainBookingClassPage;

import com.travelzen.Utility.LogCenter.*;
import com.travelzen.Utility.Utils.Utils;
import com.travelzen.Insurance.PurchaseInsurance.PageObjects.*;

public class CreatOrderAction {

	private static WebElement element;
	private static List<WebElement> elementList;
	public static WebDriver webdriver;
	private static Select oSelection;
	public static String option;
	private static WebElement[][] elementTable;

	/*
	 * 填写订单投保人&被保人信息 Action author xuemei.ren date 07/01/2016
	 */
	@Test
	public static void transmitDriver(WebDriver currentDriver) throws Exception {

		webdriver = currentDriver;
		CreatOrderPage.getDriver(currentDriver);
	}

	// 填写订单--保险生效日期--日历控件
	@Test
	public static void excutEffectiveDateAction(String string) throws Exception {
		CreatOrderPage.getEffectiveDateElement().clear();
		CreatOrderPage.getEffectiveDateElement().sendKeys(string);
		Log.info("输入保险生效日期" + string);
	}

	// 填写订单--保险生效日期--日历控件
	@Test
	public static void excutgetEffectiveDateAction() throws Exception {
	
		String string = CreatOrderPage.getEffectiveDateElement().getText();
		Log.info("选中的保险生效日期" + string);
		
	}

	// 填写订单--保险生效截止时间--日期
	@Test
	public static String excutEffectiveEndDateAction() throws Exception {
		String string = CreatOrderPage.getEffectiveDatePeriodElement().getText();
		Log.info("获取保险生效截止时间" + string);
		return string;
	}

	// 填写订单--选中保险生效截止时间--日期
	@Test
	public static void excutEffectiveEndDateClickAction() throws Exception {
		CreatOrderPage.getEffectiveDateClickElement().click();
		String string = CreatOrderPage.getEffectiveDateClickElement().getAttribute("day");
		Log.info("选中保险生效截止时间是："+string);
	}

	// 填写订单--输入常旅客
	@Test
	public static void excutFFPAction(String string) throws Exception {
		// 输入常旅客姓名
		CreatOrderPage.getFFPClickElement().sendKeys(string);
		// 选中自动匹配的第一个常旅客。如果全称搜索，则匹配常旅客
		CreatOrderPage.getFFPElement().click();
		Thread.sleep(2000);
		// creatOrderPage
		Log.info("选中常旅客 " + string);
	}

	// ***********************投保人暨被保险人信息 start*****************************
	// **********第一个被保人信息
	// 填写订单--获取被保人姓名
	@Test
	public static void excutInsureeNameAction(String num, String string) throws Exception {
		// CreatOrderPage.getInsureeNameElement(num).clear();
		CreatOrderPage.getInsureeNameElement(num).sendKeys(string);
		Log.info("填写被保人姓名" + string);
	}

	// 填写订单--获取被保人电话
	public static void excutMobelPhoneAction(String num, String string) throws Exception {
		CreatOrderPage.getMobelPhoneElement(num).sendKeys(string);
		Log.info("填写被保人姓名" + string);
	}

	// **********************填写订单--获取被保人证件类型 start ********
	public static void excutDocTypeAction(String num, String string) throws Exception {
		// 选择可入住人数
		Thread.sleep(1000);

		Select oselection = CreatOrderPage.getDocTypeElements(num);
		for (int i = 0; i < oselection.getOptions().size(); i++) {
			String sValueC = oselection.getOptions().get(i).getText();
			// 选中下拉列表元素
			if (sValueC.equals(string)) {
				oselection.selectByIndex(i);
				break;
			}
		}
	}

	// **********************填写订单--获取被保人证件类型 end ********
	// 填写订单--获取被保人证件号码
	public static void excutDocCodeAction(String num, String string) throws Exception {
		CreatOrderPage.getDocCodeElement(num).sendKeys(string);
		Log.info("填写被保人证件号码" + string);
	}

	// 填写订单--获取被保人出生日期
	public static void excutBirthDateAction(String num, String string) throws Exception {
		CreatOrderPage.getBirthDateElement(num).clear();
		CreatOrderPage.getBirthDateElement(num).sendKeys(string);
		Log.info("填写被保人出生日期" + string);
	}

	// ***************填写---性别********************
	// 填写订单--获取被保人性别
	@Test
	public static void excutGenderAction(String num, String string) throws Exception {
		Thread.sleep(1000);
		Select oselection = CreatOrderPage.getGenderElements(num);
		for (int i = 0; i < oselection.getOptions().size(); i++) {
			String sValueC = oselection.getOptions().get(i).getText();
			// 选中下拉列表元素
			if (sValueC.equals(string)) {
				oselection.selectByIndex(i);
				break;
			}
		}
	}

	// **********填写订单--投保数量***************
	public static void excutInsuranceAmountAction(String num, String string) throws Exception {
		Thread.sleep(1000);
		Select oselection = CreatOrderPage.getInsuranceAmountElements(num);
		for (int i = 0; i < oselection.getOptions().size(); i++) {
			String sValueC = oselection.getOptions().get(i).getText();
			// 选中下拉列表元素
			if (sValueC.equals(string)) {
				oselection.selectByIndex(i);
				break;
			}
		}
	}

	// **********第一个被保人是儿童的投保人信息
	// 第一个儿童被保人的投保人信息--姓名
	public static void excutInputInsureNameAction(String string) throws Exception {
		CreatOrderPage.getInsureNameElement().sendKeys(string);
		Log.info("填写被保人姓名：" + string);
	}

	// 第一个儿童被保人的投保人信息--电话
	public static void excutInputInsurerPhoneAddAction(String string) throws Exception {
		CreatOrderPage.getInsurerPhoneElement().sendKeys(string);
		Log.info("填写投保人电话：" + string);
	}

	// 第一个儿童被保人的投保人信息--证件类型
	public static void excutSelectInsurerDocTypeAddAction(String string) throws Exception {
		// 选择证件类型
		Thread.sleep(1000);
		Select oselection = CreatOrderPage.getInsurerDocTypeElements();
		for (int i = 0; i < oselection.getOptions().size(); i++) {
			String sValueC = oselection.getOptions().get(i).getText();
			// 选中下拉列表元素
			if (sValueC.equals(string)) {
				oselection.selectByIndex(i);
				break;
			}
		}
		Log.info("选中的投保人证件类型是：" + string);
	}

	// 第一个儿童被保人的投保人信息--证件号码
	public static void excutInputInsurerDocCodeAddAction(String string) throws Exception {
		CreatOrderPage.getInsurerDocCodeElement().sendKeys(string);
		Log.info("填写投保人证件号码：" + string);
	}

	// 第一个儿童被保人的投保人信息--出生日期
	public static void excutInputInsurerBirthdayAction(String string) throws Exception {
		CreatOrderPage.getInsurerBirthdayElement().clear();
		CreatOrderPage.getInsurerBirthdayElement().sendKeys(string);
		Log.info("填写投保人出生日期：" + string);
	}

	// 第一个儿童被保人的投保人信息--性别
	public static void excutSelectInsurerGenderAction(String string) throws Exception {
		Thread.sleep(1000);
		Select oselection = CreatOrderPage.getInsurerGenderElements();
		for (int i = 0; i < oselection.getOptions().size(); i++) {
			String sValueC = oselection.getOptions().get(i).getText();
			// 选中下拉列表元素
			if (sValueC.equals(string)) {
				oselection.selectByIndex(i);
				break;
			}
		}
		Log.info("选中的投保人性别是：" + string);
	}

	// ***********************投保人暨被保险人信息 end*****************************
	// ***********提交订单****************************************
	// 填写订单--新增被保险人
	public static void excutAddAction() throws Exception {
		CreatOrderPage.getAddElement().click();
		Log.info("点击新增被保险人");
	}

	// 填写订单--删除被保险人
	public static void excutDeleteAction(String num) throws Exception {
		CreatOrderPage.getDelElement(num).click();
		Log.info("删除被保险人");
	}

	// *****************结算 订单备注等信息 start*********************************
	// 填写订单--提交订单
	public static void excutSubmmitAction() throws Exception {
		CreatOrderPage.getSubmitElement().click();
		Log.info("点击提交订单");
	}
	// *****************结算 订单备注等信息 end*********************************
}

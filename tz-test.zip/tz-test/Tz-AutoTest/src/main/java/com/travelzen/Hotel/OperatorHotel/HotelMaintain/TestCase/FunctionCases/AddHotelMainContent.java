package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.FunctionCases;

import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.travelzen.Utility.Utils.*;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.*;

public class AddHotelMainContent extends FeedTest{

	public static WebDriver currentDriver;

	//酒店签约信息
	@Test(priority = 10)
	public static void MainContent_ManagerInfo() throws Exception {

		currentDriver = PointAddHotel.currentDriver;
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainMainContentAction.transmitDriver(currentDriver);
		//选择酒店签约经理
		//HotelMaintainMainContentAction.SelectManager(selectManager);//2
	}

	//TestCase中的每一个Function都可以为其做一张参数表
	//对我们需要输入的值参数化
	//酒店基本信息
	@Test(priority = 11)
	public static void MainContent_BaseInfo(String hotelName,String displayOrder,String brandSelect,String hotelStyle,
			String hotelStar,String region,String province,String city,String district,String hotelAdress,String latitude,
			String longitude,String mainPhone,String webSite,String email,String openDate,String renovationDate,
			String storey,String noofRoom,String summary
			) throws Exception {
		// 酒店基本信息“编辑”按钮触发
		HotelMaintainMainContentAction.EditbuttonCLick();
		// 编辑酒店--名称
		HotelMaintainMainContentAction.HotelName(hotelName);//"AutoTest酒店"
		// 编辑酒店--查询排序
		HotelMaintainMainContentAction.DisplayOrder(displayOrder);//"2"
		// 编辑酒店--是否推荐酒店
		HotelMaintainMainContentAction.IsReCommend();
		// 编辑酒店--连锁/品牌
		HotelMaintainMainContentAction.BrandSelect(brandSelect);//1
		// 编辑酒店--酒店类型
		HotelMaintainMainContentAction.HotelStyle(hotelStyle);//1
		// 编辑酒店--酒店星级
		HotelMaintainMainContentAction.HotalStar(hotelStar);//1
		// 编辑酒店--酒店位置--大区
		HotelMaintainMainContentAction.Region(region);//3
		// 编辑酒店--酒店位置--省份
		HotelMaintainMainContentAction.Province(province);//6
		Thread.sleep(1000);
		// 编辑酒店--酒店位置--城市
		HotelMaintainMainContentAction.City(city);//1
		Thread.sleep(1000);
		// 编辑酒店--酒店位置--行政区
		HotelMaintainMainContentAction.District(district);//1
		Thread.sleep(1000);
		// 编辑酒店--酒店位置--商业区
		HotelMaintainMainContentAction.Commercial();
		Thread.sleep(1000);
		HotelMaintainMainContentAction.SelectCommercial();
		// 编辑酒店--酒店地址
		HotelMaintainMainContentAction.HotelAdress(hotelAdress);//"科学大道"
		// 编辑酒店--酒店地址--经度
		HotelMaintainMainContentAction.latitude(latitude);//"40.0682680000"
		// 编辑酒店--酒店地址--纬度
		HotelMaintainMainContentAction.longitude(longitude);//"116.5940860000"
		// 编辑酒店--酒店电话
		HotelMaintainMainContentAction.MainPhone(mainPhone);//"012-0196-6819936"
		// 编辑酒店--酒店网站
		HotelMaintainMainContentAction.Website(webSite);//"www.baidu.com"
		// 编辑酒店--酒店Email
		HotelMaintainMainContentAction.Email(email);//"1018869@qq.com"
		// 编辑酒店--酒店开业时间
		HotelMaintainMainContentAction.OpenDate(openDate);//"2013"
		// 编辑酒店--酒店装修时间
		HotelMaintainMainContentAction.RenovationDate(renovationDate);//"2011"
		// 编辑酒店--酒店楼层
		HotelMaintainMainContentAction.Storey(storey);//"11"
		// 编辑酒店--酒店房间数
		HotelMaintainMainContentAction.NoofRoom(noofRoom);//"1100"
		// 编辑酒店--酒店介绍
		HotelMaintainMainContentAction.Summary(summary);//"这家酒店是一家非常好的酒店，设施完善，服务一流！"
		// 编辑酒店--保存编辑
		HotelMaintainMainContentAction.Savebutton();
		Thread.sleep(2000);
	}
	
	// get 酒店ID并储存在utility->Constant中
	@Test(priority = 20)
	public static void getHotelID() throws Exception{
		
		String url = currentDriver.getCurrentUrl();
		Constant.hotelId = url.substring(url.length()-24);
		System.out.println("****************HotelID:" + Constant.hotelId + "*********************");
	}
	
	//酒店照片
	@Test(priority = 12)
	public static void MainContent_PhotoInfo() throws Exception {
		//酒店服务设施“编辑”按钮触发
		HotelMaintainMainContentAction.editPhotoButton();
		Thread.sleep(3000);
		HotelMaintainMainContentAction.addPhoto();
		Thread.sleep(3000);
		HotelMaintainMainContentAction.submitPhotoButton();
		Thread.sleep(3000);
	}
	
	//酒店规定
	@Test(priority = 13)
	public static void MainContent_RuleInfo(
			String guestRemark,String ageSelect,String heightSelect,int petAllowed,String checkinTime,
			String checkoutTime,String checkinDay,String checkinPoints,String cancelTerms
			) throws Exception {
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainMainContentAction.transmitDriver(currentDriver);
		//酒店规定“编辑”按钮触发
		HotelMaintainMainContentAction.editHotelRulesButton();
		Thread.sleep(2000);
		//酒店规定--宾客类型
		HotelMaintainMainContentAction.GuestTypeCheckbox();
		Thread.sleep(1000);
		//酒店规定--宾客类型--备注
		HotelMaintainMainContentAction.GuestRemark(guestRemark);//"尊贵宾客，请小心接待！"
		Thread.sleep(1000);
		//酒店规定--儿童标准--年龄选择
		HotelMaintainMainContentAction.AgeSelect(ageSelect);//1
		Thread.sleep(1000);
		//酒店规定--儿童标准--身高选择
		HotelMaintainMainContentAction.HeightSelect(heightSelect);//1
		Thread.sleep(1000);
		//酒店规定--宠物选择
		HotelMaintainMainContentAction.PetAllowed(petAllowed);//1
		Thread.sleep(1000);
		//酒店规定--入住时间
		HotelMaintainMainContentAction.CheckinTime(checkinTime);//2
		Thread.sleep(1000);
		//酒店规定--退房时间
		HotelMaintainMainContentAction.CheckoutTime(checkoutTime);//2
		Thread.sleep(1000);
		//酒店规定--入住前“*”天
		HotelMaintainMainContentAction.CheckinDay(checkinDay);//"2"
		Thread.sleep(1000);
		//酒店规定--入住前“*”点
		HotelMaintainMainContentAction.CheckinPoints(checkinPoints);//"2"
		Thread.sleep(1000);
		//酒店规定--删除规则
		HotelMaintainMainContentAction.CancelTerms(cancelTerms);//0
		Thread.sleep(1000);
		//酒店规定--添加规则
		HotelMaintainMainContentAction.AddRulesButton();
		Thread.sleep(1000);
		//酒店规定--保存规则
		HotelMaintainMainContentAction.SaveRulesButton();
		Thread.sleep(1000);
	}
	
	//酒店服务费用
	@Test(priority = 14)
	public static void MainContent_ServiceChargeInfo(String breakerCharge,String netCharge) throws Exception {
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainMainContentAction.transmitDriver(currentDriver);
		//酒店服务费用“编辑”按钮触发
		HotelMaintainMainContentAction.EditServiceCharge();
		Thread.sleep(2000);
		//酒店服务费用--早餐
		HotelMaintainMainContentAction.BreakerCharge(breakerCharge);//"20"
		Thread.sleep(1000);
		//酒店服务费用--宽带
		HotelMaintainMainContentAction.NetCharge(netCharge);//"20"
		Thread.sleep(1000);
		//酒店服务费用--保存
		HotelMaintainMainContentAction.SaveServiceCharge();
		Thread.sleep(1000);
	}
	
	//设施包含：商务设施、酒店服务、酒店餐饮、娱乐设施。当前Case只选择了任意一种，需要改进
	//酒店服务设施
	@Test(priority = 15)
	public static void MainContent_ServerFacilityInfo(int businessCenter) throws Exception {
		
		//酒店服务设施“编辑”按钮触发
		HotelMaintainMainContentAction.EditServerFacility();
		Thread.sleep(1000);
		HotelMaintainMainContentAction.BusinessCenter(businessCenter);
		Thread.sleep(1000);
		HotelMaintainMainContentAction.SaveBusinessCenter();
		Thread.sleep(1000);
	}
	
	//酒店备注
	@Test(priority = 16)
	public static void MainContent_RemarkInfo(String privateRemark,String publicRemark) throws Exception {
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainMainContentAction.transmitDriver(currentDriver);
		//酒店备注“编辑”按钮触发
		HotelMaintainMainContentAction.EditHotelRemark();
		Thread.sleep(1000);
		//酒店备注--内部备注
		HotelMaintainMainContentAction.PrivateRemark(privateRemark);//"测试用例"
		Thread.sleep(1000);
		//酒店备注--外部备注
		HotelMaintainMainContentAction.PublicRemark(publicRemark);//"测试用例"
		Thread.sleep(1000);
		//酒店备注--保存
		HotelMaintainMainContentAction.SaveRemarkButton();
		Thread.sleep(1000);
	}
	
	//酒店基本信息完成，进入供应商信息编辑页
	@Test(priority = 17)
	public static void MainContent_ProviderInfo(String selectManager) throws Exception{
		
		//保存签约信息
		HotelMaintainMainContentAction.SelectManager(selectManager);
		HotelMaintainMainContentAction.SaveManagerButtom();
		//触发“供应商信息”Item，进入供应商信息编辑页面
		Thread.sleep(3000);
		HotelMaintainMainContentAction.ProviderButton();
		Thread.sleep(5000);
	}
	
	
	//检查比较酒店基本信息内容
	@Test
	public static void assertMainContentHotelMessage() throws Exception{
		
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainMainContentAction.transmitDriver(currentDriver);
		//点击编辑酒店基本信息按钮
		HotelMaintainMainContentAction.clickEditHotelButton();
		Thread.sleep(5000);
		//比较酒店名称一致性
		HotelMaintainMainContentAction.assertHotelName();
		//比较酒店查询排序的一致性
		//HotelMaintainMainContentAction.assertDisplayOrder();
		//比较连锁品牌的一致性
		HotelMaintainMainContentAction.assertBrandSelect();
		//比较酒店类型的一致性
		HotelMaintainMainContentAction.assertHotelStyle();
		//比较酒店星级的一致性
		//HotelMaintainMainContentAction.assertHotalStar();
		//比较酒店大区的一致性
		HotelMaintainMainContentAction.assertRegion();
		//比较酒店省份的一致性
		HotelMaintainMainContentAction.assertProvince();
		//比较酒店所在城市的一致性
		HotelMaintainMainContentAction.assertCity();
		//比较酒店所在行政区一致性
		HotelMaintainMainContentAction.assertDistrict();
		//比较酒店地址一致性
		HotelMaintainMainContentAction.assertHotelAdress();
		//比较纬度一致性
		//HotelMaintainMainContentAction.assertlatitude();
		//比较经度一致性
		//HotelMaintainMainContentAction.assertLongitude();
		//比较酒店电话一致性
		HotelMaintainMainContentAction.assertMainPhone();
		//比较酒店网址一致性
		HotelMaintainMainContentAction.assertWebsite();
		//比较酒店电子邮箱一致性
		HotelMaintainMainContentAction.assertEmail();
		//比较酒店开业时间一致性
		/*HotelMaintainMainContentAction.assertOpenDate();
		//比较酒店装修时间一致性
		HotelMaintainMainContentAction.assertRenovationDate();
		//比较酒店楼层一致性
		HotelMaintainMainContentAction.assertStorey();
		//比较酒店房间数一致性
		HotelMaintainMainContentAction.assertNoofRoom();*/
		//比较酒店介绍一致性
		HotelMaintainMainContentAction.assertSummary();
		//点击取消保存酒店信息按钮
		HotelMaintainMainContentAction.assertCancleHotel();
	}
			
			
		
	//检查比较酒店规定内容
	@Test
	public static void assertHotelRulesButton() throws Exception{
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainMainContentAction.transmitDriver(currentDriver);
		//点击编辑酒店规定按钮
		    HotelMaintainMainContentAction.assertHotelRulesButton();
		//比较宾客备注一致性
		    HotelMaintainMainContentAction.assertGuestRemark();
	    //比较儿童标准年龄选择一致性
		  /*  HotelMaintainMainContentAction.assertAgeSelect();
		//比较儿童标准身高选择一致性
		    HotelMaintainMainContentAction.assertHeightSelect();
		//比较入住时间一致性
		    HotelMaintainMainContentAction.assertCheckinTime();
		//比较退房时间一致性
		    HotelMaintainMainContentAction.assertCheckoutTime();
		//比较入住前几天几点可以退全部房费
		    HotelMaintainMainContentAction.assertCheckinDay();
		    HotelMaintainMainContentAction.assertCheckinPoints();*/
		    HotelMaintainMainContentAction.assertCancelTerms();
			//保存酒店规定按钮
		    HotelMaintainMainContentAction.assertSaveRulesButton(); 			
	}
			
			
			
	//检查酒店服务设施是否勾选
	public static void assertServerButton() throws Exception{
		//点击酒店服务按钮
		HotelMaintainMainContentAction.assertServerButton();
		//检查服务设施是否被勾选
		HotelMaintainMainContentAction.assertBusinessCenter();
	    //保存服务设施
		HotelMaintainMainContentAction.saveBusinessCenter();
		
	}
		
			
	//检查备注
	public static void assertEditHotelRemark() throws Exception{
		//点击编辑备注按钮
		HotelMaintainMainContentAction.assertEditHotelRemark();
		//比较内部备注内容
		HotelMaintainMainContentAction.assertPrivateRemark();
		//比较外部备注内容
		HotelMaintainMainContentAction.assertPublicRemark();
		//保存备注
		HotelMaintainMainContentAction.assertSaveRemarkButton();
	}
	
	
	
	
}

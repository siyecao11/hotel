package com.travelzen.Insurance.OperatorInsurance.PageObjects;
/**
 * author：qiqi.wang
 * */
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Utility.LogCenter.Log;


public class CreateOrderPage
{
	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	public static String option;
	
	public static void getDriver(WebDriver webDriver) throws Exception{
		driver = webDriver;
	}
	
	//创建订单页面-弹出客户名称弹窗-按钮
	public static WebElement getCustomerNamebuttonElement() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[3]/div[1]/table/tbody/tr[1]/td[2]/button"));
			Log.info("创建订单页面中“客户名称”按钮元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“客户名称”按钮元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-输入客户简称-输入框
	public static WebElement getCustomerShortNameInputElement() throws Exception{
		try{
			element = driver.findElement(By.name("shortName"));
			Log.info("创建订单页面中“客户简称”输入框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“客户简称”输入框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-客户查询-按钮
	public static WebElement getCustomerSearchButtonElement() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[11]/div[2]/div[1]/table/tbody/tr[1]/td[3]/button"));
			Log.info("创建订单页面中“客户查询”按钮元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“客户查询”按钮元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-选择客户-表格
	public static WebElement getCustomerSelectElement() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[11]/div[2]/div[2]/div/table/tbody/tr/td[1]"));
			Log.info("创建订单页面中“选择客户”元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“选择客户”元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-根据客户查询保险产品-按钮
	public static WebElement getProductSearchButtonElement() throws Exception{
		try{
			element = driver.findElement(By.id("searchCustomerBtn"));
			Log.info("创建订单页面中“产品查询”按钮元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“产品查询”按钮元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-选择保险范围：根据参数来选择
	/**
	 * 国内机票：DOMESTIC_INSURANCE
	 * 国际机票：INTERNATIONAL_INSURANCE
	 * 旅游：TRAVEL_INSURANCE
	 * 邮轮：CRUISE_INSURANCE
	 * 自由行：FREEDRIVING_INSURANCE
	 * */
	public static WebElement getInsuranceCoverageElement(String InsuranceCoverage) throws Exception{
		try{
			elements = driver.findElements(By.name("productType_show"));
			int n = elements.size();
			for(int i=0;i<n;i++)
			{
				String value = elements.get(i).getAttribute("value");
				if(value.equals(InsuranceCoverage))
				{
					element = elements.get(i);
					break;
				}else
				{
					continue;
				}
			}
			Log.info("创建订单页面中保险范围单选按钮组，已找到");
		}catch(Exception e){
			Log.error("创建订单页面中保险范围单选按钮组，未找到");
		}
		return element;
	} 
	
	//创建订单页面-客户名称展示-文本
	public static WebElement getCustomerNameElement() throws Exception{
		try{
			element = driver.findElement(By.name("fullName"));
			Log.info("创建订单页面中“客户名称展示”文本元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“客户名称展示”文本元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-结算方式展示-文本
	public static WebElement getClearingFormElement() throws Exception{
		try{
			element = driver.findElement(By.name("accountTypeLabel"));
			Log.info("创建订单页面中“结算方式”文本元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“结算方式”文本元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-可用余额展示-文本
	public static WebElement getBalanceElement() throws Exception{
		try{
			element = driver.findElement(By.name("totalMoney"));
			Log.info("创建订单页面中“客户可用余额”文本元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“客户可用余额”文本元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-联系人展示-文本
	public static WebElement getContactNameElement() throws Exception{
		try{
			element = driver.findElement(By.name("contactName"));
			Log.info("创建订单页面中“联系人姓名”文本元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“联系人姓名”文本元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-联系电话展示-文本
	public static WebElement getContactTelElement() throws Exception{
		try{
			element = driver.findElement(By.name("contactTel"));
			Log.info("创建订单页面中“联系电话”文本元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“联系电话”文本元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-手机号码展示-文本
	public static WebElement getContactMobilElement() throws Exception{
		try{
			element = driver.findElement(By.name("contactMobil"));
			Log.info("创建订单页面中“手机号码”文本元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“手机号码”文本元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-选择保险产品-单选
	public static WebElement getInsuranceProductElement(String ProductName) throws Exception{
		try{
			elements = driver.findElements(By.className("f-td"));
			int n=elements.size();
			for(int i=0;i<n;i++)
			{
				String value = elements.get(i).getText();
				if(value.equals(ProductName))
				{
					element = elements.get(i);
					break;
				}else
				{
					continue;
				}
			}
			Log.info("创建订单页面“保险产品”元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面“保险产品”元素，未找到。");
		}
		return element;
	}
	

	
	//创建订单页面-选择保险总人数-下拉框
	public static WebElement getInsurancePersonNumSelectElement() throws Exception{
		try{
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"personCount\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By.name("personCount"));
			Log.info("创建订单页面中“保险人数选择”下拉框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“保险人数选择”下拉框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-选择保险生效日期-日期控件
	public static WebElement getInsuranceStartDateElement() throws Exception{
		try{
			element = driver.findElement(By.name("effectiveDate"));
			Log.info("创建订单页面中“保险生效日期”控件元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“保险生效日期”控件元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-展示保险结束时间-文本
	public static WebElement getInsuranceEndDateElement() throws Exception{
		try{
			element = driver.findElement(By.id("deadlineDate"));
			Log.info("创建订单页面中“保险结束时间”文本元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“保险结束时间”文本元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-展示保险有效天数-文本
	public static WebElement getInsuranceDaysElement() throws Exception{
		try{
			element = driver.findElement(By.id("insuranceDays"));
			Log.info("创建订单页面中“保险有效天数”文本元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“保险有效天数”文本元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-填写被保人姓名-输入框
	public static WebElement getCustomerNameInputElement() throws Exception{
		try{
			element = driver.findElement(By.name("orderProducts[0].policys[0].insureeName"));
			Log.info("创建订单页面中“被保人姓名”输入框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“被保人姓名”输入框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-填写被保人手机号码-输入框
	public static WebElement getCustomerMobileInputElement() throws Exception{
		try{
			element = driver.findElement(By.name("orderProducts[0].policys[0].mobelPhone"));
			Log.info("创建订单页面中“被保人手机号码”输入框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“被保人手机号码”输入框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-选择证件类型-下拉框
	public static WebElement getIDTypeSelectElement() throws Exception{
		try{
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"orderProducts[0].policys[0].docType\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By.name("orderProducts[0].policys[0].docType"));
			Log.info("创建订单页面中“证件类型”下拉框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“证件类型”下拉框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-输入证件号码-输入框
	public static WebElement getIDNumInputElement() throws Exception{
		try{
			element = driver.findElement(By.name("orderProducts[0].policys[0].docCode"));
			Log.info("创建订单页面中“证件号码”输入框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“证件号码”输入框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-选择出生日期-日期控件
	public static WebElement getBirthDateInputElement() throws Exception{
		try{
			element = driver.findElement(By.name("orderProducts[0].policys[0].birthDate"));
			Log.info("创建订单页面中“被保人出生日期”选择框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“被保人出生日期”选择框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-选择被保人性别-下拉框
	public static WebElement getSexTypeSelectElement(){
		try{
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"orderProducts[0].policys[0].gender\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By.name("orderProducts[0].policys[0].gender"));
			Log.info("创建订单页面中“被保人性别”下拉框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“被保人性别”下拉框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-选择保险份数-下拉框
	public static WebElement getInsuranceNumSelectElement(){
		try{
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"orderProducts[0].policys[0].insuranceAmount\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By.name("orderProducts[0].policys[0].insuranceAmount"));
			Log.info("创建订单页面中“保险份数”选择框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“保险份数”选择框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-投保人姓名-输入框
	public static WebElement getApplicantNameInputElement() throws Exception{
		try{
			element = driver.findElement(By.name("orderProducts[0].policys[0].insurerName"));
			Log.info("创建订单页面中“投保人姓名”输入框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“投保人姓名”输入框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-投保人手机号-输入框
	public static WebElement getApplicantMobileInputElement() throws Exception{
		try{
			element = driver.findElement(By.name("orderProducts[0].policys[0].insurerPhone"));
			Log.info("创建订单页面中“投保人手机号码”输入框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“投保人手机号码”输入框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-投保人证件类型-下拉框
	public static WebElement getApplicantCardStyleSelectElement(){
		try{
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"orderProducts[0].policys[0].insurerDocType\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By.name("orderProducts[0].policys[0].insurerDocType"));
			Log.info("创建订单页面中“投保人证件类型”选择框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“投保人证件类型”选择框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-投保人证件号码-输入框
	public static WebElement getApplicantCardIDInputElement() throws Exception{
		try{
			element = driver.findElement(By.name("orderProducts[0].policys[0].insurerDocCode"));
			Log.info("创建订单页面中“投保人证件号码”输入框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“投保人证件号码”输入框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-投保人出生日期-日期控件
	public static WebElement getApplicantBirthdayInputElement() throws Exception{
		try{
			element = driver.findElement(By.name("orderProducts[0].policys[0].insurerBirthDate"));
			Log.info("创建订单页面中“投保人出生日期”输入框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“投保人出生日期”输入框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-投保人性别-下拉框
	public static WebElement getApplicantSexSelectElement(){
		try{
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"orderProducts[0].policys[0].insurerGender\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By.name("orderProducts[0].policys[0].insurerGender"));
			Log.info("创建订单页面中“投保人性别”选择框元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“投保人性别”选择框元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-保存订单-按钮
	public static WebElement getSaveOrderButtonElement() throws Exception{
		try{
			element = driver.findElement(By.id("btn-save"));
			Log.info("创建订单页面中“保存订单”按钮元素，已找到。");
		}catch(Exception e){
			Log.error("创建订单页面中“保存订单”按钮元素，未找到。");
		}
		return element;
	}
	
	//创建订单页面-提交订单-按钮
		public static WebElement getSubmitOrderButtonElement() throws Exception{
			try{
				element = driver.findElement(By.id("btn-submit"));
				Log.info("创建订单页面中“提交订单”按钮元素，已找到。");
			}catch(Exception e){
				Log.error("创建订单页面中“提交订单”按钮元素，未找到。");
			}
			return element;
		}
		
	
		
	
	
}

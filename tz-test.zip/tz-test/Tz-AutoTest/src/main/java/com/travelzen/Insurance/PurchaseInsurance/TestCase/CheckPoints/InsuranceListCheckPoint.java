package com.travelzen.Insurance.PurchaseInsurance.TestCase.CheckPoints;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.travelzen.Login.PurchaseLogin.TestCase.FunctionCases.LoginPurchase;
import com.travelzen.Insurance.PurchaseInsurance.Utility.Utils.DataProviderApp;
import com.travelzen.Utility.Assertion.Assertion;
import com.travelzen.Utility.Constants.Constants;
import com.travelzen.Utility.DataDriver.ExcelAction;
import com.travelzen.Utility.LogCenter.Log;
import com.travelzen.Utility.ScreenShot.RetryFail;
import com.travelzen.Utility.Utils.*;
import com.travelzen.Insurance.OperatorInsurance.AppModules.ProductManageAction;
import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.Constant;
import com.travelzen.Insurance.PurchaseInsurance.AppModules.*;

public class InsuranceListCheckPoint {

	public static WebDriver currentDriver;
	public static String actualTestCase;
	/*
	 * 填写订单投保人&被保人信息  Action
	 * author xuemei.ren date 07/01/2016
	 */
	public static String productExcelName = "Insurance/Datas/KeepForProductInfo.xls";
	public static String SellingPriceExcelName = "Insurance/Datas/SellingPriceInfo.xls";
	public static String productExcelNamePuchaser = "Insurance/Datas/p_productInfo.xls";
	
	public static void OrderDetails(WebDriver currentDriver) throws Exception{
		//获取要在采购商比对的产品名称
		String eInsuranceName = ExcelAction.getValue(productExcelName, "productName");
		ExcelAction.setValue(productExcelNamePuchaser,"insuranceName","eInsuranceName");
		
		InsuranceListAction.transmitDriver(currentDriver);
		//要比对的产品在列表页的序号
		String number = InsuranceListAction.excutInsuranceNameAction(eInsuranceName);
		//保险公司
		String aCompanyName = InsuranceListAction.excutGetCompanyAction(number);
		ExcelAction.setValue(productExcelNamePuchaser,"companyName","aCompanyName");
		//险种类型
		String aTypeName = InsuranceListAction.excutGetInsuranceTypeAction(number);
		ExcelAction.setValue(productExcelNamePuchaser,"typeName","aTypeName");
		//保险期限
		String aDeadline = InsuranceListAction.excutGetInsurancePeriodAction(number);
		ExcelAction.setValue(productExcelNamePuchaser,"deadline","aDeadline");
		//最高保额
		String aInsuranceAmount = InsuranceListAction.excutGetPolicyMaximumAction(number);
		ExcelAction.setValue(productExcelNamePuchaser,"insuranceAmount","aInsuranceAmount");
		//保险范围
		String aInsuranceScopeTem = InsuranceListAction.excutGetInsuranceApplicationAction(number);
		ExcelAction.setValue(productExcelNamePuchaser,"insuranceScopeTem","aInsuranceScopeTem");
		//面价
		String aNormalPrice = InsuranceListAction.excutGetFacePriceAction(number);
		ExcelAction.setValue(productExcelNamePuchaser,"normalPrice","aNormalPrice");
		//保险费用
		String aInsuranceFee = InsuranceListAction.excutGetnsuranceFeeAction(number);
		ExcelAction.setValue(productExcelNamePuchaser,"insuranceFee","aInsuranceFee");
		
		//System.out.println(aProductName + aCompanyName + aTypeName + aTypeCode + aDeadline + aInsuranceAmount + aNormalPrice + aUpsetPrice + aInsuranceScopeTem);
		
		String eCompanyName = ExcelAction.getValue(productExcelName, "companyName");
		String eTypeName = ExcelAction.getValue(productExcelName, "typeName");
		String eDeadline = ExcelAction.getValue(productExcelName, "deadline");
		String eInsuranceAmount = ExcelAction.getValue(productExcelName, "insuranceAmount");
		String eNormalPrice = ExcelAction.getValue(productExcelName, "normalPrice");
		String eInsuranceScopeTem = ExcelAction.getValue(productExcelName, "scope");
		String eInsuranceFee = ExcelAction.getValue(SellingPriceExcelName, "insuranceFee");
		
		//System.out.println(eProductName + eCompanyName + eTypeName + eTypeCode + eDeadline + eInsuranceAmount + eNormalPrice + eUpsetPrice + eInsuranceScopeTem);
		Assertion.verifyEquals(aCompanyName, eCompanyName, "期望保险公司名：" + eCompanyName + ";实际保险公司名：" + aCompanyName);
		Assertion.verifyEquals(aTypeName, eTypeName, "期望险种名称：" + eTypeName + ";实际险种名称：" + aTypeName);
		Assertion.verifyEquals(aDeadline, eDeadline, "期望保险期限：" + eDeadline + ";实际保险期限：" + aDeadline);
		Assertion.verifyEquals(aInsuranceAmount, eInsuranceAmount, "期望最高保额(元)：" + eInsuranceAmount + ";实际最高保额(元)：" + aInsuranceAmount);
		Assertion.verifyEquals(aNormalPrice, eNormalPrice, "期望面价：" + eNormalPrice + ";实际面价：" + aNormalPrice);
		Assertion.verifyEquals(aInsuranceFee, eInsuranceFee, "期望保险费用：" + aInsuranceFee + ";实际保险费用：" + eInsuranceFee);
		Assertion.verifyEquals(aInsuranceScopeTem, eInsuranceScopeTem, "期望适用范围：" + eInsuranceScopeTem + ";实际适用范围：" + aInsuranceScopeTem);
	}
}

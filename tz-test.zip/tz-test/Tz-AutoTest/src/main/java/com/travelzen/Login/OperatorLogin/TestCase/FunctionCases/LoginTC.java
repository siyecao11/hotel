package com.travelzen.Login.OperatorLogin.TestCase.FunctionCases;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.travelzen.Login.OperatorLogin.AppModules.LoginAction;
import com.travelzen.Login.OperatorLogin.AppModules.MenuItemAction;
import com.travelzen.Login.OperatorLogin.Utility.Constants.Constant;
import com.travelzen.Login.OperatorLogin.Utility.Constants.Utils;
import com.travelzen.Utility.LogCenter.Log;

import org.databene.feed4testng.FeedTest;
import org.testng.annotations.Test;


public class LoginTC extends FeedTest{
	
	public static WebDriver driver;
	
	//待改进
	//登录需要具体模块化或者抽象化，登录仅仅只是登录，从登录后的欢迎页面到具体的业务主页，放在业务里面
	
	@Test
	//@Source("LoginInfo.xls")
	public static void login(String username, String password) throws Exception{
		
		driver = new FirefoxDriver();
		driver.get(Constant.OPLOGINURL);
		LoginAction.excute(username,password, driver);
		Log.info("Login Successfully, Entering into HomePage...");
		
		//Waiting for HomePage loading....
		Utils.waitForElement(5, driver, "page");
		
	//Enter into hotel HomePage
		MenuItemAction.transmitDriver(driver);
		MenuItemAction.excuteHotel();

		//driver.quit();
	}
public static void login(WebDriver driver,String username, String password) throws Exception{
		
		driver.get(Constant.OPLOGINURL);
		LoginAction.excute(username,password, driver);
		Log.info("Login Successfully, Entering into HomePage...");
		
		//Waiting for HomePage loading....
		Utils.waitForElement(5, driver, "page");
		
	//Enter into hotel HomePage
		MenuItemAction.transmitDriver(driver);
		MenuItemAction.excuteHotel();
		//driver.quit();
	}
	
}

package com.travelzen.Insurance.OperatorInsurance.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.Constant;
import com.travelzen.Utility.LogCenter.Log;

/**
 * 产品管理页面 元素定位
 * @author Weixing.Yang
 *
 */
public class ProductManagePage {

	public static WebDriver driver;
	private static WebElement element;
	private static List<WebElement> elementList;
	//index用于标记数据列表中的第几行记录
	public static int index =1;
	
	//获取当前页面的Driver
	public static void getDriver(WebDriver webDriver) {

		driver = webDriver;
	}
	
	//获取产品管理页面中 “订单管理” 菜单元素
	public static WebElement getOrderManageElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href=" + Constant.ORDERMANAGEURL +"]"));
			Log.info("产品管理页面中 “订单管理” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 “订单管理” 元素 没有找到");
		}
		return element;
	}
	
	//获取产品管理页面中 “产品管理” 菜单元素
	public static WebElement getProductManageElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href=" + Constant.PRODUCTMANAGEURL +"]"));
			Log.info("产品管理页面中 “产品管理” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 “产品管理” 元素 没有找到");
		}
		return element;
	}
	
	//获取产品管理页面中 “售价维护” 菜单元素
	public static WebElement getSalePriceElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href=" + Constant.SALEPRICEURL +"]"));
			Log.info("产品管理页面中 “售价维护” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 “售价维护” 元素 没有找到");
		}
		return element;
	}
	
	//获取产品管理页面中 “新增产品” 按钮元素
	public static WebElement getAddProductButtonElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("addProductButton"));
			Log.info("产品管理页面中 “新增产品” 按钮元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 “新增产品” 按钮元素 没有找到");
		}
		return element;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条指定产品
	//产品名称
	public static WebElement getProductNameElement(String productName) throws Exception{
		
		try{
			elementList = driver.findElements(By.cssSelector("td[role='gridcell']"));
			int length = elementList.size();
			for(int i = 0; i<length; i++){
				if(elementList.get(i).getText().equals(productName)){
					element = elementList.get(i);
					index = i/10 + 1;
				}
			}
			Log.info("产品管理页面中 指定产品的 “产品名称” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 指定产品的 “产品名称” 元素 没有已找到");
		}
		return element;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条特定产品
	//“修改”按钮元素
	public static WebElement getModifyProductElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='searchTable']/div[2]/table/tbody/tr[" + index +"]" + "/td[1]/a[1]"));
			Log.info("产品管理页面中 指定产品的 “修改” 按钮元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 指定产品的 “修改” 按钮元素 没有已找到");
		}
		return element;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条特定产品
	//“挂起”按钮元素
	public static WebElement getDeleteProductElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='searchTable']/div[2]/table/tbody/tr[" + index +"]" + "/td[1]/a[2]"));
			Log.info("产品管理页面中 指定产品的 “挂起” 按钮元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 指定产品的 “挂起” 按钮元素 没有已找到");
		}
		return element;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条特定产品
	//保险公司名称
	public static WebElement getCompanyNameElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='searchTable']/div[2]/table/tbody/tr[" + index +"]" + "/td[3]"));
			Log.info("产品管理页面中 指定产品的 “保险公司名称” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 指定产品的 “保险公司名称” 元素 没有已找到");
		}
		return element;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条特定产品
	//险种名称
	public static WebElement getTypeNameElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='searchTable']/div[2]/table/tbody/tr[" + index +"]" + "/td[4]"));
			Log.info("产品管理页面中 指定产品的 “险种名称” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 指定产品的 “险种名称” 元素 没有已找到");
		}
		return element;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条特定产品
	//险种编号
	public static WebElement getTypeCodeElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='searchTable']/div[2]/table/tbody/tr[" + index +"]" + "/td[5]"));
			Log.info("产品管理页面中 指定产品的 “险种编号” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 指定产品的 “险种编号” 元素 没有已找到");
		}
		return element;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条特定产品
	//保险期限
	public static WebElement getDeadlineElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='searchTable']/div[2]/table/tbody/tr[" + index +"]" + "/td[6]"));
			Log.info("产品管理页面中 指定产品的 “保险期限” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 指定产品的 “保险期限” 元素 没有已找到");
		}
		return element;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条特定产品
	//最高保额(元)
	public static WebElement getInsuranceAmountElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='searchTable']/div[2]/table/tbody/tr[" + index +"]" + "/td[7]"));
			Log.info("产品管理页面中 指定产品的 “最高保额(元)” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 指定产品的 “最高保额(元)” 元素 没有已找到");
		}
		return element;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条特定产品
	//面价
	public static WebElement getNormalPriceElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='searchTable']/div[2]/table/tbody/tr[" + index +"]" + "/td[8]"));
			Log.info("产品管理页面中 指定产品的 “面价” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 指定产品的 “面价” 元素 没有已找到");
		}
		return element;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条特定产品
	//底价
	public static WebElement getUpsetPriceElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='searchTable']/div[2]/table/tbody/tr[" + index +"]" + "/td[9]"));
			Log.info("产品管理页面中 指定产品的 “底价” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 指定产品的 “底价” 元素 没有已找到");
		}
		return element;
	}
	
	//获取产品列表信息
	//产品管理页面中，通过产品名称 定位某条特定产品
	//适用范围
	public static WebElement getInsuranceScopeTemElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='searchTable']/div[2]/table/tbody/tr[" + index +"]" + "/td[10]"));
			Log.info("产品管理页面中 指定产品的 “适用范围” 元素 已找到");
		}catch (Exception e){
			Log.error("产品管理页面中 指定产品的 “适用范围” 元素 没有已找到");
		}
		return element;
	}
}

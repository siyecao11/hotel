package com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.CheckPoints;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.*;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
import com.travelzen.Login.OperatorLogin.AppModules.LoginAction;
import com.travelzen.Utility.Assertion.*;
import com.travelzen.Utility.DataDriver.*;
import com.travelzen.Utility.Utils.*;

//@Listeners({Hotel.OperatorHotel.PrepayHotel.utility.AssertionListener.class})
public class OrderManageOrderListCheckPoint {

	public static WebDriver currentDriver;
	
	@Test
	public static void orderListCheckPoint(String orderId) throws Exception{
		
		//调用隐式Driver取值（expected value）,用于断言
		//get 酒店ID
		currentDriver = new FirefoxDriver();
		currentDriver.get(com.travelzen.Login.OperatorLogin.Utility.Constants.Constant.OPLOGINURL);
		LoginAction.excute("yangweixing", "111111", currentDriver);
		Thread.sleep(2000);
		//跳转酒店订单管理页面的URL
		currentDriver.get(Constant.orderManageURL);
		Utils.waitForElement(5, currentDriver, "page");
		OrderManageOrderListPage.getDriver(currentDriver);
		//输入订单号
		OrderManageOrderListAction.OrderIdInput(orderId);
		Utils.waitForElement(2, currentDriver, "sleep");
		//点击搜索
		OrderManageOrderListAction.SearchOrder();
		Utils.waitForElement(2, currentDriver, "sleep");
		
		//页面实际显示的值，待比对
		//订单ID
		String aOrderId = OrderManageOrderListPage.getOrderID().getText();
		//订单客户名称
		String aKeHuName = OrderManageOrderListPage.getOrderKeHuName().getText();
		//订单支付方式
		String aPayType = OrderManageOrderListPage.getOrderPayType().getText();
		//订单酒店所在城市
		String aHotelCity = OrderManageOrderListPage.getOrderHotelCity().getText();
		//订单酒店名称
		String aHotelName = OrderManageOrderListPage.getOrderHotelName().getText();
		//订单酒店入住客人名称
		String aCustomerName = OrderManageOrderListPage.getOrderCustomerName().getText();
		//订单类型(正常酒店...)
		String aOrderType = OrderManageOrderListPage.getOrderType().getText();
		//订单来源
		String aOrderSource = OrderManageOrderListPage.getOrderSource().getText();
		//订单创建日期
		String aOrderBookingDate = OrderManageOrderListPage.getOrderBookingDate().getText();
		//订单入住/离店日期
		String aOrderCheckInOutDate = OrderManageOrderListPage.getOrderCheckInOutDate().getText();
		//订单金额
		String aOrderFee = OrderManageOrderListPage.getOrderFee().getText();
		//订单状态
		String aOrderStatus = OrderManageOrderListPage.getOrderStatus().getText();
		//订单确认状态
		String aOrderConfirmStatus = OrderManageOrderListPage.getOrderConfirmStatus().getText();
		
		//对应期望取值
		String eOrderId = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "orderId");
		String eKeHuName = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "keHuName");
		String eHotelCity = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "hotelCity");
		String eHotelName = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "hotelName");
		String eCustomerName = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "customerName");
		String eOrderType = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "orderType");
		String eOrderSource = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "orderSource");
		String eOrderBookingDate = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "bookingDate");
		String eOrderCheckInOutDate = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "checkinDate") + "到" + ExcelAction.getValue("OrderExpectHotelInfo.xls", "checkoutDate");
		String eOrderFee = ExcelAction.getValue("Hotel/OrderExpectHotelInfo.xls", "orderFee");
		
		//订单列表页--订单ID--断言
		Assertion.verifyEquals(aOrderId, eOrderId, "OrderId is " + aOrderId + " in actual");
		//订单列表页--预订酒店客户名称--断言
		Assertion.verifyEquals(aKeHuName, eKeHuName, "KeHuName is " + aKeHuName + " in actual");
		//订单列表页--订单酒店所在城市--断言
		Assertion.verifyEquals(aHotelCity, eHotelCity, "HotelCity is " + aHotelCity + " in actual");
		//订单列表页--订单预订酒店名称--断言
		Assertion.verifyEquals(aHotelName, eHotelName, "HotelName is " + aHotelName + " in actual");
		//订单列表页--订单酒店入住人名称--断言
		Assertion.verifyEquals(aCustomerName, eCustomerName, "CustomerName is " + aCustomerName + " in actual");
		//订单列表页--订单类型--断言
		Assertion.verifyEquals(aOrderType, eOrderType, "OrderType is " + aOrderType + " in actual");
		//订单列表页--订单来源--断言
		Assertion.verifyEquals(aOrderSource, eOrderSource, "OrderSource is " + aOrderSource + " in actual");
		//订单列表页--订单创建日期--断言
		Assertion.verifyEquals(aOrderBookingDate, eOrderBookingDate, "OrderBookingDate is " + aOrderBookingDate + " in actual");
		//订单列表页--订单入住/离店日期--断言
		Assertion.verifyEquals(aOrderCheckInOutDate, eOrderCheckInOutDate, "OrderCheckInOutDate is " + aOrderCheckInOutDate + " in actual");
		//订单列表页--订单金额--断言
		Assertion.verifyEquals(aOrderFee, eOrderFee, "OrderFee is " + aOrderFee+ " in actual");
		
		currentDriver.close();
	}
}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.FunctionCases;

import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.travelzen.Utility.Utils.*;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.*;

public class AddHotelDailyRate extends FeedTest{

	public static WebDriver currentDriver;
	
	//TestCase中的每一个Function都可以为其做一张参数表
	//对我们需要输入的值参数化
	
	//根据房型选择修改每日价格信息
	//选择需要修改的 房型
	@Test(priority = 1)
	public static void DailyRate_EditDailyRateByRoomCat() throws Exception {

		currentDriver = AddHotelRoomAllot.currentDriver;
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainDailyRateAction.transmitDriver(currentDriver);
		//选择目标房型
		HotelMaintainDailyRateAction.excuteSelectRoomCat(Constant.roomId);
		Thread.sleep(2000);
		//选择指定时间的 每日价格
		
	}
	
	//为指定房型添加 礼包信息
	@Test(priority = 10)
	public static void DailyRate_ModifyGifPackage(String PackageContent) throws Exception{
		
		//添加礼包按钮触发
		HotelMaintainDailyRateAction.excuteModifyGifPackage();
		Thread.sleep(2000);
		// 添加礼包 -- 选择价格计划
		HotelMaintainDailyRateAction.excuteSelectBookingClass();
		Thread.sleep(2000);
		//添加礼包 -- 添加有效期 -- 开始时间
		HotelMaintainDailyRateAction.excuteStartDate();
		Thread.sleep(2000);
		//添加礼包 -- 添加有效期 -- 结束时间
		HotelMaintainDailyRateAction.excuteEndDate();
		// 添加礼包 -- 添加有效期Btn
		HotelMaintainDailyRateAction.excuteAddTimeBtn();
		Thread.sleep(2000);
		// 添加礼包 -- 赠送方式（每间房赠送一次 、每间房每晚）
		HotelMaintainDailyRateAction.excutePresentType();
		Thread.sleep(2000);
		// 添加礼包 -- 礼包内容编辑框
		HotelMaintainDailyRateAction.excuteGiftPackageContent(PackageContent);
		Thread.sleep(2000);
		// 添加礼包 -- 保存添加礼包信息
		HotelMaintainDailyRateAction.excuteAddGiftPackageConfirmBtn();
		Thread.sleep(2000);
	}
	
	//修改指定房型的每日价格信息
	//触发修改按钮
	@Test(priority = 11)
	public static void DailyRate_ModifyDailyRateBtn() throws Exception {
		
		//修改每日价格信息: 触发“修改”btn
		HotelMaintainDailyRateAction.excuteModifyDailyRate();
		Utils.waitForElement(3, currentDriver, "script");
	}
	
	//修改指定房型的每日价格
	@Test(priority = 12)
	public static void DailyRate_DailyPriceContainerEdit(String roomCost) throws Exception {
		
		//修改每日价格
		HotelMaintainDailyRateAction.excuteDailyPriceContainerEdit(roomCost);
		Utils.waitForElement(3, currentDriver, "script");
	}
	
	//修改指定房型的每日规定
	@Test(priority = 13)
	public static void DailyRate_DailyRuleContainerEdit(String checkInTime, String checkOutTime, String checkInDay, String checkOutPoint, String CancleTerm) throws Exception {
		
		//修改每日规定
		HotelMaintainDailyRateAction.excuteDailyPriceContainerRule();
		Thread.sleep(2000);
		//修改每日规定--宽带
		HotelMaintainDailyRateAction.excuteDailyRule_Broadband(); 
		Thread.sleep(2000);
		//修改每日规定--取消变更规则--入住时间、退房时间
		HotelMaintainDailyRateAction.excuteDailyRule_CheckInTime(checkInTime);
		HotelMaintainDailyRateAction.excuteDailyRule_CheckOutTime(checkOutTime);
		//修改每日规定--取消变更规则--入住前天、点
		Thread.sleep(2000);
		HotelMaintainDailyRateAction.excuteDailyRule_CheckInDay(checkInDay);
		HotelMaintainDailyRateAction.excuteDailyRule_CheckInPoint(checkOutPoint);
		//修改每日规定--取消变更规则--房费扣除选择（全部房费、首晚房费）
		Thread.sleep(2000);
		HotelMaintainDailyRateAction.excuteDailyRule_CancleTerm(CancleTerm);
		//修改每日规定--取消变更规则 修改（删除原有规则）
		HotelMaintainDailyRateAction.excuteDailyRule_DelNewTerm();
		//修改每日规定--取消变更规则 添加（添加新规则）
		HotelMaintainDailyRateAction.excuteDailyRule_AddRulebtn();
		//修改每日规定--保存修改规定
		HotelMaintainDailyRateAction.excuteDailyRule_SaveRuleEdit();
		Thread.sleep(2000);
	}
	
	//保存修改的 每日价格信息
	@Test(priority = 14)
	public static void DailyRate_SaveModifyDailyRate() throws Exception {
		
		//保存修改
		HotelMaintainDailyRateAction.excuteModifyDailyRateElement_Save();
		Thread.sleep(2000);
		//注明变价原因
		HotelMaintainDailyRateAction.excuteModifyDailyRateElement_Save_PriceChangeCauses();
		//提交变价原因
		Thread.sleep(2000);
		HotelMaintainDailyRateAction.excuteDailyRateElement_Save_PriceChangeCauses_Save();
		Thread.sleep(2000);
	}
	
	//酒店所有信息都完成编辑后，提交审核
	@Test(priority = 15)
	public static void Hotel_CommitAudit() throws Exception {
		
		//提交审核
		HotelCommitAuditAction.excuteCommitAudit();
		Thread.sleep(2000);                   
	}
}

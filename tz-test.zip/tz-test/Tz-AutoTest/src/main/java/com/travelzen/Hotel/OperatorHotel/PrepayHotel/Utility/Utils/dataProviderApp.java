package com.travelzen.Hotel.OperatorHotel.PrepayHotel.Utility.Utils;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import com.travelzen.Utility.DataDriver.ExcelAction;
import com.travelzen.Utility.LogCenter.Log;

public class dataProviderApp {

	public static WebDriver driver;
	public static int column;
	public static int row;
	public static String isFunction;
	public static String TestCadeName;
	public static String isLoginIncludeProcess = "true";
	public static String isCreateOrderIncludeProcess = "true";

	//需要包含所有要读取参数的groups名称
	@Test(priority = 0, groups = { "数据处理中心","运营商登陆","预付酒店查询","正常单创建","添加客服说明","正常单审核取消","正常单审核确认","酒店查询","正常单创建退订单","正常单退订单取消"})
	@Parameters({"isFunctionTest","TestName"})
	public static void parameterGet(String isFunctionTest,String TestName) {
		
		isFunction = isFunctionTest;
		TestCadeName = TestName;
		System.out.println("Parameterized value is : " + isFunction);
	}

	@DataProvider(name = "normal_order")
	public static Object[][] normal_order() throws Exception {
		
		// Excel表格名称定义
		String excelName = "Hotel/Purchaser_CashpayHotel_Booking.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("excel_get_column value is : " + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("excel_get_rows value is : " + row);

		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("false"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);

		return excelData;
	}

	@DataProvider(name = "longin_data")
	public static Object[][] BookingHotel() throws Exception {
		
		// Excel表格名称定义
		String excelName = "Login/Datas/LoginOperatorData.xls";
		// 定义
		// 列 
		column = ExcelAction.excel_get_column(excelName);
		Log.info("excel_get_column value is : " + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("excel_get_rows value is : " + row);

		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true")&&TestCadeName.equalsIgnoreCase("login"))
		{
			isLoginIncludeProcess = "false";
			excelData = ExcelAction.getAllRows(excelName, row, column);
		}
		else{
			isLoginIncludeProcess = "true";
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		}	
		return excelData;
	}
	//建单客户信息功能测试用例去取多行数据------------MultipleInfo
	@DataProvider(name = "tenantInfo_data")
	public static Object[][] tenantInfo() throws Exception {
		
		// Excel表格名称定义
		String excelName = "Hotel/tenantInformation_data.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("excel_get_column value is : " + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("excel_get_rows value is : " + row);

		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true")&&TestCadeName.equalsIgnoreCase("createOrder"))
		{
			isCreateOrderIncludeProcess = "false";
			excelData = ExcelAction.getAllRows(excelName, row, column);
		}
		else{
			isCreateOrderIncludeProcess = "true";
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		}
		return excelData;
	}
	//酒店查询功能测试用例名称---------query
	@DataProvider(name = "hotelQuery_data")
	public static Object[][] hotelQuery() throws Exception {
		
		// Excel表格名称定义
		String excelName = "Hotel/BookingSearch_TestData.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("excel_get_column value is : " + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("excel_get_rows value is : " + row);

		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true")&&TestCadeName.equalsIgnoreCase("query"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);

		return excelData;
	}
	
	@DataProvider(name = "costomerRemark_data")
	public static Object[][] costomerRemark() throws Exception {
		
		// Excel表格名称定义
		String excelName = "Hotel/CostomerRemark.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("excel_get_column value is : " + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("excel_get_rows value is : " + row);

		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);

		return excelData;
	}
	//改签数据 endorseCheckinDate、endorseCheckoutDate、endorseRoomNo
	@DataProvider(name = "EndorseOrder_TestData")
	public static Object[][] EndorseOrder() throws Exception {
		
		// Excel表格名称定义
		String excelName = "Hotel/EndorseOrder_TestData.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("excel_get_column value is : " + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("excel_get_rows value is : " + row);

		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);

		return excelData;
	}
	
	//创建订单，一个用例对应一个case
	@DataProvider(name = "TestForCOrder")
	public static Object[][] cOrder() throws Exception {
		
		// Excel表格名称定义
		String excelName = "Hotel/TestForCOrder.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("excel_get_column value is : " + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("excel_get_rows value is : " + row);

		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true")&&TestCadeName.equalsIgnoreCase("createOrder"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);

		return excelData;
	}
	
}

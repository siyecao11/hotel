package com.travelzen.Insurance.OperatorInsurance.TestCase.FunctionCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.travelzen.Insurance.OperatorInsurance.AppModules.AddProductAction;
import com.travelzen.Insurance.OperatorInsurance.AppModules.ProductManageAction;
import com.travelzen.Insurance.OperatorInsurance.PageObjects.AddProductPage;
import com.travelzen.Insurance.OperatorInsurance.TestCase.CheckPoints.ProductManageListCheckPoint;
import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.Constant;
import com.travelzen.Login.OperatorLogin.TestCase.FunctionCases.LoginOperator;
import com.travelzen.Utility.Constants.Constants;

public class Test {

public enum ProductDetail{
		
		TP("太平明细", "001"), TPY("太平洋明细","002"), TK("泰康明细","003"), PA("平安明细","004"), PADZ("平安电子明细","005"), PA30("平安30元","006"),
		PA40("平安40元","007"), MYXY("美亚畅游神州","008"), MYWG("美亚万国游踪","009"), RB("人保邮轮","010"), MYLYY("美亚乐悠悠","011"), ASZY("安盛卓越亚洲行","012"),
		RBJW("人保境外旅游险","013"), PAJN("平安境内旅游险","014"), CXJW("平安境内旅游险","015"), CXJN("畅行境内航意险","016"),
		GNJP("国内机票","DOMESTIC_INSURANCE"), GJJP("国际机票","INTERNATIONAL_INSURANCE"), LY("旅游","TRAVEL_INSURANCE"), YL("邮轮","CRUISE_INSURANCE"), ZYX("自由行","FREEDRIVING_INSURANCE");
        // 成员变量
        private String name;
        private String index;

        // 构造方法
        private ProductDetail(String name, String index) {
            this.name = name;
            this.index = index;
        }

        // 通过index取name 
        public static String getName(String index) {
        	
            for (ProductDetail p : ProductDetail.values()) {
                if (p.getIndex() == index) {
                    return p.name;
                }
            }
            return null;
        }
        //通过name取index
        public static String getIndex(String name) {
        	
            for (ProductDetail p : ProductDetail.values()) {
                if (p.getName() == name) {
                    return p.index;
                }
            }
            return null;
        }

        // get set 方法
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIndex() {
            return index;
        }

        public void setIndex(String index) {
            this.index = index;
        }
	}

	public static WebDriver currentDriver;
	/*
	public static void main(String[] args) throws Exception{
		
		String s = "旅游;自由行;邮轮";
		String[] array = new String[10];
		array = s.split(";");
		ProductDetail[] p = ProductDetail.values();
		for(int i=0; i<array.length; i++)
		{
			System.out.println(array[i]);
			for (ProductDetail pd : p) {
				if(pd.name.equals(array[i])){
					System.out.println("当前index：" + pd.index);
				}
			}
		}
		System.out.println(ProductDetail.getName("005"));
		System.out.println(ProductDetail.getIndex("平安境内旅游险"));
		currentDriver = new FirefoxDriver();
		LoginOperator.driver = currentDriver;
		LoginOperator.operatorLogin("yangweixing", "111111", "杨伟兴");
		currentDriver = LoginOperator.driver;
		currentDriver.get(Constant.PRODUCTMANAGEURL);
		//传递Driver
		ProductManageAction.transmitDriver(currentDriver);
		//点击“新增产品”按钮，进入新增产品页面
		ProductManageAction.excuteAddProductButtonAction();
		//Assertion.verifyEquals("", "");
		//传递Driver
		AddProductAction.transmitDriver(currentDriver);
		//填写产品名称
		AddProductAction.excuteProductNameAction("asdasd");
		//选择保险公司名称
		AddProductAction.excuteCompanyNameAction("太平洋保险");
		
		//填写保险期限
		AddProductAction.excuteDeadlineAction("2");
		//填写最高保额
		AddProductAction.excuteInsuranceAmountAction("100000");
		//选择保险险种
		AddProductAction.excuteTypeNameAction("旅游险");
		//填写险种编号
		AddProductAction.excuteTypeCodeAction("P120000000184");
		//选择产品明细
		AddProductAction.excuteProductDetailAction("畅行境外航意险");
		//填写面价
		AddProductAction.excuteNormalPriceAction("20");
		
		AddProductAction.excuteUpsetPriceAction("10");
		//填写“最高投保份数”-“18周岁以上（含)” 份/人
		AddProductAction.excuteAdultLimitNumAction("2");
		//填写“最高投保份数”-“18周岁以下” 份/人
		AddProductAction.excuteChildLimitNumAction("1");
		//填写“年龄限制”-“投保人”-“周岁（含）以上”
		AddProductAction.excuteInsurerMinAgeLimitAction("18");
		//填写 “年龄限制”-“被投保人”-“至”
		AddProductAction.excuteInsureeMinAgeLimitAction("1");
		//填写 “年龄限制”-“被投保人”-“周岁（含）”
		AddProductAction.excuteInsureeMaxAgeLimitAction("100");
		//选择 适用范围
		AddProductAction.excuteScopeAction("旅游;邮轮");
		
		currentDriver = new FirefoxDriver();
		LoginOperator.driver = currentDriver;
		LoginOperator.operatorLogin("yangweixing", "111111", "杨伟兴");
		currentDriver = LoginOperator.driver;
		currentDriver.get(Constant.PRODUCTMANAGEURL);
		//传递Driver
		ProductManageAction.transmitDriver(currentDriver);
		ProductManageListCheckPoint.productListCheckPoint("双十一保险", currentDriver);

		String str = "20.00元";
	}
	*/
	
	public static void main(String[] args) throws Exception{
		
		
	}
}

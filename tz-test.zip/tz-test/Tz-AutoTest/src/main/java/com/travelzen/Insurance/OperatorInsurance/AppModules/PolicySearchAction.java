package com.travelzen.Insurance.OperatorInsurance.AppModules;
/**
 * author：qiqi.wang
 * */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.Constant;
import com.travelzen.Insurance.OperatorInsurance.PageObjects.OrderDetailsPage;
import com.travelzen.Insurance.OperatorInsurance.PageObjects.PolicySearchPage;
import com.travelzen.Utility.LogCenter.Log;

public class PolicySearchAction
{
	public static WebDriver webdriver;
	
	public static void transmitDriver(WebDriver driver) throws Exception{
		webdriver = driver;
		OrderDetailsPage.getDriver(webdriver);
	} 
	
	//保单查询页面-输入保单号
	public static void excutePolicyNumInput() throws Exception{
		PolicySearchPage.getPolicyNumInputElement().sendKeys(Constant.PolicyID);
		Log.info("保单查询页面“保单号”输入框，已输入。");
	}
	
	//保单查询页面-点击查询按钮
	public static void excutePolicySearchBtn() throws Exception{
		PolicySearchPage.getPolicySearchButtonElement().click();
		Log.info("保单查询页面“搜索”按钮，已点击。");
	}
	
	//保单查询页面-获取保单状态-文本
	public static String excutePolicyState() throws Exception{
		String PolicyState = PolicySearchPage.getPolicyStateElement().getText();
		Log.info("保单查询页面“保单状态”，已获取。");
		return PolicyState;
	}
	
	//保单查询页面-保单号-文本
	public static String excutePolicyNum() throws Exception{
		String PolicyNum = PolicySearchPage.getPolicyNumElement().getText();
		Log.info("保单查询页面“保单号”，已获取。");
		return PolicyNum;
	}	
	
	//保单查询页面-订单号-文本
	public static String excuteOrderNum() throws Exception{
		String OrderNum = PolicySearchPage.getOrderNumElement().getText();
		Log.info("保单查询页面“订单号”，已获取。");
		return OrderNum;
	}
	
	//保单查询页面-被保人姓名-文本
	public static String excuteCustomerName() throws Exception{
		String CustomerName = PolicySearchPage.getCustomerNameElement().getText();
		Log.info("保单查询页面“被保人姓名”，已获取。");
		return CustomerName;
	}
	
	//保单查询页面-证件类型-文本
	public static String excuteCardStyle() throws Exception{
		String CardStyle = PolicySearchPage.getCardStyleElement().getText();
		Log.info("保单查询页面“被保人证件类型”，已获取。");
		return CardStyle;
	}		
			
	//保单查询页面-证件号码-文本
	public static String excuteCardNum() throws Exception{
		String CardNum = PolicySearchPage.getCardNumElement().getText();
		Log.info("保单查询页面“被保人证件号码”，已获取。");
		return CardNum;
	}	
			
	//保单查询页面-投保人-文本
	public static String excuteApplicantName() throws Exception{
		String ApplicantName = PolicySearchPage.getApplicantNameElement().getText();
		Log.info("保单查询页面“投保人姓名”，已获取。");
		return ApplicantName;
	}
		
	//保单查询页面-生效日期-文本
	public static String excuteInsuranceStart() throws Exception{
		String InsuranceStart = PolicySearchPage.getInsuranceStartElement().getText();
		Log.info("保单查询页面“保险生效日期”，已获取。");
		return InsuranceStart;
	}
			
	//保单查询页面-截止日期-文本
	public static String excuteInsuranceEnd() throws Exception{
		String InsuranceEnd = PolicySearchPage.getInsuranceEndElement().getText();
		Log.info("保单查询页面“保险截止日期”，已获取。");
		return InsuranceEnd;
	}

	//保单查询页面-投保日期-文本
	public static String excuteCreateOrderDate() throws Exception{
		String CreateOrderDate = PolicySearchPage.getCreateOrderDateElement().getText();
		Log.info("保单查询页面“保险截止日期”，已获取。");
		return CreateOrderDate;
	}
	
	
	
	
}

package com.travelzen.Utility.DataDriver;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*
 * Excel表格读取，填值，更改；
 * 
 * */
public class ExcelAction 
{
   private static HSSFSheet ExcelWSheet;
   private static HSSFWorkbook ExcelWBook;
   private static HSSFRow hssfRow;
   public static int excelCell;
   public static int  j;
   public static int  row;
   public static int  column;
   //filePath获取当前项目的路径定位到auto-test
   public static  String filePath = System.getProperty("user.dir");
   //创建Excel文件流并定位到固定sheet页
   public static void ExcelSheet(String Path, String SheetName) throws Exception 
   {
   try 
   {
     FileInputStream ExcelFile = new FileInputStream(Path);
     ExcelWBook = new HSSFWorkbook(ExcelFile);
     ExcelWSheet = ExcelWBook.getSheet(SheetName);  
     //获取excel表格总列数即参数个数
     hssfRow = ExcelWSheet.getRow(0);
     excelCell = hssfRow.getPhysicalNumberOfCells();
     //获取Excel表格的行数
     row = ExcelWSheet.getPhysicalNumberOfRows()-1; 
     //获取Excel表格的列数
     column = hssfRow.getPhysicalNumberOfCells();
     
   } 
   catch (Exception e)
   {
     throw (e);           
   }
 }
              
    //返回excel表格列数
    public static int excel_get_column(String excelName) throws Exception 
    {
    	String fileToBeRead = filePath +"/src/main/java/resources/"+ excelName;
    	  ExcelAction.ExcelSheet(fileToBeRead, "Sheet1");
    	  
    		return hssfRow.getPhysicalNumberOfCells();           
    	
    }
    //返回excel表格行数
    public static int excel_get_rows(String excelName) throws Exception 
    {
    	String fileToBeRead = filePath +"/src/main/java/resources/"+ excelName;
    	  ExcelAction.ExcelSheet(fileToBeRead, "Sheet1");
    	  return (ExcelWSheet.getPhysicalNumberOfRows()-1);
    	
    }

    //将表格中的文本转化为字符串
    public static String getCellDataasstring(int RowNum, int ColNum) throws Exception
    {
    	try
    	{
    		String CellData = ExcelWSheet.getRow(RowNum).getCell(ColNum).getStringCellValue();
    		return CellData;
    	}
    	catch (Exception e)
    	{
    		return "Errors in Getting Cell Data";
    	}
    }
    
 
  //将表格中String类型变为Double类型
    public static double getCellDataasnumber(int RowNum, int ColNum) throws Exception
    {
    	try
        {
          double CellData = ExcelWSheet.getRow(RowNum).getCell(ColNum).getNumericCellValue();
          System.out.println("The value of CellData " + CellData);
          return CellData;
        }
        catch (Exception e)
        {
          return 000.00;
        }
    }
    
    
    //更改参数值
    //传入excel表名、参数名称、参数值，该方法将表格中原参数值改变；
    public static void setValue(String excelName,String paramter,String value) throws Exception{
     String fileToBeRead = filePath +"/src/main/java/resources/"+ excelName; // excel位置
         ExcelAction.ExcelSheet(fileToBeRead, "Sheet1");
           for (j=0;j<excelCell;j++)
            {
             String excelValue = ExcelAction.getCellDataasstring(0, j);
             if(excelValue.equals(paramter)){
           HSSFRow row = ExcelWSheet.getRow((short) 1);
                    HSSFCell cell = row.getCell((short) j);
                    cell.setCellValue(value); 
                    break;
          }
            }
            FileOutputStream out = null;
            try {
                out = new FileOutputStream(fileToBeRead);
                ExcelWBook.write(out);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    //参数保存到指定行
    //传入excel表名、参数名称、参数值，该方法将表格中原参数值改变；
    public static void setNamedValue(int excelRow,String excelName,String paramter,String value) throws Exception{
     String fileToBeRead = filePath +"/src/main/java/resources/"+ excelName; // excel位置
         ExcelAction.ExcelSheet(fileToBeRead, "Sheet1");
           for (j=0;j<excelCell;j++)
            {
             String excelValue = ExcelAction.getCellDataasstring(0, j);
             if(excelValue.equals(paramter)){
           HSSFRow row = ExcelWSheet.getRow((short) excelRow);
                    HSSFCell cell = row.getCell((short) j);
                    cell.setCellValue(value); 
                    break;
          }
            }
            FileOutputStream out = null;
            try {
                out = new FileOutputStream(fileToBeRead);
                ExcelWBook.write(out);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    //根据参数名取对应参数的值，传入excel行数，excel表名，参数名
    public static String getValue(String excelName,String paramter) throws Exception{
     String value = null;
     String fileToBeRead = filePath +"/src/main/java/resources/"+ excelName; // excel位置
     ExcelAction.ExcelSheet(fileToBeRead, "Sheet1");
       for (j=0;j<excelCell;j++)
        {
         String excelValue = ExcelAction.getCellDataasstring(0, j);
       //  System.out.println(excelValue);
         if(excelValue.equals(paramter)){
       value= ExcelAction.getCellDataasstring(1, j);
                break;
      }
        }
     return value;	
    }
    //获取指定行的参数
    //根据参数名取对应参数的值，传入excel行数，excel表名，参数名
    public static String getNamedValue(int excelRow,String excelName,String paramter) throws Exception{
     String value = null;
     String fileToBeRead = filePath +"/src/main/java/resources/"+ excelName; // excel位置
     ExcelAction.ExcelSheet(fileToBeRead, "Sheet1");
       for (j=0;j<excelCell;j++)
        {
         String excelValue = ExcelAction.getCellDataasstring(0, j);
       //  System.out.println(excelValue);
         if(excelValue.equals(paramter)){
       value= ExcelAction.getCellDataasstring(excelRow, j);
                break;
      }
        }
     return value;	
    }
    
    //获取Excel表所有行参数
    public static Object[][] getAllRows(String excelName,int rowAll,int columnAll) throws Exception{
        String value = null;        
        String fileToBeRead = filePath +"/src/main/java/resources/"+ excelName; // excel位置
        ExcelAction.ExcelSheet(fileToBeRead, "Sheet1");
      //  System.out.println( fileToBeRead); 
       // System.out.println( rowAll); 
       // System.out.println( columnAll); 
        //创建字符串数组，保存读取的Excel表格行和列数据
        Object [][]excelData = new Object[rowAll][columnAll];
        //循环读取Excel表格数据
          for (int i=1;i<rowAll+1;i++)
           {
        	  for (int k=0;k<columnAll;k++)
        	  {
        		  excelData[i-1][k]= ExcelAction.getCellDataasstring(i, k);
        		  System.out.println(excelData[i-1][k]); 
        	  }
          //  System.out.println(excelValue);            
         }          
        return excelData;	
       }
    //获取第一行数据
    public static Object[][] getFirstRow(String excelName,int row1,int columnAll) throws Exception{
        String value = null;
        String fileToBeRead = filePath +"/src/main/java/resources/"+ excelName; // excel位置
        ExcelAction.ExcelSheet(fileToBeRead, "Sheet1");
       // System.out.println(fileToBeRead); 
        //System.out.println(columnAll); 
        //创建字符串数组，保存读取的Excel表格第一列数据
        Object[][] excelData = new Object[1][columnAll];
        //循环读取Excel表格数据
          for (int k=0;k<columnAll;k++)
           {
        	  excelData[0][k]= ExcelAction.getCellDataasstring(1, k);   
        	  System.out.println( excelData[0][k]);    
         }          
        return excelData;	
       }   
}

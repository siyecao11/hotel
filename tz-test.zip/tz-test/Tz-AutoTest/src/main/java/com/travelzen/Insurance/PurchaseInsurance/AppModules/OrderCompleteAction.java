package com.travelzen.Insurance.PurchaseInsurance.AppModules;

import org.testng.annotations.Test;

public class OrderCompleteAction {
  public void f() {
  }
}

package com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.FunctionCases;

import java.util.Arrays;
import java.util.List;

import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.*;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.utility.Constants.*;
import com.travelzen.Utility.Utils.Utils;

public class RetreatOrderOperator extends FeedTest{

	public static WebDriver driver;
	public static String orderType;
	public static String orderId;
	public static List<String> ListRC = Arrays.asList("CHANGEALL", "1");
	public static List<String> listCR = Arrays.asList("NOW_SETTLE", "2015-10-17");
	
	//从正常单获取Driver
	@Test(priority = 50, groups ={"正常单创建退订单"})
	public static void getNormalOrderDriver() throws Exception{
		
		orderType = "normal";
		driver = NormalOrderOperator.driver;
	}
	
	//从调账单获取Driver
	@Test(priority = 50, groups ={""})
	public static void getAdjustmentOrderDriver() throws Exception{
		
		orderType = "adjustment";
	//	driver = AdjustmentOrderTC.driver;
	}
	
	//从变更单获取Driver
	@Test(priority = 50, groups ={""})
	public static void getEndorseOrderDriver() throws Exception{
		
		orderType = "endorse";
		//driver = EndorseOrderTC.driver;
	}
	
	//退订单创建--审核
	@Test(priority = 51, groups ={"正常单创建退订单"})
	public static void retreatOrderId() throws Exception{
		
		//于订单列表页查找指定ID的订单（上一步骤中创建的正常订单）
		//并跳转到订单详情页
		//判断是在哪类订单基础上做退订
		if(orderType.equals("normal")){
			
			orderId = Constant.NormalOrderId;
		}else if(orderType.equals("endorse")){
			
			orderId = Constant.EndorseOrderId;
		}else if(orderType.equals("adjustment")){
			
			orderId = Constant.adjustmentOrderId;
		}
	}
	
	//于订单列表页查找指定ID的订单（上一步骤中创建的订单）
	//并跳转到订单详情页
	@Test(priority = 52, groups ={"正常单创建退订单"})
	public static void OrderDetail() throws Exception{
		//跳转到订单列表页
		driver.get(Constant.orderManageURL);
		Thread.sleep(2000);
		OrderManageOrderListAction.transmitDriver(driver);
		//根据订单ID查询出订单，点击进入订单详情页
		OrderManageOrderListAction.OrderIdInput(Constant.TempId);
		Thread.sleep(2000);
		OrderManageOrderListAction.SearchOrder();
		Thread.sleep(2000);
		OrderManageOrderListAction.OrderClick();
		Thread.sleep(2000);
	}
	//创建退订单，
	@Test(priority = 53, groups ={"正常单创建退订单"})
	public static void retreatOrderCreate() throws Exception {

		Utils.waitForElement(5, driver, "page");
		OrderManageNormalOrderCompleteAction.transmitDriver(driver);

		// 点击创建退订单
		OrderManageNormalOrderCompleteAction.CreatRetreatOrder();
		// 选择支付全部房费
		OrderManageNormalOrderCompleteAction.excute_select_RetreatCondition(ListRC);
		// 保存退订条件
		OrderManageNormalOrderCompleteAction.excute_Save_RetreatCondition();
		//传递浏览器
		Utils.waitForElement(5, driver, "page");
		OrderManageRetreatOrderCreatAction.transmitDriver(driver);
		// 跳转到CreatRetreat页面，创建退订单
		OrderManageRetreatOrderCreatAction.excute_RetreatCreat_Link();
		Thread.sleep(2000);
		// 跳转到CreatRetreat页面，获取退订单号
		Constant.TempId = OrderManageRetreatOrderCreatAction.excute_RetreatCreat_id();
		System.out.println("TempId value "+ Constant.TempId);
		Thread.sleep(2000);

	}
	
	//于订单列表页查找指定ID的订单（上一步骤中创建的订单）
	//并跳转到订单详情页
	@Test(priority = 54, groups ={"正常单退订单确认"})
	public static void retreatOrderDetail() throws Exception{
		//跳转到订单列表页
		driver.get(Constant.orderManageURL);
		Thread.sleep(2000);
		OrderManageOrderListAction.transmitDriver(driver);
		//根据订单ID查询出订单，点击进入订单详情页
		OrderManageOrderListAction.OrderIdInput(Constant.TempId);
		Thread.sleep(2000);
		OrderManageOrderListAction.SearchOrder();
		Thread.sleep(2000);
		OrderManageOrderListAction.OrderClick();
		Thread.sleep(2000);
	}
	
	//确认退订 -- 退订审核：酒店确认码&&结算提醒设置
	@Test(priority = 55, groups ={"正常单退订单确认"})
	public static void retreatOrderAuditOrderCodeSettle() throws Exception{

		OrderManageAuditOrderAction.transmitDriver(driver);
		// 跳转到审核页面，退订单审核
		OrderManageAuditOrderAction.excute_ConfirmBooking_Link();
		// 选择酒店有确认码，
		OrderManageAuditOrderAction.excute_ConfirmID1("ComfiemID");
		// 保存酒店确认信息
		OrderManageAuditOrderAction.excute_Save_ConfirmID();
		// 选择结算方式为现结方式
		OrderManageAuditOrderAction.excute_NOW_SETTLE(listCR);
		// 保存酒店结算方式
		OrderManageAuditOrderAction.excute_Save_Count();
	}
	
	//取消退订 
	@Test(priority = 55, groups ={"正常单退订单取消"})
	public static void  retreatOrderAuditOrderCancle() throws Exception{

		Utils.waitForElement(5, driver, "page");
		// 审核 调账单Driver传递
		OrderManageRetreatOrderAuditAction.transmitDriver(driver);
		OrderManageRetreatOrderAuditAction.excut_Cancel_RetreatOrder_Click();
		Thread.sleep(2000);
		OrderManageRetreatOrderAuditAction.excuteCancelRemark();
		Thread.sleep(2000);
		OrderManageRetreatOrderAuditAction.excuteCancelOrderSave();
		Thread.sleep(2000);
	}
	
}

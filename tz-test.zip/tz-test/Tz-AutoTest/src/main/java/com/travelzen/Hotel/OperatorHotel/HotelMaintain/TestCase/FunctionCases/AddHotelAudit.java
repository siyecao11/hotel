package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.FunctionCases;

import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import com.travelzen.Utility.Utils.*;
import com.travelzen.Utility.Constants.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.*;

public class AddHotelAudit extends FeedTest{

	public static WebDriver currentDriver;
	
	//TestCase中的每一个Function都可以为其做一张参数表
	//对我们需要输入的值参数化
	
	//酒店提交后审核
	//酒店提交审核后，绝大多数情况下再酒店维护页的酒店列表中，是位列第一条数据的
	//此处选择审核的也是酒店列表中的第一条数据
	//可能存在需要审核和选择的酒店不一致的情况
	@Test(priority = 10)
	public static void auditHotelAudit() throws Exception {

		currentDriver = AddHotelDailyRate.currentDriver;
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainHomeAction.transmitDriver(currentDriver);
		//选择目标酒店，点击进入酒店信息维护页
		HotelMaintainHomeAction.executeSelectHotelIndex();
		Thread.sleep(2000);
	}
	
	//酒店审核通过
	@Test(priority = 12)
	public static void auditAuditPass() throws Exception {

		Utils.waitForElement(5, currentDriver, "page");
		// 因为是新开页面，所以需要切换窗口
		// 获取当前页面句柄
		String handle = currentDriver.getWindowHandle();
		// 获取所有页面的句柄，并循环判断不是当前的句柄，就做选取switchTo()
        for (String handles : currentDriver.getWindowHandles()) 
        {
			if (handles.equals(handle))
				continue;
			currentDriver.switchTo().window(handles);
		}
		HoetlMaintainAuditAction.transmitDriver(currentDriver);
		//选择目标酒店，点击进入酒店信息维护页
		HoetlMaintainAuditAction.excuteAuditPass();
		Thread.sleep(3000);
		currentDriver.close();
		//酒店审核上线完成后，等待5min进入酒店查询模块
	}
	
	//酒店审核驳回
	@Test(priority = 13)
	public static void auditAuditFailed() throws Exception {

		Utils.waitForElement(5, currentDriver, "page");
		// 因为是新开页面，所以需要切换窗口
		// 获取当前页面句柄
		String handle = currentDriver.getWindowHandle();
		// 获取所有页面的句柄，并循环判断不是当前的句柄，就做选取switchTo()
        for (String handles : currentDriver.getWindowHandles()) 
        {
			if (handles.equals(handle))
				continue;
			currentDriver.switchTo().window(handles);
		}
		HoetlMaintainAuditAction.transmitDriver(currentDriver);
		//选择目标酒店，点击进入酒店信息维护页
		//审核失败
		HoetlMaintainAuditAction.excuteAuditFailed();
		Thread.sleep(3000);
		HotelMaintainHomeAction.transmitDriver(currentDriver);
		//选择目标酒店，点击进入酒店信息维护页,重新提交审核
		HotelMaintainHomeAction.executeSelectHotelIndex();
		Thread.sleep(2000);
		//提交审核
		//页面的“通过”和“提交”元素实际为同一元素，所以使用“通过”的方法
		auditAuditPass();
		Thread.sleep(3000);
		HoetlMaintainAuditAction.transmitDriver(currentDriver);
		//选择目标酒店，点击进入酒店信息维护页,重新提交审核
		HotelMaintainHomeAction.executeSelectHotelIndex();
		Thread.sleep(2000);
		//审核通过
		auditAuditPass();
	}
	
	//酒店 挂起 操作
	@Test(priority = 14)
	public static void Guaqi(String hotelName) throws Exception{
		
		//输入需要 挂起的酒店
		HotelMaintainHomeAction.excuteHotelNameTextBox(hotelName);
		HotelMaintainHomeAction.executeSearchHotel();
		//选中需要 挂起的酒店
		Thread.sleep(3000);
		HotelMaintainHomeAction.excuteHotelCheckBox();
		//挂起酒店
		Thread.sleep(2000);
		HotelMaintainHomeAction.excuteGuaqiButton();
		Thread.sleep(2000);
		HotelMaintainHomeAction.excuteGuaqiConfirmBtn();
		Thread.sleep(2000);
	}
	
	//酒店 解挂 操作
	@Test(priority = 15)
	public static void Jiegua(String hotelName) throws Exception{
		
		//输入需要 解挂的酒店
		HotelMaintainHomeAction.excuteHotelNameTextBox(hotelName);
		HotelMaintainHomeAction.executeSearchHotel();
		//选中需要 解挂的酒店
		Thread.sleep(3000);
		HotelMaintainHomeAction.excuteHotelCheckBox();
		//解挂酒店
		Thread.sleep(2000);
		HotelMaintainHomeAction.excuteJieguaButton();
		
		Thread.sleep(3000);
		HotelMaintainHomeAction.excuteJieguaConfirmBtn();
	}
	
	@Test(priority = 16)
	public static void quiteDriver() throws Exception{
		
		//退出当前driver
		currentDriver.quit();
	}
}

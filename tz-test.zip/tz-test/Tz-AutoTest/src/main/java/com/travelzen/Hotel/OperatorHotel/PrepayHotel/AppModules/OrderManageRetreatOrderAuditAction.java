package com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;
import com.travelzen.Utility.LogCenter.Log;

public class OrderManageRetreatOrderAuditAction {


	// private static Select oselection;

	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {

		OrderManageRetreatOrderAuditPage.getWebDriver(driver);
	}
	// *********************点击--确认退订 Action***********************
	//
	@Test
	public static void excut_Confirm_RetreatOrder_Click() throws Exception {

		OrderManageRetreatOrderAuditPage.getConfirm_RetreatOrder_Link().click();
	}

	// *********************点击--取消退订 Action***********************
	//
	@Test
	public static void excut_Cancel_RetreatOrder_Click() throws Exception {

		OrderManageRetreatOrderAuditPage.getCancel_RetreatOrder_Link().click();
	}
	
	//  "取消退订原因" Action
	@Test
	public static void excuteCancelRemark() throws Exception {
		
		OrderManageRetreatOrderAuditPage.getCancelRemarkElement().sendKeys("退订错误，取消退订");
		Log.info("CancelRemark btn is clicked");
	}
	
	//  "取消退订原因" 保存 Action
	@Test
	public static void excuteCancelOrderSave() throws Exception {
		
		OrderManageRetreatOrderAuditPage.getCancelOrderSaveElement().click();
		Log.info("CancelOrderSaveElement is clicked");
	}
}

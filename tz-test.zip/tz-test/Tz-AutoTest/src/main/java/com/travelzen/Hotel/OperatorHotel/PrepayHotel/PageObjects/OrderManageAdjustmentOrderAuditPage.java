package com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.travelzen.Utility.LogCenter.*;

public class OrderManageAdjustmentOrderAuditPage {
  
	public static WebDriver driver;
	private static WebElement element;
	
	@Test
	public static void getWebDriver(WebDriver webdriver) {
		
		driver = webdriver;
		
	}
	
	//调账单 审核页面
	//Location "确认调账" btn元素
	@Test
	public static WebElement getAdjustmentOrderConfirmBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("adjustment_operator_confirm_order"));
			Log.info("AdjustmentOrderConfirmBtn elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("AdjustmentOrderConfirmBtn elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "取消调账" btn元素
	@Test
	public static WebElement getAdjustmentOrderCancleBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("adjustment_operator_cancel_order"));
			Log.info("AdjustmentOrderCancleBtn elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("AdjustmentOrderCancleBtn elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "修改订单" btn元素
	@Test
	public static WebElement getAdjustmentOrderModifyBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("adjustment_operator_modify_order"));
			Log.info("AdjustmentOrderModifyBtn elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("AdjustmentOrderModifyBtn elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "挂账金额" 输入框元素
	@Test
	public static WebElement getSettleOrderFeeYuanElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("settleOrderFeeYuan"));
			Log.info("settleOrderFeeYuan elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("settleOrderFeeYuan elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "挂账备注" 输入框元素
	@Test
	public static WebElement getSettleRemarkElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("settleRemark"));
			Log.info("settleRemark elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("settleRemark elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "留账金额" 编辑btn元素
	//触发留账相关信息编辑框
	@Test
	public static WebElement getLiuZhangElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("span[class='btn_liuzhang_edit']"));
			Log.info("LiuZhang elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("LiuZhang elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "留账金额" -- 留账金额  输入框元素
	@Test
	public static WebElement getResFeeForPopElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("resFeeForPop"));
			Log.info("resFeeForPop elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("resFeeForPop elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "留账金额" -- 酒店/供应商确认人 元素
	@Test
	public static WebElement getResContactForPopElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("resContactForPop"));
			Log.info("resContactForPop elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("resContactForPop elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "留账金额" -- 留账有效期  元素
	//触发时间插件显示时间显示框
	@Test
	public static WebElement getResValidDateForPopElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("resValidDateForPop"));
			Log.info("resValidDateForPop elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("resValidDateForPop elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "留账金额" -- 留账有效期  -- 时间插件 元素
	@Test
	public static WebElement getTimeElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/div[2]/table/tbody/tr[5]/td/a"));
			Log.info("time elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("time elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "留账金额" -- 备注  元素
	@Test
	public static WebElement getResRemarkForPopElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("resRemarkForPop"));
			Log.info("resRemarkForPop elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("resRemarkForPop elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "留账金额" -- 确定保存Btn  元素
	@Test
	public static WebElement getConfirmReservationBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("confirmReservationBtn"));
			Log.info("confirmReservationBtn elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("confirmReservationBtn elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "留账金额" -- 取消保存Btn  元素
	@Test
	public static WebElement getCancleReservationBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[class='button_2_2 close']"));
			Log.info("CancleReservationBtn elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("CancleReservationBtn elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location "留账金额" -- 留账保存后，核对本单挂账提醒  元素
	@Test
	public static WebElement getComformSettlementElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("comformSettlement"));
			Log.info("comformSettlement elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("comformSettlement elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location 删除留账信息 “删除”  元素
	@Test
	public static WebElement getResDeleteBtnElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("resDeleteBtn"));
			Log.info("resDeleteBtn elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("resDeleteBtn elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location 取消调账--取消原因  元素
	@Test
	public static WebElement getCancelRemarkElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("cancelRemark"));
			Log.info("cancelRemark elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("cancelRemark elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
	
	//Location 取消调账--取消--保存 元素
	@Test
	public static WebElement getCancelOrderSaveElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("cancelOrderWindow_save"));
			Log.info("cancelOrderWindow_save elements is found in AuditAdjustmentOrder Page");
		}catch (Exception e){
			Log.error("cancelOrderWindow_save elements is not found in AuditAdjustmentOrder Page");
		}
		return element;
	}
}

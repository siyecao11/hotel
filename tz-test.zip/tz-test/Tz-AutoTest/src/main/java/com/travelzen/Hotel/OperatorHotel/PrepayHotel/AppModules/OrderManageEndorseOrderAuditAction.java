package com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.Log;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;
/*
 * 变更单审核界面控制层
 * */
public class OrderManageEndorseOrderAuditAction {

	public static List<WebElement> elementList;
	public static void transmitDriver(WebDriver driver) throws Exception{
		OrderManageEndorseOrderAuditPage.getDriver(driver);
		}
	
	//点击确认变更按钮
	public static void confirmEndrose() throws Exception{
		OrderManageEndorseOrderAuditPage.getConfirmEndroseButton().click();
		Log.info("************ConfirmEndroseButton is clicked ****************");
	}
	
	//点击取消变更按钮
	public static void cancelEndrose() throws Exception{
		OrderManageEndorseOrderAuditPage.getCancelEndroseButton().click();
		Log.info("************CancelEndroseButton is clicked ****************");
	}
	
	//点击修改订单按钮
	public static void modifyEndrose() throws Exception{
		OrderManageEndorseOrderAuditPage.getModifyEndroseButton().click();
		Log.info("************ModifyEndroseButton is clicked ****************");
	}
	
	//  "取消便更原因" Action
	@Test
	public static void excuteCancelRemark() throws Exception {
		
		OrderManageEndorseOrderAuditPage.getCancelRemarkElement().sendKeys("便更错误，取消便更");
		Log.info("CancelRemark btn is clicked");
	}
	
	//  "取消便更原因" 保存 Action
	@Test
	public static void excuteCancelOrderSave() throws Exception {
		
		OrderManageEndorseOrderAuditPage.getCancelOrderSaveElement().click();
		Log.info("CancelOrderSaveElement is clicked");
	}
	
	public static void excute_ConfirmBooking_Link() throws Exception {

		OrderManageNormalOrderAuditPage.getConfirmBooking_Link().click();
	}

	// ******************************酒店确认码 弹层Action Start  ************************************

	// 选择 是否需要酒店预订码：1为需要，0为不需要
	// 选择并输入预定条件
	@Test
	public static void excute_input_ConfirmID(List<String> list)
			throws Exception {

		// 选择预定要求，bookingRequirement
		// element = elementList.get(0).getAttribute("value")
		switch (list.get(0)) {
		case "1":
			excute_ConfirmID1(list.get(1));
			break;
		case "0":
			excute_ConfirmID2();
			break;

		}

	}

	// 需要酒店确认码：
	@Test
	public static void excute_ConfirmID1(String string) throws Exception {

		elementList = OrderManageNormalOrderAuditPage.getConfirmBooking_ConfirmID1();

		elementList.get(0).click();
		elementList.get(1).clear();
		elementList.get(1).sendKeys(string);
		Log.info("ConfirmBooking_ConfirmID has been input");
	}

	// 不需要酒店确认码
	@Test
	public static void excute_ConfirmID2() throws Exception {

		OrderManageNormalOrderAuditPage.getConfirmBooking_ConfirmID2().click();
		Log.info("ConfirmBooking NO ConfirmID has been select");

	}

	// 保存酒店确认码信息
	@Test
	public static void excute_Save_ConfirmID() throws Exception {
		OrderManageNormalOrderAuditPage.getConfirmBooking_Save().click();
		Log.info("ConfirmID has been saved");

	}

	// ******************************酒店确认码 弹层Action End   ************************************

	// *****************************结算修改提醒 弹层Action Start ***********************************

	// 选择并输入结算条件：现结(需要选择具体时间：上午Or下午)、周结、半月结、月结
	@Test
	public static void excute_change_CountReminder(List<String> stringList)
			throws Exception {
		// 选择预定要求，bookingRequirement
		// element = elementList.get(0).getAttribute("value")

		switch (stringList.get(0)) {
		case "NOW_SETTLE":
			excute_NOW_SETTLE(stringList);
			break;
		case "WEEK_SETTLE":
			excute_WEEK_SETTLE();
			break;
		case "HALF_MONTH_SETTLE":
			excute_HALF_MONTH_SETTLE();
			break;
		case "MONTH_SETTLE":
			excute_MONTH_SETTLE();
			break;

		}

	}

	// 现结方式
	// 上午、下午时间是默认的，该选项没有写入传值
	@Test
	public static void excute_NOW_SETTLE(List<String> stringList)
			throws Exception {

		 elementList = OrderManageNormalOrderAuditPage.getCount_NOW_SETTLE();

		// elementList.get(0).click();
		Log.info(elementList.size() + "elementList size");
		for (int i = 1; i < elementList.size(); i++) {
			if (i == 1)
				elementList.get(i).clear();
			elementList.get(i).sendKeys(stringList.get(i));
		}
		elementList.get(0).click();
		Log.info("NOW_SETTLE has been select");
	}

	// 周结方式
	@Test
	public static void excute_WEEK_SETTLE() throws Exception {

		OrderManageNormalOrderAuditPage.getCount_WEEK_SETTLE().click();
		Log.info("WEEK_SETTLE has been select");

	}

	// 半月结方式
	@Test
	public static void excute_HALF_MONTH_SETTLE() throws Exception {

		OrderManageNormalOrderAuditPage.getCount_HALF_MONTH_SETTLE().click();
		Log.info("HALF_MONTH_SETTLE has been select");

	}

	// 月结方式
	@Test
	public static void excute_MONTH_SETTLE() throws Exception {

		OrderManageNormalOrderAuditPage.getCount_MONTH_SETTLE().click();
		Log.info("MONTH_SETTLE  has been select");

	}

	// 保存酒店结算方式
	@Test
	public static void excute_Save_Count() throws Exception {
		OrderManageNormalOrderAuditPage.getCount_Save().click();
		Log.info("Count Reminder has been saved");

	}
	
	
	
	
	
	
	
	
}

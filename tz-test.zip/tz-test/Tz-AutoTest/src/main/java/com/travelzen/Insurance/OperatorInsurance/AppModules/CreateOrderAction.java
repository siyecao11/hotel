package com.travelzen.Insurance.OperatorInsurance.AppModules;
/**
 * author:qiqi.wang
 * */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.CreateOrderPage;
import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.Constant;
import com.travelzen.Utility.LogCenter.Log;

public class CreateOrderAction
{
	public static WebDriver webdriver;
	
	public static void transmitDriver(WebDriver driver) throws Exception{
		webdriver = driver;
		CreateOrderPage.getDriver(webdriver);
	}
	
	//创建订单页面-弹出客户窗口-点击按钮
	public static void excuteCustomerNameBtn() throws Exception{
		try{
			CreateOrderPage.getCustomerNamebuttonElement().click();
			Log.info("创建订单页面“弹出客户窗口”按钮元素，已点击。");
		}catch(Exception e){
			Log.error("创建订单页面“弹出客户窗口”按钮元素，未点击。");
		}
	}
	
	//创建订单页面-输入客户简称-输入
	public static void excuteCustomerShortNameInput(String CustomerName) throws Exception{
		try{
			CreateOrderPage.getCustomerShortNameInputElement().sendKeys(CustomerName);
			Log.info("创建订单页面“客户简称”，已输入。");
		}catch (Exception e){
			Log.error("创建订单页面“客户简称”，未输入。");
		}
	}
	
	//创建订单页面-搜索客户-点击按钮
	public static void excuteCustomerSearchBtn() throws Exception{
		try{
			CreateOrderPage.getCustomerSearchButtonElement().click();
			Log.info("创建订单页面“搜索客户”按钮，已点击。");
		}catch (Exception e){
			Log.error("创建订单页面“搜索客户”按钮，未点击。");
		}
	}
	
	//创建订单页面-选择客户-点击客户名称
	public static void excuteCustomerSelect() throws Exception{
		try{
			CreateOrderPage.getCustomerSelectElement().click();
			Log.info("创建订单页面“选择客户”，已点击。");
		}catch (Exception e){
			Log.error("创建订单页面“选择客户”，未点击。");
		}
	}
	
	//创建订单页面-选择保险覆盖范围-点击单选按钮
	public static void excuteInsuranceCoverageSelect(String InsuranceCoverage)throws Exception{
		try{
			CreateOrderPage.getInsuranceCoverageElement(InsuranceCoverage).click();
			Log.info("创建订单页面“保险覆盖范围”，已选择。");
		}catch(Exception e){
			Log.error("创建订单页面“保险覆盖范围”，未选择。");
		}
	}
	
	//创建订单页面-搜索保险产品-点击按钮
	public static void excuteInsuranceProductSearchBtn() throws Exception{
		try{
			CreateOrderPage.getProductSearchButtonElement().click();
			Log.info("创建订单页面“查询产品”，已点击。");
		}catch (Exception e){
			Log.error("创建订单页面“查询产品”，未点击。");
		}
	}
	
	//创建订单页面-选择保险产品-点击选择
	public static void excuteInsuranceProductSelect(String ProductName)throws Exception{
		try{
			CreateOrderPage.getInsuranceProductElement(ProductName).click();
			Log.info("创建订单页面“产品选择”，已选择。");
		}catch(Exception e){
			Log.error("创建订单页面“产品选择”，未选择。");
		}
	}
	
	//创建订单页面-选择被保人数-点击选择
	public static void excuteInsurancePersonNumSelect(String PersonNum) throws Exception{
		try{
			Select personNum = new Select(CreateOrderPage.getInsurancePersonNumSelectElement());
			personNum.selectByValue(PersonNum);
			Log.info("创建订单页面“被保人数”，已选择。");
		}catch(Exception e){
			Log.error("创建订单页面“被保人数”，未选择。");
		}
	}
	
	//创建订单页面-保险生效日期-点击选择
	public static void excuteInsuranceStartDate(String StartDate)throws Exception{
		try{
			CreateOrderPage.getInsuranceStartDateElement().sendKeys(StartDate);
			Log.info("创建订单页面“保险生效日期”，已选择。");
		}catch(Exception e){
			Log.error("创建订单页面“保险生效日期”，未选择。");
		}
	}
	
	//创建订单页面-被保人姓名-输入
	public static void excuteCustomerNameInput(String CustomerName) throws Exception{
		try{
			CreateOrderPage.getCustomerNameInputElement().sendKeys(CustomerName);
			Log.info("创建订单页面“被保人姓名”，已输入。");
		}catch(Exception e){
			Log.error("创建订单页面“被保人姓名”，未输入");
		}
	}
	
	//创建订单页面-被保人手机号-输入
	public static void excuteCustomerMobileInput(String CustomerMobile) throws Exception{
		try{
			CreateOrderPage.getCustomerMobileInputElement().sendKeys(CustomerMobile);
			Log.info("创建订单页面“被保人手机”，已输入。");
		}catch(Exception e){
			Log.error("创建订单页面“被保人手机”，未输入");
		}
	}
	
	//创建订单页面-选择被保人证件类型-点击选择
		public static void excuteIDTypeSelect(String IDType) throws Exception{
			try{
				Select IdType = new Select(CreateOrderPage.getIDTypeSelectElement());
				IdType.selectByVisibleText(IDType);
				Log.info("创建订单页面“被保人证件类型”，已选择。");
			}catch(Exception e){
				Log.error("创建订单页面“被保人证件类型”，未选择。");
			}
		}
	
	//创建订单页面-被保人证件号码-输入
		public static void excuteIDNumInput(String IDNum) throws Exception{
			try{
				CreateOrderPage.getIDNumInputElement().sendKeys(IDNum);
				Log.info("创建订单页面“被保人证件号码”，已输入。");
			}catch(Exception e){
				Log.error("创建订单页面“被保人证件号码”，未输入");
			}
		}
	
	//创建订单页面-被保人出生日期-输入
		public static void excuteBirthDateInput(String BirthDate) throws Exception{
			try{
				CreateOrderPage.getBirthDateInputElement().sendKeys(BirthDate);
				Log.info("创建订单页面“被保人出生日期”，已输入。");
			}catch(Exception e){
				Log.error("创建订单页面“被保人出生日期”，未输入");
			}
		}
	
	//创建订单页面-被保人性别-选择
		public static void excuteSexTypeSelect(String Sex) throws Exception{
			try{
				Select oSelect = new Select(CreateOrderPage.getSexTypeSelectElement());
				oSelect.selectByVisibleText(Sex);
				Log.info("创建订单页面“被保人性别”，已选择。");
			}catch(Exception e){
				Log.error("创建订单页面“被保人性别”，未选择。");
			}
		}
	
	//创建订单页面-保险份数-选择
		public static void excuteInsuranceNumSelect(String InsuranceNum) throws Exception{
			try{
				Select oSelect = new Select(CreateOrderPage.getInsuranceNumSelectElement());
				oSelect.selectByValue(InsuranceNum);
				Log.info("创建订单页面“保险份数”，已选择。");
			}catch(Exception e){
				Log.error("创建订单页面“保险份数”，未选择。");
			}
		}
		
	//创建订单页面-保存订单-按钮
		public static void excuteSaveOrderBtn() throws Exception{
			try{
				CreateOrderPage.getSaveOrderButtonElement().click();
				Log.info("创建订单页面“保存订单”，已点击。");
			}catch(Exception e){
				Log.error("创建订单页面“保存订单”，未点击 ");
			}
		}
		
	//创建订单页面-提交订单-按钮
		public static void excuteSubmitOrderBtn() throws Exception{
			try{
				CreateOrderPage.getSubmitOrderButtonElement().click();
				Log.info("创建订单页面“提交订单”，已点击。");
			}catch (Exception e){
				Log.error("创建订单页面“提交订单”，未点击。");
			}
		}
	//创建订单页面-获取联系人姓名
		public static void excuteConstactName() throws Exception{
			try{
				String ConstactName = CreateOrderPage.getContactNameElement().getText();
				Constant.ConstactName = ConstactName;
				Log.info("创建订单页面“联系人姓名”，已获取。");
			}catch (Exception e){
				Log.error("创建订单页面“联系人姓名”，未获取。");
			}
		}
	//创建订单页面-获取联系人电话
		public static void excuteConstactTel() throws Exception{
			try{
				String ConstactTel = CreateOrderPage.getContactTelElement().getText();
				Constant.ConstactTel = ConstactTel;
				Log.info("创建订单页面“联系人电话”，已获取。");
			}catch (Exception e){
				Log.error("创建订单页面“联系人电话”，未获取。");
			}
		}
	
	//创建订单页面-获取联系人手机
		public static void excuteConstactMobile() throws Exception{
			try{
				String ConstactMobile = CreateOrderPage.getContactMobilElement().getText();
				Constant.ConstactMobile = ConstactMobile;
				Log.info("创建订单页面“联系人手机”，已获取。");
			}catch (Exception e){
				Log.error("创建订单页面“联系人手机”，未获取。");
			}
		}
	
	
	
}

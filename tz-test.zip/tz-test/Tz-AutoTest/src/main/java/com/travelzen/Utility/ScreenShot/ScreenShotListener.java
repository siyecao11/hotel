package com.travelzen.Utility.ScreenShot;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import org.testng.TestRunner;

import com.travelzen.Utility.Constants.Constants;
/*
 * 监听器：脚本运行失败截图功能；
 * 注意： 1.需要在每个testcase的beforeMethod方法中将driver传入公共driver中，即Constants.classDriver = driver;
 *      2.需要在每个testcase的test方法之前加上监听方法的索引即：@Listeners({com.travelzen.Utility.ScreenShot.ScreenShotListener.class});
 * 
 * */
public class ScreenShotListener  extends TestListenerAdapter {
	private static Logger logger = Logger.getLogger(TestRunner.class);
	public static final String CONFIG = "config.properties";
	
	@Override
	public void onTestFailure(ITestResult tr) {
		super.onTestFailure(tr);
		logger.info(tr.getName() + " Failure");
		screenShot();
	}

	@Override
	public void onTestSkipped(ITestResult tr) {
		super.onTestSkipped(tr);  
		screenShot();
	}

	@Override
	public void onTestSuccess(ITestResult tr) {
		super.onTestSuccess(tr);
	}

	@Override
	public void onTestStart(ITestResult tr) {
		super.onTestStart(tr);
	}

	@Override
	public void onFinish(ITestContext testContext) {
		super.onFinish(testContext);
	}

	public static void screenShot() {
	    String dir_name = "screenshot";  // 这里定义了截图存放目录名
	    if (!(new File(dir_name).isDirectory())) {  // 判断是否存在该目录
	        new File(dir_name).mkdir();  // 如果不存在则新建一个目录
	    }
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd-HHmmss");
	    String time = sdf.format(new Date());  // 这里格式化当前时间，例如20160406-165210
	    try {
	    	System.out.println(Constants.classDriver);
	        File source_file =((TakesScreenshot) Constants.classDriver).getScreenshotAs(OutputType.FILE);  // 关键代码，执行屏幕截图，默认会把截图保存到temp目录
	        FileUtils.copyFile(source_file, new File(dir_name + File.separator + time + ".png"));  // 这里将截图另存到我们需要保存的目录，例如screenshot\20120406-165210.png
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
}

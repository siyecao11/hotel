package com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules;

import java.util.List;
import java.util.Random;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.travelzen.Utility.Utils.Utils;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.utility.Constants.*;
import com.travelzen.Utility.LogCenter.Log;


public class HotelMaintainDailyRateAction {

	private static WebDriver webdriver;
	private static List<WebElement> eList;
	private static WebElement element;
	public static String sDate;
	private static Random random = new Random();
	// 生成1~6和1~10的两个随机数
	private static int a = random.nextInt(6);
	private static int b = random.nextInt(6);
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		webdriver = driver;
		HotelMaintainDailyRatePage.getWebDriver(webdriver);
	}
	
	//选择房型Action
	@Test
	public static void excuteSelectRoomCat(String roomCatID) throws Exception{
		
		HotelMaintainDailyRatePage.getAllRoomCat().selectByValue(roomCatID);
		Log.info(roomCatID + "room is selected");
	}
	
	//修改礼包Action
	@Test
	public static void excuteModifyGifPackage() throws Exception{
		
		HotelMaintainDailyRatePage.getModifyGifPackageElement().click();
		Log.info("ModifyGiftPackage btn is clicked, edit gift package");
	}
	
	//下一页Action
	@Test
	public static void excuteNextPage() throws Exception{
		
		HotelMaintainDailyRatePage.getNextPage().click();
		Log.info("nextPage_ btn is clicked");
	}
		
	//删除礼包Action
	@Test
	public static void excuteDeleteGifPackage() throws Exception{
		
		HotelMaintainDailyRatePage.getDeleteGifPackageElement().click();
		Log.info("DeleteGiftPackage btn is clicked, delete gift package");
	}
	
	//**********************************房型 “修改礼包” 内容Action  Start  ******************************
	
	// 添加礼包 -- 选择价格计划
	@Test
	public static void excuteSelectBookingClass() throws Exception{
		
		HotelMaintainDailyRatePage.getSelectBookingClassElement().click();
		Log.info("SelectBookingClass checkbox is clicked");
	}
	
	// 添加礼包 -- 起始有效期
	@Test
	public static void excuteStartDate() throws Exception{
		
		element = HotelMaintainDailyRatePage.getStartDate();
		element.click();
		Thread.sleep(2000);
/*		JavascriptExecutor jsExecutor = (JavascriptExecutor)webdriver;
		//执行JS, 先定义出需要去除readonly属性的元素，然后移除属性readonly
		String id = "package_add_start_date_" + Constant.roomId;
		String js ="var sid =" + id +";var setDate=document.getElementById(sid);setDate.removeAttribute('readonly');";
		jsExecutor.executeScript(js);
		//往已移除readonly属性元素中写值
		element.clear();
		element.sendKeys("2015-08-25");*/
		HotelMaintainDailyRatePage.getStartDateTime().click();
	}
	
	// 添加礼包 -- 截止有效期
	@Test
	public static void excuteEndDate() throws Exception{
		
		HotelMaintainDailyRatePage.getEndDate().click();
		Thread.sleep(2000);
/*		element = HotelMaintainDailyRatePage.getStartDate();
		JavascriptExecutor jsExecutor = (JavascriptExecutor)webdriver;
		//执行JS, 先定义出需要去除readonly属性的元素，然后移除属性readonly
		String id = "package_add_end_date_" + Constant.roomId;
		jsExecutor.executeScript("var setDate=document.getElementById(" + id + ");setDate.removeAttribute('readonly');");
		//往已移除readonly属性元素中写值
		element.clear();
		element.sendKeys("2015-11-25");*/
		HotelMaintainDailyRatePage.getEndDateTime();
	}
	
	// 添加礼包 -- 添加有效期Btn
	@Test
	public static void excuteAddTimeBtn() throws Exception{
		
		HotelMaintainDailyRatePage.getAddTimeBtnElement().click();
		Log.info("AddTimeBtn button is clicked");
	}
	
	// 添加礼包 -- 赠送方式（每间房赠送一次 、每间房每晚）
	//此处仅定位返回 每间房每晚 的类型
	@Test
	public static void excutePresentType() throws Exception{
		
		HotelMaintainDailyRatePage.getPresentTypeElement().click();
		Log.info("PresentType is selected");
	}
	
	// 添加礼包 -- 礼包内容编辑框
	@Test
	public static void excuteGiftPackageContent(String pContent) throws Exception{
		
		HotelMaintainDailyRatePage.getGiftPackageContentElement().sendKeys(pContent);;
		Log.info("GiftPackageContent is writed");
	}
	
	// 添加礼包 -- 保存添加礼包信息
	@Test
	public static void excuteAddGiftPackageConfirmBtn() throws Exception{
		
		HotelMaintainDailyRatePage.getAddGiftPackageConfirmBtnElement().click();;;
		Log.info("AddGiftPackageConfirmBtn is clicked, gift package info is saved");
	}
	
	//**********************************房型 “修改礼包” 内容Action  End   ******************************
	
	//修改房型的每日价格信息按钮 Action
	@Test
	public static void excuteModifyDailyRate() throws Exception{
		
		HotelMaintainDailyRatePage.getModifyDailyRateElement().click();
		Log.info("ModifyDailyRate btn is clicked, ready to modify DailyRate");
	}
	
	//修改房型的每日价格&&规定后 	 “保存”Action
	@Test
	public static void excuteModifyDailyRateElement_Save() throws Exception{
		
		HotelMaintainDailyRatePage.getModifyDailyRateElement_Save().click();
		Log.info("ModifyDailyRate Save btn is clicked, edit Saved");
	}
	
	//修改房型的每日价格&&规定后 	 “取消”Action
	@Test
	public static void excuteModifyDailyRateElement_Cancle() throws Exception{
		
		HotelMaintainDailyRatePage.getModifyDailyRateElement_Cancle().click();
		Log.info("ModifyDailyRate Save btn is clicked, edit Cancled");
	}
	
	//修改房型的每日	“价格” DailyPrice Action
	@Test
	public static void excuteDailyPriceContainerEdit(String newValue) throws Exception{
		
		eList = HotelMaintainDailyRatePage.getDailyPriceContainerEdit();
		//在每个房型对应展示的7天价格中，选择任意1天修改价格
		for(int i=0; i<eList.size(); i++)
		{
			if(a == i){
				Utils.waitForElement(3, webdriver, "script");
				eList.get(i).clear();
				eList.get(i).sendKeys(newValue);
				sDate = eList.get(i).getAttribute("date").toString();
			}
		}
		Log.info("Edit DailyPrice");
	}
	
	//指定日期的DailyRate中的价格 -- 底价
	@Test
	public static String excuteBaseFeeInDay(String sdate, String roomId) throws Exception{
		String date = "";
		String value = "";
		while(value.equals(""))
		{	
			excuteSelectRoomCat(roomId);
			Thread.sleep(2000);
			eList = HotelMaintainDailyRatePage.getDailyPriceContainerEdit();
			for(int i=0; i<eList.size(); i++)
			{
				date = eList.get(i).getAttribute("date").toString();
				if(date.equals(sdate))
				{
					value = eList.get(i).getAttribute("value").toString();
					break;
				}
			}
			HotelMaintainDailyRatePage.getNextPage().click();
			Thread.sleep(2000);
		}
		return value;
	}
	
	//修改房型的每日	“规定” DailyRule Action
	@Test
	public static void excuteDailyPriceContainerRule() throws Exception{
		
		eList = HotelMaintainDailyRatePage.getDailyPriceRule();
		//在每个房型对应展示的7天价格中，选择任意2天(与每日修改的价格中一致)的规定
		//JavascriptExecutor js = (JavascriptExecutor) webdriver;
		
		for(int i=0; i<eList.size(); i++)
		{
			if(a == i){
				eList.get(i).click();
				//js.executeScript("arguments[0].click();", eList.get(i));
				
			}
		}
	}
	
	//******************************房型 “每日规定” 内容 Action********************************
	
	//Action “包含服务” -> “宽带” 点击
	@Test
	public static void excuteDailyRule_Broadband() throws Exception{
		
		HotelMaintainDailyRatePage.getDailyRule_Broadband(sDate).click();
		Log.info("DailyRule_Broadband is clicked");
	}

	// Action “包含服务” ->“早餐” 选择
	@Test
	public static void excuteDailyRule_BreakFast(String breakFastNum) throws Exception {

		HotelMaintainDailyRatePage.getDailyRule_BreakFast().selectByValue(breakFastNum);
		Log.info("DailyRule_BreakFast is Selected");
	}

	// Action “礼包信息” -> “删除礼包” 点击 （如果每日规则中含有礼包信息，则可以调用改方法）
	@Test
	public static void excuteDailyRule_PackageInfoDel() throws Exception {

		HotelMaintainDailyRatePage.getDailyRule_PackageInfoDel().click();
		Log.info("DailyRule_PackageInfoDel is clicked");
	}

	// Action  “增加规定” -> “入住时间” 选择
	@Test
	public static void excuteDailyRule_CheckInTime(String checkInTime) throws Exception {

		HotelMaintainDailyRatePage.getDailyRule_CheckInTime(sDate).selectByValue(checkInTime);
		Log.info("DailyRule_CheckInTime is Selected");
	}
	
	// Action  “增加规定” -> “退房时间” 选择
	@Test
	public static void excuteDailyRule_CheckOutTime(String checkOutTime) throws Exception {

		HotelMaintainDailyRatePage.getDailyRule_CheckOutTime(sDate).selectByValue(checkOutTime);
		Log.info("DailyRule_CheckOutTime is Selected");
	}
	
	// Action  “增加规定” -> “入住前” “ 天 ” 传值
	@Test
	public static void excuteDailyRule_CheckInDay(String checkInDay) throws Exception {

		HotelMaintainDailyRatePage.getDailyRule_CheckInDay(sDate).clear();
		HotelMaintainDailyRatePage.getDailyRule_CheckInDay(sDate).sendKeys(checkInDay);
		Log.info("DailyRule_CheckInDay value is send");
	}	
	
	// Action  “增加规定” -> “入住前” “ 点 ” 传值
	@Test
	public static void excuteDailyRule_CheckInPoint(String checkInPoint) throws Exception {

		HotelMaintainDailyRatePage.getDailyRule_CheckInPoint(sDate).clear();
		HotelMaintainDailyRatePage.getDailyRule_CheckInPoint(sDate).sendKeys(checkInPoint);
		Log.info("DailyRule_CheckInPoint value is send");
	}
	
	// Action  “增加规定” -> “扣除房费”规则  选择
	@Test
	public static void excuteDailyRule_CancleTerm(String cancleTerm) throws Exception {

		HotelMaintainDailyRatePage.getDailyRule_CancleTerm(sDate).selectByValue(cancleTerm);
		Log.info("DailyRule_CancleTerm is Selected");
	}
	
	// Action  “增加规定” -> “删除原规定” 点击 
	//需要先删除原有的规定内容，才能添加新的规定内容
	@Test
	public static void excuteDailyRule_DelNewTerm() throws Exception {

		HotelMaintainDailyRatePage.getDailyRule_DelNewTerm(sDate).click();
		Log.info("DailyRule_DelNewTerm is clicked");
	}
	
	// Action  “增加规定” -> “添加”Btn 点击 
	@Test
	public static void excuteDailyRule_AddRulebtn() throws Exception {

		HotelMaintainDailyRatePage.getDailyRule_AddRulebtn(sDate).click();
		Log.info("DailyRule_AddRulebtn is clicked");
	}

	// Action  “确定”Btn 点击 （保存修改）
	@Test
	public static void excuteDailyRule_SaveRuleEdit() throws Exception {

		HotelMaintainDailyRatePage.getDailyRule_SaveRuleEdit(sDate).click();
		Log.info("DailyRule_SaveRuleEdit is clicked");
	}
	
	// Action  “取消”Btn 点击 （取消修改）
	@Test
	public static void excuteDailyRule_CancleRuleEdit() throws Exception {

		HotelMaintainDailyRatePage.getDailyRule_CancleRuleEdit(sDate).click();
		Log.info("DailyRule_CancleRuleEdit is clicked");
	}
	
	//***************************************	EDN	 ***************************************
	
	//******************************每日价格信息修改 “变价原因” Action********************************
	// Action  修改 ->变价 “变价原因”传值 
	@Test
	public static void excuteModifyDailyRateElement_Save_PriceChangeCauses() throws Exception {
		
		HotelMaintainDailyRatePage.getModifyDailyRateElement_SavePriceChangeCauses().clear();
		System.out.println("TTTTTTTTTTTTT");
		HotelMaintainDailyRatePage.getModifyDailyRateElement_SavePriceChangeCauses().sendKeys("Test Chang Save");
		Log.info("ModifyDailyRateElement_Save_PriceChangeCauses is edited");
	}
	
	// Action  修改 ->变价“确定”Btn 点击 
	@Test
	public static void excuteDailyRateElement_Save_PriceChangeCauses_Save() throws Exception {

		HotelMaintainDailyRatePage.getDailyRateElement_Save_PriceChangeCauses_Save().click();
		Log.info("ModifyDailyRateElement_Save_PriceChangeCauses_Save is clicked");
	}
	
	// Action  修改 ->变价“取消”Btn 点击 
	@Test
	public static void excuteDailyRateElement_Save_PriceChangeCauses_Cancle() throws Exception {
		
		Thread.sleep(2000);
		HotelMaintainDailyRatePage.getDailyRateElement_Save_PriceChangeCauses_Cancle().click();
		Log.info("ModifyDailyRateElement_Save_PriceChangeCauses_Cancle is clicked");
	}
	
	//***************************************	EDN	 ***************************************
}

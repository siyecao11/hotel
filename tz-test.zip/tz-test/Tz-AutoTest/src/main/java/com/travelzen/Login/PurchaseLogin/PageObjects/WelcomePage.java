package com.travelzen.Login.PurchaseLogin.PageObjects;

import org.testng.annotations.Test;
import org.openqa.selenium.*;

import com.travelzen.Utility.LogCenter.Log;


public class WelcomePage extends BaseClass{
	private static WebElement element;
	public static WebDriver driver;

	@Test
	public static void getWebDriver(WebDriver webdriver) throws Exception {

		driver = webdriver;
	}
	
	public WelcomePage(WebDriver driver){
		super(driver);
	}

	// get Hotel menuItem element
	@Test
	public static WebElement getHotelMenu() throws Exception {
		try {
			Log.info("Login Successfully, "+driver+" Entering into HomePage...");
			element = driver.findElement(By.xpath("html/body/div[3]/header/nav/ul/li[4]/a"));
			Log.info("Hotel Menu item is found on the Wlecome Page");
		} catch (Exception e) {
			Log.error("********Hotel Menu item is not found on the Wlecome Page********");
		}
		return element;
	}

	// get DomesticFlight menuItem element
	@Test
	public static WebElement getDomesticFlightMenu() throws Exception {
		try {
			element = driver.findElement(By.cssSelector("a[item='国内机票']"));
			Log.info("DomesticFlight Menu item is found on the Wlecome Page");
		} catch (Exception e) {
			Log.error("********DomesticFlight Menu item is not found on the Wlecome Page********");
		}
		return element;
	}
	
	// get InternationalFlight menuItem element
	@Test
	public static WebElement getInternationalFlightMenu() throws Exception {
		try {
			element = driver.findElement(By.cssSelector("a[item='国际机票']"));
			Log.info("InternationalFlight Menu item is found on the Wlecome Page");
		} catch (Exception e) {
			Log.error("********InternationalFlight Menu item is not found on the Wlecome Page********");
		}
		return element;
	}

	// get Additional menuItem element
	@Test
	public static WebElement getAdditionalMenu() throws Exception {
		try {
			element = driver.findElement(By.cssSelector("a[item='保险']"));
			Log.info("Additional Menu item is found on the Wlecome Page");
		} catch (Exception e) {
			Log.error("********Additional Menu item is not found on the Wlecome Page********");
		}
		return element;
	}
	
}

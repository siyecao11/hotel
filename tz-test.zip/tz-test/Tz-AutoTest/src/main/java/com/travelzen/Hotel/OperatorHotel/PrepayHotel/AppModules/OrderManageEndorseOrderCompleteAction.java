package com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules;

import org.openqa.selenium.WebDriver;
import com.travelzen.Utility.LogCenter.Log;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;
/*
 * 变更单完成页面控制层
 * */
public class OrderManageEndorseOrderCompleteAction {

	public static void transmitDriver(WebDriver driver) throws Exception{
		OrderManageEndorseOrderCompletePage.getDriver(driver);
	} 
	//变更单完成页面--创建变更单
	public static void createEndorseOrder() throws Exception{
		OrderManageEndorseOrderCompletePage.creatEndorseOrder().click();
		Log.info("EndorseOrder is clicked in the EndorseOrder Complete Page.");
	}
	//变更单完成页面--创建调账单
	public static void createAdjustmentOrder() throws Exception{
		OrderManageEndorseOrderCompletePage.creatAdjustmentOrder().click();
		Log.info("AdjustmentOrder is clicked in the EndorseOrder Complete Page.");
	}
	//变更单完成页面--创建退订单
	public static void creatRetreatOrder() throws Exception{
		OrderManageEndorseOrderCompletePage.creatRetreatOrder().click();
		Log.info("RetreatOrder is clicked in the EndorseOrder Complete Page.");
	}
	
	
}

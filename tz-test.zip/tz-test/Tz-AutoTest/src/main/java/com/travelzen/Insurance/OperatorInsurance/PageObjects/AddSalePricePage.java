package com.travelzen.Insurance.OperatorInsurance.PageObjects;

import org.cyberneko.html.HTMLElements.ElementList;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.travelzen.Utility.LogCenter.Log;

import java.util.List;

/**
 * 
 * @author changhui.hu
 * 
 */

public class AddSalePricePage {

	public static WebDriver driver;
	private static WebElement element;
	public static List<WebElement> elementList;
	//number用于标记售价列表的第几行记录
	public static int number=1;

	// 获取当前页面的driver
	public static void getDriver(WebDriver webDriver) {
		driver = webDriver;
	}

	// 获取新建售价页面的提交按钮元素
	public static WebElement getSubmitAddElement() throws Exception {
		try {
			element = driver.findElement(By.id("submitAddButton"));
			Log.info("新建售价页面的提交按钮元素已找到");
		} catch (Exception e) {
			Log.error("新建售价页面的提交按钮元素未找到");
		}
		return element;
	}

	// 获取新建售价页面的返回按钮元素
	public static WebElement getReturnElement() throws Exception {
		try {
			element = driver.findElement(By
					.cssSelector("button[class='btns btn-return']"));
			Log.info("新建售价页面的返回按钮元素已找到");
		} catch (Exception e) {
			Log.error("新建售价页面的返回按钮元素未找到");
		}
		return element;
	}

	// 获取新建售价页面单选框的元素
	public static WebElement getRadioButtonElement() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='addSalePriceForm']/div[1]/table/tbody/tr[1]/td[1]/input"));
			Log.info("新建售价页面单选框的元素已找到");
		} catch (Exception e) {
			Log.error("新建售价页面单选框的元素未找到");
		}
		return element;
	}

	// 获取新建售价页面,通过产品名称 定位某条指定产品
	// 产品名称
	public static WebElement getInsuPriceElements(String productName) throws Exception {
		try {
			elementList = driver.findElements(By.cssSelector("td[class='f-td']"));
			int length = elementList.size();
			for (int i = 0; i < length; i++) {
				if (elementList.get(i).getText().equals(productName)) {
					element = elementList.get(i);
					number=i+1;
					break;
				} else {
					continue;
				}
			}
			Log.info("新建售价页面产品名称的元素已找到");
		} catch (Exception e) {
			Log.error("新建售价页面产品名称的元素未找到");
		}
		return element;
	}

	//获取保险产品列表信息
	//险种编号
	public static WebElement getInsnumberElement() throws Exception{
		try{
			element=driver.findElement(By.xpath(".//*[@id='addSalePriceForm']/div[1]/table/tbody/tr["+number+"]"+"/td[3]"));
			Log.info("新建售价页面的险种编号的元素已找到");
		}catch(Exception e){
			Log.error("新建售价页面的险种编号的元素未找到");
		}
		return element;
	}
	
	//获取保险产品列表信息
	//险种名称
	public static WebElement getInsNameElement() throws Exception{
		try{
			element=driver.findElement(By.xpath(".//*[@id='addSalePriceForm']/div[1]/table/tbody/tr["+number+"]"+"/td[4]"));
			Log.info("新建售价页面的保险名称的元素已找到");
		}catch(Exception e){
			Log.error("新建售价页面的保险名称的元素未找到");
		}
		return element;
	}
	
	//获取保险产品列表信息
	//保险期限
	public static WebElement getInsLimitedElement() throws Exception{
		try{
			element=driver.findElement(By.xpath(".//*[@id='addSalePriceForm']/div[1]/table/tbody/tr["+number+"]"+"/td[5]"));
			Log.info("新建售价页面的保险期限的元素已找到");
		}catch(Exception e){
			Log.error("新建售价页面的保险期限的元素未找到");
		}
		return element;
	}
	
	//获取保险产品列表信息
	//最高保额（元）
	public static WebElement getMixPriceElement() throws Exception{
		try{
			element=driver.findElement(By.xpath(".//*[@id='addSalePriceForm']/div[1]/table/tbody/tr["+number+"]"+"/td[6]"));
			Log.info("新建售价页面的最高保额的元素已找到");
		}catch(Exception e){
			Log.error("新建售价页面的最高保额的元素未找到");
		}
		return element;
	}
	
	//获取保险产品列表信息
	//面价
	public static WebElement getTopPriceElement() throws Exception{
		try{
			element=driver.findElement(By.xpath(".//*[@id='addSalePriceForm']/div[1]/table/tbody/tr["+number+"]"+"/td[7]"));
			Log.info("新建售价页面的面价的元素已找到");
		}catch(Exception e){
			Log.error("新建售价页面面价的元素未找到");
		}
		return element;
	}
	
	//获取保险产品列表信息
	//保险费用
	public static WebElement getInsPriceElement() throws Exception{
		try{
			element=driver.findElement(By.xpath(".//*[@id='addSalePriceForm']/div[1]/table/tbody/tr["+number+"]"+"/td[8]"));
			Log.info("新建售价页面的保险费用的元素已找到");
		}catch(Exception e){
			Log.error("新建售价页面的保险费用元素未找到");
		}
		return element;
	}
	
	//获取保险产品列表信息
	//适用范围
	public static WebElement getUseWideElement() throws Exception{
		try{
			element=driver.findElement(By.xpath(".//*[@id='addSalePriceForm']/div[1]/table/tbody/tr["+number+"]"+"/td[9]"));
			Log.info("新建售价页面的适用范围的元素已找到");
		}catch(Exception e){
			Log.error("新建售价页面的适用范围元素未找到");
		}
		return element;
	}
	
	//获取保险产品列表信息
	//操作
	public static WebElement getOperateElement() throws Exception{
		try{
			element=driver.findElement(By.xpath(".//*[@id='addSalePriceForm']/div[1]/table/tbody/tr["+number+"]"+"/td[10]/a"));
			Log.info("新建售价页面的操作的元素已找到");
		}catch(Exception e){
			Log.error("新建售价页面的操作元素未找到");
		}
		return element;
	}
	
	// 获取新建售价页面中加价额元素
	public static WebElement getAddpriceTextElement() throws Exception {
		try {
			element = driver.findElement(By.id("add_price_txt"));
			Log.info("新建售价页面中加价额元素已找到");
		} catch (Exception e) {
			Log.error("新建售价页面中加价额元素未找到");
		}
		return element;
	}

	// 获取新建售价页面中加价按钮元素
	public static WebElement getAddPriceButtoneElement() throws Exception {
		try {
			element = driver.findElement(By.id("add_price_btn"));
			Log.info("新建售价页面中加价按钮元素已找到");
		} catch (Exception e) {
			Log.error("新建售价页面中加价按钮元素未找到");
		}
		return element;
	}

	// 获取新建售价页面中客户组元素
	public static WebElement getCustomGroupElementElement(String custom) throws Exception{
		try{
		elementList=driver.findElements(By.className("customerGroup_ckbox"));
		int n=elementList.size();
		for(int i=0;i<n;i++){
			if(elementList.get(i).getText().equals(custom)){
				element=elementList.get(i);
				break;
			}else {
				continue;
			}
		}
		Log.info("新建售价页面中客户组元素已找到");
	}catch(Exception e){
		Log.error("新建售价页面中客户组元素未找到");
	}
		return element;
	}
	
}

package com.travelzen.Insurance.OperatorInsurance.AppModules;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.AddProductPage;
import com.travelzen.Utility.LogCenter.Log;

/**
 * 添加保险产品页面 元素Action
 * @author Weixing.Yang
 *
 */
public class AddProductAction {

	private static WebDriver webDriver;
	
	//枚举：产品明细对应的16中产品类型 + 产品适用范围
	//Radio对象，页面中共有16个，value属性值为001~016
	//分别对应：太平明细 、太平洋明细 、泰康明细 、平安明细 、平安电子明细 、平安30元 、平安40元 、美亚畅游神州 
	//美亚万国游踪、人保邮轮 、美亚乐悠悠、 安盛卓越亚洲行 、人保境外旅游险 、平安境内旅游险 、平安境内旅游险 、畅行境内航意险
	//国内机票、国际机票、旅游、邮轮、自由行
	public enum ProductDetail{
		
		TP("太平明细", "001"), TPY("太平洋明细","002"), TK("泰康明细","003"), PA("平安明细","004"), PADZ("平安电子明细","005"), PA30("平安30元","006"),
		PA40("平安40元","007"), MYXY("美亚畅游神州","008"), MYWG("美亚万国游踪","009"), RB("人保邮轮","010"), MYLYY("美亚乐悠悠","011"), ASZY("安盛卓越亚洲行","012"),
		RBJW("人保境外旅游险","013"), PAJN("平安境内旅游险","014"), CXJW("畅行境外航意险","015"), CXJN("畅行境内航意险","016"),
		GNJP("国内机票","DOMESTIC_INSURANCE"), GJJP("国际机票","INTERNATIONAL_INSURANCE"), LY("旅游","TRAVEL_INSURANCE"), YL("邮轮","CRUISE_INSURANCE"), ZYX("自由行","FREEDRIVING_INSURANCE");
        // 成员变量
        private String name;
        private String index;

        // 构造方法
        private ProductDetail(String name, String index) {
            this.name = name;
            this.index = index;
        }

        //通过index去name
        public static String getName(String index) {
        	
            for (ProductDetail p : ProductDetail.values()) {
                if (p.getIndex().equals(index)) {
                    return p.name;
                }
            }
            return null;
        }
        
        //通过name取index
        public static String getIndex(String name) {
        	
            for (ProductDetail p : ProductDetail.values()) {
                if (p.getName().equals(name)) {
                    return p.index;
                }
            }
            return null;
        }

        // get set 方法
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIndex() {
            return index;
        }

        public void setIndex(String index) {
            this.index = index;
        }
	}
	
	//传递当前Driver
	public static void transmitDriver(WebDriver driver) throws Exception{
		
		webDriver = driver;
		AddProductPage.getDriver(webDriver);
	}
	
	//新增产品页面中，点击  “提交” 按钮
	public static void excuteSubmitAddButtonAction() throws Exception{
		
		AddProductPage.getSubmitAddButtonElement().click();
		Log.info("点击  “提交” 按钮");
	}
	
	//新增产品页面中，点击  “返回” 按钮
	public static void excuteReturnButtonAction() throws Exception{
		
		AddProductPage.getReturnButtonElement().click();
		Log.info("点击  “返回” 按钮");
	}
	
	//新增产品页面中，“产品名称” 字段输入值
	public static void excuteProductNameAction(String productName) throws Exception{
		
		AddProductPage.getProductNameElement().clear();
		AddProductPage.getProductNameElement().sendKeys(productName);
		Log.info("“产品名称” 字段输入值: " + productName);
	}
	
	//新增产品页面中，“保险公司名称” 字段值选择
	public static void excuteCompanyNameAction(String companyName) throws Exception{
		
		JavascriptExecutor jsExecutor = (JavascriptExecutor)webDriver;
		//去除隐藏select的display的none属性
		jsExecutor.executeScript("var setDate=document.getElementsByName(\"companyName\")[0];setDate.removeAttribute('style');");
		//设置selected option的值
		//AddProductPage.getCompanyNameElement().selectByValue(companyName);
		AddProductPage.getCompanyNameElement().selectByVisibleText(companyName);
		Log.info("“保险公司名称” 字段值选择: " + companyName);
	}
	
	//新增产品页面中，“保险期限” 字段输入值
	public static void excuteDeadlineAction(String deadline) throws Exception{
		
		AddProductPage.getDeadlineElement().clear();
		AddProductPage.getDeadlineElement().sendKeys(deadline);
		Log.info("“保险期限” 字段输入值: " + deadline);
	}
	
	//新增产品页面中，“最高保额” 字段输入值
	public static void excuteInsuranceAmountAction(String insuranceAmount) throws Exception{
		
		AddProductPage.getInsuranceAmountElement().clear();
		AddProductPage.getInsuranceAmountElement().sendKeys(insuranceAmount);
		Log.info("“最高保额” 字段输入值: " + insuranceAmount);
	}
	
	//新增产品页面中，“保险险种” 字段值选择
	public static void excuteTypeNameAction(String typeName) throws Exception{
		
		JavascriptExecutor jsExecutor = (JavascriptExecutor)webDriver;
		//去除隐藏select的display的none属性
		jsExecutor.executeScript("var setDate=document.getElementsByName(\"typeName\")[0];setDate.removeAttribute('style');");
		//设置selected option的值
		//AddProductPage.getTypeNameElement().selectByValue(typeName);
		AddProductPage.getTypeNameElement().selectByVisibleText(typeName);
		Log.info("“保险险种” 字段值选择: " + typeName);
	}
	
	//新增产品页面中，“险种编号” 字段输入值
	public static void excuteTypeCodeAction(String typeCode) throws Exception{
		
		AddProductPage.getTypeCodeElement().clear();
		AddProductPage.getTypeCodeElement().sendKeys(typeCode);
		Log.info("“险种编号” 字段输入值: " + typeCode);
	}
	
	//新增产品页面中，“产品明细” 字段值选择
	//Radio对象，页面中共有16个，value属性值为001~016
	//分别对应：太平明细 、太平洋明细 、泰康明细 、平安明细 、平安电子明细 、平安30元 、平安40元 、美亚畅游神州 
	//美亚万国游踪、人保邮轮 、美亚乐悠悠、 安盛卓越亚洲行 、人保境外旅游险 、平安境内旅游险 、畅行境外航意险 、畅行境内航意险
	//参数productDetail为产品对应明细，如：“泰康明细 ”
	public static void excuteProductDetailAction(String productDetail) throws Exception{
		
		int index = Integer.parseInt(ProductDetail.getIndex(productDetail));
		AddProductPage.getProductDetailElement().get(index-1).click();
		Log.info("“产品明细” 字段值选择: " + productDetail);
	}
	
	//新增产品页面中，“面价” 字段输入值
	public static void excuteNormalPriceAction(String normalPrice) throws Exception{
		
		AddProductPage.getNormalPriceElement().clear();
		AddProductPage.getNormalPriceElement().sendKeys(normalPrice);
		Log.info("“面价” 字段输入值: " + normalPrice);
	}
	
	//新增产品页面中，“底价” 字段输入值
	public static void excuteUpsetPriceAction(String upsetPrice) throws Exception{
		
		AddProductPage.getUpsetPriceElement().clear();
		AddProductPage.getUpsetPriceElement().sendKeys(upsetPrice);
		Log.info("“底价” 字段输入值: " + upsetPrice);
	}
	
	//新增产品页面中， “最高投保份数”-“18周岁以上（含)” 字段输入值
	public static void excuteAdultLimitNumAction(String adultLimitNum) throws Exception{
		
		AddProductPage.getAdultLimitNumElement().clear();
		AddProductPage.getAdultLimitNumElement().sendKeys(adultLimitNum);
		Log.info(" “最高投保份数”-“18周岁以上（含)” 字段输入值: " + adultLimitNum);
	}
	
	//新增产品页面中， “最高投保份数”-“18周岁以下” 字段输入值
	public static void excuteChildLimitNumAction(String childLimitNum) throws Exception{
		
		AddProductPage.getChildLimitNumElement().clear();
		AddProductPage.getChildLimitNumElement().sendKeys(childLimitNum);
		Log.info("“最高投保份数”-“18周岁以下” 字段输入值: " + childLimitNum);
	}
	
	//新增产品页面中， “年龄限制”-“投保人”-“周岁（含）以上” 字段输入值
	public static void excuteInsurerMinAgeLimitAction(String insurerMinAgeLimit) throws Exception{
		
		AddProductPage.getInsurerMinAgeLimitElement().clear();
		AddProductPage.getInsurerMinAgeLimitElement().sendKeys(insurerMinAgeLimit);
		Log.info("“年龄限制”-“投保人”-“周岁（含）以上” 字段输入值: " + insurerMinAgeLimit);
	}
	
	//新增产品页面中， “年龄限制”-“被投保人”-“至” 字段输入值
	public static void excuteInsureeMinAgeLimitAction(String insureeMinAgeLimit) throws Exception{
		
		AddProductPage.getInsureeMinAgeLimitElement().clear();
		AddProductPage.getInsureeMinAgeLimitElement().sendKeys(insureeMinAgeLimit);
		Log.info("“年龄限制”-“被投保人”-“至” 字段输入值: " + insureeMinAgeLimit);
	}
	
	//新增产品页面中， “年龄限制”-“被投保人”-“周岁（含）”  字段输入值
	public static void excuteInsureeMaxAgeLimitAction(String insureeMaxAgeLimit) throws Exception{
		
		AddProductPage.getInsureeMaxAgeLimitElement().clear();
		AddProductPage.getInsureeMaxAgeLimitElement().sendKeys(insureeMaxAgeLimit);
		Log.info("“年龄限制”-“被投保人”-“周岁（含）” 字段输入值: " + insureeMaxAgeLimit);
	}
	
	//新增产品页面中, “适用范围” 字段值选择
	//checkbox对象，页面中共有5个，value属性值为DOMESTIC_INSURANCE、INTERNATIONAL_INSURANCE、TRAVEL_INSURANCE、CRUISE_INSURANCE、FREEDRIVING_INSURANCE
	//分别对应：国内机票 、国际机票 、旅游 、邮轮、自由行
	//参数scope为使用范围项，如："旅游;自由行;邮轮"（约定参数中的不同内容用“;”隔开）
	public static void excuteScopeAction(String scope) throws Exception{
		
		String[] array = new String[10];
		//分隔出参数中的不同内容
		array = scope.split(";");
		//取枚举ProductDetail中所有的对象内容
		ProductDetail[] p = ProductDetail.values();
		//获取AddProductPage.getScopeElement()返回的list大小
		int length = AddProductPage.getScopeElement().size();
		//循环遍历枚举中的值name与参数中传入的值相等，取对应的index
		//跟进index操作选中那选元素
		for(int i=0; i<array.length; i++)
		{
			for (ProductDetail pd : p) {
				if(pd.name.equals(array[i])){
					for(int j=0; j<length; j++){
						
						if(AddProductPage.getScopeElement().get(j).getAttribute("value").equals(pd.index)){
							//匹配上的checkbox点击
							AddProductPage.getScopeElement().get(j).click();
						}
					}
				}
			}
		}
		Log.info("“适用范围” 字段值选择: " + scope);
	}
}

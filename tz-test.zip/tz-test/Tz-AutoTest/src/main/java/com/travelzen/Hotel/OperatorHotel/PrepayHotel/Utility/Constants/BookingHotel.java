package com.travelzen.Hotel.OperatorHotel.PrepayHotel.Utility.Constants;

public class BookingHotel {

	//酒店查询预订URL
	public static final String searchHotelURL = "http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/booking/search";
	//酒店订单管理URL
	public static final String orderManageURL = "http://order.hotel.op3.tdxinfo.com/tops-front-operator-hotel-order/order/hotel/hotelSearch";
	//酒店维护URL
	public static final String hotelMaintainURL = "http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/maintain/search";
	//酒店售价维护URL
	public static final String salePricyURL = "http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/salesPolicy/search/goSearch";
	//酒店报表URL
	public static final String hotelReportURL = "http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/report/search";
	//酒店产品维护URL
	public static final String productMaintainURL = "http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/product/gta/gotoSetting";
	//酒店基本信息维护URL
	public static final String addHotelIndexURL = "/tops-front-operator-hotel/hotel/operator/add?hotelId=";
	//GTA订单管理页面
	public static final String gtaHotelOrderManageURL = "http://order.hotel.op3.tdxinfo.com/tops-front-operator-hotel-order/order/hotel/gta/GTAHotelOrderSearch";
	
	//酒店详情页面URL需要在拼接酒店ID
	//酒店详情--酒店信息页面URL
	public static final String hotelInfoURL = "http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/add?hotelId=";
	//酒店详情--供应商信息页面URL
	public static final String hotelProviderInfoURL = "http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/contract/getContract?hotelId=";
	//酒店详情--酒店房型页面URL
	public static final String hotelRoomCatURL = "http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/roomCat/getRoomCat?hotelId=";
	//酒店详情--价格计划页面URL
	public static final String hotelBookingClassURL = "http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/bookingClass/list?hotelId=";
	//酒店详情--酒店库存与房态页面URL
	public static final String hotelRoomAllotURL = "http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/roomAllot/gotoRoomAllot?hotelId=";
	//酒店详情--每日价格页面URL
	public static final String hotelDailyRateURL = "http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/roomDailyRate/gotoDailyRate?hotelId=";
	
	//酒店ID
	public static String hotelId="54378b27e4b00231855c1f78";
	//房型ID
	public static String roomId="5437925fe4b00231855c1f8b";
	//价格计划ID
	public static String bookingClassId="55e020bfe4b00c7a69014ae0";
	//预订按钮ID
	//public static String bookHotelId="54cb57a5e4b0a15d9dca0afb_54cb585ce4b0a15d9dca0b0f_54cb58a8e4b0a15d9dca0b1b";
	public static String bookHotelId=BookingHotel.hotelId+'_'+BookingHotel.roomId+'_'+BookingHotel.bookingClassId;
	//正常单ID
	public static String NormalOrderId;
	//变更单ID
	public static String EndorseOrderId;
	//调账单ID
	public static String adjustmentOrderId = "";
	//退订单
	public static String RetreatOrderId;
	//现付酒店预订酒店常量定义
	//现付酒店ID
	public static String cashHotelId="40101025";
	//现付酒店房型ID
	public static String cashRoomId="1007";
	//现付酒店价格计划ID ${(ratePlan.guarantee?string)!}','${(ratePlan.amount)!}','${(ratePlan.startTime)!}','${(ratePlan.endTime)!}
	public static String cashBookingClassId="8164";
	//现付酒店价格计划ID
	public static String cashGuaranteestring="";
	//现付酒店价格计划ID
	public static String cashGuaranteeAmount="";
	//现付酒店价格计划ID
	public static String cashGuaranteeStartTime="";
	//现付酒店价格计划ID
	public static String cashGuaranteeEndTime="";
	//现付酒店预订按钮ID
	public static String cashbookHotelId=BookingHotel.cashHotelId+','+BookingHotel.cashRoomId+','+BookingHotel.cashRoomId+','+BookingHotel.cashBookingClassId+','+BookingHotel.cashGuaranteestring+','+BookingHotel.cashGuaranteeAmount+','+BookingHotel.cashGuaranteeStartTime+','+BookingHotel.cashGuaranteeEndTime;
	
	public static String ployicId = "699";
	
}

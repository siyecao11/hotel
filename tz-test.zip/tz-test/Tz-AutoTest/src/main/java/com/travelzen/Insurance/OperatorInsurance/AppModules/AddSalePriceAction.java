package com.travelzen.Insurance.OperatorInsurance.AppModules;

import java.sql.Driver;

import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.AddSalePricePage;
import com.travelzen.Utility.LogCenter.Log;

/**
 * 
 * @author changhui.hu
 *
 */

public class AddSalePriceAction {
	public static WebDriver webDriver;
	
	//传递当前driver
	public static void transmitdriver(WebDriver driver) throws Exception{
		webDriver=driver;
		AddSalePricePage.getDriver(webDriver);
	}
	
	//新增售价页面，点击“提交”按钮
	public static void excuteSubmitButtonAction() throws Exception{
		AddSalePricePage.getSubmitAddElement().click();
		Log.info("点击提交按钮");
	}
	
	//新增售价页面，点击“返回”按钮
	public static void excuteReturnButtonAction() throws Exception{
		AddSalePricePage.getReturnElement().click();
	}
	
	//新增售价页面，点击“单选框”按钮
	public static void excuteRadioButtonAction() throws Exception{
		AddSalePricePage.getRadioButtonElement().click();
	}
	
	//新增售价页面，输入加价值
	public static void excuteAddpriceText() throws Exception{
		AddSalePricePage.getAddpriceTextElement().clear();
//		AddSalePricePage.getAddPriceButtoneElement().sendKeys(String productName);
	}
	
	
	
	
	

}

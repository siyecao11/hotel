package com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.FunctionCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.databene.feed4testng.FeedTest;

import com.travelzen.Login.OperatorLogin.AppModules.MenuItemAction;
import com.travelzen.Login.OperatorLogin.TestCase.FunctionCases.LoginOperator;
import com.travelzen.Utility.ScreenShot.RetryFail;
import com.travelzen.Utility.Constants.*;

@Listeners({ com.travelzen.Utility.ScreenShot.ScreenShotListener.class,
		com.travelzen.Utility.ScreenShot.RetryListener.class })
public class PointSearchHotel extends FeedTest {

	public static WebDriver driver;

	@BeforeClass(alwaysRun = true)
	public static void beforeClass() {
		driver = LoginOperator.driver;
	}

	@BeforeMethod(alwaysRun = true)
	public static void beforeMethod() {
		Constants.classDriver = driver;
	}

	@Test(retryAnalyzer = RetryFail.class, priority = 6, groups = { "进入酒店业务模块", "正常单审核确认","正常单审核取消","正常单创建","预付酒店查询" })
	public static void pointSearchHotel() throws Exception {
		// enter into hotel HomePage
		MenuItemAction.transmitDriver(driver);
		MenuItemAction.excuteHotel();

	}

}

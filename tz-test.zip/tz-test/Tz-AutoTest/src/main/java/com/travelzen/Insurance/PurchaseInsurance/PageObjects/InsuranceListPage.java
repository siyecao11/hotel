package com.travelzen.Insurance.PurchaseInsurance.PageObjects;

import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.*;

public class InsuranceListPage {

	private static WebElement element;
	private static List<WebElement> elementList;
	public static WebDriver driver;
	public static Select select;
	public static String option;
	public static String insuranceId;

	/*
	 * author xuemei.ren date 07/01/2016
	 */
	public static void getDriver(WebDriver webdriver) throws Exception {
		driver = webdriver;
	}
	// 打开保险链接

	// 产品列表页面--所有保险产品--elementList
	public static List<WebElement> getInsuranceProductListElement() throws Exception {
		try {
			elementList = driver.findElements(By.className("insuranceType"));
			Log.info("保险产品元素在产品列表页面");
		} catch (Exception e) {
			Log.error("保险产品元素不在产品列表页面");
		}
		return elementList;
	}

	// 产品列表页面--保险名称--text
	public static WebElement getInsuranceNameElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[3]/div[" + number + "]/div[2]/table/tbody/tr[1]/td/span[1]"));
			Log.info("保险名称元素在产品列表页面");
		} catch (Exception e) {
			Log.error("保险名称元素不在产品列表页面");
		}
		return element;
	}

	// 产品列表页面--适用范围--text
	public static WebElement getInsuranceApplicationElement(String number) throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[3]/div[" + number + "]/div[2]/table/tbody/tr[1]/td/span[2]"));
			Log.info("保险名称元素在产品列表页面");
		} catch (Exception e) {
			Log.error("保险名称元素不在产品列表页面");
		}
		return element;
	}

	// 产品列表页面--保险公司--text
	public static WebElement getInsuranceCompanyElement(String number) throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[3]/div[" + number + "]/div[2]/table/tbody/tr[2]/td[1]"));
			Log.info("保险名称元素在产品列表页面");
		} catch (Exception e) {
			Log.error("保险名称元素不在产品列表页面");
		}
		return element;
	}

	// 产品列表页面--保险期限--text
	public static WebElement getInsurancePeriodElement(String number) throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[3]/div[" + number + "]/div[2]/table/tbody/tr[2]/td[2]"));
			Log.info("保险名称元素在产品列表页面");
		} catch (Exception e) {
			Log.error("保险名称元素不在产品列表页面");
		}
		return element;
	}

	// 产品列表页面--面价--text
	public static WebElement getFacePriceElement(String number) throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[3]/div[" + number + "]/div[2]/table/tbody/tr[2]/td[3]"));
			Log.info("保险名称元素在产品列表页面");
		} catch (Exception e) {
			Log.error("保险名称元素不在产品列表页面");
		}
		return element;
	}

	// 产品列表页面--险种类型--text
	public static WebElement getInsuranceTypeElement(String number) throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[3]/div[" + number + "]/div[2]/table/tbody/tr[3]/td[1]"));
			Log.info("险种类型元素在产品列表页面");
		} catch (Exception e) {
			Log.error("险种类型元素不在产品列表页面");
		}
		return element;
	}

	// 产品列表页面--最高保额--text
	public static WebElement getPolicyMaximumElement(String number) throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[3]/div[" + number + "]/div[2]/table/tbody/tr[3]/td[2]"));
			Log.info("最高保额元素在产品列表页面");
		} catch (Exception e) {
			Log.error("最高保额元素不在产品列表页面");
		}
		return element;
	}

	// 产品列表页面--保险费用--text
	public static WebElement getInsuranceFeeElement(String number) throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[3]/div[" + number + "]/div[2]/table/tbody/tr[3]/td[3]"));
			Log.info("保险费用元素在产品列表页面");
		} catch (Exception e) {
			Log.error("保险费用元素不在产品列表页面");
		}
		return element;
	}

	// 产品列表页面---选中保险--立即购买--btn
	public static WebElement getBuyInsuranceElement(String number) throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[3]/div[" + number + "]/div[2]/table/tbody/tr[2]/td[4]/a/span[2]"));
			Log.info("立即购买元素在产品列表页面");
		} catch (Exception e) {
			Log.error("立即购买元素不在产品列表页面");
		}
		return element;
	}

}

﻿package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.CheckPoints;

import java.util.List;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import com.travelzen.Utility.LogCenter.*;
import com.travelzen.Utility.DataDriver.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.*;
import com.travelzen.Utility.Assertion.Assertion;

//@Listeners({Hotel.OperatorHotel.PrepayHotel.utility.AssertionListener.class})
public class HotelMaintainRoomCatCheckPoint extends FeedTest{

		private static WebDriver driver;
	//	@Test(dataProvider = "feeder")
	//	@Source("LoginInfo_TestData.xls")
	//	public static void RoomCatCheckPoint(String username, String password) throws Exception{
		public static void RoomCatCheckPoint() throws Exception{

	/*		PointAddHotel.pointAddHotel(username, password);
			driver=PointAddHotel.currentDriver;
			//酒店签约信息
			
			driver.get("http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/roomCat/getRoomCat?hotelId=55de68f0e4b00c7a69014a7a");
			HotelMaintainRoomCatAction.transmitDriver(driver);
	
			//点击编辑房型
			HotelMaintainRoomCatPage.getEditRoomCat().click();
	*/		
			//获取 打包产品
			String EpacSal = HotelMaintainRoomCatPage.getEPackagedSales().getAttribute("checked");
			Log.info("Edit RoomCat PackagedSales value "+EpacSal+" element is found in RoomCat Page");
			if(EpacSal.equalsIgnoreCase("true")){
					EpacSal = "1";
				}
			//String telephone = ExcelAction.getValue("Purchaser_PrepayHotel_Booking.xls","contactTel");
			String PacSal = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "PacSal");
			Log.info("Actual value "+PacSal+" is got");
			Assertion.verifyEquals(EpacSal,PacSal, "PackagedSales is " + EpacSal + " in actual");
		/*
			//获取 房间名称
			String EroomName = HotelMaintainRoomCatPage.getERoomName().getAttribute("value");
			Log.info("Edit RoomCat RoomName value "+EroomName+" is found in RoomCat Page");		
			String roomName = ExcelAction.getValue("AddHotel_TestData.xls","roomName");
			Log.info("Actual value "+roomName+" is got");			
			Assertion.verifyEquals(EroomName,roomName, "RoomName is " + EroomName + " in actual");
		*/	
			//获取 入住人数
			String ECapaciyNo = HotelMaintainRoomCatPage.getECapaciyNo().getAttribute("defaultvalue");
			Log.info("Edit RoomCat CapaciyNo value "+ECapaciyNo+" is found in RoomCat Page");
			String capacityNo = ExcelAction.getValue("Hotel/AddHotel_TestData.xls","capacityNo");
			Log.info("Actual value "+capacityNo+" is got");
			Assertion.verifyEquals(ECapaciyNo,capacityNo, "CapaciyNo is " + ECapaciyNo + " in actual");
			
			//获取 套内面积
			String EInsideSpace = HotelMaintainRoomCatPage.getEInsideSpace().getAttribute("value");
			Log.info("Edit RoomCat InsideSpace value "+EInsideSpace+" is found in RoomCat Page");
			String StartFloor = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "insideSpace");
			Log.info("Actual value "+StartFloor+" is got");
			Assertion.verifyEquals(EInsideSpace,StartFloor, "InsideSpace is " + EInsideSpace + " in actual");
			
			//获取 开始楼层
			String EStartFloor = HotelMaintainRoomCatPage.getEFloorNum1().getAttribute("value");
			Log.info("Edit RoomCat StartFloor value "+EStartFloor+" is found in RoomCat Page");
			if(EStartFloor.equalsIgnoreCase("true")){
				EStartFloor = "1";
			}
			String startFloor = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "StartFloor");
			Log.info("Actual value "+startFloor+" is got");
			Assertion.verifyEquals(EStartFloor,startFloor, "StartFloor is " + EStartFloor + " in actual");
			
			//获取 结束楼层
			String EEndFloor = HotelMaintainRoomCatPage.getEFloorNum2().getAttribute("value");
			Log.info("Edit RoomCat EndFloor value "+EEndFloor+" is found in RoomCat Page");
			String EndFloor = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "EndFloor");
			Log.info("Actual value "+EndFloor+" is got");
			Assertion.verifyEquals(EndFloor,EndFloor, "HotelName is " + EndFloor + " in actual");
			
			//获取 窗户
			String EHotelWindow = HotelMaintainRoomCatPage.getEHotelWindow().getAttribute("defaultvalue");
			Log.info("Edit RoomCat PackagedSales value "+EHotelWindow+" is found in RoomCat Page");
			String hotelWindow = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "hotelWindow");
			Log.info("Actual value "+hotelWindow+" is got");
			Assertion.verifyEquals(EHotelWindow,hotelWindow, "hotelWindow is " + EHotelWindow + " in actual");
			/*			
			//获取 床型
			String ERoomBedType = HotelMaintainRoomCatPage.getERoomBedType();
			Log.info("Edit RoomCat RoomBedType value "+ERoomBedType+" is found in RoomCat Page");
			String bedType = ExcelAction.getValue("AddHotel_TestData.xls", "bedType");
			Log.info("Actual value "+bedType+" is got");		
			Assertion.verifyEquals(ERoomBedType,bedType, "HotelName is " + ERoomBedType + " in actual");
			
	//获取 房间设施
			String EpacSal = HotelMaintainRoomCatPage.getERoomFacilities().getAttribute("checked");
			Log.info("Edit RoomCat PackagedSales value "+EpacSal+" is found in RoomCat Page");		
			String PacSal = ExcelAction.getValue("AddHotel_TestData.xls", "PacSal");
			Log.info("Actual value "+PacSal+" is got");
			Assertion.verifyEquals(EpacSal,PacSal, "HotelName is " + EpacSal + " in actual");
			
		*/	
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
}
}

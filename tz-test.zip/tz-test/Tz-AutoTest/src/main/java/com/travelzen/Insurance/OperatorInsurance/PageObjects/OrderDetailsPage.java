package com.travelzen.Insurance.OperatorInsurance.PageObjects;
/*
 * author：wang
 * */
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Utility.LogCenter.Log;


public class OrderDetailsPage
{
	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	public static String option;
	
	public static void getDriver(WebDriver webDriver) throws Exception{
		driver = webDriver;
	}
	
	//订单详情页面-订单号-文本
	public static WebElement getOrderIDElement() throws Exception{
		try{
			System.out.println(driver);
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[3]/div[1]/div[1]/span[1]/strong"));
			Log.info("订单详情页面“订单号”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“订单号”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-客户姓名-文本
	public static WebElement getCustomerNameElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[4]/ul[1]/li[1]/span"));
			Log.info("订单详情页面“客户姓名”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“客户姓名”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-联系人姓名-文本
	public static WebElement getConstactNameElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[4]/ul[1]/li[4]/span"));
			Log.info("订单详情页面“联系人姓名”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“联系人姓名”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-联系人电话-文本
	public static WebElement getConstactTelElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[4]/ul[1]/li[5]/span"));
			Log.info("订单详情页面“联系人电话”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“联系人电话”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-联系人手机-文本
	public static WebElement getConstactMobileElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[4]/ul[1]/li[6]/span"));
			Log.info("订单详情页面“联系人手机”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“联系人手机”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-客户备注-输入框
	public static WebElement getCustomerRemarkinputElement() throws Exception{
		try{
			element =driver.findElement(By.id("externalMemo"));
			Log.info("订单详情页面“客户备注”输入框元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“客户备注”输入框元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-内部备注-输入框
	public static WebElement getInsideRemarkinputElement() throws Exception{
		try{
			element =driver.findElement(By.id("innerMemo"));
			Log.info("订单详情页面“内部备注”输入框元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“内部备注”输入框元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-产品名称-文本
	public static WebElement getProductNameElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='flight_info_grid']/table/tbody/tr/td[1]"));
			Log.info("订单详情页面“产品名称”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“产品名称”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-险种编号-文本
	public static WebElement getProductIDElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='flight_info_grid']/table/tbody/tr/td[2]"));
			Log.info("订单详情页面“险种编号”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“险种编号”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-保险险种-文本
	public static WebElement getInsuranceTypeElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='flight_info_grid']/table/tbody/tr/td[3]"));
			Log.info("订单详情页面“保险险种”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“保险险种”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-保险期限-文本
	public static WebElement getInsuranceTimeElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='flight_info_grid']/table/tbody/tr/td[4]"));
			Log.info("订单详情页面“保险期限”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“保险期限”文本元素，未找到。");
		}
		return element;
	}
	
	//点单详情页面-最高保额-文本
	public static WebElement getInsuranceMaxCoverageElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='flight_info_grid']/table/tbody/tr/td[5]"));
			Log.info("订单详情页面“最高保额”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“最高保额”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-保险费用-文本
	public static WebElement getInsuranceCashElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='flight_info_grid']/table/tbody/tr/td[6]"));
			Log.info("订单详情页面“保险费用”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“保险费用”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-被保人姓名-文本
	public static WebElement getRecognizeeNameElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[1]"));
			Log.info("订单详情页面“被保人姓名”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“被保人姓名”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-被保人证件类型-文本
	public static WebElement getRecognizeeCardStyleElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[2]"));
			Log.info("订单详情页面“被保人证件类型”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“被保人证件类型”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-被保人证件号码-文本
	public static WebElement getRecognizeeCardIDElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[3]"));
			Log.info("订单详情页面“被保人证件号码”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“被保人证件号码”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-被保人性别-文本
	public static WebElement getRecognizeeSexElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[4]"));
			Log.info("订单详情页面“被保人性别”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“被保人性别”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-被保人出生日期-文本
	public static WebElement getRecognizeeBirthdayElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[5]"));
			Log.info("订单详情页面“被保人出生日期”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“被保人出生日期”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-被保人手机号码-文本
	public static WebElement getRecognizeeMobilePhoneElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[6]"));
			Log.info("订单详情页面“被保人手机号码”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“被保人手机号码”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-保险生效日期-文本
	public static WebElement getInsuranceStartDateElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[7]"));
			Log.info("订单详情页面“保险生效日期”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“保险生效日期”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-保单号-文本
	public static WebElement getPolicyIDElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[8]"));
			Log.info("订单详情页面“保单号”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“保单号”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-保险份数-文本
	public static WebElement getInsuranceNumberElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[9]"));
			Log.info("订单详情页面“保险份数”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“保险份数”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-订单状态-文本
	public static WebElement getOrderStateElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[10]"));
			Log.info("订单详情页面“订单状态”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“订单状态”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-投保人-文本
	public static WebElement getApplicantNameElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[11]"));
			Log.info("订单详情页面“投保人姓名”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“投保人姓名”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-证件类型-文本
	public static WebElement getApplicantCardStyleElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[12]"));
			Log.info("订单详情页面“投保人证件类型”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“投保人证件类型”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-证件号码-文本
	public static WebElement getApplicantCardIDElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[13]"));
			Log.info("订单详情页面“投保人证件号码”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“投保人证件号码”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-投保人手机号码-文本
	public static WebElement getApplicantMobilePhoneElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[4]/table/tbody/tr/td[14]"));
			Log.info("订单详情页面“投保人手机号码”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“投保人手机号码”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-应收合计-文本
	public static WebElement getTotalCastElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='order_calc']/ul/li[1]/label/input"));
			Log.info("订单详情页面“应收合计”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“应收合计”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-保险数量-文本
	public static WebElement getInsuranceNumElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='order_calc']/ul/li[3]/label/input"));
			Log.info("订单详情页面“保险份数”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“保险份数”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-保险单价-文本
	public static WebElement getInsurancePriceElement() throws Exception{
		try{
			element =driver.findElement(By.xpath(".//*[@id='order_calc']/ul/li[5]/label/input"));
			Log.info("订单详情页面“保险单价”文本元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“保险单价”文本元素，未找到。");
		}
		return element;
	}
	
	//订单详情页面-追加备注-按钮
	public static WebElement getAddRemarkElement() throws Exception{
		try{
			element =driver.findElement(By.id("btn-additionalRmarks"));
			Log.info("订单详情页面“追加备注”按钮元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“追加备注”按钮元素，未找到。");
		}
		return element;
	}
	
	//订单详情页-保存备注-按钮
	public static WebElement getSaveRemarkElement() throws Exception{
		try{
			element =driver.findElement(By.id("btn-saveAdditionalRmarks"));
			Log.info("订单详情页面“保存备注”按钮元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“保存备注”按钮元素，未找到。");
		}
		return element;
	}
	
	//订单详情页-订单管理-按钮
	public static WebElement getOrderManagementElement() throws Exception{
		try{
			element =driver.findElement(By.xpath("html/body/div[3]/div[1]/ul/li[10]/ol/li[1]/a"));
			Log.info("订单详情页面“订单管理”按钮元素，已找到。");
		}catch(Exception e){
			Log.error("订单详情页面“订单管理”按钮元素，未找到。");
		}
		return element;
	}
	
	
}

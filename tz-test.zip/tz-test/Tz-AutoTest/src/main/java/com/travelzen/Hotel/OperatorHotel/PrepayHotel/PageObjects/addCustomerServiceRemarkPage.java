package com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.Log;

public class addCustomerServiceRemarkPage {

	public static WebDriver driver;
	private static WebElement element;
	private static List<WebElement> elementList;

	// 正常单完成页

	public static void getWebDriver(WebDriver webdriver) {

		driver = webdriver;
	}

	// 添加客服说明 -- 文本框
	public static WebElement log_content() throws Exception {
		try {
			element = driver
					.findElement(By
							.id("log_content"));
			Log.info("log_content is found in the addCustomerService Page.");
		} catch (Exception e) {
			Log.error("log_content is not found in the addCustomerService Page.");
		}
		return element;
	}

	/**
	 * Weixing.Yang
	 * @return
	 * @throws Exception
	 */
	// 添加客服说明  -- 按钮
	public static WebElement addCustomerService() throws Exception {
		try {
			element = driver.findElement(By
					.xpath(".//*[@id='mainContent']/div[4]/div[2]/table[2]/tbody/tr[1]/td[5]/a/span[2]"));
			Log.info("addCustomerService is found in the addCustomerService Page.");
		} catch (Exception e) {
			Log.error("addCustomerService is not found in the addCustomerService Page.");
		}
		return element;
	}

	// **********************************跳回订单管理页面
	// Start*******************************
	// 订单管理  -- 按钮
	public static WebElement getOrderManageButton() throws Exception {
		try {
			element = driver.findElement(By.cssSelector("a[href='http://order.hotel.op3.tdxinfo.com/tops-front-operator-hotel-order/order/hotel/hotelSearch']"));
			Log.info("OrderManage is found in the addCustomerService Page.");
		} catch (Exception e) {
			Log.error("OrderManage is not found in the addCustomerService Page.");
		}
		return element;
	}

}
package com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules;

import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.travelzen.Utility.LogCenter.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.SpotPaymentCreateOrderPage;
import  com.travelzen.Utility.Constants.*;
import com.travelzen.Utility.DataDriver.*;


public class SpotPaymentCreateOrderAction
{
	public static Select select;
	public static String option;
	@Test
	public static void transmitDriver(WebDriver webdriver) throws Exception {
		
		SpotPaymentCreateOrderPage.getDriver(webdriver);
	}
	//循环获取标签页的url判断是否为目标url
	public static void switchToWindow(WebDriver driver)
	{
		Set<String> handles = driver.getWindowHandles();
		handles.remove(driver.getWindowHandle());
		for (String handle : handles)
		{
			driver.switchTo().window(handle);
			if (driver.getCurrentUrl().contains("http://order.hotel.op3.tdxinfo.com/tops-front-operator-hotel-order//order/hotel/selfpay/orderView"))
			{
				break;
			}
		}
	}
	//选择住房客人人数
		public static void roomNum(String roomnum) throws Exception{
			try{
			Select roomNum = new Select(SpotPaymentCreateOrderPage.getRoomNum());
			roomNum.selectByValue(roomnum);
			}catch (Exception e){
				Log.error("RoomNum is not selected");
			}
		}
		//住房客人中文名称
		public static void customerCname(String chineseName) throws Exception{
			try{
				SpotPaymentCreateOrderPage.getCustomerCname().sendKeys(chineseName);
			}catch (Exception e){
				Log.error("Customername is not writed");
			}
		}
		//住房客人英文名称
		public static void customerEname(String englishName) throws Exception{
			try{
				SpotPaymentCreateOrderPage.getCustomerEname().sendKeys(englishName);
			}catch (Exception e){
				Log.error("Customername is not writed");
			}
		}
		//酒店备注：尽量大床
		public static void queenBed() throws Exception{
			try{
				SpotPaymentCreateOrderPage.getQueenBed().click();
			}catch (Exception e){
				Log.error("QueenBed is not selected");
			}
		}
		
		//酒店备注：尽量双床
			public static void twinBeds() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getTwinBeds().click();
				}catch (Exception e){
					Log.error("TwinBeds is not selected");
				}
			}
		//酒店备注：尽量无烟
			public static void noSmoke() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getNoSmoke().click();
				}catch (Exception e){
					Log.error("NoSmoke is not clicked.");
				}
			}
			
		//酒店备注：尽量高楼层
			public static void highRise() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getHighRise().click();
				}catch (Exception e){
					Log.error("HighRise is not clicked.");
				}
			}
		//酒店备注：尽量相邻
			public static void adjacent() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getAdjacent().click();
				}catch (Exception e){
					Log.error("Adjacent is not clicked");
				}
			}
				
		//酒店备注：尽量原房续住
			public static void Continue() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getContinue().click();
				}catch (Exception e){
					Log.error("Adjacent is not clicked");
				}
			}
		//到店时间：23:00 前
			public static void arriveTime() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getArriveTime().click();
				}catch (Exception e){
					Log.error("ArriveTime is not clicked.");
				}
			}
			
			//到店时间：23:00 后
			public static void arriveTimes() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getArriveTimes().click();
				}catch (Exception e){
					Log.error("ArriveTimes is not clicked.");
				}
			}
			//确认方式
			public static void confrimType(String confrimType) throws Exception{
				try{
				Select confrim =new Select(SpotPaymentCreateOrderPage.getConfrimType());
				confrim.selectByValue(confrimType);
				}catch (Exception e){
					Log.error("ConfrimType is not selected");
				}
			}
		//联系人姓名输入框
			public static void contactName(String contactName) throws Exception{
				try{
					SpotPaymentCreateOrderPage.getContactName().sendKeys(contactName);
				}catch (Exception e){
					Log.error("ContactName is not writed");
				}
			}	
		//手机号码输入框
			public static void mobileNum(String mobileNum) throws Exception{
				try{
					SpotPaymentCreateOrderPage.getMobileNum().sendKeys(mobileNum);
				}catch (Exception e){
					Log.error("MobileNum is not writed");
				}
			}	
		//固定电话输入框
			public static void telephoneNum(String telePhone) throws Exception{
				try{
					SpotPaymentCreateOrderPage.getTelephoneNum().sendKeys(telePhone);
				}catch (Exception e){
					Log.error("TelephoneNum is not writed");
				}
			}	
		
		//email输入框
			public static void email(String email) throws Exception{
				try{
					SpotPaymentCreateOrderPage.getEmail().sendKeys(email);
				}catch (Exception e){
					Log.error("Email is not writed");
				}
			}		
		//创建订单按钮
			public static void createOrderButton() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getCreateOrderButton().click();
				}catch (Exception e){
					Log.error("CreateOrderButton is not clicked");
				}
			}		
		//获取订单号
			public static void getOrderId() throws Exception{
				try{
				SpotPaymentCreateOrderPage.getOrderId().click();
				}catch (Exception e){
					Log.error("OrderId is not clicked");
				}
			}		
			
			
			
		/*//订单列表按钮
			public static void orderList() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getOrderList().click();
				}catch (Exception e){
					Log.error("OrderList is not clicked.");
				}
			}	
		//现付酒店订单标签
			
			public static void spotPaymentOrder() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getSpotPaymentOrder().click();
				}catch (Exception e){
					Log.error("SpotPaymentOrder is not clicked.");
				}
			}	
		//订单号输入框
			
			public static void  orderNum() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getOrderNum().sendKeys(Constant.SpotPaymentOrderId);
				}catch (Exception e){
					Log.error("OrderNum is not writed.");
				}
			}	
			
		//查询按钮
			public static void orderSearch() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getOrderSearch().click();
				}catch (Exception e){
					Log.error("OrderSearchPage is not clicked.");
				}
			}	
		//
		//订单号
			public static void orderNumber() throws Exception{
				try{
					SpotPaymentCreateOrderPage.getOrderNumber().click();
				}catch (Exception e){
					Log.error("OrderNumber is not clicked.");
				}
			}	*/
	//比较客户名称
			public static void getUserName() throws Exception{
				try{
					String userName = SpotPaymentCreateOrderPage.getCustomerName().getText();
					System.out.println(userName);
					String eUserName = ExcelAction.getValue("Hotel/SpotPayment_Data.xls", "customerName");
				    System.out.println(userName+"------"+eUserName);
				    Assert.assertEquals(eUserName, userName);
				}catch (Exception e){
					Log.error("CustomerName is not same");
				}
			}
	//比较入店时间
			public static void checkInTime() throws Exception{
				try{
					String checkInTime = SpotPaymentCreateOrderPage.getCheckinTime().getText();
					System.out.println(checkInTime);
					String eCheckinTime = ExcelAction.getValue("Hotel/SpotPayment_Data.xls", "checkinDate");
					System.out.println(checkInTime+"------"+eCheckinTime);
					Assert.assertEquals(eCheckinTime, checkInTime);
				}catch (Exception e){
					Log.error("checkinTime is not same");
				}
			}
	//比较离店时间
			public static void checkOutTime() throws Exception{
				try{
					String checkOutTime = SpotPaymentCreateOrderPage.getCheckoutTime().getText();
					String eCheckoutTime = ExcelAction.getValue("Hotel/SpotPayment_Data.xls", "checkoutDate");
					System.out.println(checkOutTime+"------"+eCheckoutTime);
					Assert.assertEquals(eCheckoutTime, checkOutTime);
				}catch (Exception e){
					Log.error("checkoutTime is not same");
				}
			}
	//比较酒店名称
			public static void hotelName() throws Exception{
				try{
					String hotelName = SpotPaymentCreateOrderPage.getHotelName().getText();
					String ehotelName = ExcelAction.getValue("Hotel/SpotPayment_Data.xls", "hotelName");
					System.out.println(hotelName+"------"+ehotelName);
					Assert.assertEquals(ehotelName, hotelName);
				}catch (Exception e){
					Log.error("hotelName is not same");
				}
			}
	//比较旅客姓名
			public static void customerName() throws Exception{
				try{
					String customer = SpotPaymentCreateOrderPage.getCustomersName().getText();
					String customerName = customer.substring(0, 3);
					String ecustomersName = ExcelAction.getValue("Hotel/SpotPayment_Data.xls", "chineseName");
					System.out.println(customerName+"------"+ecustomersName);
					Assert.assertEquals(ecustomersName, customerName);
				}catch (Exception e){
					Log.error("customerName is not same");
				}
			}
	
	//比较联系人姓名
			public static void contactName() throws Exception{
				try{
					String contactName = SpotPaymentCreateOrderPage.getcontactName().getText();
					String eContactName = ExcelAction.getValue("Hotel/SpotPayment_Data.xls", "contactName");
					System.out.println(contactName+"------"+eContactName);
					Assert.assertEquals(eContactName, contactName);
				}catch (Exception e){
					Log.error("ContactName is not same");
				}
			}
	//比较联系人手机
			public static void mobilePhone() throws Exception{
				try{
					String mobilePhone = SpotPaymentCreateOrderPage.getMobilePhone().getText();
					String emobilePhone = ExcelAction.getValue("Hotel/SpotPayment_Data.xls", "mobileNum");
					System.out.println(mobilePhone+"------"+emobilePhone);
					Assert.assertEquals(emobilePhone, mobilePhone);
				}catch (Exception e){
					Log.error("MobilePhone is not same");
				}
			}
	//比较联系人电话
			public static void telePhone() throws Exception{
				try{
					String telePhone = SpotPaymentCreateOrderPage.getTelePhone().getText();
					String etelePhone = ExcelAction.getValue("Hotel/SpotPayment_Data.xls", "telePhone");
					System.out.println(telePhone+"------"+etelePhone);
					Assert.assertEquals(etelePhone, telePhone);
				}catch (Exception e){
					Log.error("TelePhone is not same");
				}
			}
	//比较联系人邮箱
			public static void email() throws Exception{
				try{
					String email = SpotPaymentCreateOrderPage.getemail().getText();
					String eEmail = ExcelAction.getValue("Hotel/SpotPayment_Data.xls", "email");
					System.out.println(email+"------"+eEmail);
					Assert.assertEquals(eEmail, email);
				}catch (Exception e){
					Log.error("Email is not same");
				}
			}
		
			
	
}

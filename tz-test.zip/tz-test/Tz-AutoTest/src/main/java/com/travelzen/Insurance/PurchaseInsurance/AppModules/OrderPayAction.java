package com.travelzen.Insurance.PurchaseInsurance.AppModules;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.travelzen.Insurance.PurchaseInsurance.PageObjects.OrderPayPage;
import com.travelzen.Utility.LogCenter.Log;

public class OrderPayAction {
	/*
	 * author xuemei.ren date 07/01/2016
	 */

	private static WebElement element;
	private static List<WebElement> elementList;
	public static WebDriver webdriver;
	private static Select oSelection;
	public static String option;
	private static WebElement[][] elementTable;

	public static void transmitDriver(WebDriver currentDriver) throws Exception {

		webdriver = currentDriver;
		OrderPayPage.getDriver(currentDriver);
	}
	
	//订单支付--获取订单号 html/body/section/div/div[1]/table/tbody/tr/td[3]/a/span
	public static String excutObtainOrderIdAction() throws Exception {

		String string = OrderPayPage.getOrderIdElement().getText();
		Log.info("获取的订单号是" +string );
		return string;
	}
	// 订单支付--输入“支付密码”
	public static void excutInputPasswordAction(String string) throws Exception {

		OrderPayPage.getPasswordElement().sendKeys(string);
		Log.info("输入支付密码" + string);
	}

	// 订单支付--点击“确认付款”
	public static void excutPayAffirmAction() throws Exception {

		OrderPayPage.getPayAffirmElement().click();
		Log.info("点击'确认付款'按钮");
	}
}

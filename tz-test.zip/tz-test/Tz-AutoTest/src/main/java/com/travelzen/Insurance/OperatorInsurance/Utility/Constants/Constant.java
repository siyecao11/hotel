package com.travelzen.Insurance.OperatorInsurance.Utility.Constants;

/**
 * 
 * @author Weixing.Yang
 *
 */
public class Constant {
	
	//****以下定义URL全为 保险
	//****OP3测试环境地址
	
	//产品管理页面URL
	public static final String PRODUCTMANAGEURL = "http://aop.op3.tdxinfo.com/tops-front-operator-additional/additional/insurance/product/productSearch";
	//售价维护页面URL
	public static final String SALEPRICEURL = "http://aop.op3.tdxinfo.com/tops-front-operator-additional/additional/insurance/salePrice/salePriceSearch";
	//订单管理页面URL
	public static final String ORDERMANAGEURL = "http://aop.op3.tdxinfo.com/tops-front-operator-additional/additional/insurance/order/orderSearch";
	//运营商创建订单单号
	public static String OperatorOrderId;
	//运营商订单支付金额
	public static String OperatorOrderPay;
	//运营商创建订单联系人姓名
	public static String ConstactName;
	//运营商创建订单联系人电话
	public static String ConstactTel;
	//运营商创建订单联系人手机
	public static String ConstactMobile;
	//运营商创建订单保单号
	public static String PolicyID;
}

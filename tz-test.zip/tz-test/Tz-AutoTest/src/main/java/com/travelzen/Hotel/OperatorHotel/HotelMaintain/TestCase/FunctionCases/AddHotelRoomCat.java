package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.FunctionCases;

import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.travelzen.Utility.Utils.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.*;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
public class AddHotelRoomCat extends FeedTest{

	public static WebDriver currentDriver;

	//TestCase中的每一个Function都可以为其做一张参数表
	//对我们需要输入的值参数化
	
	//添加酒店房型
	@Test(priority = 10)
	public static void RoomCat_AddRoomCat(String PacSal,String roomName,String capacityNo,String insideSpace,
			String StartFloor,String EndFloor,String hotelWindow,String bedType,String bedSize,String roomFacilities) throws Exception {

		currentDriver = AddHotelProviderMessage.currentDriver;
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainRoomCatAction.transmitDriver(currentDriver);
		
		//酒店房型--“添加房型”按钮触发
		HotelMaintainRoomCatAction.excute_Click_AddRoom();
		Thread.sleep(3000);
		//选择是否机+酒
		HotelMaintainRoomCatAction.excute_Input_PackagedSales(PacSal);
		//Thread.sleep(3000);
		//输入房型名称
		HotelMaintainRoomCatAction.excute_Input_RoomName(roomName);
		//Thread.sleep(3000);
		//选择可入住人数
		HotelMaintainRoomCatAction.excute_Select_CapaciyNo(capacityNo);
		//Thread.sleep(3000);
		//输入套内面积
		HotelMaintainRoomCatAction.excute_Input_InsideSpace(insideSpace);
		//Thread.sleep(3000);
		//输入 开始楼层
		HotelMaintainRoomCatAction.excute_Input_StartFloor(StartFloor);
		//Thread.sleep(3000);
		//输入结束楼层
		HotelMaintainRoomCatAction.excute_Input_EndFloor(EndFloor);
		//Thread.sleep(3000);
		//选择房间窗户信息
		HotelMaintainRoomCatAction.excute_Select_HotelWindow(hotelWindow);
		//Thread.sleep(3000);
		//选择床型
		HotelMaintainRoomCatAction.excute_Select_BedType(bedType);
		//Thread.sleep(3000);
		//选择床尺寸  
		//床型尺寸暂时不传
		//HotelMaintainRoomCatAction.excute_Select_BedSize(bedSize);
		
		//选择房间设施
		HotelMaintainRoomCatAction.excute_Select_RoomFacilities(roomFacilities);
	
		//保存房型
		HotelMaintainRoomCatAction.excute_Save();
		//添加价格计划
		
		//酒店房型--“添加房型”--保存编辑
		//HotelMaintainRoomCatAction.excute_Save();
		//Thread.sleep(3000);
	}
	
	//get 酒店房型ID并储存在utility->Constant中
	//只能获取到第一个房型的ID，待改进
	@Test(priority = 11)
	public static void getHotelRoomCatID() throws Exception{
		
		Constant.roomId = HotelMaintainRoomCatAction.excuteGetRoomCatId();
		System.out.println("****************RoomID:" + Constant.roomId + "*********************");
	}
	
	//添加酒店房型后，进入价格计划编辑页
	@Test(priority = 12)
	public static void RoomCat_BookingClass() throws Exception{
		
		//触发“价格计划”Item，进入价格计划编辑页面
		HotelMaintainRoomCatAction.excute_BookingClassItem();
		Thread.sleep(5000);
	}
}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.FunctionCases;

public class Test {

}

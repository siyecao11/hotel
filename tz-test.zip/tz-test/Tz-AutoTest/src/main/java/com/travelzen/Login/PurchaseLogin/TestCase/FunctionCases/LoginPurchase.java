package com.travelzen.Login.PurchaseLogin.TestCase.FunctionCases;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.travelzen.Login.PurchaseLogin.AppModules.LoginAction;
import com.travelzen.Login.PurchaseLogin.AppModules.MenuItemAction;
import com.travelzen.Login.PurchaseLogin.Utility.Constants.Constant;
import com.travelzen.Login.PurchaseLogin.Utility.Utils.DataProviderApp;
import com.travelzen.Utility.Assertion.Assertion;
import com.travelzen.Utility.Constants.Constants;
import com.travelzen.Utility.ScreenShot.RetryFail;
import com.travelzen.Utility.Utils.Utils;

public class LoginPurchase {

	public static WebDriver driver;

	@BeforeClass(alwaysRun = true)
	public static void beforeClass() {

		// driver = new FirefoxDriver();
	}

	@BeforeMethod(alwaysRun = true)
	public static void beforeMethod() {
		
		System.setProperty("webdriver.firefox.bin", "C:/Program Files (x86)/Mozilla Firefox/firefox.exe");
		ProfilesIni pi = new ProfilesIni();
		FirefoxProfile profile = pi.getProfile("default");
		driver = new FirefoxDriver(profile);
		Constants.classDriver = driver;
	}

	@AfterMethod(alwaysRun = true)
	public static void afterMethod() {

		if (DataProviderApp.isLoginIncludeProcess.equalsIgnoreCase("false")) {
			driver.close();
		}
	}
	
	@Test(dataProvider = "longin_data", dataProviderClass = DataProviderApp.class, retryAnalyzer = RetryFail.class, priority = 1, groups = {"采购商登陆"})
	public static void operatorLogin(String username, String password,
			String ename) throws Exception {

		// 打开采购商登陆页面
		driver.get(Constant.PurchaserURL);
		// 输入用户名和密码，执行登陆
		LoginAction.transmitDriver(driver);
		// 传入用户信息，执行登录功能
		LoginAction.setUserNameValue(username);
		// 断言 输入是否成功
		Assertion.verifyEquals(LoginAction.getSetUserNameValue(), username);
		// 传入用户密码
		LoginAction.setPasswordValue(password);
		// 断言 登录button的名称
		Assertion.verifyEquals(LoginAction.getLoginBtnName(), "登  录");
		LoginAction.clickLogin();

		// 登录后页面跳转等待
		Utils.waitForElement(5, driver, "page");
		// 页面跳转，传递Driver
		MenuItemAction.transmitDriver(driver);

	}
}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.HotelMaintain.utility.Constants.*;
import com.travelzen.Utility.LogCenter.Log;

public class SalesPolicyHomePage {
	
	public static WebDriver driver;
	public static WebElement element;
	
	@Test
	public static void getWebDriver(WebDriver webdriver) throws Exception{
		
		driver = webdriver;
	}
	
	@Test//定位添加预付售价按钮
	public static WebElement getAddPrepayPrice() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-hotel/hotel/operator/salesPolicy/gotoAdd?salesPolicyType=CREME']"));
			Log.info("AddPrepayPrice Button item is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********AddPrepayPolicy Button is not found on hotelMaintain Page********");
		}
		return element;
	}
	
	@Test//定位添加现付售价按钮
	public static WebElement getAddCashPrice() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-hotel/hotel/operator/salesPolicy/gotoAdd?salesPolicyType=SPOTPAYMENT']"));
			Log.info("AddCashPrice Button item is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********AddCashPrice Button is not found on hotelMaintain Page********");
		}
		return element;
	}
	
	@Test//定位查询按钮
	public static WebElement getSearchPolicyBtn() throws Exception{
		try{
			element = driver.findElement(By.id("searchButton"));
			Log.info("SearchPolicyButton is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********SearchPolicyBtn is not found on hotelMaintain Page********");
		}
		return element;
	}
	
	@Test//定位规则名称输入框
	public static WebElement getPolicyName() throws Exception{
		try{
			element = driver.findElement(By.name("policyName"));
			Log.info("PolicyName is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********PolicyName is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
	
	@Test//定位规则ID输入框
	public static WebElement getPolicyId() throws Exception{
		try{
			element = driver.findElement(By.name("policyId"));
			Log.info("PolicyId is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********PolicyId is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
	
	@Test//定位规则状态输入框
	public static WebElement getPolicyStatus() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[name='policyStatus']"));
			Log.info("PolicyStatus is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********PolicyStatus is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
	
	@Test//定位查用户类型输入框：创建人/操作人
	public static WebElement getSearchUserType() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[name='searchUserType']"));
			Log.info("SearchUserType is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********SearchUserType is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
	
	@Test//定位创建人/操作人的名称输入框
	public static WebElement getSearchUser() throws Exception{
		try{
			element = driver.findElement(By.name("searchUser"));
			Log.info("SearchUser is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********SearchUser is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
	
	@Test//定位创建起始日期
	public static WebElement getStartCreateTime() throws Exception{
		try{
			element = driver.findElement(By.name("startCreateTime"));
			Log.info("StartCreateTime is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********StartCreateTime is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
	
	@Test//定位创建结束日期
	public static WebElement getEndCreateTime() throws Exception{
		try{
			element = driver.findElement(By.name("endCreateTime"));
			Log.info("EndCreateTime is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********EndCreateTime is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
	
	@Test//定位客户组下拉框
	public static WebElement getCustomerGroup() throws Exception{
		try{
			element = driver.findElement(By.name("customerGroupId"));
			Log.info("CustomerGroup is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********CustomerGroup is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
	
	@Test//定位规则类型下拉框
	public static WebElement getPolicyAddType() throws Exception{
		try{
			element = driver.findElement(By.name("policyAddType"));
			Log.info("PolicyAddType is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********PolicyAddType is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
	
	@Test//定位城市输入框
	public static WebElement getCityName() throws Exception{
		try{
			element = driver.findElement(By.id("city"));
			Log.info("CityName is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********CityName is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
	
	@Test//定位酒店输入框
	public static WebElement getHotelName() throws Exception{
		try{
			element = driver.findElement(By.id("hotelName"));
			Log.info("HotelName is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********HotelName is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
	
	@Test//定位客户名称输入框
	public static WebElement getCustomerName() throws Exception{
		try{
			element = driver.findElement(By.id("customer"));
			Log.info("CustomerName is found on the SalesPolicyHome Page");
		}catch(Exception e){
			Log.error("********CustomerName is not found on the SalesPolicyHome Page********");
		}
		return element;
	}
}

package com.travelzen.Insurance.PurchaseInsurance.PageObjects;

import org.testng.annotations.Test;

public class OrderCompletePage {
  public void f() {
  }
}

package com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.FunctionCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.travelzen.Login.OperatorLogin.TestCase.FunctionCases.LoginOperator;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.Utility.Utils.dataProviderApp;
import com.travelzen.Utility.Constants.Constants;
import com.travelzen.Utility.ResultCollection.Report;
import com.travelzen.Utility.ScreenShot.RetryFail;

@Listeners({com.travelzen.Utility.Assertion.AssertionListener.class, com.travelzen.Utility.ResultCollection.CustomReporter.class, com.travelzen.Utility.ScreenShot.ScreenShotListener.class,com.travelzen.Utility.ScreenShot.RetryListener.class})
public class CreateNormalOrder {

	public static WebDriver currentDriver;

	@AfterSuite(alwaysRun = true)
	public static void afterSuite() throws Exception{
		
		Report.showReport();
		currentDriver.quit();
	}
	
/*	@AfterMethod(alwaysRun=true)
	public static void afterMethod() throws Exception{
		
		driver.close();
	}*/
	
	@Test(priority = 0, groups = {"创建订单"})
	@Parameters({"isFunctionTest","TestName"})
	public static void createNormalOrderParameter(String isFunctionTest,String TestName) throws Exception{
		
		dataProviderApp.parameterGet(isFunctionTest, TestName);
		
	}

	@Test(dataProvider = "TestForCOrder", dataProviderClass = dataProviderApp.class, retryAnalyzer = RetryFail.class, priority = 1, groups = {"创建订单"})
	public static void createNormalOrderLogin(String username, String password, String ename, String customerName, String checkinDate,String checkoutDate, String roomNo, String name) throws Exception{
		
		LoginOperator.beforeMethod();
		System.out.println("ERTYUIO");
		LoginOperator.operatorLogin(username, password, ename);
		System.out.println("TTTTTYYYY");
		NormalOrderOperator.driver = LoginOperator.driver;
		NormalOrderOperator.NormalOrderCreate(customerName, checkinDate, checkoutDate, roomNo, name);
		currentDriver = NormalOrderOperator.driver;
		currentDriver.close();
	}
	
	
}

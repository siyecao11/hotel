package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.ProcessCases;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.travelzen.Utility.*;
import com.travelzen.Utility.DataDriver.*;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.BookingHotelAction;


import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;

import org.databene.feed4testng.FeedTest;
import org.databene.benerator.anno.*;

public class BookingHotel extends FeedTest{
	
	public static WebDriver driver;
	
//	@Test(dataProvider = "feeder")
//	@Source("LoginInfo_TestData.xls")
	
	//加价暂时由参数表中传递
	//后续改进通过政策ID获取加价值
	public static void searchBooking(WebDriver dr,String customerName,String checkinDate,String checkoutDate,int roomNo, int addPrice) throws Exception{
		
/*		driver = new FirefoxDriver();
		driver.get(Constant.OPLOGINURL);
		Login_Action.excute(username, password, driver);
		Log.info("Login Successfully, Entering into HomePage...");
		//Waiting for HomePage loading....
		Utils.waitForElement(5, driver, "page");*/
		
//		driver = AddHotelAudit.currentDriver;
		driver = dr;
		Thread.sleep(2000);
		//Enter into hotel HomePage
/*		MenuItemAction.transmitDriver(driver);
		//点击酒店标签
		MenuItemAction.excuteHotel();
		Thread.sleep(1000);
		QueryBookingAction.transmitDriver(driver);
		//点击搜索预定标签
		QueryBookingAction.Booking();*/
		Thread.sleep(1000);
		BookingHotelAction.transmitDriver(driver);
		//点击搜索客户按钮
		BookingHotelAction.CustomerSearch();
		Thread.sleep(5000);
		//输入客户简称
		BookingHotelAction.CustomerName(customerName);//"wang"
		Thread.sleep(4000);
		//将客户名称记录到 断言表中
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "keHuName", customerName);
		//点击搜索客户按钮
		BookingHotelAction.SearchCustomer();
		Thread.sleep(2000);
		//选择客户
		BookingHotelAction.SelectCustomer();
		Thread.sleep(1000);
		//点击城市输入框，弹出城市选择列表
		BookingHotelAction.City();
		Thread.sleep(1000);
		//选择城市
		BookingHotelAction.SelectCity();
		//将城市记录到 断言表中
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "hotelCity", "杭州");
		//选择入住时间
		BookingHotelAction.CheckinDate(checkinDate);//"2015-09-13"
		//选择出店时间
		BookingHotelAction.CheckoutDate(checkoutDate);//"2015-09-14"
		//填写酒店位置和名称信息
		//Query_Booking_Action.Location("西湖");
		//Query_Booking_Action.HotelName("金");
		//选择房间数
		BookingHotelAction.RoomNo(roomNo);//0;
		Thread.sleep(1000);
		BookingHotelAction.transmitDriver(driver);
		Thread.sleep(1000);
		//选择酒店
		BookingHotelAction.SearchHotel();
		Thread.sleep(5000);
		//Query_Booking_Action.AllPrice();
		//酒店搜索结果列表中检查 挂起酒店是否搜索出来
		//BookingHotelCheckPoint.bookingHotelGuaqiCheckPoint();
		Thread.sleep(2000);
		//点击预订按钮
		BookingHotelAction.Reserve(Constant.bookHotelId);
		
	}
	
	public static void searchBookingConfirm(WebDriver dr,String customerName,String checkinDate,String checkoutDate,int roomNo, int addPrice) throws Exception{
		
		driver = dr;
		Thread.sleep(2000);
		BookingHotelAction.transmitDriver(driver);
		//点击搜索客户按钮
		BookingHotelAction.CustomerSearch();
		Thread.sleep(3000);
		//输入客户简称
		BookingHotelAction.CustomerName(customerName);//"wang"
		Thread.sleep(2000);
		//将客户名称记录到 断言表中
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "keHuName", customerName);
		//点击搜索客户按钮
		BookingHotelAction.SearchCustomer();
		Thread.sleep(2000);
		//选择客户
		BookingHotelAction.SelectCustomer();
		Thread.sleep(1000);
		//点击城市输入框，弹出城市选择列表
		BookingHotelAction.City();
		Thread.sleep(1000);
		//选择城市
		BookingHotelAction.SelectCity();
		//将城市记录到 断言表中
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "hotelCity", "杭州");
		//选择入住时间
		BookingHotelAction.CheckinDate(checkinDate);//"2015-09-13"
		//选择出店时间
		BookingHotelAction.CheckoutDate(checkoutDate);//"2015-09-14"
		BookingHotelAction.RoomNo(roomNo);//0
		Thread.sleep(1000);
		BookingHotelAction.transmitDriver(driver);
		Thread.sleep(1000);
		//选择酒店
		BookingHotelAction.SearchHotel();
		Thread.sleep(5000);
		//在酒店搜索结果中查找是否有“挂起”/“解挂”的酒店
		
	}
	
	@Test(priority = 13)
	public static void quiteDriver() throws Exception{
		
		//退出当前driver
		//driver.close();
	}
}
package com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.CheckPoints;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.CheckPoints.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.ProcessCases.*;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.*;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
import com.travelzen.Login.OperatorLogin.AppModules.LoginAction;
import com.travelzen.Utility.Assertion.*;
import com.travelzen.Utility.DataDriver.*;
import com.travelzen.Utility.Utils.*;


//@Listeners({Hotel.OperatorHotel.PrepayHotel.utility.AssertionListener.class})
public class OrderManagerPublicCheckPoint {

	public static WebDriver currentDriver;
	public static WebDriver hidingDriver;
	
	@Test
	public static void publicCheckPoint(String checkinDate, int addPrice, String checkoutDate) throws Exception{
		
		//调用隐式Driver取值（expected value）,用于断言
		//get 酒店ID
		hidingDriver = new FirefoxDriver();
		hidingDriver.get(com.travelzen.Login.OperatorLogin.Utility.Constants.Constant.OPLOGINURL);
		LoginAction.excute("yangweixing", "111111", hidingDriver);
		Thread.sleep(2000);
		//拼凑酒店基本信息页面的URL
		String hotelId = Constant.hotelId;
		String hotelMessageURL = Constant.hotelInfoURL + hotelId;
		hidingDriver.get(hotelMessageURL);
		HotelMaintainMainContentAction.transmitDriver(hidingDriver);
		Thread.sleep(2000);
		//获取酒店名称和酒店地址
		HotelMaintainMainContentAction.EditbuttonCLick();
		Thread.sleep(2000);
		String ehotelName = HotelMantainMainContentPage.HotelName().getAttribute("value");
		String ehotelAddress = HotelMantainMainContentPage.HotelAddress().getAttribute("value");
		HotelMaintainMainContentAction.Savebutton();
		Thread.sleep(4000);
		//获取酒店规定内容
		HotelMaintainMainContentAction.editHotelRulesButton();
		Thread.sleep(2000);
		String echeckInTime = HotelMaintainMainContentAction.excuteCheckinTime();
		String echeckOutTime = HotelMaintainMainContentAction.excuteCheckoutTime();
		String ecalclePloicy = HotelMaintainMainContentAction.excuteCancelPolicy();
		
		//将获取的期望值写人Excel中
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "hotelName", ehotelName);
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "hotelAddress", ehotelAddress);
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "checkInTime", echeckInTime);
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "checkOutTime", echeckOutTime);
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "canclePloicy", ecalclePloicy);
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "checkinDate", checkinDate);
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "checkoutDate", checkoutDate);
		
		//获取酒店DailyRate的价格
		//拼凑DailyRate页面URL
		hotelMessageURL = Constant.hotelDailyRateURL + hotelId;
		hidingDriver.get(hotelMessageURL);
		//传递Driver
		HotelMaintainDailyRateAction.transmitDriver(hidingDriver);
		Thread.sleep(2000);
		//获取指定房型价格计划下的指定日期的价格
		String ebaseFee = HotelMaintainDailyRateAction.excuteBaseFeeInDay(checkinDate, Constant.roomId);
		//System.out.println(ehotelName + ehotelAddress + ebaseFee);
		//关闭Driver
		hidingDriver.close();
		
		//切换到原页面窗口
		currentDriver = BookingHotel.driver;
		Utils.waitForElement(5, currentDriver, "page");
		OrderManagePublicCheckPointAction.transmitDriver(currentDriver);
		//取值（actual value）,用于断言
		currentDriver = BookingHotel.driver;
		Utils.waitForElement(5, currentDriver, "page");
		OrderManagePublicCheckPointAction.transmitDriver(currentDriver);
	
		//获取订单页中 预订产品信息中 的酒店名称（实际显示名称）
		String ahotelName = OrderManagePublicCheckPointAction.excuteHotelDetailBoHotelName();
		//获取订单页中 预订产品信息中 的酒店地址（实际显示地址）
		String ahotelAddress = OrderManagePublicCheckPointAction.excuteHotelDetailBoHotelAddress();
		//获取订单页中 预订产品信息中 的入住日期（实际入住日期）
		String checkit = OrderManagePublicCheckPointAction.excuteHotelDetailBoCheckinDate();
		//获取订单页中 预订产品信息中 的离店日期（实际离店日期）
		String checkot = OrderManagePublicCheckPointAction.excuteHotelDetailBoCheckoutDate();
		
		//获取订单页中 费用明细信息中 的底价（实际显示底价）
		String abaseFee = OrderManagePublicCheckPointAction.excuteBasicFeeYuan().replace(".00", "");
		//获取订单页中 费用明细信息中 的加价（实际显示加价）
		String aaddPrice = OrderManagePublicCheckPointAction.excuteMarkupFeeYuan().replace(".00", "");
		//获取订单页中 费用明细信息中 的卖价（实际显示卖价）
		String asellPrice = OrderManagePublicCheckPointAction.excuteSellingFeeYuan().replace(".00", "");
		//获取订单页中 费用明细信息中 的期望显示的卖价
		int esellPrice = Integer.parseInt(ebaseFee) + addPrice;
		//获取订单页中 费用明细信息中 的每日合计（实际显示每日合计）
		String adailyTotal = OrderManagePublicCheckPointAction.excuteDailyTotal().replace(".00", "");
		//获取订单页中 费用明细信息中 的期望显示的每日合计
		int edailyTotal = esellPrice * Integer.parseInt(OrderManagePublicCheckPointAction.excuteHotelDetailBoRoomNo());
		//获取订单页中 费用明细信息中 的合计（实际显示合计）
		String aheJi = OrderManagePublicCheckPointAction.excuteHeJi().replace(".00", "");
		//获取订单页中 费用明细信息中 的期望显示的合计
		int eheJi = esellPrice * Integer.parseInt(OrderManagePublicCheckPointAction.excuteHotelDetailBoNightNo());
		
		//获取订单页中 订单金额信息中 的实际收入（实际显示实际收入）
		String atotalOrderFeeYuan = OrderManagePublicCheckPointAction.excuteOrderTotalShow().replace(".00", "");
		//获取订单页中 订单金额信息中 的政策成本（实际显示政策成本）
		String atotalBasicFeeYuan = OrderManagePublicCheckPointAction.excuteTotalBasicFeeYuanShow().replace(".00", "");
		//获取订单页中 订单金额信息中 的加价（实际显示加价）
		String atotalMarkupFeeYuan = OrderManagePublicCheckPointAction.excuteTotalMarkupFeeYuanShow().replace(".00", "");
		//获取订单页中 订单金额信息中 的手续费（实际显示手续费）
		String aorderProcedureFeeYuan = OrderManagePublicCheckPointAction.excuteOrderProcedureFeeYuan().replace(".00", "");
		//获取订单页中 订单金额信息中 的期望显示实际收入
		//改计算仅是考虑正常单的实际金额计算
		//变更单、退订单以及调账单需要重新设计计算公式
		int etotalOrderFeeYuan = Integer.parseInt(OrderManagePublicCheckPointAction.excuteTotalSellingFeeYuan().replace(".00", "")) + Integer.parseInt(aorderProcedureFeeYuan);
		//将订单金额记录到断言表中
		ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "orderFee", etotalOrderFeeYuan + ".00");
		//获取订单页中 订单金额信息中 的期望显示政策成本
		int etotalBasicFeeYuan = Integer.parseInt(OrderManagePublicCheckPointAction.excuteTotalBasicFeeYuan().replace(".00", ""));
		//获取订单页中 订单金额信息中 的期望显示加价
		int etotalMarkupFeeYuan = Integer.parseInt(OrderManagePublicCheckPointAction.excuteTotalMarkupFeeYuan().replace(".00", ""));
		//获取订单页中 订单金额信息中 的期望显示手续费
		
		//获取订单页中 本单挂账信息中 的实际成本（实际显示实际成本）
		String aactualCost = OrderManagePublicCheckPointAction.excuteActualCost().replace(".00", "");
		//获取订单页中 本单挂账信息中 的挂账金额（实际显示挂账金额）
		String asettleOrderFeeYuan = aactualCost;
		//获取订单页中 本单挂账信息中 的留账金额（实际显示留账金额）
		String areservationFeeYuanShow = OrderManagePublicCheckPointAction.excuteReservationFeeYuanShow().replace(".00", "");
		//获取订单页中 本单挂账信息中 的期望显示实际成本
		int eactualCost = etotalBasicFeeYuan;
		//获取订单页中 本单挂账信息中 的期望显示挂账金额
		int esettleOrderFeeYuan = etotalBasicFeeYuan;
		
		//获取订单页中 酒店规定信息中 的实际入住时间（实际显示入住时间）
		String acheckInTime = OrderManagePublicCheckPointAction.excuteHotelDetailBoCheckinProvision();
		//获取订单页中 酒店规定信息中 的实际退房时间（实际显示退房时间）
		String acheckOutTime = OrderManagePublicCheckPointAction.excuteHotelDetailBoCheckoutProvision();
		//获取订单页中 酒店规定信息中 的实际取消变更规则（实际显示消变更规则）
		String acalclePloicy = OrderManagePublicCheckPointAction.excuteHotelDetailBoCancleProvision();
		
		//获取当前订单状态
		String orderStatus = OrderManagePublicCheckPointAction.excuteOrderStatus();
		
		//System.out.println(ahotelName + ahotelAddress + abaseFee);
		//订单页中的 预订产品 酒店名称 断言
		Assertion.verifyEquals(ahotelName, ehotelName, "HotelName is " + ahotelName + " in actual");
		//订单页中的 预订产品 酒店地址 断言
		Assertion.verifyEquals(ahotelAddress, ehotelAddress, "HotelAdress is " + ahotelAddress + " in actual");
		//订单页中的 预订产品 入住日期 断言
		Assertion.verifyEquals(checkit, checkinDate, "CheckinDate is " + checkit + " in actual");
		//订单页中的 预订产品 离店日期 断言
		Assertion.verifyEquals(checkot, checkoutDate, "CheckoutDate is " + checkot + " in actual");
		
		//订单页中的 费用明细  底价  断言
		Assertion.verifyEquals(abaseFee, ebaseFee, "BasicFeeYuan is " + abaseFee + "in actual");
		//订单页中的 费用明细  加价  断言
		Assertion.verifyEquals(Integer.parseInt(aaddPrice), addPrice, "MarkupFeeYuan is " + aaddPrice + " in actual");
		//订单页中的 费用明细  卖价  断言
		Assertion.verifyEquals(Integer.parseInt(asellPrice), esellPrice, "SellingFeeYuan is " + asellPrice + " in actual");
		//订单页中的 费用明细  每日合计  断言
		Assertion.verifyEquals(Integer.parseInt(adailyTotal), edailyTotal, "edailyTotalFeeYuan is " + adailyTotal + " in actual");
		//订单页中的 费用明细  合计  断言
		Assertion.verifyEquals(Integer.parseInt(aheJi), eheJi, "HeJi is " + aheJi + " in actual");
		//订单页中的 订单金额  实际收入  断言
		Assertion.verifyEquals(Integer.parseInt(atotalOrderFeeYuan), etotalOrderFeeYuan, "TotalOrderFeeYuan is " + atotalOrderFeeYuan + " in actual");
		//订单页中的 订单金额  政策成本  断言
		Assertion.verifyEquals(Integer.parseInt(atotalBasicFeeYuan), etotalBasicFeeYuan, "TotalBasicFeeYuan is " + atotalBasicFeeYuan + " in actual");
		//订单页中的 订单金额  加价  断言
		Assertion.verifyEquals(Integer.parseInt(atotalMarkupFeeYuan), etotalMarkupFeeYuan, "ToalMarkupFeeYuan is " + atotalMarkupFeeYuan + " in actual");
		//订单页中的 本单挂账  实际成本  断言
		Assertion.verifyEquals(Integer.parseInt(aactualCost), eactualCost, "ActualCost is " + aactualCost + " in actual");
		//订单页中的 本单挂账  挂账金额  断言
		Assertion.verifyEquals(Integer.parseInt(asettleOrderFeeYuan), esettleOrderFeeYuan, "SettleOrderFeeYuan is " + asettleOrderFeeYuan + " in actual");
		//订单页中的 酒店规定  入住时间  断言
		Assertion.verifyEquals(acheckInTime, echeckInTime, "CheckInTime is " + acheckInTime + "in actual");
		//订单页中的 酒店规定  退房时间  断言
		Assertion.verifyEquals(acheckOutTime, echeckOutTime, "CheckOutTime is " + acheckOutTime + "in actual");
		//订单页中的 酒店规定  变更取消规则  断言
		Assertion.verifyEquals(acalclePloicy, ecalclePloicy, "CanclePloicy is " + acalclePloicy + "in actual");
		
		//订单页中的 订单状态 断言
		Assertion.verifyEquals(orderStatus, "审核", "OrderStatus is " + orderStatus + "in actual");
		
	}
}

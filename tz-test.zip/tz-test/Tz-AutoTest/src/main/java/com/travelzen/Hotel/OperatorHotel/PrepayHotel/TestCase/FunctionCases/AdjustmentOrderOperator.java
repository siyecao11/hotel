package com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.FunctionCases;

import java.util.Arrays;
import java.util.List;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageAdjustmentOrderAuditAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageAdjustmentOrderCreateAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageNormalOrderAuditAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageNormalOrderCompleteAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageOrderListAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.OrderManageOrderPayAction;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.FunctionCases.*;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
import com.travelzen.Utility.Utils.Utils;

public class AdjustmentOrderOperator extends FeedTest{

	public static WebDriver driver;
	public static String orderType;
	public static String orderId;
	
public static WebDriver currentDriver;
	//从正常单获取Driver
	@Test(priority = 30, groups ={"正常单创建调账单","正常单变更后调账确认流程","正常单变更后变更再调账确认流程","正常单变更后调账确认流程","正常单变更后变更再调账确认流程","正常单调账取消流程","正常单变更后调账取消流程"})
	public static void getNormalOrderTCDriver() throws Exception{
		
		orderType = "normal";
		driver = NormalOrderOperator.driver;
	}
	
	//从变更单获取Driver
	@Test(priority = 30, groups ={"正常单创建调账单","正常单变更后调账确认流程","正常单变更后变更再调账确认流程","正常单变更后调账确认流程","正常单变更后变更再调账确认流程","正常单调账取消流程","正常单变更后调账取消流程"})
	public static void getEndorseOrderTCDriver() throws Exception{
		
		orderType = "endorse";
		//driver = EndorseOrderTC.driver;
	}
	
	//从退订单获取Driver
	@Test(priority = 30, groups ={""})
	public static void getrRetreatOrderTCDriver() throws Exception{
		
		orderType = "retreat";
		//driver = RetreatOrderTC.driver;
	}
	//获取订需要调账的订单号，正常单、变更单、调账单
	@Test(priority = 31, groups ={"正常单创建调账单","正常单变更后调账确认流程","正常单变更后变更再调账确认流程","正常单变更后调账确认流程","正常单变更后变更再调账确认流程","正常单调账取消流程","正常单变更后调账取消流程"})
	public static void adjustmentOrderID() throws Exception{	
		
		/* 如果需要在调账单的TC中单独创建一个正常单，然后在此基础上再创建调账单的话，需要单独传参	
		 * public static void adjustmentOrderCancle(String username, String password,String customerName,String checkinDate,String checkoutDate,int roomNo,String name,int addPrice) throws Exception{	
		PointSearchHotel.pointSearchHotel(username, password);
		driver = PointSearchHotel.currentDriver;
		BookingHotel.searchBooking(driver, customerName, checkinDate, checkoutDate, roomNo, addPrice);
		//创建正常单
		OrderManageNormalOrder.NormalOrder_ContractInfo(name,checkinDate, addPrice, checkoutDate);*/
		
		
		//于订单列表页查找指定ID的订单（上一步骤中创建的正常订单）
		//并跳转到订单详情页
		//判断是在哪类订单基础上做调账
		if(orderType.equals("normal")){
			
			orderId = Constant.NormalOrderId;
		}else if(orderType.equals("endorse")){
			
			orderId = Constant.EndorseOrderId;
		}else if(orderType.equals("retreat")){
			
			orderId = Constant.RetreatOrderId;
		}

	}


	//于订单列表页查找指定ID的订单（上一步骤中创建的订单）
	//并跳转到订单详情页
	@Test(priority = 32, groups ={"正常单创建调账单","正常单调账确认流程","正常单变更后调账确认流程","正常单变更后变更再调账确认流程","正常单调账取消流程","正常单变更后调账取消流程"})
	public static void orderDetail() throws Exception{
		System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		System.out.println("Welcome to orderDetail method!!!");
		driver.get(Constant.orderManageURL);
		Thread.sleep(2000);
		OrderManageOrderListAction.transmitDriver(driver);
		//根据订单ID查询出订单，点击进入订单详情页
		OrderManageOrderListAction.OrderIdInput(Constant.TempId);
		Thread.sleep(2000);
		OrderManageOrderListAction.SearchOrder();
		Thread.sleep(2000);
		OrderManageOrderListAction.OrderClick();
		Thread.sleep(2000);
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
	}
	
	//TestCase中的每一个Function都可以为其做一张参数表
	//对我们需要输入的值参数化
	
	//调账单的创建、审核、完成(取消)等都在此Case中
	//调账单 审核模块 调用的是公共模块的审核
	//OrderManage_NormalOrder_Audit
	
	//调账单 --创建 调账单 Case
	@Test(priority = 33, groups ={"正常单创建调账单","正常单变更后调账确认流程","正常单变更后变更再调账确认流程","正常单调账取消流程","正常单变更后调账取消流程"})
	public static void adjustmentOrderCreateOrder() throws Exception {
		System.out.println("Welcome to adjustmentOrderCreateOrder method!!!");
		//获取当前订单(正常单||变更单||退订单||调账单)完成页的Driver
		//currentDriver = 当前页面Action.currentDriver;
		//订单(正常单||变更单||退订单||调账单)完成单页的Driver传到创建 调账单
		System.out.println("TTTTTTTTTTTTTTTTTTTTT");
		//driver = cdriver;
		Utils.waitForElement(5, driver, "page");
		OrderManageNormalOrderCompleteAction.transmitDriver(driver);
		//当前页面Action.click创建调账单button
		System.out.println("TTTTTTTTTTTTTTTTTTTTTTTTTTT");
		OrderManageNormalOrderCompleteAction.createAdjustmentOrder();
		Thread.sleep(2000);
		
		Utils.waitForElement(5, driver, "page");
		//创建 调账单Driver传递
		OrderManageAdjustmentOrderCreateAction.transmitDriver(driver);
		//创建调账单 -- 修改低价和卖价
		OrderManageAdjustmentOrderCreateAction.excuteModifyPrice();
		Thread.sleep(2000);
		//创建调账单 -- 修改低价和卖价 -- 确认
		OrderManageAdjustmentOrderCreateAction.excuteSaveCostBtn();
		Thread.sleep(2000);
		//创建调账单 -- 修改低价和卖价 -- 确认 -- 修改价格原因
		OrderManageAdjustmentOrderCreateAction.excuteModifyRemark();
		Thread.sleep(2000);
		//创建调账单 -- 修改低价和卖价 -- 确认 -- 修改价格原因  -- 确认保存
		OrderManageAdjustmentOrderCreateAction.excuteModifyRemarkWindow_Save();
		Thread.sleep(2000);
		//创建调账单 -- 手续费上
		OrderManageAdjustmentOrderCreateAction.excuteOrderProcedureFeeYuan("50");
		Thread.sleep(2000);
		//创建调账单Btn
		OrderManageAdjustmentOrderCreateAction.excuteCreateAdjustmentOrderBtn();
		Thread.sleep(2000);
		//订单支付页面 -- 储存订单ID
		OrderManageOrderPayAction.transmitDriver(driver);
		Constant.adjustmentOrderId = OrderManageOrderPayAction.GetOrderId();
		Constant.TempId = Constant.adjustmentOrderId;
		
		Thread.sleep(3000);
	}
	
	@Test(priority = 34, groups ={"正常单调账确认流程","正常单变更后调账确认流程","正常单变更后变更再调账确认流程","正常单调账取消流程","正常单变更后调账取消流程"})
	public static void adjustOrderDetail() throws Exception{
		System.out.println("Welcome to orderDetail method!!!");
		driver.get(Constant.orderManageURL);
		Thread.sleep(2000);
		OrderManageOrderListAction.transmitDriver(driver);
		//根据订单ID查询出订单，点击进入订单详情页
		OrderManageOrderListAction.OrderIdInput(Constant.TempId);
		Thread.sleep(2000);
		OrderManageOrderListAction.SearchOrder();
		Thread.sleep(2000);
		OrderManageOrderListAction.OrderClick();
		Thread.sleep(2000);
	}

	//调账单 --审核 调账单 Case
	@Test(priority = 35, groups ={"正常单调账确认流程","正常单变更后调账确认流程","正常单变更后变更再调账确认流程","正常单调账取消流程","正常单变更后调账取消流程"})
	public static void adjustmentOrderAuditOrder() throws Exception {
		System.out.println("Welcome to adjustmentOrderAuditOrder method!!!");
		Utils.waitForElement(5, driver, "page");
		// 审核 调账单Driver传递
		OrderManageAdjustmentOrderAuditAction.transmitDriver(driver);
		// 调账单审核 -- "留账金额" 编辑btn
		OrderManageAdjustmentOrderAuditAction.excuteLiuZhang();
		Thread.sleep(2000);
		// 调账单审核 -- "留账金额" -- 留账金额
		OrderManageAdjustmentOrderAuditAction.excuteResFeeForPop("200");
		// 调账单审核 -- "留账金额" -- 酒店/供应商确认人
		OrderManageAdjustmentOrderAuditAction.excuteResContactForPop("Yang weixing");
		// 调账单审核 -- "留账金额" -- 留账有效期
		OrderManageAdjustmentOrderAuditAction.excuteResValidDateForPop();
		Thread.sleep(2000);
		// 调账单审核 -- "留账金额" -- 留账有效期  -- 时间插件
		OrderManageAdjustmentOrderAuditAction.excuteTime();
		Thread.sleep(2000);
		OrderManageAdjustmentOrderAuditAction.excuteResRemarkForPop("留账金额备注内容在此 留人不留书");
		// 调账单审核 -- "留账金额" -- 确定保存Btn
		OrderManageAdjustmentOrderAuditAction.excuteConfirmReservationBtn();
		Thread.sleep(2000);
		// 调账单审核 -- "留账金额" -- 留账保存后，核对本单挂账提醒
		OrderManageAdjustmentOrderAuditAction.excuteComformSettlement();
		// 调账单审核 -- "挂账金额"
		OrderManageAdjustmentOrderAuditAction.excuteSettleOrderFeeYuan("-500");
		Thread.sleep(2000);
		// 调账单审核 -- "挂账备注"
		OrderManageAdjustmentOrderAuditAction.excuteSettleRemark("挂账备注");
		Thread.sleep(2000);
		// 调账单审核 -- "确认调账"
		OrderManageAdjustmentOrderAuditAction.excuteAdjustmentOrderConfirmBtn();
	}
	
	// 确认调账 -- 调账审核：酒店确认码&&结算提醒设置
	@Test(priority = 36, groups ={"正常单调账确认流程","正常单变更后调账确认流程","正常单变更后变更再调账确认流程"})
	public static void adjustmentOrderAuditOrderCodeSettle() throws Exception{
		System.out.println("Welcome to adjustmentOrderAuditOrderCodeSettle method!!!");
		OrderManageNormalOrderAuditAction.transmitDriver(driver);
		//选择酒店是否需要确认码，“0”不需要、“1”需要
		List<String> slist = Arrays.asList("0");
		OrderManageNormalOrderAuditAction.excute_input_ConfirmID(slist);
		//保存酒店确认码信息
		OrderManageNormalOrderAuditAction.excute_Save_ConfirmID();
		Thread.sleep(2000);
		//选择酒店结算信息，
		List<String> slistT = Arrays.asList("WEEK_SETTLE");
		OrderManageNormalOrderAuditAction.excute_change_CountReminder(slistT);
		//保存酒店结算信息
		Thread.sleep(2000);
		OrderManageNormalOrderAuditAction.excute_Save_Count();
		Thread.sleep(2000);
	}
	
	//取消调账 
	@Test(priority = 36, groups ={"正常单调账取消流程","正常单变更后调账取消流程"})
	public static void  adjustmentOrderAuditOrderCancle(WebDriver cdriver) throws Exception{
		System.out.println("Welcome to adjustmentOrderAuditOrderCancle method!!!");
		driver = cdriver;
		Utils.waitForElement(5, driver, "page");
		// 审核 调账单Driver传递
		OrderManageAdjustmentOrderAuditAction.transmitDriver(driver);
		OrderManageAdjustmentOrderAuditAction.excuteAdjustmentOrderCancleBtn();
		Thread.sleep(2000);
		OrderManageAdjustmentOrderAuditAction.excuteCancelRemark();
		Thread.sleep(2000);
		OrderManageAdjustmentOrderAuditAction.excuteCancelOrderSave();
		Thread.sleep(2000);
	}
	

	
	
}

package com.travelzen.Insurance.OperatorInsurance.AppModules;
/**
 * author:qiqi.wang
 * */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.EditOrderPage;
import com.travelzen.Utility.LogCenter.Log;

public class EditOrderAction
{
	public static WebDriver webdriver;
	public static void transmitDriver(WebDriver driver) throws Exception {
		webdriver = driver;
		EditOrderPage.getDriver(webdriver);
	}
	
	//修改订单页面-修改联系人姓名-输入
	public static void excuteContactName(String ContactName)throws Exception{
		try{
			EditOrderPage.getContactNameInputElement().clear();
			EditOrderPage.getContactNameInputElement().sendKeys(ContactName);
			Log.info("修改订单页面“联系人”信息，已修改。");
		}catch(Exception e){
			Log.error("修改订单页面“联系人”信息，未修改。");
		}
	}
	
	//修改订单页面-修改联系电话-输入
	public static void excuteContactTel(String ContactTel)throws Exception{
		try{
			EditOrderPage.getContactTelInputElement().clear();
			EditOrderPage.getContactTelInputElement().sendKeys(ContactTel);
			Log.info("修改订单页面“联系人电话”信息，已修改。");
		}catch(Exception e){
			Log.error("修改订单页面“联系人电话”信息，未修改。");
		}
	}
	
	//修改订单页面-修改手机号码-输入
	public static void excuteContactMobile(String ContactMobile)throws Exception{
		try{
			EditOrderPage.getContactMobilePhoneInputElement().clear();
			EditOrderPage.getContactMobilePhoneInputElement().sendKeys(ContactMobile);
			Log.info("修改订单页面“联系人手机”信息，已修改。");
		}catch(Exception e){
			Log.error("修改订单页面“联系人手机”信息，未修改。");
		}
	}

	
	//修改订单页面-修改保险生效时间-输入
	public static void excuteInsuranceStartTime(String InsuranceStart) throws Exception{
		try{
			EditOrderPage.getInsuranceStartDateElement().clear();
			EditOrderPage.getInsuranceStartDateElement().sendKeys(InsuranceStart);
			Log.info("修改订单页面“保险开始时间”信息，已修改。");
		}catch(Exception e){
			Log.error("修改订单页面“保险开始时间”信息，未修改。");
		}
	}
	
	//修改订单页面-修改被保人姓名-输入
	public static void excuteCustomerNameInput(String CustomerName) throws Exception{
		try{
			EditOrderPage.getCustomerNameInputElement().clear();
			EditOrderPage.getCustomerNameInputElement().sendKeys(CustomerName);
			Log.info("修改订单页面“被保人姓名”信息，已修改。");
		}catch(Exception e){
			Log.error("修改订单页面“被保人姓名”信息，未修改。");
		}
	}
	
	//修改订单页面-修改被保人手机号码-输入
	public static void excuteCustomerMobileInput(String CustomerMobile) throws Exception{
		try{
			EditOrderPage.getCustomerMobileInputElement().clear();
			EditOrderPage.getCustomerMobileInputElement().sendKeys(CustomerMobile);
			Log.info("修改订单页面“被保人手机号码”信息，已修改。");
		}catch(Exception e){
			Log.error("修改订单页面“被保人手机号码”信息，未修改。");
		}
	}
	
	//修改订单页面-修改被保人证件类型-选择
	public static void excuteIDTypeSelect(String IDType)throws Exception{
		try{
			Select oselect = new Select(EditOrderPage.getIDTypeSelectElement());
			oselect.selectByValue(IDType);
			Log.info("修改订单页面“被保人证件类型”，已选择。");
		}catch(Exception e){
			Log.error("修改订单页面“被保人证件类型”，未修改。");
		}
	}
	
	//修改订单页面-输入证件号码-输入
	public static void excuteIDNumInput(String IDNum) throws Exception{
		try{
			EditOrderPage.getIDNumInputElement().clear();
			EditOrderPage.getIDNumInputElement().sendKeys(IDNum);
			Log.info("修改订单页面“被保人证件号码”信息，已修改。");
		}catch(Exception e){
			Log.error("修改订单页面“被保人证件号码”信息，未修改。");
		}
	}
	
	//修改订单页面-选择被保人出生年月-输入
	public static void excuteBirthDateInput(String BirthDate) throws Exception{
		try{
			EditOrderPage.getBirthDateInputElement().clear();
			EditOrderPage.getBirthDateInputElement().sendKeys(BirthDate);
			Log.info("修改订单页面“被保人出生年月”信息，已修改。");
		}catch(Exception e){
			Log.error("修改订单页面“被保人出生年月”信息，未修改。");
		}
	}
	
	//修改订单页面-选择被保人性别-选择
	public static void excuteSexTypeSelect(String SexType)throws Exception{
		try{
			Select oselect = new Select(EditOrderPage.getSexTypeSelectElement());
			oselect.selectByValue(SexType);
			Log.info("修改订单页面“被保人性别”，已修改。");
		}catch(Exception e){
			Log.error("修改订单页面“被保人性别”，未修改。");
		}
	}
	
	//修改订单页面-选择保险份数-选择
	public static void excuteInsuranceNumSelect(String InsuranceNum)throws Exception{
		try{
			Select oselect = new Select(EditOrderPage.getInsuranceNumSelectElement());
			oselect.selectByValue(InsuranceNum);
			Log.info("修改订单页面“保险份数”，已修改。");
		}catch(Exception e){
			Log.error("修改订单页面“保险份数”，未修改。");
		}
	}
	
	//修改订单页面-取消编辑-点击
	public static void excuteCancelEditOrder() throws Exception{
		try{
			EditOrderPage.getCancelEditButtonElement().click();
			Log.info("修改订单页面“取消编辑”，已点击。");
		}catch(Exception e){
			Log.error("修改订单页面“取消编辑”，未点击。");
		}
	}
	
	//修改订单页面-保存编辑-点击
	public static void excuteSaveEditOrder() throws Exception{
		try{
			EditOrderPage.getSaveEditButtonElement().click();
			Log.info("修改订单页面“保存编辑”，已点击。");
		}catch(Exception e){
			Log.error("修改订单页面“保存编辑”，未点击");
		}
	}
	
	
	
	
}

package com.travelzen.Insurance.OperatorInsurance.AppModules;
/**
 * author:qiqi.wang
 * */
import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.StayPaymentPage;
import com.travelzen.Utility.LogCenter.Log;

public class StayPaymentAction
{
	public static WebDriver webdriver;
	public static void transmitDriver(WebDriver driver) throws Exception{
		webdriver = driver;
		StayPaymentPage.getDriver(webdriver);
	}
	
	//等待支付页面-支付订单-点击
	public static void excutePayOrderBtn() throws Exception{
		try{
			StayPaymentPage.getPayOrderButtonElement().click();
			Log.info("等待支付页面“支付按钮”，已点击。");
		}catch(Exception e){
			Log.error("等待支付页面“支付按钮”，未点击。");
		}
	}
	//等待支付页面-修改订单-点击
	public static void excuteEditOrderBtn() throws Exception{
		try{
			StayPaymentPage.getEditOrderButtonElement().click();
			Log.info("等待支付页面“修改订单按钮”，已点击。");
		}catch(Exception e){
			Log.error("等待支付页面“修改订单按钮”，未点击。");
		}
	}
	//等待支付页面-取消订单-点击
		public static void excuteCancelOrderBtn() throws Exception{
			try{
				StayPaymentPage.getCancelOrderButtonElement().click();
				Log.info("等待支付页面“取消订单按钮”，已点击。");
			}catch(Exception e){
				Log.error("等待支付页面“取消订单按钮”，未点击。");
			}
		}
	//等待支付页面-确认支付订单-点击
		public static void excuteConfirmPayOrderBtn() throws Exception{
			try{
				StayPaymentPage.getConfirmPayOrderButtonElement().click();
				Log.info("等待支付页面“确认支付订单按钮”，已点击。");
			}catch(Exception e){
				Log.error("等待支付页面“确认支付订单按钮”，未点击。");
			}
		}
	
	
}

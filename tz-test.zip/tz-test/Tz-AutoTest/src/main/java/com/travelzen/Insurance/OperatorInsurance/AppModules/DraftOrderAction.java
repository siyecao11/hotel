package com.travelzen.Insurance.OperatorInsurance.AppModules;
/**
 * qiqi.wang
 * */
import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.DraftOrderPage;
import com.travelzen.Utility.LogCenter.Log;

public class DraftOrderAction
{
	public static WebDriver webdriver;
	public static void transmitDriver(WebDriver driver) throws Exception{
		webdriver = driver;
		DraftOrderPage.getDriver(webdriver);
	}
	//订单草稿页面-提交订单-点击
	public static void excuteSubmitOrderBtn() throws Exception{
		try{
			DraftOrderPage.getSubmitOrderButtonElement().click();
			Log.info("订单草稿页面“提交订单”按钮，已点击。");
		}catch(Exception e){
			Log.error("订单草稿页面“提交订单”按钮，未点击。");
		}
	}
	//订单草稿页面-修改订单-点击
	public static void excuteEditOrderBtn() throws Exception{
		try{
			DraftOrderPage.getEditOrderButtonElement().click();
			Log.info("订单草稿页面“修改订单”按钮，已点击。");
		}catch(Exception e){
			Log.error("订单草稿页面“修改订单”按钮，未点击。");
		}
	}
	//订单草稿页面-取消订单-点击
		public static void excuteCancelOrderBtn() throws Exception{
			try{
				DraftOrderPage.getCancelOrderButtonElement().click();
				Log.info("订单草稿页面“取消订单”按钮，已点击。");
			}catch(Exception e){
				Log.error("订单草稿页面“取消订单”按钮，未点击。");
			}
		}
	//订单草稿页面-确认提交-点击
		public static void excuteConfirmSubmitOrderBtn() throws Exception{
			try{
				DraftOrderPage.getConfirmSubmitOrderButtonElement().click();
				Log.info("订单草稿页面“确认提交订单”按钮，已点击。");
			}catch(Exception e){
				Log.error("订单草稿页面“确认提交订单”按钮，未点击。");
			}
		}	
	
}

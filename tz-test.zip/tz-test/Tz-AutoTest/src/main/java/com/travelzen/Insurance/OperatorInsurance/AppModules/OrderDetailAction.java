package com.travelzen.Insurance.OperatorInsurance.AppModules;
/**
 * author:qiqi.wang
 * */

import org.openqa.selenium.WebDriver;
import com.travelzen.Insurance.OperatorInsurance.PageObjects.OrderDetailsPage;
import com.travelzen.Utility.LogCenter.Log;


public class OrderDetailAction
{
	public static WebDriver webdriver;
	
	public static void transmitDriver(WebDriver driver) throws Exception{
		webdriver = driver;
		OrderDetailsPage.getDriver(webdriver);
	} 
	
	//点击添加订单备注
	public static void excuteAddOrderRemark() throws Exception{
		OrderDetailsPage.getAddRemarkElement().click();
		Log.info("订单详情页面“订单备注”按钮，已点击。");
	}
	//添加客户备注
	public static void excuteAddCustomerRemark(String customerRemark) throws Exception{
		OrderDetailsPage.getCustomerRemarkinputElement().sendKeys(customerRemark);
		Log.info("订单详情页面“客户备注”输入框，已填写。");
	}
	
	//添加内部备注
		public static void excuteAddInsideRemark(String insideRemark) throws Exception{
			OrderDetailsPage.getInsideRemarkinputElement().sendKeys(insideRemark);
			Log.info("订单详情页面“内部备注”输入框，已填写。");
		}
	//点击保存按钮
		public static void excuteSaveRemark() throws Exception{
			OrderDetailsPage.getSaveRemarkElement().click();
			Log.info("订单详情页面“保存”按钮，已点击。");
		}
	//获取订单号
	public static String excuteOrderID() throws Exception{
		String OrderID = OrderDetailsPage.getOrderIDElement().getText();
		Log.info("订单详情页“订单号”已获取。"+OrderID);
		return OrderID;
	}
	
	//获取客户姓名-文本
		public static String excuteCustomerName() throws Exception{
			String CustomerName = OrderDetailsPage.getCustomerNameElement().getText();
			Log.info("订单详情页面“客户姓名”已获取。"+CustomerName);
			return CustomerName;
		}
		
		//获取联系人姓名-文本
		public static String excuteConstactName() throws Exception{
			String ConstactName = OrderDetailsPage.getConstactNameElement().getText();
			Log.info("订单详情页面“联系人姓名”已获取"+ConstactName);
			return ConstactName;
		}
		
		//获取联系人电话-文本
		public static String excuteConstactTel() throws Exception{
			String ConstactTel =OrderDetailsPage.getConstactTelElement().getText();
			Log.info("订单详情页面“联系人电话”以获取。"+ConstactTel);
			return ConstactTel;
		}
		
		//获取联系人手机-文本
		public static String excuteConstactMobile() throws Exception{
			String ConstactMobile =OrderDetailsPage.getConstactMobileElement().getText();
			Log.info("订单详情页面“联系人手机”已获取。"+ConstactMobile);
			return ConstactMobile;
		}
		
		//获取客户备注-输入框
		public static String excuteCustomerRemarkinput() throws Exception{
			String CustomerRemark =OrderDetailsPage.getCustomerRemarkinputElement().getText();
			Log.info("订单详情页面“客户备注”已获取。"+CustomerRemark);
			return CustomerRemark;
		}
		
		//获取内部备注-输入框
		public static String excuteInsideRemarkinput() throws Exception{
			String InsideRemark = OrderDetailsPage.getInsideRemarkinputElement().getText();
			Log.info("订单详情页面“内部备注”已获取。"+InsideRemark);
			return InsideRemark;
		}
		
		//获取产品名称-文本
		public static String excuteProductName() throws Exception{
			String ProductName = OrderDetailsPage.getProductNameElement().getText();
			Log.info("订单详情页面“产品名称”已获取。"+ProductName);
			return ProductName;
		}
		
		//获取险种编号-文本
		public static String excuteProductID() throws Exception{
			String ProductID = OrderDetailsPage.getProductIDElement().getText();
			Log.info("订单详情页面“险种编号”已获取。"+ProductID);
			return ProductID;
		}
		
		//获取保险险种-文本
		public static String excuteInsuranceType() throws Exception{
			String InsuranceType = OrderDetailsPage.getInsuranceTypeElement().getText();
			Log.info("订单详情页面“保险险种”已获取。"+InsuranceType);
			return InsuranceType;
		}
		
		//获取保险期限-文本
		public static String excuteInsuranceTime() throws Exception{
			String InsuranceTime = OrderDetailsPage.getInsuranceTimeElement().getText();
			Log.info("订单详情页面“保险期限”已获取。"+InsuranceTime);
			return InsuranceTime;
		}
		
		//点单详情页面-最高保额-文本
		public static String excuteInsuranceMaxCoverage() throws Exception{
			String InsuranceMaxCoverage = OrderDetailsPage.getInsuranceMaxCoverageElement().getText();
			Log.info("订单详情页面“最高保额”已获取。"+InsuranceMaxCoverage);
			return InsuranceMaxCoverage;
		}
		
		//获取保险费用-文本
		public static String excuteInsuranceCash() throws Exception{
			String InsuranceCash = OrderDetailsPage.getInsuranceCashElement().getText();
			Log.info("订单详情页面“保险费用”已获取。"+InsuranceCash);
			return InsuranceCash;
		}
		
		//获取被保人姓名-文本
		public static String excuteRecognizeeName() throws Exception{
			String RecognizeeName = OrderDetailsPage.getRecognizeeNameElement().getText();
			Log.info("订单详情页面“被保人姓名”已获取。"+RecognizeeName);
			return RecognizeeName;
		}
		
		//获取被保人证件类型-文本
		public static String excuteRecognizeeCardStyle() throws Exception{
			String RecognizeeCardStyle = OrderDetailsPage.getRecognizeeCardStyleElement().getText();
			Log.info("订单详情页面“被保人证件类型”已获取。"+RecognizeeCardStyle);
			return RecognizeeCardStyle;
		}
		
		//获取被保人证件号码-文本
		public static String excuteRecognizeeCardID() throws Exception{
			String RecognizeeCardID = OrderDetailsPage.getRecognizeeCardIDElement().getText();
			Log.info("订单详情页面“被保人证件号码”已获取。"+RecognizeeCardID);
			return RecognizeeCardID;
		}
		
		//获取被保人性别-文本
		public static String excuteRecognizeeSex() throws Exception{
			String RecognizeeSex = OrderDetailsPage.getRecognizeeSexElement().getText();
			Log.info("订单详情页面“被保人性别”已获取。"+RecognizeeSex);
			return RecognizeeSex;
		}
		
		//获取被保人出生日期-文本
		public static String excuteRecognizeeBirthday() throws Exception{
			String RecognizeeBirthday = OrderDetailsPage.getRecognizeeBirthdayElement().getText();
			Log.info("订单详情页面“被保人出生日期”已获取。"+RecognizeeBirthday);
			return RecognizeeBirthday;
		}
		
		//获取被保人手机号码-文本
		public static String excuteRecognizeeMobilePhone() throws Exception{
			String RecognizeeMobilePhone = OrderDetailsPage.getRecognizeeMobilePhoneElement().getText();
			Log.info("订单详情页面“被保人手机号码”已获取。"+RecognizeeMobilePhone);
			return RecognizeeMobilePhone;
		}
		
		//获取保险生效日期-文本
		public static String excuteInsuranceStartDate() throws Exception{
			String InsuranceStartDate = OrderDetailsPage.getInsuranceStartDateElement().getText();
			Log.info("订单详情页面“保险生效日期”已获取。"+InsuranceStartDate);
			return InsuranceStartDate;
		}
		
		//获取保单号-文本
		public static String excutePolicyID() throws Exception{
			String PolicyID = OrderDetailsPage.getPolicyIDElement().getText();
			Log.info("订单详情页面“保单号”已获取。"+PolicyID);
			return PolicyID;
		}
		
		//获取保险份数-文本
		public static String excuteInsuranceNumber() throws Exception{
			String InsuranceNumber = OrderDetailsPage.getInsuranceNumberElement().getText();
			InsuranceNumber = InsuranceNumber.substring(0, 1);
			Log.info("订单详情页面“保险份数”已获取。"+InsuranceNumber);
			return InsuranceNumber;
		}
		
		//获取订单状态-文本
		public static String excuteOrderState() throws Exception{
			String OrderState = OrderDetailsPage.getOrderStateElement().getText();
			Log.info("订单详情页面“订单状态”已获取。"+OrderState);
			return OrderState;
		}
		
		//获取投保人姓名-文本
		public static String excuteApplicantName() throws Exception{
			String ApplicantName = OrderDetailsPage.getApplicantNameElement().getText();
			Log.info("订单详情页面“投保人姓名”已获取。"+ApplicantName);
			return ApplicantName;
		}
		
		//获取证件类型-文本
		public static String excuteApplicantCardStyle() throws Exception{
			String ApplicantCardStyle = OrderDetailsPage.getApplicantCardStyleElement().getText();
			Log.info("订单详情页面“证件类型”已获取。"+ApplicantCardStyle);
			return ApplicantCardStyle;
		}
		
		//获取证件号码-文本
		public static String excuteApplicantCardID() throws Exception{
			String ApplicantCardID = OrderDetailsPage.getApplicantCardIDElement().getText();
			Log.info("订单详情页面“证件号码”已获取。"+ApplicantCardID);
			return ApplicantCardID;
		}
		
		//获取投保人手机号码-文本
		public static String excuteApplicantMobilePhone() throws Exception{
			String ApplicantMobilePhone = OrderDetailsPage.getApplicantMobilePhoneElement().getText();
			Log.info("订单详情页面“投保人手机号码”已获取。"+ApplicantMobilePhone);
			return ApplicantMobilePhone;
		}
		
		//获取应收合计-文本
		public static String excuteTotalCast() throws Exception{
			String TotalCast = OrderDetailsPage.getTotalCastElement().getAttribute("value");
			Log.info("订单详情页面“应收合计”已获取。"+TotalCast);
			return TotalCast;
		}
		
		//获取保险份数-文本
		public static String excuteInsuranceNum() throws Exception{
			String InsuranceNum = OrderDetailsPage.getInsuranceNumElement().getAttribute("value");
			Log.info("订单详情页面“保险份数”已获取。"+InsuranceNum);
			return InsuranceNum;
		}
		
		//获取保险单价-文本
		public static String excuteInsurancePrice() throws Exception{
			String InsurancePrice = OrderDetailsPage.getInsurancePriceElement().getAttribute("value");
			Log.info("订单详情页面“保险单价”已获取。"+InsurancePrice);
			return InsurancePrice;
		}
	
		//点击订单管理按钮
		public static void excuteOrderManagement() throws Exception{
			OrderDetailsPage.getOrderManagementElement().click();
			Log.info("订单详情页面“订单管理”按钮，已点击。");
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

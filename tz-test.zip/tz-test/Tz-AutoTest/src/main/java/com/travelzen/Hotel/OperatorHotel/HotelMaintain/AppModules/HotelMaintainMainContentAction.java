/*
 * 
 * 酒店维护/新增酒店/酒店信息
 * 王琪琪
 * 2015/08/10
 * 
 * */
package com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.EditHotelMaintainMainContentPage;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.HotelMantainMainContentPage;
import com.travelzen.Utility.Assertion.*;
import com.travelzen.Utility.DataDriver.*;
import com.travelzen.Utility.LogCenter.*;
public class HotelMaintainMainContentAction {

	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {
		
		HotelMantainMainContentPage.getDriver(driver);
		EditHotelMaintainMainContentPage.getDriver(driver);
	}
	
	//进入酒店信息页面
	@Test
	public static void SelectManager(String manager) throws Exception {
		//Click hotel menItem, goto hotel HomePage
		Select select =new Select(HotelMantainMainContentPage.SignManager());
		select.selectByVisibleText(manager);
		Log.info(" ***********SignManager is clicked ***********");
	}
	//点击编辑基本信息按钮
	@Test
	public static void EditbuttonCLick() throws Exception{
		HotelMantainMainContentPage.EditButton().click();
		Log.info(" ***********Editbutton is clicked ***********");
	}
    //输入酒店名称
	@Test
	public static void HotelName(String HotelName) throws Exception{
		HotelMantainMainContentPage.HotelName().sendKeys(HotelName);
		Log.info(" ***********HotelName is Writed ***********");
	}
	//输入酒店查询排序
	@Test
	public static void DisplayOrder(String DisplayOrder) throws Exception{
		HotelMantainMainContentPage.DisplayOrder().sendKeys(DisplayOrder);
		Log.info(" ***********DisplayOrder is writed ***********");
	}
	//勾选推荐酒店
	@Test
	public static void IsReCommend() throws Exception{
		HotelMantainMainContentPage.IsRecommend().click();
		Log.info(" ***********IsRecommend is checked ***********");
	}
	//连锁品牌
	@Test
	public static void BrandSelect(String BrandSelect) throws Exception{
		Select select = new Select(HotelMantainMainContentPage.BrandSelect());
		select.selectByVisibleText(BrandSelect);
		Log.info(" ***********BrandSelect is selected ***********");
	}
	//酒店类型
	@Test
	public static void HotelStyle(String HotelStyle) throws Exception{
		Select hotelStyle =new Select(HotelMantainMainContentPage.HotelStyle());
		hotelStyle.selectByVisibleText(HotelStyle);
		Log.info(" ***********hotelStyle is selected ***********");
	}
	//酒店星级
	@Test
	public static void HotalStar(String HotalStar) throws Exception{
		Select hotalstar = new Select(HotelMantainMainContentPage.HotelStar());
		hotalstar.selectByVisibleText(HotalStar);
		Log.info(" ***********hotelStar is selected ***********");
	}
	//酒店大区
	@Test
	public static void Region(String Region) throws Exception{
		Select region = new Select(HotelMantainMainContentPage.Region());
		region.selectByVisibleText(Region);
		Log.info(" ***********Region is selected ***********");
	}
	//酒店省份
	@Test
	public static void Province(String Province) throws Exception{
		Select province = new Select(HotelMantainMainContentPage.Province());
		province.selectByVisibleText(Province);
		Log.info(" ***********Province is selected ***********");
	}
	//酒店所在城市
	@Test
	public static void City(String City) throws Exception{
		Select city = new Select(HotelMantainMainContentPage.City());
		city.selectByVisibleText(City);
		Log.info(" ***********City is selected ***********");
	}
	//酒店行政区
	@Test
	public static void District(String District) throws Exception{
		Select district = new Select(HotelMantainMainContentPage.District());
		district.selectByVisibleText(District);
		Log.info(" ***********District is selected ***********");
	}
	//酒店商业区
	@Test
	public static void Commercial() throws Exception{
		HotelMantainMainContentPage.Commercial().click();
		Log.info(" ***********Commercial is clicked ***********");
	}
	
	@Test
	public static void SelectCommercial() throws Exception{
		HotelMantainMainContentPage.SelectCommercial().click();
		Log.info(" ***********SelectCommercial is clicked ***********");
	}
	//酒店地址
	@Test
	public static void HotelAdress(String HotelAdress) throws Exception{
		HotelMantainMainContentPage.HotelAddress().sendKeys(HotelAdress);
		Log.info(" ***********HotelAdress is writed ***********");
	}
	//纬度
	@Test
	public static void latitude(String latitude) throws Exception{
		HotelMantainMainContentPage.Latitude().sendKeys(latitude);
		Log.info(" ***********latitude is writed ***********");
	}
	//经度
	@Test
	public static void longitude(String longitude) throws Exception{
		HotelMantainMainContentPage.Longitude().sendKeys(longitude);
		Log.info(" ***********longitude is writed ***********");
	}
	
	//酒店电话
	@Test
	public static void MainPhone(String MainPhone) throws Exception{
		HotelMantainMainContentPage.MainPhone().sendKeys(MainPhone);
		Log.info(" ***********Mainphone is writed ***********");
	}
	//酒店网址
	@Test
	public static void Website(String Website) throws Exception{
		HotelMantainMainContentPage.Website().sendKeys(Website);
		Log.info(" ***********Website is writed ***********");
	}
	//酒店电子邮箱
	@Test
	public static void Email(String Email) throws Exception{
		HotelMantainMainContentPage.Email().sendKeys(Email);
		Log.info(" ***********Email is writed ***********");
	}
	//酒店开业时间
	@Test
	public static void OpenDate(String OpenDate) throws Exception{
		HotelMantainMainContentPage.OpenDate().sendKeys(OpenDate);
		Log.info(" ***********OpenDate is writed ***********");
	}
	//酒店装修时间
	@Test
	public static void RenovationDate(String RenovationDate) throws Exception{
		HotelMantainMainContentPage.RenovationDate().sendKeys(RenovationDate);
		Log.info(" ***********RenovationDate is writed ***********");
	}
	//酒店楼层
	@Test
	public static void Storey(String Storey) throws Exception{
		HotelMantainMainContentPage.Storey().sendKeys(Storey);
		Log.info(" ***********Storey is writed ***********");
	}
	//酒店房间数
	@Test
	public static void NoofRoom(String BoofRoom) throws Exception{
		HotelMantainMainContentPage.NoofRoom().sendKeys(BoofRoom);
		Log.info(" ***********NoofRoom is writed ***********");
	}
	//酒店介绍
	@Test
	public static void Summary(String Summary) throws Exception{
		HotelMantainMainContentPage.Summary().sendKeys(Summary);
		Log.info(" ***********Summary is writed ***********");
	}
	//点击保存按钮，保存酒店基本信息
	@Test
	public static void Savebutton() throws Exception{
		HotelMantainMainContentPage.Save_button().click();
		Log.info(" ***********Savebutton is writed ***********");
	}
	//点击取消保存按钮，取消保存酒店基本信息
	@Test
	public static void CancleSavebutton() throws Exception{
		HotelMantainMainContentPage.CancleSave_button().click();
		Log.info(" ***********CancleSavebutton is writed ***********");
	}
	
	//选择签约经理
	/********************************************************************************************/
	@Test
	public static void SaveManagerButtom() throws Exception{
		HotelMantainMainContentPage.ManagerSaveButton().click();
		Log.info(" ***********SaveManagerButtom is clicked ***********");
	}
	
	
	
	//点击编辑照片按钮
	/********************************************************************************************/
	@Test
	public static void editPhotoButton() throws Exception{
		HotelMantainMainContentPage.Edit_HotelPhoto_Button().click();
		Log.info(" ***********editPhotoButton is clicked ***********");
	}
	//上传照片
	@Test
	public static void addPhoto() throws Exception{ 
		String filePath ="E:\\tz\\TzAutoTest\\01.jpg";
		HotelMantainMainContentPage.AddPhoto().sendKeys(filePath);
		Log.info(" ***********addPhoto is added ***********");
	}
	
	//保存照片
	@Test
	public static void submitPhotoButton() throws Exception{
		HotelMantainMainContentPage.Submitphoto().click();
		Log.info(" ***********submitPhotoButton is clicked ***********");
	}
	
	
	
	
	
	
	//编辑酒店规定
	/********************************************************************************************/
	
	
	//点击编辑酒店规定按钮
	@Test
	public static void editHotelRulesButton() throws Exception{
		HotelMantainMainContentPage.EditHotelRulesButton().click();
		Log.info(" ***********editHotelRulesButton is clicked ***********");
	}
	//选择宾客类型
	@Test
	public static void GuestTypeCheckbox() throws Exception{
		if (!HotelMantainMainContentPage.GuestTypeCheckbox1().isSelected())
		{
			HotelMantainMainContentPage.GuestTypeCheckbox1().click();
		}
		Log.info(" ***********GuestTypeCheckbox is clicked ***********");
	}
	//填写宾客备注
	@Test
	public static void GuestRemark(String GuestRemark) throws Exception{
		HotelMantainMainContentPage.Guestremark().sendKeys(GuestRemark);
		Log.info(" ***********GuestRemark is writed ***********");
	}
	
	//儿童标准年龄选择
	@Test
	public static void AgeSelect(String AgeSelect) throws Exception{
		Select ageselect = new Select(HotelMantainMainContentPage.AgeSelect());
		ageselect.selectByVisibleText(AgeSelect);
		Log.info(" ***********AgeSelect is selected ***********");
	}
	//儿童标准身高选择
	@Test
	public static void HeightSelect(String HeightSelect) throws Exception{
		Select heightselect = new Select(HotelMantainMainContentPage.HegihtSelect());
		heightselect.selectByVisibleText(HeightSelect);
		Log.info(" ***********HeightSelect is selected ***********");
	}
	//宠物选择
	@Test
	public static void PetAllowed(int PetAllowed) throws Exception{
		HotelMantainMainContentPage.PetAllowed().get(PetAllowed).click();
		Log.info(" ***********PetAllowed is selected ***********");
	}
	//入住时间
	@Test
	public static void CheckinTime(String CheckinTime) throws Exception{
		Select checkintime = new Select(HotelMantainMainContentPage.CheckinTime());
		checkintime.selectByVisibleText(CheckinTime);
		Log.info(" ***********CheckinTime is selected ***********");
	}
	
	//get 具体的入住时间，用于后面的断言检查点
	@Test
	public static String excuteCheckinTime() throws Exception{
		
		String checkin = HotelMantainMainContentPage.getCheckinTime().getFirstSelectedOption().getText();
		return checkin;
	}
	
	//退房时间
	@Test
	public static void CheckoutTime(String CheckoutTime) throws Exception{
		Select checkouttime = new Select(HotelMantainMainContentPage.CheckoutTime());
		checkouttime.selectByVisibleText(CheckoutTime);
		Log.info(" ***********CheckoutTime is selected ***********");
	}
	
	//get 具体的退房时间，用于后面的断言检查点
	@Test
	public static String excuteCheckoutTime() throws Exception{
		
		String checkout = HotelMantainMainContentPage.getCheckoutTime().getFirstSelectedOption().getText();
		return checkout;
	}
	
	//get 具体的变更取消规则，用于后面的断言检查点
	@Test
	public static String excuteCancelPolicy() throws Exception{
		
		String calclePloicy = HotelMantainMainContentPage.getCancelPolicy().getAttribute("value").toString();
		return calclePloicy;
	}
	
	//入住前几天几点可以退全部房费
	@Test
	public static void CheckinDay(String CheckinDay) throws Exception{
		HotelMantainMainContentPage.CheckinDay().sendKeys(CheckinDay);
		Log.info(" ***********CheckinDay is writed ***********");
	}
	
	@Test
	public static void CheckinPoints(String CheckinPoint) throws Exception{
		HotelMantainMainContentPage.CheckinPoints().sendKeys(CheckinPoint);
		Log.info(" ***********CheckinPoints is writed ***********");
	}
	
	@Test
	public static void CancelTerms(String CancelTerms) throws Exception{
		Select cancelterms =new Select(HotelMantainMainContentPage.CancelTerms());
		cancelterms.selectByVisibleText(CancelTerms);
		Log.info(" ***********CancelTerms is selected ***********");
	}
	//添加按钮
	@Test
	public static void AddRulesButton() throws Exception{
		HotelMantainMainContentPage.AddrulesButton().click();
		Log.info(" ***********AddRulesButton is clicked ***********");
	}
	
	//保存酒店规定
	@Test
	public static void SaveRulesButton() throws Exception{
		HotelMantainMainContentPage.SaveRulesButton().click();
		Log.info(" ***********SaveRulesButton is clicked ***********");
	}
	
	
	
	//编辑服务费用
	/********************************************************************************************/
	//点击编辑按钮
	@Test
	public static void EditServiceCharge() throws Exception{
		HotelMantainMainContentPage.EditServiceCharge().click();
		Log.info(" ***********EditServiceCharge is clicked ***********");
	}
	
	//设置早餐费费用
	@Test
	public static void BreakerCharge(String BreakerCharge) throws Exception{
		HotelMantainMainContentPage.BreakerCharge().sendKeys(BreakerCharge);
		Log.info(" ***********BreakerCharge is writed ***********");
	}
	//设置宽带费用
	@Test
	public static void NetCharge(String NetCharge) throws Exception{
		HotelMantainMainContentPage.NetCharge().sendKeys(NetCharge);
		Log.info(" ***********NetCharge is writed ***********");
	}
	//保存服务费用
	@Test
	public static void SaveServiceCharge() throws Exception{
		HotelMantainMainContentPage.SaveServiceCharge().click();
		Log.info(" ***********SaveServiceCharge is clicked ***********");
	}
	
	
	
	
	//编辑服务设施
	/********************************************************************************************/
	//点击编辑服务设施
	@Test
	public static void EditServerFacility() throws Exception{
		HotelMantainMainContentPage.EditServerFacility().click();
		Log.info(" ***********EditServerFacility is clicked ***********");
	}
	//勾选服务设施
	@Test
	public static void BusinessCenter(int BusinessCenter) throws Exception{
		HotelMantainMainContentPage.BusinessCenter().get(BusinessCenter).click();
		Log.info(" ***********BusinessCenter is clicked ***********");
	}
	//保存服务设施
	@Test
	public static void SaveBusinessCenter() throws Exception{
		HotelMantainMainContentPage.SaveBusinessCenter().click();
		Log.info(" ***********SaveBusinessCenter is clicked ***********");
	}
	
	
    //编辑备注
	/********************************************************************************************/
	//点击编辑备注按钮
	@Test
	public static void EditHotelRemark() throws Exception{
		HotelMantainMainContentPage.EditHotelRemark().click();
		Log.info(" ***********EditHotelRemark is clicked ***********");
	}
	//填写内部备注
	@Test
	public static void PrivateRemark(String PrivateRemak) throws Exception{
		HotelMantainMainContentPage.PrivateRemark().sendKeys(PrivateRemak);
		Log.info(" ***********PrivateRemark is writed ***********");
	}
	//填写外部备注
	@Test
	public static void PublicRemark(String PublicRemark) throws Exception{
		HotelMantainMainContentPage.PublicRemark().sendKeys(PublicRemark);
		Log.info(" ***********PublicRemark is writed ***********");
	}
	//保存备注
	@Test
	public static void SaveRemarkButton() throws Exception{
		HotelMantainMainContentPage.SaveRemarkButton().click();
		Log.info(" ***********SaveRemarkButton is clicked ***********");
	}
	
	
	/********************************************************************************************/
	
	//进入供应商信息界面
	@Test
	public static void ProviderButton() throws Exception{
		HotelMantainMainContentPage.ProviderButton().click();
		Log.info(" ***********ProviderButton is clicked ***********");
	}
	
	
	
	
	
	
	
	
	
	/********************************************************************************************/
	//添加酒店基本信息页面的断言
	//点击编辑酒店信息按钮
	@Test
	public static void clickEditHotelButton() throws Exception{
		EditHotelMaintainMainContentPage.EditButton().click();
		Log.info("***********Hotel is Clicked ***********");
		}
	//比较酒店名称的一致性
	@Test
	public static void assertHotelName() throws Exception{
		String pageHotelName = EditHotelMaintainMainContentPage.editHotelName().getAttribute("value");
		ExcelAction.setValue("Hotel/ActualValue.xls", "hotelName", pageHotelName);
		String hotelName = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "hotelName");
		Assertion.verifyEquals(pageHotelName, hotelName,"HotelName is right");
	}
	
	//比较酒店查询排序的一致性
	@Test
	public static void assertDisplayOrder() throws Exception{
		String pageDisplayOrder = EditHotelMaintainMainContentPage.editDisplayOrder().getAttribute("value");
		ExcelAction.setValue("Hotel/ActualValue.xls", "displayOrder", pageDisplayOrder);
		String displayOrder = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "displayOrder");
		Assertion.verifyEquals(pageDisplayOrder, displayOrder,"DisplayOrder is right");
	}

		//比较连锁品牌的一致性
		@Test
		public static void assertBrandSelect() throws Exception{
			String pageBrandSelect = EditHotelMaintainMainContentPage.getBrandSelect();
			ExcelAction.setValue("Hotel/ActualValue.xls", "brandSelect", pageBrandSelect);
			String brandSelect = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "brandSelect");
			Assertion.verifyEquals(pageBrandSelect, brandSelect,"BrandSelect is right");
		}
		//比较酒店类型的一致性
		@Test
		public static void assertHotelStyle() throws Exception{
			String pageHotelStyle =EditHotelMaintainMainContentPage.getHotelStyle();
			String brandSelect = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "hotelStyle");
			ExcelAction.setValue("Hotel/ActualValue.xls", "hotelStyle", pageHotelStyle);
			Assertion.verifyEquals(pageHotelStyle, brandSelect,"HotelStyle is right");
		}
		//比较酒店星级的一致性
		@Test
		public static void assertHotalStar() throws Exception{
			String pageHotelStar = EditHotelMaintainMainContentPage.getHotelStar();
			ExcelAction.setValue("Hotel/ActualValue.xls", "hotalStar", pageHotelStar);
			String brandSelect = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "hotalStar");
			Assertion.verifyEquals(pageHotelStar, brandSelect,"HotalStar is right");
		}
		//比较酒店大区的一致性
		@Test
		public static void assertRegion() throws Exception{
			String pageRegion = EditHotelMaintainMainContentPage.getRegion();
			ExcelAction.setValue("Hotel/ActualValue.xls", "region", pageRegion);
			String region = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "region");
			Assertion.verifyEquals(pageRegion, region,"Region is right");
		}
		//比较酒店省份的一致性
		@Test
		public static void assertProvince() throws Exception{
			String pageProvince = EditHotelMaintainMainContentPage.getProvince();
			ExcelAction.setValue("Hotel/ActualValue.xls", "province", pageProvince);
			String province = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "province");
			Assertion.verifyEquals(pageProvince, province,"Province is right");
		}
		//比较酒店所在城市的一致性
		@Test
		public static void assertCity() throws Exception{
			String pageCity = EditHotelMaintainMainContentPage.getCity();
			ExcelAction.setValue("Hotel/ActualValue.xls", "city", pageCity);
			String city = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "city");
			Assertion.verifyEquals(pageCity, city,"City is right");
		}
		//比较酒店所在行政区一致性
		@Test
		public static void assertDistrict() throws Exception{
			String pageDistrict = EditHotelMaintainMainContentPage.getDistrict();
			ExcelAction.setValue("Hotel/ActualValue.xls", "district", pageDistrict);
			String district = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "district");
			Assertion.verifyEquals(pageDistrict, district,"District is right");
		}
		//比较酒店地址一致性
		@Test
		public static void assertHotelAdress() throws Exception{
			String pageHotelAdress = EditHotelMaintainMainContentPage.editHotelAddress().getAttribute("value");
			ExcelAction.setValue("Hotel/ActualValue.xls", "hotelAdress", pageHotelAdress);
			String hotelAdress = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "hotelAdress");
			Assertion.verifyEquals(pageHotelAdress, hotelAdress,"HotelAdress is right");
		}
		//比较纬度一致性
		@Test
		public static void assertlatitude() throws Exception{
			String pageLatitude = EditHotelMaintainMainContentPage.editLatitude().getAttribute("value");
			ExcelAction.setValue("Hotel/ActualValue.xls", "latitude", pageLatitude);
			String latitude = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "latitude");
			Assertion.verifyEquals(pageLatitude, latitude,"Latitude is right");
		}
		//比较经度一致性
		@Test
		public static void assertLongitude() throws Exception{
			String pageLongitude = EditHotelMaintainMainContentPage.editLongitude().getAttribute("value");
			ExcelAction.setValue("Hotel/ActualValue.xls", "longitude", pageLongitude);
			String longitude = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "longitude");
			Assertion.verifyEquals(pageLongitude, longitude,"Longitude is right");
		}
		
		//比较酒店电话一致性
		@Test
		public static void assertMainPhone() throws Exception{
			String pageMainPhone = EditHotelMaintainMainContentPage.editMainPhone().getAttribute("value");
			ExcelAction.setValue("Hotel/ActualValue.xls", "mainPhone", pageMainPhone);
			String mainPhone = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "mainPhone");
			Assertion.verifyEquals(pageMainPhone, mainPhone,"MainPhone is right");
		}
		//比较酒店网址一致性
		@Test
		public static void assertWebsite() throws Exception{
			String pageWebsite = EditHotelMaintainMainContentPage.editWebsite().getAttribute("value");
			ExcelAction.setValue("Hotel/ActualValue.xls", "website", pageWebsite);
			String website = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "website");
			Assertion.verifyEquals(pageWebsite, website,"Website is right");
		}
		//比较酒店电子邮箱一致性
		@Test
		public static void assertEmail() throws Exception{
			String pageEmail = EditHotelMaintainMainContentPage.editEmail().getAttribute("value");
			ExcelAction.setValue("Hotel/ActualValue.xls", "email", pageEmail);
			String email = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "email");
			Assertion.verifyEquals(pageEmail, email,"Email is right");
		}
		//比较酒店开业时间一致性
		@Test
		public static void assertOpenDate() throws Exception{
			String pageOpenDate = EditHotelMaintainMainContentPage.editOpenDate().getAttribute("value");
			ExcelAction.setValue("Hotel/ActualValue.xls", "openDate", pageOpenDate);
			String openDate = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "openDate");
			Assertion.verifyEquals(pageOpenDate, openDate,"OpenDate is right");
		}
		//比较酒店装修时间一致性
		@Test
		public static void assertRenovationDate() throws Exception{
			String pageRenovationDate = EditHotelMaintainMainContentPage.editRenovationDate().getAttribute("value");
			ExcelAction.setValue("Hotel/ActualValue.xls", "renovationDate", pageRenovationDate);
			String renovationDate = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "renovationDate");
			Assertion.verifyEquals(pageRenovationDate, renovationDate,"RenovationDate is right");
		}
		//比较酒店楼层一致性
		@Test
		public static void assertStorey() throws Exception{
			String pageStorey = EditHotelMaintainMainContentPage.editStorey().getAttribute("value");
			ExcelAction.setValue("Hotel/ActualValue.xls", "storey", pageStorey);
			String storey = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "storey");
			Assertion.verifyEquals(pageStorey, storey,"Storey is right");
		}
		//比较酒店房间数一致性
		@Test
		public static void assertNoofRoom() throws Exception{
			String pageNoofRoom = EditHotelMaintainMainContentPage.editNoofRoom().getAttribute("value");
			ExcelAction.setValue("Hotel/ActualValue.xls", "noofRoom", pageNoofRoom);
			String noofRoom = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "noofRoom");
			Assertion.verifyEquals(pageNoofRoom, noofRoom,"NoofRoom is right");
		}
		//比较酒店介绍一致性
		@Test
		public static void assertSummary() throws Exception{
			String pageSummary = EditHotelMaintainMainContentPage.editSummary().getText();
			ExcelAction.setValue("Hotel/ActualValue.xls", "summary", pageSummary);
			String summary =  ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "summary");
			Assertion.verifyEquals(pageSummary, summary,"Summary is right");
		}
	//点击取消保存酒店信息按钮
		@Test
		public static void assertCancleHotel() throws Exception{
			EditHotelMaintainMainContentPage.editCancleSave_button().click();
		}
		
		
		
	/******************************编辑酒店规定******************************/
	//点击编辑酒店规定按钮
		@Test
		public static void assertHotelRulesButton() throws Exception{
			EditHotelMaintainMainContentPage.editHotelRulesButton().click();
		}
		/*//选择宾客类型
		@Test
		public static void GuestTypeCheckbox() throws Exception{
			if (!HotelMantainMainContentPage.GuestTypeCheckbox1().isSelected())
			{
				HotelMantainMainContentPage.GuestTypeCheckbox1().click();
			}
			Log.info(" ***********GuestTypeCheckbox is clicked ***********");
		}*/
		
		//填写宾客备注
		@Test
		public static void assertGuestRemark() throws Exception{
			String pageGuestRemark = EditHotelMaintainMainContentPage.editGuestremark().getAttribute("value");
			ExcelAction.setValue("Hotel/ActualValue.xls", "guestRemark", pageGuestRemark);
			System.out.println(pageGuestRemark);
			String guestRemark = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "guestRemark");
			Assertion.verifyEquals(pageGuestRemark, guestRemark,"GuestRemark is right");
		}
		
		//儿童标准年龄选择
		@Test
		public static void assertAgeSelect() throws Exception{
			String pageAgeSelect = EditHotelMaintainMainContentPage.getAgeSelect();
			ExcelAction.setValue("Hotel/ActualValue.xls", "ageSelect", pageAgeSelect);
			String ageSelect = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "ageSelect");
			Assertion.verifyEquals(pageAgeSelect, ageSelect,"AgeSelect is right");
		}
		//儿童标准身高选择
		@Test
		public static void assertHeightSelect() throws Exception{
			String pageHeightSelect = EditHotelMaintainMainContentPage.getHegihtSelect();
			ExcelAction.setValue("Hotel/ActualValue.xls", "heightSelect", pageHeightSelect);
			String heightSelect = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "heightSelect");
			Assertion.verifyEquals(pageHeightSelect, heightSelect,"HeightSelect is right");
		}
		/*//宠物选择
		@Test
		public static void PetAllowed(int PetAllowed) throws Exception{
			HotelMantainMainContentPage.PetAllowed().get(PetAllowed).click();
			Log.info(" ***********PetAllowed is selected ***********");
		}*/
		//比较入住时间一致性
		@Test
		public static void assertCheckinTime() throws Exception{
			String pageCheckinTime = EditHotelMaintainMainContentPage.getCheckinTime();
			ExcelAction.setValue("Hotel/ActualValue.xls", "checkinTime", pageCheckinTime);
			String checkinTime = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "checkinTime");
			Assertion.verifyEquals(pageCheckinTime, checkinTime,"CheckinTime is right");
		}
		
	
		
		//比较退房时间一致性
		@Test
		public static void assertCheckoutTime() throws Exception{
			String pageCheckoutTime = EditHotelMaintainMainContentPage.getCheckoutTime();
			ExcelAction.setValue("Hotel/ActualValue.xls", "checkoutTime", pageCheckoutTime);
			String checkoutTime = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "checkoutTime");
			Assertion.verifyEquals(pageCheckoutTime, checkoutTime,"CheckoutTime is right");
			//Log.info(" ***********CheckoutTime is selected ***********");
		}
		
		
		
		//入住前几天几点可以退全部房费
		@Test
		public static void assertCheckinDay() throws Exception{
			String pageCheckinDay = EditHotelMaintainMainContentPage.editCheckinDay();
			ExcelAction.setValue("Hotel/ActualValue.xls", "checkinDay", pageCheckinDay);
			String checkinDay = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "checkinDay");
			Assertion.verifyEquals(pageCheckinDay, checkinDay,"CheckinDay is right");
		}
		
		@Test
		public static void assertCheckinPoints() throws Exception{
			String pageCheckinPoint = EditHotelMaintainMainContentPage.editCheckinPoints();
			ExcelAction.setValue("Hotel/ActualValue.xls", "checkinPoints", pageCheckinPoint);
			String checkinPoint = ExcelAction.getValue("Hotel/AddHotel_TestData.xls", "checkinPoints");
			Assertion.verifyEquals(pageCheckinPoint, checkinPoint,"CheckinPoint is right");
		}
		
		@Test
		public static void assertCancelTerms() throws Exception{
			String pageCancelTerms = EditHotelMaintainMainContentPage.getCancelTerms();
			ExcelAction.setValue("Hotel/ActualValue.xls", "cancelTerms", pageCancelTerms);
			String cancelterms =ExcelAction.getValue("Hotel/AddHotel_TestData.xls","cancelTerms");
			Assertion.verifyEquals(pageCancelTerms, cancelterms,"Cancelterms is right");
		}
		
		//保存酒店规定按钮
		@Test
		public static void assertSaveRulesButton() throws Exception{
			EditHotelMaintainMainContentPage.editSaveRulesButton().click();

		}
		
		/****************************编辑酒店服务设施***************************/
	
	//编辑酒店服务设施按钮
		@Test
		public static void assertServerButton() throws Exception{
			EditHotelMaintainMainContentPage.editServerFacility().click();
			Log.info(" ***********ServerFacilityButton is clicked ***********");
		}
	//检查服务设施是否被勾选
		@Test
		public static void assertBusinessCenter() throws Exception{
			String businessCenter =ExcelAction.getValue("Hotel/AddHotel_TestData.xls","businessCenter");
			ExcelAction.setValue("Hotel/ActualValue.xls", "businessCenter", businessCenter);
			int business = Integer.parseInt(businessCenter);
			if(EditHotelMaintainMainContentPage.editBusinessCenter().get(business).isSelected())
			{
				Log.info(" --------BusinessCenter is selected --------");
			}
			
		}
	//保存服务设施
		@Test
		public static void saveBusinessCenter() throws Exception{
			HotelMantainMainContentPage.SaveBusinessCenter().click();
			Log.info(" ***********SaveBusinessCenter is clicked ***********");
		}
		
		
	    //编辑备注
		/********************************************************************************************/
		//点击编辑备注按钮
		@Test
		public static void assertEditHotelRemark() throws Exception{
			HotelMantainMainContentPage.EditHotelRemark().click();
			Log.info(" ***********EditHotelRemark is clicked ***********");
		}
		//比较内部备注内容
		@Test
		public static void assertPrivateRemark() throws Exception{
			String privateRemark = ExcelAction.getValue("Hotel/AddHotel_TestData.xls","privateRemark");
			String pagePrivateRemark = EditHotelMaintainMainContentPage.PrivateRemark().getText();
			ExcelAction.setValue("Hotel/ActualValue.xls", "privateRemark", pagePrivateRemark);
			Assertion.verifyEquals(privateRemark, pagePrivateRemark,"PrivateRemark is right");
		}
		//比较外部备注内容
		@Test
		public static void assertPublicRemark() throws Exception{
			String pagePublicRemark = EditHotelMaintainMainContentPage.PublicRemark().getText();
			ExcelAction.setValue("Hotel/ActualValue.xls", "publicRemark", pagePublicRemark);
			String publicRemark = ExcelAction.getValue("Hotel/AddHotel_TestData.xls","publicRemark");
			Assertion.verifyEquals(pagePublicRemark, publicRemark,"PublicRemark is right");
		}
		//保存备注
		@Test
		public static void assertSaveRemarkButton() throws Exception{
			HotelMantainMainContentPage.SaveRemarkButton().click();
			Log.info(" ***********SaveRemarkButton is clicked ***********");
		}
			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
}



package com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.HotelMaintain.utility.Constants.*;
import com.travelzen.Utility.LogCenter.Log;

public class HotelMaintainAuditPage {

	public static WebDriver driver;
	private static WebElement element;
	
	@Test
	public static void getWebDriver(WebDriver webdriver) {
		
		driver = webdriver;
		
	}
	
	//get audit pass element
	@Test
	public static WebElement getAuditPassElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@class='actions block']/div[3]/a[1]"));
			Log.info("AuditPass element is found in Audit Page");
		}catch (Exception e){
			Log.error("AuditPass element is not found in Audit Page");
		}
		return element;
	}
	
	//get audit failed element
	@Test
	public static WebElement getAuditFailedElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@class='actions block']/div[3]/a[2]"));
			Log.info("AuditFailed element is found in Audit Page");
		}catch (Exception e){
			Log.error("AuditFailed element is not found in Audit Page");
		}
		return element;
	}
	
	//get audit closed element
	@Test
	public static WebElement getAuditClosedElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@class='actions block']/div[3]/a[3]"));
			Log.info("AuditClosed element is found in Audit Page");
		}catch (Exception e){
			Log.error("AuditClosed element is not found in Audit Page");
		}
		return element;
	}
}

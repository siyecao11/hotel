package com.travelzen.Insurance.OperatorInsurance.AppModules;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.AddProductPage;
import com.travelzen.Utility.LogCenter.Log;

public class GetProductInfoAction {

	private static WebDriver webDriver;
	
	//枚举：产品明细对应的16中产品类型 + 产品适用范围
	//Radio对象，页面中共有16个，value属性值为001~016
	//分别对应：太平明细 、太平洋明细 、泰康明细 、平安明细 、平安电子明细 、平安30元 、平安40元 、美亚畅游神州 
	//美亚万国游踪、人保邮轮 、美亚乐悠悠、 安盛卓越亚洲行 、人保境外旅游险 、平安境内旅游险 、平安境内旅游险 、畅行境内航意险
	//国内机票、国际机票、旅游、邮轮、自由行
	public enum ProductDetail{
		
		TP("太平明细", "001"), TPY("太平洋明细","002"), TK("泰康明细","003"), PA("平安明细","004"), PADZ("平安电子明细","005"), PA30("平安30元","006"),
		PA40("平安40元","007"), MYXY("美亚畅游神州","008"), MYWG("美亚万国游踪","009"), RB("人保邮轮","010"), MYLYY("美亚乐悠悠","011"), ASZY("安盛卓越亚洲行","012"),
		RBJW("人保境外旅游险","013"), PAJN("平安境内旅游险","014"), CXJW("畅行境外航意险","015"), CXJN("畅行境内航意险","016"),
		GNJP("国内机票","DOMESTIC_INSURANCE"), GJJP("国际机票","INTERNATIONAL_INSURANCE"), LY("旅游","TRAVEL_INSURANCE"), YL("邮轮","CRUISE_INSURANCE"), ZYX("自由行","FREEDRIVING_INSURANCE");
        // 成员变量
        private String name;
        private String index;

        // 构造方法
        private ProductDetail(String name, String index) {
            this.name = name;
            this.index = index;
        }

        //通过index去name
        public static String getName(String index) {
        	
            for (ProductDetail p : ProductDetail.values()) {
                if (p.getIndex().equals(index)) {
                    return p.name;
                }
            }
            return null;
        }
        
        //通过name取index
        public static String getIndex(String name) {
        	
            for (ProductDetail p : ProductDetail.values()) {
                if (p.getName().equals(name)) {
                    return p.index;
                }
            }
            return null;
        }

        // get set 方法
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIndex() {
            return index;
        }

        public void setIndex(String index) {
            this.index = index;
        }
	}
	
	//传递当前Driver
	public static void transmitDriver(WebDriver driver) throws Exception{
		
		webDriver = driver;
		AddProductPage.getDriver(webDriver);
	}
	
	//新增产品页面中，点击  “提交” 按钮
	public static void excuteSubmitAddButtonAction() throws Exception{
		
		AddProductPage.getSubmitAddButtonElement().click();
		Log.info("点击  “提交” 按钮");
	}
	
	//新增产品页面中，点击  “返回” 按钮
	public static void excuteReturnButtonAction() throws Exception{
		
		AddProductPage.getReturnButtonElement().click();
		Log.info("点击  “返回” 按钮");
	}
	
	//新增产品页面中，“产品名称” 字段内容获取
	public static String excuteProductNameAction() throws Exception{
		
		String productName = AddProductPage.getProductNameElement().getAttribute("value");
		Log.info("“产品名称” 字段值: " + productName);
		return productName;
	}
	
	//新增产品页面中，“保险公司名称” 字段内容获取
	public static String excuteCompanyNameAction() throws Exception{
		
		JavascriptExecutor jsExecutor = (JavascriptExecutor)webDriver;
		//去除隐藏select的display的none属性
		jsExecutor.executeScript("var setDate=document.getElementsByName(\"companyName\")[0];setDate.removeAttribute('style');");
		//设置selected option的值
		//AddProductPage.getCompanyNameElement().selectByValue(companyName);
		String companyName = AddProductPage.getCompanyNameElement().getFirstSelectedOption().getText();
		Log.info("“保险公司名称” 字段值: " + companyName);
		return companyName;
	}
	
	//新增产品页面中，“保险期限” 字段内容获取
	public static String excuteDeadlineAction() throws Exception{
		
		String deadline = AddProductPage.getDeadlineElement().getAttribute("value");
		Log.info("“保险期限” 字段值: " + deadline);
		return deadline;
	}
	
	//新增产品页面中，“最高保额” 字段输入值
	public static String excuteInsuranceAmountAction() throws Exception{
		
		String insuranceAmount = AddProductPage.getInsuranceAmountElement().getAttribute("value");
		Log.info("“最高保额” 字段值: " + insuranceAmount);
		return insuranceAmount;
	}
	
	//新增产品页面中，“保险险种” 字段值选择
	public static String excuteTypeNameAction() throws Exception{
		
		JavascriptExecutor jsExecutor = (JavascriptExecutor)webDriver;
		//去除隐藏select的display的none属性
		jsExecutor.executeScript("var setDate=document.getElementsByName(\"typeName\")[0];setDate.removeAttribute('style');");
		//设置selected option的值
		//AddProductPage.getTypeNameElement().selectByValue(typeName);
		String typeName = AddProductPage.getTypeNameElement().getFirstSelectedOption().getText();
		Log.info("“保险险种” 字段值: " + typeName);
		return typeName;
	}
	
	//新增产品页面中，“险种编号” 字段值内容
	public static String excuteTypeCodeAction() throws Exception{
		
		String typeCode = AddProductPage.getTypeCodeElement().getAttribute("value");
		Log.info("“险种编号” 字段值: " + typeCode);
		return typeCode;
	}
	
	//新增产品页面中，“产品明细” 字段值选择
	//Radio对象，页面中共有16个，value属性值为001~016
	//分别对应：太平明细 、太平洋明细 、泰康明细 、平安明细 、平安电子明细 、平安30元 、平安40元 、美亚畅游神州 
	//美亚万国游踪、人保邮轮 、美亚乐悠悠、 安盛卓越亚洲行 、人保境外旅游险 、平安境内旅游险 、畅行境外航意险 、畅行境内航意险
	public static String excuteProductDetailAction() throws Exception{
		
		int length = AddProductPage.getProductDetailElement().size();
		String productDetail = "";
		String index = "";
		for(int i = 0; i<length; i++){
			if(AddProductPage.getProductDetailElement().get(i).isSelected()){
				index = AddProductPage.getProductDetailElement().get(i).getAttribute("value");
			}
		}
		productDetail = ProductDetail.getName(index);
		Log.info("“产品明细” 字段值选择: " + productDetail);
		return productDetail;
	}
	
	public static String excuteNormalPriceAction() throws Exception{
		
		String normalPrice = AddProductPage.getNormalPriceElement().getAttribute("value");
		Log.info("“面价” 字段值: " + normalPrice);
		return normalPrice;
	}
	
	//新增产品页面中，“底价” 字段值内容
	public static String excuteUpsetPriceAction() throws Exception{
		
		String upsetPrice = AddProductPage.getUpsetPriceElement().getAttribute("value");
		Log.info("“底价” 字段值: " + upsetPrice);
		return upsetPrice;
	}
	
	//新增产品页面中， “最高投保份数”-“18周岁以上（含)” 字段输入值
	public static String excuteAdultLimitNumAction() throws Exception{
		
		String adultLimitNum = AddProductPage.getAdultLimitNumElement().getAttribute("value");
		Log.info(" “最高投保份数”-“18周岁以上（含)” 字段输入值: " + adultLimitNum);
		return adultLimitNum;
	}
	
	//新增产品页面中， “最高投保份数”-“18周岁以下” 字段输入值
	public static String excuteChildLimitNumAction() throws Exception{
		
		String childLimitNum = AddProductPage.getChildLimitNumElement().getAttribute("value");
		Log.info("“最高投保份数”-“18周岁以下” 字段输入值: " + childLimitNum);
		return childLimitNum;
	}
	
	//新增产品页面中， “年龄限制”-“投保人”-“周岁（含）以上” 字段输入值
	public static String excuteInsurerMinAgeLimitAction() throws Exception{
		
		String insurerMinAgeLimit = AddProductPage.getInsurerMinAgeLimitElement().getAttribute("value");
		Log.info("“年龄限制”-“投保人”-“周岁（含）以上” 字段输入值: " + insurerMinAgeLimit);
		return insurerMinAgeLimit;
	}
	
	//新增产品页面中， “年龄限制”-“被投保人”-“至” 字段输入值
	public static String excuteInsureeMinAgeLimitAction() throws Exception{
		
		String insureeMinAgeLimit = AddProductPage.getInsureeMinAgeLimitElement().getAttribute("value");
		Log.info("“年龄限制”-“被投保人”-“至” 字段输入值: " + insureeMinAgeLimit);
		return insureeMinAgeLimit;
	}
	
	//新增产品页面中， “年龄限制”-“被投保人”-“周岁（含）”  字段输入值
	public static String excuteInsureeMaxAgeLimitAction() throws Exception{
		
		String insureeMaxAgeLimit = AddProductPage.getInsureeMaxAgeLimitElement().getAttribute("value");
		Log.info("“年龄限制”-“被投保人”-“周岁（含）” 字段输入值: " + insureeMaxAgeLimit);
		return insureeMaxAgeLimit;
	}
	
	//新增产品页面中, “适用范围” 字段值选择
	//checkbox对象，页面中共有5个，value属性值为DOMESTIC_INSURANCE、INTERNATIONAL_INSURANCE、TRAVEL_INSURANCE、CRUISE_INSURANCE、FREEDRIVING_INSURANCE
	//分别对应：国内机票 、国际机票 、旅游 、邮轮、自由行
	public static String excuteScopeAction() throws Exception{
		
		int length = AddProductPage.getScopeElement().size();
		String scope ="";
		int flag = 0;
		for(int i = 0; i<length; i++){
			
			if(AddProductPage.getScopeElement().get(i).getAttribute("checked").equals("checked")){
				if(flag > 0){
					scope = scope + ";";
				}
				scope = scope + AddProductPage.getScopeElement().get(i).getText();
				flag++;
			}
		}
		Log.info("“适用范围” 字段值: " + scope);
		return scope;
	}
}

package com.travelzen.Insurance.OperatorInsurance.TestCase.CheckPoints;
/**
 * author:qiqi.wang
 * */
import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.Constant;
import com.travelzen.Insurance.OperatorInsurance.AppModules.OrderSearchAction;
import com.travelzen.Utility.Assertion.Assertion;
import com.travelzen.Utility.DataDriver.ExcelAction;


public class OrderSearchCheckPoint
{
	public static String productExcelName = "Insurance/Datas/KeepForProductInfo.xls";
	public static String OrderDetailsExcelName = "Insurance/Datas/OperaterCreateOrder.xls";
	public static void OrderSearch(WebDriver driver) throws Exception{
		OrderSearchAction.transmitDriver(driver);
		//订单查询页面-获取订单号
			String OrderId = OrderSearchAction.excuteOrderIDGet();
		//订单查询页面-获取客户名称
			//String CustomerName = OrderSearchAction.excuteCustomerName();
		//订单查询页面-获取产品名称
			//String ProductName = OrderSearchAction.excuteProductName();
		//订单查询页面-获取产品期限
			String ProductTime =OrderSearchAction.excuteProductTime();
		//订单查询页面- 获取订单合计费用
			String OrderCash = OrderSearchAction.excuteOrderCash();
		//订单查询页面-保险生效时间
			String StartDate = OrderSearchAction.excuteInsuranceStartDate();
		//订单查询页面- 保险截止日期
			String EndDate =OrderSearchAction.excuteInsuranceEndDate();
		//订单查询页面- 保险创建日期
			String OrderCreateDate = OrderSearchAction.excuteOrderCreateDate();
			
		//期望结果：
			String eOrderId = Constant.OperatorOrderId;
			String eCustomerName = ExcelAction.getValue(OrderDetailsExcelName, "CustomerShortName");
			String eProductName = ExcelAction.getValue(productExcelName, "companyName");
			String eProductTime = ExcelAction.getValue(productExcelName, "deadline");
			String eOrderCash = Constant.OperatorOrderPay;
			String eStartDate = ExcelAction.getValue(OrderDetailsExcelName, "StartDate");
			
		//将实际结果与期望结果进行对比
			Assertion.verifyEquals(OrderId, eOrderId, "期望订单号："+eOrderId+";实际订单号:"+OrderId);
			//Assertion.verifyEquals(CustomerName, eCustomerName, "期望客户名字："+eCustomerName+";实际客户名字:"+CustomerName);
			//Assertion.verifyEquals(ProductName, eProductName, "期望产品名称："+eProductName+";实际产品名称:"+ProductName);
			Assertion.verifyEquals(ProductTime, eProductTime, "期望产品期限："+eProductTime+";实际产品期限:"+ProductTime);
			Assertion.verifyEquals(OrderCash, eOrderCash, "期望订单费用："+eOrderCash+";实际订单费用:"+OrderCash);
			Assertion.verifyEquals(StartDate, eStartDate, "期望保险生效时间："+eStartDate+";实际保险生效时间:"+StartDate);
			
	}
}

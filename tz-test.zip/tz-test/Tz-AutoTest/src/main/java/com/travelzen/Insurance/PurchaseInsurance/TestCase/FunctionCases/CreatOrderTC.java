package com.travelzen.Insurance.PurchaseInsurance.TestCase.FunctionCases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.travelzen.Login.PurchaseLogin.TestCase.FunctionCases.LoginPurchase;
import com.travelzen.Insurance.PurchaseInsurance.Utility.Utils.DataProviderApp;
import com.travelzen.Utility.Assertion.Assertion;
import com.travelzen.Utility.Constants.Constants;
import com.travelzen.Utility.DataDriver.ExcelAction;
import com.travelzen.Utility.ScreenShot.RetryFail;
import com.travelzen.Utility.Utils.Utils;
import com.travelzen.Insurance.PurchaseInsurance.Utility.Constants.constants;
import com.travelzen.Insurance.PurchaseInsurance.AppModules.*;
import java.util.Date;
import java.util.Calendar;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class CreatOrderTC {

	public static WebDriver currentDriver;
	// 从正常单获取Driver

	@BeforeClass(alwaysRun = true)
	public static void beforeClass() {

	}

	@BeforeMethod(alwaysRun = true)
	public static void beforeMethod() {
		// 从登陆过去
		currentDriver = BuyInsuranceTC.currentDriver;
		Constants.classDriver = currentDriver;
	}

	@AfterMethod(alwaysRun = true)
	public static void afterMethod() {

		if (DataProviderApp.isLoginIncludeProcess.equalsIgnoreCase("false")) {
			currentDriver.close();
		}
	}

	// ***********填写产品信息
	// 产品信息--输入保险生效日期
	@Test(dataProvider = "insurance_productEffectiveDate", priority = 20, groups = {
			"添加产品信息" }, dataProviderClass = DataProviderApp.class)
	public static void addProductInfo(String effectiveDate) throws Exception {
		CreatOrderAction.transmitDriver(currentDriver);
		CreatOrderAction.excutEffectiveDateAction(effectiveDate);
	}

	/*	// 产品信息--产品生效日期功能验证
	@Test(dataProvider = "insurance_productEffectivePeriod", priority = 20, groups = {
			"生效日期校验" }, dataProviderClass = DataProviderApp.class)
	public static void addProductInfoVerify(String insuranceName,String effectiveDate,String period) throws Exception {
		//购买产品
		BuyInsuranceTC.buyInsurance(insuranceName);
		//传递driver到建单页面
		CreatOrderAction.transmitDriver(currentDriver);
		//输入产品生效日期
		CreatOrderAction.excutEffectiveDateAction(effectiveDate);
		//选中日历控件中保险生效时间
		CreatOrderAction.excutEffectiveEndDateClickAction();
		//计算得出产品生效截止日期
		String eEndDate = getSpecifiedDayAfter(effectiveDate,period);
		System.out.println("返回的失效日期转换的字符串是："+eEndDate);
		//获取页面显示生效截止日期
		String EndDate = CreatOrderAction.excutEffectiveEndDateAction();
		Assertion.verifyEquals(EndDate, eEndDate, 
				"期望保险生效截止时间：" + eEndDate + ";实际保险生效截止时间:" + EndDate);
		Thread.sleep(3000);
		
	}
	*/

	// 单个成人建单
	@Test(dataProvider = "insurance_creatOrderAdu", priority = 21, groups = {
			"单成人建单" }, dataProviderClass = DataProviderApp.class)
	public static void oneAduInsuree(String num, String insureeName, String mobelPhone, String docType, String docCode,
			String birthDate, String gender, String insuranceAmount) throws Exception {

		// 被保险人信息--输入被保险人--姓名，num是第几个被保险人，0表示第一个
		CreatOrderAction.excutInsureeNameAction(num, insureeName);
		// 被保险人信息--输入被保险人--电话
		CreatOrderAction.excutMobelPhoneAction(num, mobelPhone);
		// 被保险人信息--输入被保险人--证件类型
		CreatOrderAction.excutDocTypeAction(num, docType);
		Utils.waitForElement(1, currentDriver, "wait");
		// 被保险人信息--输入被保险人--证件号码
		CreatOrderAction.excutDocCodeAction(num, docCode);
		// 被保险人信息--输入被保险人--出生日期
		CreatOrderAction.excutBirthDateAction(num, birthDate);
		// 被保险人信息--输入被保险人--性别
		CreatOrderAction.excutGenderAction(num, gender);
		Utils.waitForElement(1, currentDriver, "wait");
		// 被保险人信息--输入被保险人--保险数量
		CreatOrderAction.excutInsuranceAmountAction(num, insuranceAmount);
		Utils.waitForElement(1, currentDriver, "wait");
		// 提交订单
		// CreatOrderAction.excutSubmmitAction();

	}

	// 儿童+投保人建单
	@Test(dataProvider = "insurance_creatOrderChd", priority = 21, groups = {
			"单儿童建单" }, dataProviderClass = DataProviderApp.class)
	public static void oneChdInsuree(String num, String insureeName, String mobelPhone, String docType, String docCode,
			String birthDate, String gender, String insuranceAmount, String insureName, String insurePhone,
			String insureDocType, String insureDocCode, String insureBirthDate, String insureGender) throws Exception {
		// 输入儿童被保险人信息
		oneAduInsuree(num, insureeName, mobelPhone, docType, docCode, birthDate, gender, insuranceAmount);
		// 输入儿童投保人信息--姓名
		CreatOrderAction.excutInputInsureNameAction(insureName);
		// 输入儿童投保人信息--手机号
		CreatOrderAction.excutInputInsurerPhoneAddAction(insurePhone);
		// 选中儿童投保人信息--证件类型
		CreatOrderAction.excutSelectInsurerDocTypeAddAction(insureDocType);
		Utils.waitForElement(1, currentDriver, "wait");
		// 输入儿童投保人信息--证件号码
		CreatOrderAction.excutInputInsurerDocCodeAddAction(insureDocCode);
		// 输入儿童投保人信息--出生日期
		CreatOrderAction.excutInputInsurerBirthdayAction(insureBirthDate);
		// 选中儿童投保人信息--性别
		CreatOrderAction.excutSelectInsurerGenderAction(insureGender);
		Utils.waitForElement(1, currentDriver, "wait");
		// 提交订单
		// CreatOrderAction.excutSubmmitAction();
	}

	// 多成人建单
	@Test(dataProvider = "insurance_creatOrderMulti", priority = 21, groups = {
			"多成人建单" }, dataProviderClass = DataProviderApp.class)
	public static void multiAduInsuree(String num, String insureeName, String mobelPhone, String docType,
			String docCode, String birthDate, String gender, String insuranceAmount) throws Exception {
		// 根据读取数据源，多次调用单成人建单，实现多成人建单
		oneAduInsuree(num, insureeName, mobelPhone, docType, docCode, birthDate, gender, insuranceAmount);
		if (Integer.parseInt(num) != 2)
			// 新增被保险人
			CreatOrderAction.excutAddAction();

	}
	
	// 多成人建单
		@Test(dataProvider = "insurance_creatOrderMulti", priority = 21, groups = {
				"多成人建单FC" }, dataProviderClass = DataProviderApp.class)
		public static void multiAduInsureeFC(String num, String insureeName, String mobelPhone, String docType,
				String docCode, String birthDate, String gender, String insuranceAmount) throws Exception {
			// 根据读取数据源，多次调用单成人建单，实现多成人建单
			oneAduInsuree(num, insureeName, mobelPhone, docType, docCode, birthDate, gender, insuranceAmount);
			if (Integer.parseInt(num) != 2)
				// 新增被保险人
				CreatOrderAction.excutAddAction();
			else
				CreatOrderAction.excutDeleteAction(num);
		}

	// 常旅客建单
	@Test(dataProvider = "insurance_FFPOrder", priority = 21, groups = {
			"常旅客建单" }, dataProviderClass = DataProviderApp.class)
	public static void FFP(String name) throws Exception {
		// 选择常旅客
		CreatOrderAction.excutFFPAction(name);
	}

	// ************订单提交****************
	// 订单提交
	@Test(priority = 22, groups = { "订单提交" })
	public static void submmitOrder() throws Exception {
		// 提交订单
		CreatOrderAction.excutSubmmitAction();
	}

	// ******************保存订单号*******************
	// 保存订单号到“退保表格”
	@Test(priority = 23, groups = { "获取退保单订单号" })
	public static void orderSavetoSurrender() throws Exception {
		// 传递driver到订单支付页
		OrderPayAction.transmitDriver(currentDriver);
		// 获取订单支付页订单号
		String orderId = OrderPayAction.excutObtainOrderIdAction();
		// 保存订单号
		constants.surenderOrderId = orderId;
		System.out.print("保存的退保单订单号是：" + constants.surenderOrderId);
		// ExcelAction.setValue("Insurance/Datas/p_surrenderOderId.xls",
		// "orderId", orderId);
	}

	// 保存订单号到“取消投保”
	@Test(priority = 23, groups = { "获取取消投保单订单号" })
	public static void orderSavetoInsureCancel() throws Exception {
		// 传递driver到订单支付页
		OrderPayAction.transmitDriver(currentDriver);
		// 获取订单支付页订单号
		String orderId = OrderPayAction.excutObtainOrderIdAction();
		// 保存订单号
		constants.cancelInsureOrderId = orderId;
		System.out.print("保存的取消投保单订单号是：" + constants.cancelInsureOrderId);
		// ExcelAction.setValue("Insurance/Datas/p_insureCancelOderId.xls",
		// "orderId", orderId);
	}

	// 保存订单号到“正常单表格表格”
	@Test(priority = 23, groups = { "获取正常单订单号" })
	public static void orderSavetoNormal() throws Exception {
		// 传递driver到订单支付页
		OrderPayAction.transmitDriver(currentDriver);
		// 获取订单支付页订单号
		String orderId = OrderPayAction.excutObtainOrderIdAction();
		// 保存订单号
		constants.NormalOrderId = orderId;
		System.out.print("保存的正常单订单号是：" + constants.NormalOrderId);
		// ExcelAction.setValue("Insurance/Datas/p_normalOderId.xls", "orderId",
		// orderId);
	}

	//
	// ************订单支付*********************可移植到ordermaintain中
	// 订单支付
	@Test(dataProvider = "insurance_payOrder", priority = 24, groups = {
			"订单支付" }, dataProviderClass = DataProviderApp.class)
	public static void orderPay(String password) throws Exception {
		// driver传递
		// OrderPayAction.transmitDriver(currentDriver);
		// 输入支付密码，默认使用账户支付
		OrderPayAction.excutInputPasswordAction(password);
		// 确认付款
		OrderPayAction.excutPayAffirmAction();
		Thread.sleep(3000);

	}
	//
}

package com.travelzen.Insurance.OperatorInsurance.PageObjects;
/**
 * author：qiqi.wang
 * */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.travelzen.Utility.LogCenter.Log;

public class OrderManagePage
{
	public static WebDriver driver;
	private static WebElement element;
	
	//获取当前页面的Driver
	public static void getDriver(WebDriver webDriver) {

		driver = webDriver;
	}
	
	//订单管理页面-订单查询-按钮
	public static WebElement getOrderSearchElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("html/body/div[3]/div[2]/div[2]/div[1]/a[1]"));
			Log.info("订单管理页面中“订单查询”元素，已找到。");
		}catch (Exception e){
			Log.error("订单管理页面中“订单查询”元素，未找到。");
		}
		return element;
	}
	//订单管理页面-保单查询-按钮
	public static WebElement getPolicySearchElement() throws Exception{
		
		try{
			element = driver.findElement(By.className("item"));
			Log.info("订单管理页面中“保单查询”元素，已找到。");
		}catch (Exception e){
			Log.error("订单管理页面中“保单查询”元素，未找到。");
		}
		return element;
	}
	
	
	
	
	
	
	
	
}

package com.travelzen.Insurance.OperatorInsurance.AppModules;
/**
 * author:qiqi.wang
 * 
 * */
import java.util.Set;

import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.OrderSearchPage;
import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.Constant;
import com.travelzen.Utility.LogCenter.Log;

public class OrderSearchAction
{
	public static WebDriver webdriver;
	
	public static void transmitDriver(WebDriver driver) throws Exception{
		webdriver = driver;
		OrderSearchPage.getDriver(webdriver);
	} 
	
	//订单查询页面-创建订单-点击按钮
	public static void excuteCreateOrderBtn() throws Exception{
		try{
			OrderSearchPage.getCreateOrderButtonElement().click();
			Log.info("订单查询页面“创建订单”按钮元素，已找到。");
		}catch(Exception e){
			Log.error("订单查询页面“创建订单”按钮元素，未找到。");
		}
	}
	
	//订单查询页面-输入订单号-输入
	public static void excuteInputOrderID(String OrderID) throws Exception{
		OrderSearchPage.getOrderNumberInputElement().sendKeys(OrderID);
		Log.info("订单查询页面“订单号”，已输入。");
	}
	
	//订单查询页面-订单搜索-点击按钮
	public static void excuteOrderSearch() throws Exception{
		OrderSearchPage.getSearchOrderButtonElement().click();
		Log.info("订单查询页面“订单搜索”按钮，已点击。");
	}
	
	//订单查询页面-点击订单号
	public static void excuteOrderIDClick() throws Exception{
		OrderSearchPage.getListOrderIDElement().click();
		Log.info("订单查询页面“被查询订单号”，已点击，进入订单详情页面");
	}
	
	//订单查询页面-获取订单号
	public static String excuteOrderIDGet() throws Exception{
		String OrderId = OrderSearchPage.getListOrderIDElement().getText();
		Log.info("订单查询页面“被查询订单号”，已获得。"+OrderId);
		return OrderId;
	}
	
	//订单查询页面-获取客户名称
	public static String excuteCustomerName() throws Exception{
		String CustomerName = OrderSearchPage.getListCustomerNameElement().getText();
		Log.info("订单查询页面“客户名称”，已获得。"+CustomerName);
		return CustomerName;
	}
	
	//订单查询页面-获取产品名称
	public static String excuteProductName() throws Exception{
		String ProductName = OrderSearchPage.getListProductNameElement().getText();
		Log.info("订单查询页面“产品名称”，已获得。"+ProductName);
		return ProductName;
	}
	
	//订单查询页面-获取产品期限
	public static String excuteProductTime() throws Exception{
		String ProductTime = OrderSearchPage.getListDeadlineElement().getText();
		ProductTime = ProductTime.substring(0, 1);
		Log.info("订单查询页面“产品期限”，已获得。"+ProductTime);
		return ProductTime;
	}
	
	//订单查询页面- 获取订单合计费用
	public static String excuteOrderCash() throws Exception{
		String OrderCash = OrderSearchPage.getListTotalCastElement().getText();
		int n = OrderCash.length();
		OrderCash = OrderCash.substring(0, n-1);
		Log.info("订单查询页面“合计费用”，已获得。"+OrderCash);
		return OrderCash;
	}
	
	//订单查询页面-保险生效时间
	public static String excuteInsuranceStartDate() throws Exception{
		String StartDate = OrderSearchPage.getListStartDateElement().getText();
		Log.info("订单查询页面“保险生效日期”，已获得。"+StartDate);
		return StartDate;
	}
	
	//订单查询页面- 保险截止日期
	public static String excuteInsuranceEndDate() throws Exception{
		String EndDate = OrderSearchPage.getListEndDateElement().getText();
		Log.info("订单查询页面“保险生效日期”，已获得。"+EndDate);
		return EndDate;
	}
	//订单查询页面- 保险创建日期
	public static String excuteOrderCreateDate() throws Exception{
		String OrderCreateDate = OrderSearchPage.getListCreateDateElement().getText();
		Log.info("订单查询页面“保险生效日期”，已获得。"+OrderCreateDate);
		return OrderCreateDate;
	}
	
	//driver跳转到订单详情页窗口
	public static void switchToWindow(WebDriver driver)
	{
		Set<String> handles = driver.getWindowHandles();
		handles.remove(driver.getWindowHandle());
		for (String handle : handles)
		{
			driver.switchTo().window(handle);
			if (driver.getCurrentUrl().contains("http://aop.op3.tdxinfo.com/tops-front-operator-additional/additional/insurance/orderDetail/detail?id"))
			{
				break;
			}
		}
	}
	
	
	
	
}

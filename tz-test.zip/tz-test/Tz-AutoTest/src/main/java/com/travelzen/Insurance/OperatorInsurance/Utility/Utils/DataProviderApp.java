package com.travelzen.Insurance.OperatorInsurance.Utility.Utils;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.travelzen.Utility.DataDriver.ExcelAction;
import com.travelzen.Utility.LogCenter.Log;
import com.travelzen.Utility.ResultCollection.Report;

public class DataProviderApp {

	public static WebDriver driver;
	public static int column;
	public static int row;
	public static String isFunction;
	public static String TestCadeName;
	public static String isLoginIncludeProcess = "true";
	
	//需要包含所有要读取参数的groups名称
	@Test(priority = 0, groups = {"新增产品","保险运营商正常单创建"})
	@Parameters({"isFunctionTest","TestName"})
	public static void parameterGet(String isFunctionTest,String TestName) {
		
		isFunction = isFunctionTest;
		TestCadeName = TestName;
	}
	//保险正常建单数据表
	@DataProvider(name = "NormalCreateOrder")
	public static Object[][] CreateOrder() throws Exception{
		String excelName = "Insurance/Datas/OperaterCreateOrder.xls";
		// 定义
		// 列 
		column = ExcelAction.excel_get_column(excelName);
		Log.info("excel_get_column value is : " + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("excel_get_rows value is : " + row);

		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true")&&TestCadeName.equalsIgnoreCase("addProduct"))
		{
			isLoginIncludeProcess = "false";
			excelData = ExcelAction.getAllRows(excelName, row, column);
		}
		else{
			isLoginIncludeProcess = "true";
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		}	
		return excelData;
	}
	
	//读保险产品信息表
	//*****保险产品信息*****
	@DataProvider(name = "ProductDetail")
	
	public static Object[][] BookingHotel() throws Exception {
		
		// Excel表格名称定义
		String excelName = "Insurance/Datas/ProductDetail.xls";
		// 定义
		// 列 
		column = ExcelAction.excel_get_column(excelName);
		Log.info("excel_get_column value is : " + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("excel_get_rows value is : " + row);

		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true")&&TestCadeName.equalsIgnoreCase("addProduct"))
		{
			isLoginIncludeProcess = "false";
			excelData = ExcelAction.getAllRows(excelName, row, column);
		}
		else{
			isLoginIncludeProcess = "true";
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		}	
		return excelData;
	}
	
	//**********运营商保险订单备注***********
	@DataProvider(name = "OrderRemark")
	public static Object[][] OrderRemark() throws Exception{
		// Excel表格名称定义
		String excelName = "Insurance/Datas/OperatorOrderRemark.xls";
		// 定义
		// 列 
		column = ExcelAction.excel_get_column(excelName);
		Log.info("excel_get_column value is : " + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("excel_get_rows value is : " + row);

		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true")&&TestCadeName.equalsIgnoreCase("addProduct"))
		{
			isLoginIncludeProcess = "false";
			excelData = ExcelAction.getAllRows(excelName, row, column);
		}
		else{
			isLoginIncludeProcess = "true";
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		}	
		return excelData;
	}
	
	//读修改保险产品信息表
	//*****编辑保险产品信息*****
	@DataProvider(name = "ModifyProductDetail")
	
	public static Object[][] modifyProductDetail() throws Exception {
		
		// Excel表格名称定义
		String excelName = "Insurance/Datas/ModifyProductDetail.xls";
		// 定义
		// 列 
		column = ExcelAction.excel_get_column(excelName);
		Log.info("excel_get_column value is : " + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("excel_get_rows value is : " + row);

		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true"))
		{
			excelData = ExcelAction.getAllRows(excelName, row, column);
		}
		else{
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		}	
		return excelData;
	}

}

package com.travelzen.Insurance.PurchaseInsurance.Utility.Utils;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import com.travelzen.Utility.DataDriver.ExcelAction;
import com.travelzen.Utility.LogCenter.Log;
import com.travelzen.Utility.ResultCollection.Report;

public class DataProviderApp {

	public static WebDriver driver;
	public static int column;
	public static int row;
	public static String isFunction;
	public static String TestCaseName;
	public static String isLoginIncludeProcess = "true";
	public static String isCreateOrderIncludeProcess = "true";

	@AfterSuite(alwaysRun = true)
	public static void afterSuite() throws Exception {

		Report.showReport();
	}

	// 需要包含所有要读取参数的groups名称
	@Test(priority = 1, groups = { "初始化数据" })
	@Parameters({ "isFunctionTest", "TestName" })
	public static void parameterGet(String isFunctionTest, String TestName) {

		isFunction = isFunctionTest;
		TestCaseName = TestName;
		System.out.println("是否是功能测试 : " + isFunction);
		System.out.println("功能测试用例名称: " + TestName);
	}
	
	// 预定产品数据
	@DataProvider(name = "insurance_buyProduct")
	public static Object[][] buyProduct() throws Exception {

		// Excel表格名称定义
		String excelName = "Insurance/Datas/p_buyProduct.xls";
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("获取Excel表格列数是 ：" + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("获取Excel表格行数是：" + row);
		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		excelData = ExcelAction.getAllRows(excelName, row, column);

		return excelData;
	}

	@DataProvider(name = "insurance_productEffectiveDate")
	public static Object[][] productInfo() throws Exception {

		// Excel表格名称定义
		String excelName = "Insurance/Datas/p_productEffectiveDate.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("获取Excel表格列数是 ：" + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("获取Excel表格行数是 ：" + row);
		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true") && TestCaseName.equalsIgnoreCase("creatOrder"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		return excelData;
	}

	@DataProvider(name = "insurance_productEffectivePeriod")
	public static Object[][] productEffectivePeriod() throws Exception {

		// Excel表格名称定义
		String excelName = "Insurance/Datas/p_productEffectivePeriod.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("获取Excel表格列数是 ：" + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("获取Excel表格行数是 ：" + row);
		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true") && TestCaseName.equalsIgnoreCase("effectiveDate"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		return excelData;
	}

	@DataProvider(name = "insurance_creatOrderAdu")
	public static Object[][] creatOrder() throws Exception {

		// Excel表格名称定义
		String excelName = "Insurance/Datas/p_creatOrderAdu.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("获取Excel表格列数是 ：" + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("获取Excel表格行数是 ：" + row);
		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true") && TestCaseName.equalsIgnoreCase("creatOrder"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		return excelData;
	}

	// 取消投保人信息 name
	@DataProvider(name = "insurance_cancelInsureOrder")
	public static Object[][] cancelOrder() throws Exception {

		// Excel表格名称定义
		String excelName = "Insurance/Datas/p_cancelInsureOrder.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("获取Excel表格列数是 ：" + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("获取Excel表格行数是 ：" + row);
		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true") && TestCaseName.equalsIgnoreCase("cancelInsureOrder"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		return excelData;
	}

	// 退保人信息 name
	@DataProvider(name = "insurance_surenderOrder")
	public static Object[][] surenderOrder() throws Exception {

		// Excel表格名称定义
		String excelName = "Insurance/Datas/p_surrenderOrder.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("获取Excel表格列数是 ：" + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("获取Excel表格行数是 ：" + row);
		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true") && TestCaseName.equalsIgnoreCase("surenderOrder"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		return excelData;
	}

	// 订单支付密码
	@DataProvider(name = "insurance_payOrder")
	public static Object[][] payOrder() throws Exception {

		// Excel表格名称定义
		String excelName = "Insurance/Datas/p_payOrder.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("获取Excel表格列数是 ：" + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("获取Excel表格行数是 ：" + row);
		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true") && TestCaseName.equalsIgnoreCase("surenderOrder"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		return excelData;
	}

	// 单儿童建单测试
	@DataProvider(name = "insurance_creatOrderChd")
	public static Object[][] creatOrderChd() throws Exception {

		// Excel表格名称定义
		String excelName = "Insurance/Datas/p_creatOrderChd.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("获取Excel表格列数是 ：" + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("获取Excel表格行数是 ：" + row);
		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true") && TestCaseName.equalsIgnoreCase("surenderOrder"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		return excelData;
	}

	// 多成人建单（3成人）
	@DataProvider(name = "insurance_creatOrderMulti")
	public static Object[][] creatOrderMulti() throws Exception {

		// Excel表格名称定义
		String excelName = "Insurance/Datas/p_creatOrderMulti.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("获取Excel表格列数是 ：" + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("获取Excel表格行数是 ：" + row);
		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		excelData = ExcelAction.getAllRows(excelName, row, column);
		return excelData;
	}

	// 单儿童建单测试
	@DataProvider(name = "insurance_FFPOrder")
	public static Object[][] FFPOrder() throws Exception {

		// Excel表格名称定义
		String excelName = "Insurance/Datas/p_FFPOrder.xls";
		// 定义
		// 列
		column = ExcelAction.excel_get_column(excelName);
		Log.info("获取Excel表格列数是 ：" + column);
		// 行
		row = ExcelAction.excel_get_rows(excelName);
		Log.info("获取Excel表格行数是 ：" + row);
		// 定义二维数组
		Object[][] excelData = new Object[row][column];
		// 获取功能测试或者非功能测试数据
		if (isFunction.equalsIgnoreCase("true") && TestCaseName.equalsIgnoreCase("surenderOrder"))
			excelData = ExcelAction.getAllRows(excelName, row, column);
		else
			excelData = ExcelAction.getFirstRow(excelName, row, column);
		return excelData;
	}

}

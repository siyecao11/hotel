package com.travelzen.Utility.Assertion;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners({com.travelzen.Utility.Assertion.AssertionListener.class, com.travelzen.Utility.ResultCollection.CustomReporter.class })
public class Demo {

/*	public static void main(String[] args){
		
		Assert.assertEquals(3, 3, "比较两个数是否相等：");
		System.out.println("NTF");
        Assertion.verifyEquals(2, 3, "比较两个数是否相等：");
        
        Assertion.verifyEquals(2, 2, "比较两个数是否相等："); 
	}*/
	
	@DataProvider
	public Object[][] dataProvider() {
		return new Object[][] { { 7 }, { 8} };
	}

	@Test(dataProvider = "dataProvider")
	public void testAssert1(int a) {
//		Assert.assertEquals(7, a);
		Assertion.verifyEquals(7, a);
	}

	@Test
	public void testAssert2() {
//		Assert.assertEquals("2", "2");
		Assertion.verifyEquals(2, 2);
	}
}

package com.travelzen.Insurance.OperatorInsurance.TestCase.FunctionCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.CreateOrderPage;
import com.travelzen.Insurance.OperatorInsurance.PageObjects.OrderManagePage;
import com.travelzen.Insurance.OperatorInsurance.PageObjects.OrderSearchPage;
import com.travelzen.Utility.LogCenter.Log;

public class NewTest {
	public static WebDriver driver; 
  @Test
  public void f() throws Exception {
	  driver = new FirefoxDriver();
	  driver.get("http://member.op3.tdxinfo.com/tops-front-operator-member/facade/signin");
	  driver.findElement(By.name("username")).sendKeys("yangweixing");
	  driver.findElement(By.name("password")).sendKeys("111111");
	  driver.findElement(By.name("login")).click();
	  Thread.sleep(2000);
	  driver.findElement(By.cssSelector("a[item='保险']")).click();
	  Thread.sleep(2000);
	  //点击以订单管理
	  driver.findElement(By.xpath("html/body/div[3]/div[1]/ul/li[10]/ol/li[1]/a")).click();
	  Log.info("订单管理");
	  Thread.sleep(2000);
	  //点击订单查询按钮
	  OrderManagePage.getDriver(driver);
	  OrderManagePage.getOrderSearchElement().click();
	  Log.info("订单查询");
	  Thread.sleep(2000);
	  //创建订单
	  OrderSearchPage.getDriver(driver);
	  OrderSearchPage.getCreateOrderButtonElement().click();
	  Thread.sleep(2000);
	  CreateOrderPage.getDriver(driver);
	  CreateOrderPage.getCustomerNamebuttonElement().click();
	  Thread.sleep(2000);
	  CreateOrderPage.getCustomerShortNameInputElement().sendKeys("OP3C100");
	  Thread.sleep(2000);
	  CreateOrderPage.getCustomerSearchButtonElement().click();
	  Thread.sleep(2000);
	  CreateOrderPage.getCustomerSelectElement().click();
	  CreateOrderPage.getProductSearchButtonElement().click();
	  CreateOrderPage.getInsuranceCoverageElement("TRAVEL_INSURANCE").click();
	  CreateOrderPage.getInsuranceProductElement("中国人寿保险").click();

  }
}

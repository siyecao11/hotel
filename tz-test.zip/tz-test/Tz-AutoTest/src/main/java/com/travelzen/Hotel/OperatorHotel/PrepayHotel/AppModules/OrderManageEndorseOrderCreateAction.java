package com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules;

import org.openqa.selenium.WebDriver;

import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;
import com.travelzen.Utility.LogCenter.Log;

public class OrderManageEndorseOrderCreateAction {

	public static void transmitDriver(WebDriver driver) throws Exception{
		OrderManageEndorseOrderCreatePage.GetDriver(driver);
	}
	
	//点击创建变更单按钮
	public static void CreateEndorseOrder() throws Exception{
		OrderManageEndorseOrderCreatePage.CreateButton().click();
		Log.info("*************CreateEndorseOrder is clicked****************");
	}
	
}

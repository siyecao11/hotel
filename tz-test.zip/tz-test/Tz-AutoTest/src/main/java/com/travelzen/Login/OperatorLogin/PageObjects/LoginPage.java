package com.travelzen.Login.OperatorLogin.PageObjects;

import org.testng.annotations.Test;
import org.openqa.selenium.*;
import com.travelzen.Utility.LogCenter.Log;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BaseClass {
	// (全)局部变量定义
	private static WebElement element;
	public static WebDriver driver;

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	public static void getWebDriver(WebDriver webdriver) throws Exception {
		driver = webdriver;
	}

	// 获取用户名输入框元素
	@Test
	public static WebElement txt_UserNmae() throws Exception {
		try {
			element = driver.findElement(By.name("username"));
			Log.info("UserName text box is found on the Login Page");
		} catch (Exception e) {
			Log.error("********UserName text box is not found on the Login Page********");
		}
		return element;
	}

	// 获取密码输入框元素
	@Test
	public static WebElement txt_Password() throws Exception {
		try {
			element = driver.findElement(By.name("password"));
			Log.info("Password text box is found on the Login Page");
		} catch (Exception e) {
			Log.error("********Password text box is not found on the Login Page********");
		}
		return element;
	}

	// 获取登录按钮元素
	@Test
	public static WebElement btn_LogIn() throws Exception {
		try {
			element = driver.findElement(By.name("login"));
			Log.info("LogIn button is found on the Login Page");
		} catch (Exception e) {
			Log.error("********LogIn button is not found on the Login Page********");
		}
		return element;
	}
}

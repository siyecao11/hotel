package com.travelzen.Insurance.PurchaseInsurance.TestCase.FunctionCases;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.travelzen.Login.PurchaseLogin.TestCase.FunctionCases.LoginPurchase;
import com.travelzen.Insurance.PurchaseInsurance.Utility.Utils.DataProviderApp;
import com.travelzen.Utility.Assertion.Assertion;
import com.travelzen.Utility.Constants.Constants;
import com.travelzen.Utility.ScreenShot.RetryFail;
import com.travelzen.Utility.Utils.*;
import com.travelzen.Insurance.PurchaseInsurance.AppModules.*;

public class BuyInsuranceTC {

	public static WebDriver currentDriver;
	public static String actualTestCase;
	// 从正常单获取Driver

	@BeforeClass(alwaysRun = true)
	public static void beforeClass() {

	}

	@BeforeMethod(alwaysRun = true)
	public static void beforeMethod() {
		// 从登陆过去
		currentDriver = LoginPurchase.driver;
		Constants.classDriver = currentDriver;
	}

	@AfterMethod(alwaysRun = true)
	public static void afterMethod() {

		if (DataProviderApp.isLoginIncludeProcess.equalsIgnoreCase("false")) {
			currentDriver.close();
		}
	}
	// 预定指定保险产品
		@Test(priority = 4, groups = {"立即购买" })
		@Parameters("testCase")
		public static void getInsuranceName(String testCase) throws Exception {
			actualTestCase = testCase;
			
		}


	// 预定指定保险产品
	@Test(dataProvider = "insurance_buyProduct", priority = 5, groups = {
			"立即购买" }, dataProviderClass = DataProviderApp.class)
	@Parameters("actualTestCase")
	public static void buyInsurance(String testCase, String insuranceName) throws Exception {
		if (testCase.equalsIgnoreCase(actualTestCase)) {
			// 选择保险产目录
			BaseAction.transmitDriver(currentDriver);
			BaseAction.excutSelectInsuranceAction();
			Utils.waitForElement(1, currentDriver, "wait");
			// 选中测试用例对应的保险产品
			Thread.sleep(2000);
			InsuranceListAction.transmitDriver(currentDriver);
			InsuranceListAction.excutBuyInsuranceAction(insuranceName);
			Utils.waitForElement(1, currentDriver, "wait");

		}
	}
	// 预定指定保险产品
		@Test(dataProvider = "insurance_productEffectivePeriod", priority = 5, groups = {
				"校验产品生效日期FC" }, dataProviderClass = DataProviderApp.class)
		@Parameters("actualTestCase")
		public static void buyInsurance(String insuranceName,String effectiveDate,String period) throws Exception {
			
				// 选择保险产目录
				BaseAction.transmitDriver(currentDriver);
				BaseAction.excutSelectInsuranceAction();
				Utils.waitForElement(1, currentDriver, "wait");
				// 选中测试用例对应的保险产品
				Thread.sleep(2000);
				InsuranceListAction.transmitDriver(currentDriver);
				InsuranceListAction.excutBuyInsuranceAction(insuranceName);
				Utils.waitForElement(1, currentDriver, "wait");
				//传递driver到建单页面
				CreatOrderAction.transmitDriver(currentDriver);
				//输入产品生效日期
				CreatOrderAction.excutEffectiveDateAction(effectiveDate);
				//选中日历控件中保险生效时间
				CreatOrderAction.excutEffectiveEndDateClickAction();
				//计算得出产品生效截止日期
				String eEndDate = getSpecifiedDayAfter(effectiveDate,period);
				System.out.println("返回的失效日期转换的字符串是："+eEndDate);
				//获取页面显示生效截止日期
				String EndDate = CreatOrderAction.excutEffectiveEndDateAction();
				Assertion.verifyEquals(EndDate, eEndDate, 
						"期望保险生效截止时间：" + eEndDate + ";实际保险生效截止时间:" + EndDate);
				Thread.sleep(3000);
				
			
		}

		/**
		 * 字符串转换成日期
		 * 
		 * @param str
		 * @return date
		 */
		@Test
		public static Date StrToDate(String str) {

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date date = null;
			try {
				date = format.parse(str);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return date;
		}
		
		/**
		* 日期转换成字符串
		* @param date
		* @return str
		*/
		@Test
		public static String DateToStr(Date date) {
		  
		   SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		   String str = format.format(date);
		   return str;
		} 
		
		/**
		* 获得指定日期的后n天
		* @param specifiedDay n
		* @return dayAfter
		*/
		@Test
		public static String getSpecifiedDayAfter(String specifiedDay,String n){
			System.out.println("获取的生效日期是："+specifiedDay+"和有效时间是："+n+"天");
		Calendar c = Calendar.getInstance();
		Date date=null;
		try {
		date = new SimpleDateFormat("yy-MM-dd").parse(specifiedDay);
		System.out.println("获取的生效日期转换的日期格式时间是："+date);
		} catch (ParseException e) {
		e.printStackTrace();
		}
		c.setTime(date);
		int day=c.get(Calendar.DATE);
		int num=Integer.parseInt(n);
		c.set(Calendar.DATE,day+num-1);

		String dayAfter=new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
		System.out.println("获取的失效日期转换的字符串是："+dayAfter);
		return dayAfter;
		} 
}

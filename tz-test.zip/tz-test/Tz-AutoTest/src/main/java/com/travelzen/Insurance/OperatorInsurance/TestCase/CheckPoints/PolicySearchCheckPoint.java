package com.travelzen.Insurance.OperatorInsurance.TestCase.CheckPoints;
/**
 * author：qiqi.wang
 * */
import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.PageObjects.PolicySearchPage;
import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.Constant;
import com.travelzen.Insurance.OperatorInsurance.AppModules.OrderSearchAction;
import com.travelzen.Insurance.OperatorInsurance.AppModules.PolicySearchAction;
import com.travelzen.Utility.Assertion.Assertion;
import com.travelzen.Utility.DataDriver.ExcelAction;
import com.travelzen.Utility.LogCenter.Log;
public class PolicySearchCheckPoint
{
	public static String productExcelName = "Insurance/Datas/KeepForProductInfo.xls";
	public static String OrderDetailsExcelName = "Insurance/Datas/OperaterCreateOrder.xls";
	public static void OrderSearch(WebDriver driver) throws Exception{
	
		PolicySearchAction.transmitDriver(driver);
		//保单查询页面-获取保单状态-文本
			String PolicyState = PolicySearchAction.excutePolicyState();
		//保单查询页面-保单号-文本
			String PolicyNum = PolicySearchAction.excutePolicyNum();
		//保单查询页面-订单号-文本
			String OrderNum = PolicySearchAction.excuteOrderNum();
		//保单查询页面-被保人姓名-文本
			String CustomerName = PolicySearchAction.excuteCustomerName();
		//保单查询页面-证件类型-文本
			String CardStyle = PolicySearchAction.excuteCardStyle();
		//保单查询页面-证件号码-文本
			String CardNum = PolicySearchAction.excuteCardNum();	
		//保单查询页面-投保人-文本
			String ApplicantName = PolicySearchAction.excuteApplicantName();
		//保单查询页面-生效日期-文本
			String InsuranceStart = PolicySearchAction.excuteInsuranceStart();
		//保单查询页面-截止日期-文本
			String InsuranceEnd = PolicySearchAction.excuteInsuranceEnd();
		//保单查询页面-投保日期-文本
			String CreateOrderDate = PolicySearchAction.excuteCreateOrderDate();
	
		//期望值
			String ePolicyNum = Constant.PolicyID;
			String eOrderNum = Constant.OperatorOrderId;
			String eCustomerName = ExcelAction.getValue(OrderDetailsExcelName, "CustomerName");
			String eCardStyle = ExcelAction.getValue(OrderDetailsExcelName, "IDType");
			String eCardNum = ExcelAction.getValue(OrderDetailsExcelName, "IDNum");
			String eApplicantName = ExcelAction.getValue(OrderDetailsExcelName, "CustomerName");
			String eInsuranceStart = ExcelAction.getValue(OrderDetailsExcelName, "StartDate");
		//进行比较
			Assertion.verifyEquals(PolicyNum, ePolicyNum, "期望保单号："+ePolicyNum+";实际保单号:"+PolicyNum);
			Assertion.verifyEquals(OrderNum, eOrderNum, "期望订单号："+eOrderNum+";实际订单号:"+OrderNum);
			Assertion.verifyEquals(CustomerName, eCustomerName, "期望被保人姓名："+eCustomerName+";实际被保人姓名:"+CustomerName);
			Assertion.verifyEquals(CardStyle, eCardStyle, "期望被保人证件类型："+eCardStyle+";实际被保人证件类型:"+CardStyle);
			Assertion.verifyEquals(CardNum, eCardNum, "期望被保人证件号："+eCardNum+";实际被保人证件号:"+CardNum);
			Assertion.verifyEquals(ApplicantName, eApplicantName, "期望投保人姓名："+eApplicantName+";实际投保人姓名:"+ApplicantName);
			Assertion.verifyEquals(InsuranceStart, eInsuranceStart, "期望保险生效时间："+eInsuranceStart+";实际保险生效时间:"+InsuranceStart);

	}
}

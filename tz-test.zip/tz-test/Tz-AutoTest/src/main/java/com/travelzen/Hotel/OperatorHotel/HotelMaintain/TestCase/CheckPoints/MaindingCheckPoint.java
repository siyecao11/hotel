package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.CheckPoints;

import java.util.List;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

//@Listeners({Hotel.OperatorHotel.PrepayHotel.utility.AssertionListener.class})
public class MaindingCheckPoint {

	@Test
	public void maindingCheckPoint() throws Exception {
		
		List<String> str;
		
	}

}

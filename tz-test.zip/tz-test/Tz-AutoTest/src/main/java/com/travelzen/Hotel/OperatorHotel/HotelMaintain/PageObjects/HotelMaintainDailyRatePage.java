package com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.utility.Constants.*;
import com.travelzen.Utility.LogCenter.Log;

public class HotelMaintainDailyRatePage {

	public static WebDriver driver;
	private static List<WebElement> elementList;
	private static WebElement element;
	private static Select selectNum;
	
	@Test
	public static void getWebDriver(WebDriver webdriver) {
		
		driver = webdriver;
		
	}
	
	//Location 选择房型的下拉选择框Select
	@Test
	public static Select getAllRoomCat() throws Exception{
		
		try{
			selectNum = new Select(driver.findElement(By.cssSelector("select[id='selRoomCat']")));
			Log.info("RoomCat Select element is found in RoomCat Page");
		}catch (Exception e){
			Log.error("RoomCat Select element is not found in RoomCat Page");
		}
		return selectNum;
	}
	
	//Location "下一页"元素
	@Test
	public static WebElement getNextPage() throws Exception{
		
		try{
			element = driver.findElement(By.id("nextPage_"));
			Log.info("nextPage_ element is found in RoomCat Page");
		}catch (Exception e){
			Log.error("nextPage_ element is not found in RoomCat Page");
		}
		return element;
	}
	
	//Location  修改礼包
	//多个房型：返回指定房型对应 修改礼包 元素
	@Test
	public static WebElement getModifyGifPackageElement() throws Exception{
		
		String ide = "sfbzf_top_" + Constant.roomId;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/ul/li[4]/a"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("ModifyGifPackage elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("ModifyGifPackage elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Location  删除礼包
	//多个房型：返回指定房型对应 删除礼包 元素
	@Test
	public static WebElement getDeleteGifPackageElement() throws Exception{
		
		String ide = "sfbzf_top_" + Constant.roomId;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/ul/li[3]/a"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("DeleteGifPackage elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("DeleteGifPackage elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//**********************************房型 “修改礼包” 内容元素定位  Start  ******************************
	
	//Location  选择价格计划
	//多个几个计划：返回指定的一个价格计划
	@Test
	public static WebElement getSelectBookingClassElement() throws Exception{
		
		String ide = "addPackageWindow_" + Constant.roomId;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/table/tbody/tr/td/label/input"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("SelectBookingClass elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("SelectBookingClass elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Location  有效期 起始时间
	//Test
	public static WebElement getStartDate() throws Exception{
		
		String ide = "addPackageWindow_" + Constant.roomId;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/table/tbody/tr[3]/td/input"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("StartDate elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("StartDate elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Location 有效期 起始时间 -- 时间插件
	//当天为起始时间
	@Test
	public static WebElement getStartDateTime() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("em[class='fastival today']"));
			Log.info("StartDate elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("StartDate elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Location 有效期 截止时间 -- 时间插件
	//当天为起始时间
	@Test
	public static void getEndDateTime() throws Exception{
		
		try{
			element = driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div[2]"));
			element.findElement(By.linkText("30")).click();
			Log.info("EndDate elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("EndDate elements is not found in RoomRate Page");
		}
	}
	
	//Location  有效期 截止时间
	//Test
	public static WebElement getEndDate() throws Exception{
		
		String ide = "addPackageWindow_" + Constant.roomId;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/table/tbody/tr[3]/td/input[2]"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("EndDate elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("EndDate elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Location  添加有效期btn
	@Test
	public static WebElement getAddTimeBtnElement() throws Exception{
		
		String ide = "addPackageWindow_" + Constant.roomId;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/table/tbody/tr[3]/td/a"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("AddTimeBtn elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("AddTimeBtn elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Location  赠送方式（每间房赠送一次 、每间房每晚）
	//此处仅定位返回 每间房每晚 的类型
	@Test
	public static WebElement getPresentTypeElement() throws Exception{
		
		String ide = "addPackageWindow_" + Constant.roomId;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/table/tbody/tr[5]/td/label[2]/input"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("PresentType elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("PresentType elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Location  礼包内容编辑框
	@Test
	public static WebElement getGiftPackageContentElement() throws Exception{
		
		String ide = "addPackageWindow_" + Constant.roomId;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/table/tbody/tr[6]/td/textarea"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("GiftPackageContent elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("GiftPackageContent elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Location  添加礼包 -- 确定 按钮
	@Test
	public static WebElement getAddGiftPackageConfirmBtnElement() throws Exception{
		
		String ide = "addPackageWindow_" + Constant.roomId;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/table/tbody/tr[8]/td/div/a"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("AddGiftPackageConfirmBtn elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("AddGiftPackageConfirmBtn elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Location  添加礼包 -- 取消 按钮
	@Test
	public static WebElement getAddGiftPackageCancleBtnElement() throws Exception{
		
		String ide = "addPackageWindow_" + Constant.roomId;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/table/tbody/tr[8]/td/div/a[2]"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("AddGiftPackageCancleBtn elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("AddGiftPackageCancleBtn elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//**********************************房型 “修改礼包” 内容元素定位     EDN	 ******************************
	
	//Location  "修改 "
	//多个房型：同时返回房型对应 修改 元素
	@Test
	public static WebElement getModifyDailyRateElement() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@class='df_page_btn show']/p/a[1]"));
			Log.info("ModifyDailyRate elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("MModifyDailyRate elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Location  "修改 " 之  “保存”
	@Test
	public static WebElement getModifyDailyRateElement_Save() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@class='bcqx edit']/a[1]"));
			Log.info("ModifyDailyRate save elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("MModifyDailyRate save elements is not found in RoomRate Page");
		}
		return element;
	}

	//******************房型 “修改每日价格信息” 保存之 “变价原因” 内容元素定位*********************
	
	//Location  "修改 " “保存” 之  “变价原因” 输入框元素定位
	@Test
	public static WebElement getModifyDailyRateElement_SavePriceChangeCauses() throws Exception{
		
		try{
			//element = driver.findElement(By.xpath(".//*[@class='qzmbjyy']/textarea[1]"));
			String str = Constant.roomId;
			element = driver.findElement(By.id("priceChangeCauses_"+str));
			Log.info("ModifyDailyRate save PriceChangeCauses elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("MModifyDailyRate save PriceChangeCauses elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Location "修改 " “保存” 之  “变价原因” “确定” 元素定位
	@Test
	public static WebElement getDailyRateElement_Save_PriceChangeCauses_Save() throws Exception{
		
		try{
			//element = driver.findElement(By.cssSelector("a[class='tianjiaqueding_btn']"));
			String str ="updateSaveDiv_" + Constant.roomId;
			String xp = "//*[@id=" +"'" + str + "'" + "]/div/div/a";
			element = driver.findElement(By.xpath(xp));
			Log.info("DailyRateElement_Save_PriceChangeCauses_Save elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.error("DailyRateElement_Save_PriceChangeCauses_Save elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//Location "修改 " “保存” 之  “变价原因” “取消” 元素定位
	@Test
	public static WebElement getDailyRateElement_Save_PriceChangeCauses_Cancle() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[class='tianjiaquxiao_btn']"));
			Log.info("DailyRateElement_Save_PriceChangeCauses_Cancle elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.info("DailyRateElement_Save_PriceChangeCauses_Cancle elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//***************************************	EDN	 ***************************************
		
	
	//Location  "修改 " 之  “取消”
	@Test
	public static WebElement getModifyDailyRateElement_Cancle() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@class='bcqx edit']/a[2]"));
			Log.info("ModifyDailyRate cancle elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("MModifyDailyRate cancle elements is not found in RoomRate Page");
		}
		return element;
	}
	
	//Locatin 房型的每天  “价格”元素框
	@Test
	public static List<WebElement> getDailyPriceContainerEdit() throws Exception{
		
		try{
			//DailyPrice 每日价格元素  每个房型对应显示最近7天的，即7个元素框
			elementList = driver.findElements(By.cssSelector("input[name='roomCost']"));
			Log.info("All of DailyPriceContainerEdit elements is found in RoomRate Page");
		}catch (Exception e){
			Log.info("DailyPriceContainerEdit elements is not found in RoomRate Page");
		}
		return elementList;
	}
	
	//Locatin 房型的每天 “规定”元素
	@Test
	public static List<WebElement> getDailyPriceRule() throws Exception{
		
		try{
			//DailyPriceRule 每日价格规定元素  每个房型对应显示最近7天的，即7个元素
			elementList = driver.findElements(By.cssSelector("span[class='rule']"));
			Log.info("All of DailyPriceContainerRule elements is found in RoomRate Page");
		}catch (Exception e){
			Log.info("DailyPriceContainerRule elements is not found in RoomRate Page");
		}
		return elementList;
	}
	
	//******************************房型 “每日规定” 内容元素定位  Start ********************************
	
	//Location “包含服务” -> “宽带” 元素
	@Test
	public static WebElement getDailyRule_Broadband(String sDate) throws Exception{
		
		String sid = "broadband_" + Constant.bookingClassId + "_" + sDate;
		try{
			element = driver.findElement(By.id(sid));
			Log.info("DailyRule_Broadband elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.info("DailyRule_Broadband elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//Location “包含服务” -> “早餐” 元素
	@Test
	public static Select getDailyRule_BreakFast() throws Exception{
		
		try{
			selectNum = new Select(driver.findElement(By.cssSelector("select[servicedetail='BUFFET_BREAKFAST']")));
			Log.info("DailyRule_BreakFast Select element is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.error("DailyRule_BreakFast Select element is not found in RoomRate_DailyRule Page");
		}
		return selectNum;
	}
	
	//Location “礼包信息” -> “删除礼包” 元素
	@Test
	public static WebElement getDailyRule_PackageInfoDel() throws Exception{
		
		try{
			element = driver.findElement(By.xpath("//*[@class='clock package']/div/p/label"));
			Log.info("DailyRule_PackageInfo Delete elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.info("DailyRule_PackageInfo Delete elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//Location “增加规定” -> “入住时间” 元素
	@Test
	public static Select getDailyRule_CheckInTime(String sDate) throws Exception{
		
		String sid = "checkInTime_" + Constant.bookingClassId + "_" + sDate;
		try{
			element = driver.findElement(By.id(sid));
			selectNum = new Select(element);
			Log.info("DailyRule_CheckInTime Select element is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.error("DailyRule_CheckInTime Select element is not found in RoomRate_DailyRule Page");
		}
		return selectNum;
	}
	
	//Location “增加规定” -> “退房时间” 元素
	@Test
	public static Select getDailyRule_CheckOutTime(String sDate) throws Exception{
		
		String sid = "checkOutTime_" + Constant.bookingClassId + "_" + sDate;
		try{
			element = driver.findElement(By.id(sid));
			selectNum = new Select(element);
			Log.info("DailyRule_CheckOutTime Select element is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.error("DailyRule_CheckOutTime Select element is not found in RoomRate_DailyRule Page");
		}
		return selectNum;
	}
	
	//Location “增加规定” -> “入住前” “ 天 ” 元素
	@Test
	public static WebElement getDailyRule_CheckInDay(String sDate) throws Exception{
		
		String sid = "checkInDay_" + Constant.bookingClassId + "_" + sDate;
		try{
			element = driver.findElement(By.id(sid));
			Log.info("DailyRule_CheckInDay elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.info("DailyRule_CheckInDay elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//Location “增加规定” -> “入住前” “ 点 ” 元素
	@Test
	public static WebElement getDailyRule_CheckInPoint(String sDate) throws Exception{
		
		String sid = "checkInPoint_" + Constant.bookingClassId + "_" + sDate;
		try{
			element = driver.findElement(By.id(sid));
			Log.info("DailyRule_CheckInPoint elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.info("DailyRule_CheckInPoint elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//Location “增加规定” -> “扣除房费”规则 元素
	@Test
	public static Select getDailyRule_CancleTerm(String sDate) throws Exception{
		
		String sid = "cancelTerm_" + Constant.bookingClassId + "_" + sDate;
		try{
			selectNum = new Select(driver.findElement(By.id(sid)));
			Log.info("DailyRule_CancleTerm Select element is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.error("DailyRule_CancleTerm Select element is not found in RoomRate_DailyRule Page");
		}
		return selectNum;
	}
	
	//Location “增加规定” -> “添加” 元素
	@Test
	public static WebElement getDailyRule_AddRulebtn(String sDate) throws Exception{
		
		String ide = "termValid_" + Constant.bookingClassId + "_" + sDate;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/div[3]/a"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("DailyRule_AddRulebtn elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.info("DailyRule_AddRulebtn elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//Location “增加规定” -> “删除原规定” 元素
	@Test
	public static WebElement getDailyRule_DelNewTerm(String sDate) throws Exception{
		
		String ide = "termValid_" + Constant.bookingClassId + "_" + sDate;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/div[4]/div/p/label"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("DailyRule_DelNewTerm elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.info("DailyRule_DelNewTerm elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//Location “确定” 元素
	@Test
	public static WebElement getDailyRule_SaveRuleEdit(String sDate) throws Exception{
		
		String ide = "edit_serviceRequire_" + Constant.bookingClassId + "_" + sDate;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/div/a"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("DailyRule_SaveRuleEdit elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.info("DailyRule_SaveRuleEdit elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//Location “取消” 元素
	@Test
	public static WebElement getDailyRule_CancleRuleEdit(String sDate) throws Exception{
		
		String ide = "edit_serviceRequire_" + Constant.bookingClassId + "_" + sDate;
		try{
			String sxp = "//*[@id=" + "'" + ide + "'" + "]/div/a"; 
			element = driver.findElement(By.xpath(sxp));
			Log.info("DailyRule_CancleRuleEdit elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.info("DailyRule_CancleRuleEdit elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//**********************************房型 “每日规定” 内容元素定位  EDN  **********************************
	
	//Location  “按时段修改”
	//多个房型：同时返回房型对应  按时段修改  元素集
	@Test
	public static List<WebElement> getModifyDailyRate_DurTimeElement() throws Exception{
		
		try{
			elementList = driver.findElements(By.xpath("//*[@class='df_page_btn show']/p/a[2]"));
			Log.info("All of ModifyDailyRate_DurTime elements is found in RoomRate Page");
		}catch (Exception e){
			Log.error("ModifyDailyRate_DurTime elements is not found in RoomRate Page");
		}
		return elementList;
	}
	
	//***********************************房型 “按时段修改” 内容元素定位  Start  *******************************
	
	
	//***********************************房型 “按时段修改” 内容元素定位	EDN	 *********************************
	
	
	//***************************酒店信息完成后 “提交审核”内容元素定位  Start  *********************************
	
	//Location “提交” 元素
	@Test
	public static WebElement getCommitAuditElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("audit"));
			Log.info("CommitAudit elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.info("CommitAudit elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//Location “关闭” 元素
	@Test
	public static WebElement getCloseCommitAuditElement() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='/tops-front-operator-hotel/hotel/operator/maintain/search']"));
			Log.info("CloseCommitAudit elements is found in RoomRate_DailyRule Page");
		}catch (Exception e){
			Log.info("CloseCommitAudit elements is not found in RoomRate_DailyRule Page");
		}
		return element;
	}
	
	//******************************酒店信息完成后 “提交审核”内容元素定位   EDN  *****************************
}

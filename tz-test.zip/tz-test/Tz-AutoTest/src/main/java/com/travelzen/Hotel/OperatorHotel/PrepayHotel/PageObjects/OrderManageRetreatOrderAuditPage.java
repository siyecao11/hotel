package com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.Log;


public class OrderManageRetreatOrderAuditPage {
	public static WebDriver driver;
	private static WebElement element;
	// private static List<Select> selectNumList;
	
	//退订单审核页面元素
	//取消退订、确认退订
	@Test
	public static void getWebDriver(WebDriver webdriver) {

		driver = webdriver;

	}



	// *********************获取确认退订单页面元素***********************
	//
	@Test
	public static WebElement getConfirm_RetreatOrder_Link() throws Exception {

		// getConfirmBooking_Link().click();
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='operator_confirm_refund_order']/span[2]"));
			Log.info(" Creat_RetreatOrder_Link element is found in OrderManage_RetreatOrder_Audit_Page");
		} catch (Exception e) {
			Log.error(" Creat_RetreatOrder_Link element is not found in OrderManage_RetreatOrder_Audit_Page");
		}
		return element;
	}

	// *********************获取取消退订单页面元素***********************
	//
	@Test
	public static WebElement getCancel_RetreatOrder_Link() throws Exception {

		// getConfirmBooking_Link().click();
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='operator_cancel_refund_order']/span[2]"));
			Log.info(" Cancel_RetreatOrder_Link element is found in OrderManage_RetreatOrder Page");
		} catch (Exception e) {
			Log.error(" Cancel_RetreatOrder_Link element is not found in OrderManage_RetreatOrder_Audit_ Page");
		}
		return element;
	}
	
	//Location 取消退订--取消原因  元素
	@Test
	public static WebElement getCancelRemarkElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("cancelRemark"));
			Log.info("cancelRemark elements is found in OrderManage_RetreatOrder_Audit_ Page");
		}catch (Exception e){
			Log.error("cancelRemark elements is not found in OrderManage_RetreatOrder_Audit_ Page");
		}
		return element;
	}
	
	//Location 取消退订--取消--保存 元素
	@Test
	public static WebElement getCancelOrderSaveElement() throws Exception{
		
		try{
			element = driver.findElement(By.id("cancelOrderWindow_save"));
			Log.info("cancelOrderWindow_save elements is found in OrderManage_RetreatOrder_Audit_ Page");
		}catch (Exception e){
			Log.error("cancelOrderWindow_save elements is not found in OrderManage_RetreatOrder_Audit_ Page");
		}
		return element;
	}
}

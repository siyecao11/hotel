package com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.travelzen.Utility.LogCenter.Log;
/*
 * 
 * 变更单创建页面
 * 
 * */
public class OrderManageEndorseOrderCreatePage extends BaseClass{

	public static WebDriver driver;
	private static WebElement element;
	public OrderManageEndorseOrderCreatePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

    public static void GetDriver(WebDriver webdriver){
    	driver = webdriver;
    }
    
    //创建变更单按钮
    public static WebElement CreateButton() throws Exception{
    	try{
    		element = driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/div/div/div[2]/div[3]/a[3]/span[2]"));
    	}catch (Exception e){
    		Log.error("CreateButton is not found in the EndorseOrder_Create Page.");
    	}
    	return element;
    }
    
    
    
    
    
    
    
    
    
    
    
    
}

package com.travelzen.Insurance.OperatorInsurance.PageObjects;
/**
 * author：qiqi.wang
 * */
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Utility.LogCenter.Log;

public class OrderPaymentPage
{
	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	public static String option;
	
	public static void getDriver(WebDriver webDriver) throws Exception{
		driver = webDriver;
	}
	
	//订单支付页面-获取用户名，订单号码-文本， wang（预存客户） - 订单号1601091106032021
	public static WebElement getCustomerNameOrderIDElement() throws Exception{
		try{
			element = driver.findElement(By.className("pms-label"));
			Log.info("订单支付页面“用户名订单号码”文本元素，已找到");
		}catch(Exception e){
			Log.error("订单支付页面“用户名订单号码”文本元素，未找到");
		}
		return element;
	} 
	
	//订单支付页面-获取支付金额-文本，11.00
	public static WebElement getTotalPayElement() throws Exception{
		try{
			element = driver.findElement(By.className("pms-money"));
			Log.info("订单支付页面“支付金额”文本元素，已找到");
		}catch(Exception e){
			Log.error("订单支付页面“支付金额”文本元素，未找到");
		}
		return element;
	} 
	
}

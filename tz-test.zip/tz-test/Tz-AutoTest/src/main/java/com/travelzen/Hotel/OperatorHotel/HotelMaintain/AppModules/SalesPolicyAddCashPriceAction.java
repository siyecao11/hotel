package com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.travelzen.Utility.LogCenter.*;
import com.travelzen.Utility.Assertion.*;
import com.travelzen.Utility.DataDriver.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.SalesPolicyAddCashPricePage;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.SalesPolicyAddPrePayPricePage;
//import Hotel.OperatorHotel.PrepayHotel.utility.Assertion;
//import Hotel.OperatorHotel.PrepayHotel.utility.ExcelAction;

public class SalesPolicyAddCashPriceAction {
	
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception{
		SalesPolicyAddCashPricePage.getWebDriver(driver);
	}
	@Test//输入规则名称
	public static void inputPolicyName(String ruleName) throws Exception{
		//String name = new String();
		//name = "tllruler";
		SalesPolicyAddCashPricePage.getPolicyName().sendKeys(ruleName);
		Log.info(" ***********PolicyName is writed ***********");
	}
	@Test//输入有效期开始日期
	public static void inputValidStartDate(String startDate) throws Exception{
		//String date = new String();
		//date = "2015-01-01";
		SalesPolicyAddCashPricePage.getValidStartDate().sendKeys(startDate);
		Log.info(" ***********ValidStartDate is writed ***********");
	}
	
	@Test//输入有效期结束日期
	public static void inputValidEndDate(String endDate) throws Exception{
		//String date = new String();
		//date = "2017-01-01";
		SalesPolicyAddCashPricePage.getValidEndDate().sendKeys(endDate);
		Log.info(" ***********ValidEndDate is writed ***********");
	}
	
	@Test//反选星期
	public static void clickUnCheckedWeekDay() throws Exception{
		List<WebElement> elementList =  SalesPolicyAddCashPricePage.getUnCheckedWeekDay();
		if(CollectionUtils.isNotEmpty(elementList)){
			for(WebElement element : elementList){
				element.click();
			}
		}
		Log.info(" ***********unchecked weekday is clicked ***********");
	}
	@Test//输入客户返佣金额
	public static void inputFormularNumber(String number) throws Exception{
		//String number = new String();
		//number = "1";
		SalesPolicyAddCashPricePage.getFormularNumber().sendKeys(number);
		Log.info(" ***********FormularNumber is writed ***********");
	}
	@Test //选择客户设置
	public static void selectCustomerSet() throws Exception{
		SalesPolicyAddCashPricePage.getCustomerSet().click();
		Log.info("***********CustomerSet is selected ***********");
	}
	@Test //点击确认切换按钮
	public static void clickConfirmBtn() throws Exception{
		SalesPolicyAddCashPricePage.getConfirmBtn().click();
		Log.info("***********ConfirmBtn is selected ***********");
	}
	@Test //输入客户名称
	public static void inputCustomerName(String customerName) throws Exception{
		//String customerName = new String();
		//customerName = "tll";
		SalesPolicyAddCashPricePage.getCustomerName().sendKeys(customerName);//用例传入参数：客户名称
		Log.info("***********CustomerName is writed***********");
	}
	@Test //点击查询客户按钮
	public static void clickSearchCustomer() throws Exception{
		SalesPolicyAddCashPricePage.getSearchCustomer().click();
		Log.info("***********SearchCustomer is clicked***********");
	}
	@Test //选中查询出来的全部客户
	public static void clickCheckCustomer() throws Exception{
		SalesPolicyAddCashPricePage.getCheckCustomer().click();
		Log.info("***********CheckCustomer is clicked***********");
	}
	@Test //点击发布售价按钮
	public static void clickImportBtn() throws Exception{
		SalesPolicyAddCashPricePage.getImportBtn().click();
		Log.info("***********ImportBtn is clicked***********");
	}
	@Test//进入售价规则详情页
	public static void clickRuleName() throws Exception{
		SalesPolicyAddPrePayPricePage.rulesDetils().click();
		Log.info("***********ruleName is clicked***********");
	}
	@Test //比较规则名称
	public static void rulesName() throws Exception{
		String rulename = SalesPolicyAddPrePayPricePage.getRuleName().getText();
		String erulename = ExcelAction.getValue("Hotel/SalesPolicy.xls", "ruleName");
		Assertion.verifyEquals(rulename, erulename,"***********ruleName is same***********");
	}
	@Test//比较规则有效期
	public static void rulesTime() throws Exception{
		String Totaltime = SalesPolicyAddPrePayPricePage.getRulesTime().getText();
		String Starttime = Totaltime.substring(0, 10);
		System.out.println(Totaltime+"-----------"+Starttime);
		String Endtime = Totaltime.substring(13,23);
		System.out.println(Totaltime+"-----------"+Endtime);
		String eStarttime = ExcelAction.getValue("Hotel/SalesPolicy.xls", "startDate");
		String eEndtime = ExcelAction.getValue("Hotel/SalesPolicy.xls", "endDate");
		Assertion.verifyEquals(Starttime, eStarttime, "***********startDate is same***********");
		Assertion.verifyEquals(Endtime, eEndtime, "***********endDate is same***********");
	}

	@Test//点击返回按钮
	public static void back() throws Exception{
		SalesPolicyAddPrePayPricePage.backButton().click();
		Log.info("***********ruleName is clicked***********");
	}

}

package com.travelzen.Insurance.OperatorInsurance.TestCase.CheckPoints;
/**
 * author:qiqi.wang
 * */
import org.openqa.selenium.WebDriver;

import com.travelzen.Insurance.OperatorInsurance.Utility.Constants.Constant;
import com.travelzen.Insurance.OperatorInsurance.AppModules.OrderDetailAction;
import com.travelzen.Utility.Assertion.Assertion;
import com.travelzen.Utility.DataDriver.ExcelAction;
import com.travelzen.Utility.LogCenter.Log;

public class OrderDetailsCheckPoint
{
	public static String productExcelName = "Insurance/Datas/KeepForProductInfo.xls";
	public static String OrderDetailsExcelName = "Insurance/Datas/OperaterCreateOrder.xls";
	public static void OrderDetails(WebDriver driver) throws Exception{
			OrderDetailAction.transmitDriver(driver);
		//获取订单号
			String OrderID = OrderDetailAction.excuteOrderID();	
		//获取客户姓名-文本	
			String CustomerName = OrderDetailAction.excuteCustomerName();
		//获取联系人姓名-文本
			String ConstactName = OrderDetailAction.excuteConstactName();	
		//获取联系人电话-文本
			String ConstactTel =OrderDetailAction.excuteConstactTel();
		//获取联系人手机-文本
			String ConstactMobile =OrderDetailAction.excuteConstactMobile();
		//获取客户备注-输入框
			String CustomerRemark =OrderDetailAction.excuteCustomerRemarkinput();
		//获取内部备注-输入框
			String InsideRemark = OrderDetailAction.excuteInsideRemarkinput();
		//获取产品名称-文本
			String ProductName = OrderDetailAction.excuteProductName();
		//获取险种编号-文本
			String ProductID = OrderDetailAction.excuteProductID();
		//获取保险险种-文本
			String InsuranceType = OrderDetailAction.excuteInsuranceType();
		//获取保险期限-文本
			String InsuranceTime = OrderDetailAction.excuteInsuranceTime();
		//点单详情页面-最高保额-文本
			String InsuranceMaxCoverage = OrderDetailAction.excuteInsuranceMaxCoverage();
		//获取保险费用-文本
			String InsuranceCash = OrderDetailAction.excuteInsuranceCash();				
		//获取被保人姓名-文本
			String RecognizeeName = OrderDetailAction.excuteRecognizeeName();
		//获取被保人证件类型-文本
			String RecognizeeCardStyle = OrderDetailAction.excuteRecognizeeCardStyle();
		//获取被保人证件号码-文本
			String RecognizeeCardID = OrderDetailAction.excuteRecognizeeCardID();
		//获取被保人性别-文本
			String RecognizeeSex = OrderDetailAction.excuteRecognizeeSex();
		//获取被保人出生日期-文本
			String RecognizeeBirthday = OrderDetailAction.excuteRecognizeeBirthday();
		//获取被保人手机号码-文本
			String RecognizeeMobilePhone = OrderDetailAction.excuteRecognizeeMobilePhone();
		//获取保险生效日期-文本
			String InsuranceStartDate = OrderDetailAction.excuteInsuranceStartDate();
		//获取保单号-文本
			String PolicyID = OrderDetailAction.excutePolicyID();
			Constant.PolicyID = PolicyID;
		//获取保险份数-文本
			String InsuranceNumber = OrderDetailAction.excuteInsuranceNumber();
		//获取订单状态-文本
			String OrderState = OrderDetailAction.excuteOrderState();	
		//获取投保人姓名-文本
			String ApplicantName = OrderDetailAction.excuteApplicantName();
		//获取证件类型-文本
			String ApplicantCardStyle = OrderDetailAction.excuteApplicantCardStyle();
		//获取证件号码-文本
			String ApplicantCardID = OrderDetailAction.excuteApplicantCardID();	
		//获取投保人手机号码-文本
			String ApplicantMobilePhone = OrderDetailAction.excuteApplicantMobilePhone();
		//获取应收合计-文本
			String TotalCast = OrderDetailAction.excuteTotalCast();
		//获取保险份数-文本
			String InsuranceNum = OrderDetailAction.excuteInsuranceNum();	
		//获取保险单价-文本
			String InsurancePrice = OrderDetailAction.excuteInsurancePrice();
		
		
		//获取原始数据	
			String eOrderID = Constant.OperatorOrderId;
			Log.info(eOrderID);
			String eCustomerName = ExcelAction.getValue(OrderDetailsExcelName, "CustomerShortName");
			Log.info(eCustomerName);
			String eConstactName = Constant.ConstactName;
			String eConstactTel = Constant.ConstactTel;
			String eConstactMobile = Constant.ConstactMobile;
			String eProductName = ExcelAction.getValue(OrderDetailsExcelName, "ProductName");
			String eProductID = ExcelAction.getValue( productExcelName, "typeCode");
			String eInsuranceType = ExcelAction.getValue( productExcelName, "typeName");
			String eInsuranceTime = ExcelAction.getValue( productExcelName, "deadline");
			String eInsuranceMaxCoverage = ExcelAction.getValue( productExcelName, "insuranceAmount");
			String eInsuranceCash = ExcelAction.getValue( productExcelName, "normalPrice");				
			String eRecognizeeName = ExcelAction.getValue( OrderDetailsExcelName, "CustomerName");
			String eRecognizeeCardStyle = ExcelAction.getValue( OrderDetailsExcelName, "IDType");
			String eRecognizeeCardID = ExcelAction.getValue( OrderDetailsExcelName, "IDNum");
			String eRecognizeeSex = ExcelAction.getValue( OrderDetailsExcelName, "Sex");
			String eRecognizeeBirthday = ExcelAction.getValue( OrderDetailsExcelName, "BirthDate");
			String eRecognizeeMobilePhone = ExcelAction.getValue( OrderDetailsExcelName, "CustomerMobile");
			String eInsuranceStartDate = ExcelAction.getValue( OrderDetailsExcelName, "StartDate");
			String eInsuranceNumber = ExcelAction.getValue( OrderDetailsExcelName, "InsuranceNum");	
			//投保人信息
			String eApplicantName = ExcelAction.getValue( OrderDetailsExcelName, "CustomerName");
			String eApplicantCardStyle = ExcelAction.getValue( OrderDetailsExcelName, "IDType");
			String eApplicantCardID = ExcelAction.getValue( OrderDetailsExcelName, "IDNum");	
			String eApplicantMobilePhone = ExcelAction.getValue( OrderDetailsExcelName, "CustomerMobile");
		
			String eTotalCast = Constant.OperatorOrderPay;
			String eInsuranceNum = ExcelAction.getValue( OrderDetailsExcelName, "InsuranceNum");	
			String eInsurancePrice = ExcelAction.getValue( productExcelName, "normalPrice");
			
		Assertion.verifyEquals(OrderID, eOrderID, "期望订单号："+eOrderID+";实际订单号:"+OrderID);
		Assertion.verifyEquals(CustomerName, eCustomerName, "期望客户名称："+eCustomerName+";实际客户名称:"+CustomerName);
		Assertion.verifyEquals(ConstactName, eConstactName, "期望联系人姓名："+eConstactName+";实际联系人姓名:"+ConstactName);
		Assertion.verifyEquals(ConstactTel, eConstactTel, "期望联系人电话："+eConstactTel+";实际联系人电话:"+ConstactTel);
		Assertion.verifyEquals(ConstactMobile, eConstactMobile, "期望联系人手机："+eConstactMobile+";实际联系人手机:"+ConstactMobile);
		Assertion.verifyEquals(ProductName, eProductName, "期望产品名称："+eProductName+";实际产品名称:"+ProductName);
		Assertion.verifyEquals(ProductID, eProductID, "期望产品编号："+eProductID+";实际产品编号:"+ProductID);
		Assertion.verifyEquals(InsuranceType, eInsuranceType, "期望保险类型："+eInsuranceType+";实际保险类型:"+InsuranceType);
		Assertion.verifyEquals(InsuranceTime, eInsuranceTime, "期望保险期限："+eInsuranceTime+";实际保险期限:"+InsuranceTime);
		Assertion.verifyEquals(InsuranceMaxCoverage, eInsuranceMaxCoverage, "期望保险最大保额："+eInsuranceMaxCoverage+";实际保险最大保额:"+InsuranceMaxCoverage);
		Assertion.verifyEquals(InsuranceCash, eInsuranceCash, "期望保险价格："+eInsuranceCash+";实际保险价格:"+InsuranceCash);
		Assertion.verifyEquals(RecognizeeName, eRecognizeeName, "期望被保人姓名："+eRecognizeeName+";实际被保人姓名:"+RecognizeeName);
		Assertion.verifyEquals(RecognizeeCardStyle, eRecognizeeCardStyle, "期望被保人证件类型："+eRecognizeeCardStyle+";实际被保人证件类型:"+RecognizeeCardStyle);
		Assertion.verifyEquals(RecognizeeCardID, eRecognizeeCardID, "期望被保人证件号码："+eRecognizeeCardID+";实际被保人证件号码:"+RecognizeeCardID);
		Assertion.verifyEquals(RecognizeeSex, eRecognizeeSex, "期望被保人性别："+eRecognizeeSex+";实际被保人性别:"+RecognizeeSex);
		Assertion.verifyEquals(RecognizeeBirthday, eRecognizeeBirthday, "期望被保人出生日期："+eRecognizeeBirthday+";实际被保人出生日期:"+RecognizeeBirthday);
		Assertion.verifyEquals(RecognizeeMobilePhone, eRecognizeeMobilePhone, "期望被保人手机号码："+eRecognizeeMobilePhone+";实际被保人手机号码:"+RecognizeeMobilePhone);
		Assertion.verifyEquals(InsuranceStartDate, eInsuranceStartDate, "期望保险生效日期："+eInsuranceStartDate+";实际保险生效日期:"+InsuranceStartDate);
		Assertion.verifyEquals(InsuranceNumber, eInsuranceNumber, "期望保险份数："+eInsuranceNumber+";实际保险份数:"+InsuranceNumber);
		Assertion.verifyEquals(ApplicantName, eApplicantName, "期望投保人姓名："+eApplicantName+";实际投保人姓名:"+OrderID);
		Assertion.verifyEquals(ApplicantCardStyle, eApplicantCardStyle, "期望投保人证件类型："+eApplicantCardStyle+";实际投保人证件类型:"+ApplicantCardStyle);
		Assertion.verifyEquals(ApplicantCardID, eApplicantCardID, "期望投保人证件号码："+eApplicantCardID+";实际投保人证件号码:"+ApplicantCardID);
		Assertion.verifyEquals(ApplicantMobilePhone, eApplicantMobilePhone, "期望投保人手机号码："+eApplicantMobilePhone+";实际投保人手机号码:"+ApplicantMobilePhone);
		Assertion.verifyEquals(TotalCast, eTotalCast, "期望保险总花费："+eTotalCast+";实际保险总花费:"+TotalCast);
		Assertion.verifyEquals(InsuranceNum, eInsuranceNum, "期望保险份数："+eInsuranceNum+";实际保险份数:"+InsuranceNum);
		Assertion.verifyEquals(InsurancePrice, eInsurancePrice, "期望保险单价："+eInsurancePrice+";实际保险单价:"+InsurancePrice);
		//点击订单管理按钮
		OrderDetailAction.excuteOrderManagement();
			
			
			
	}
}

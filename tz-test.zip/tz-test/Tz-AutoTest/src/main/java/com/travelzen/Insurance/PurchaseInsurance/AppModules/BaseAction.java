package com.travelzen.Insurance.PurchaseInsurance.AppModules;

import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.*;
import com.travelzen.Insurance.PurchaseInsurance.PageObjects.*;

public class BaseAction {

	public static WebDriver webdriver;
	
	/*
	 * author xuemei.ren date 07/01/2016
	 */
	public static void transmitDriver(WebDriver currentDriver) throws Exception {

		webdriver = currentDriver;
		basePage.getDriver(currentDriver);
	}

	// 基本目录操作--打开保险目录
	public static void excutSelectInsuranceAction() throws Exception {
		basePage.getInsuranceLinkElement().click();
		Log.info("保险目录已被打开");
	}

}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.HotelMaintain.utility.Constants.*;
import com.travelzen.Utility.LogCenter.Log;


public class HotelMaintainProviderMessagePage extends BaseClass{
	
	private static WebElement element;
	public static WebDriver driver;
	public HotelMaintainProviderMessagePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	 
	public static void getDriver(WebDriver webdriver){
		driver = webdriver;
	}
    
	
	
	//编辑合同按钮
	@Test
	public static WebElement EditContract() throws Exception{
		try{
			element = driver.findElement(By.id("addContract"));
		}catch (Exception e){
			Log.error("********EditContract is not found on the ProviderMessage Page********");
		}
		return element;
	}
	
	//合同开始时间
	@Test
	public static WebElement ContractStartTime() throws Exception{
		try{
			//((JavascriptExecutor) driver).executeScript("document.getElementByName(\"contractStartDate\").readOnly = false;");
			element = driver.findElement(By.name("contractStartDate"));
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"contractStartDate\")[0];setDate.removeAttribute('readonly');");
		}catch (Exception e){
			Log.error("********ContractStartTime is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	@Test
	public static WebElement SetContractStartTime(String beginTime) throws Exception{
		try{
			element = driver.findElement(By.linkText(beginTime));
			//开始时间设置为当天
			//element.findElement(By.cssSelector("em.fastival.today"));

		}catch (Exception e){
			Log.error("********SetContractStartTime is not found on the ProviderMessage Page********");
		}
		return element;
		}
	//合同结束时间
	@Test
	public static WebElement ContractEndTime() throws Exception{
		try{
			element = driver.findElement(By.name("contractEndDate"));
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"contractEndDate\")[0];setDate.removeAttribute('readonly');");
		}catch (Exception e){
			Log.error("********ContractEndTime is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	@Test
	public static WebElement SetContractEndTime(String endTime) throws Exception{
		try{
			element = driver.findElement(By.linkText(endTime));
		}catch (Exception e){
			Log.error("********SetContractEndTime is not found on the ProviderMessage Page********");
		}
		return element;
		}
//到期提醒
	@Test
	public static WebElement RemindTime() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='beforeDays']"));
		}catch (Exception e){
			Log.error("********RemindTime is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//供应商类型
	@Test
	public static WebElement Supplier() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='supplier.supplierType']"));
		}catch (Exception e){
			Log.error("********Supplier is not found on the ProviderMessage Page********");
		}
		return element;
		}
	//供应商名称
	@Test
	public static WebElement SupplierName() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='typeContent']"));
		}catch (Exception e){
			Log.error("********SupplierName is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//供应商备注ע
	@Test
	public static WebElement SupplierRemark() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='typeRemark']"));
		}catch (Exception e){
			Log.error("********SupplierRemark is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//供应商实体
	@Test
	public static WebElement SupplierEntity() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@name='supplier.supplierEntity']"));
		}catch (Exception e){
			Log.error("********SupplierEntity is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	
	
	
	//供应商结算提醒
	@Test
	public static WebElement SupplierSettlePeriod() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@name='supplier.settlePeriod']"));
		}catch (Exception e){
			Log.error("********SupplierSettlePeriod is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	
	
	
	//收款人姓名
	@Test
	public static WebElement AccountName() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[10]/div[2]/form/table/tbody/tr[7]/td[2]/input[1]"));
		}catch (Exception e){
			Log.error("********AccountName is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//开户银行
	@Test
	public static WebElement BankName() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[10]/div[2]/form/table/tbody/tr[7]/td[2]/input[2]"));
		}catch (Exception e){
			Log.error("********BankName is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//开户账号
	@Test
	public static WebElement BankNumber() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[10]/div[2]/form/table/tbody/tr[7]/td[2]/input[3]"));
		}catch (Exception e){
			Log.error("********BankNumber is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	//保存合同
	@Test
	public static WebElement SaveContract() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/div[10]/div[2]/form/div/a[1]"));
		}catch (Exception e){
			Log.error("********SaveContract is not found on the ProviderMessage Page********");
		}
		return element;
		}
	
	/*****************************************************************************************************/	
	
	
	//添加联系人
	@Test
	public static WebElement AddContact() throws Exception{
		try{
			element = driver.findElement(By.id("addContact"));
		}catch (Exception e){
			Log.error("********AddContact is not found on the ProviderMessage Page********");
		}
		return element;
	}
	//修改联系人
	@Test
	public static WebElement EditContact() throws Exception{
		try{
			element = driver.findElement(By.id("editContact-0"));
		}catch (Exception e){
			Log.error("********EditContact is not found on the ProviderMessage Page********");
		}
		return element;
	}
	//联系人姓名
	@Test
	public static WebElement ContactName() throws Exception{
		try{
			element = driver.findElement(By.id("firstName"));
	}catch (Exception e){
		Log.error("********ContactName is not found on the ProviderMessage Page********");
	}
		return element;
	}
	
	//联系人手机
	@Test
	public static WebElement ContactMobilephone() throws Exception{
		try{
			element =driver.findElement(By.name("mobilePhone"));
		}catch (Exception e){
			Log.error("********ContactMobilephone is not found on the ProviderMessage Page********");
		}
		return element;
	}
	
	//联系人传真
	
	    @Test
		public static WebElement ContactFox() throws Exception{
			try{
				element =driver.findElement(By.name("fax"));
			}catch (Exception e){
				Log.error("********ContactFox is not found on the ProviderMessage Page********");
			}
			return element;
		}
		
	//联系人办公室电话
		@Test
		public static WebElement ContactOfficePhone() throws Exception{
			try{
				element =driver.findElement(By.name("officePhone"));
			}catch (Exception e){
				Log.error("********ContactOfficePhone is not found on the ProviderMessage Page********");
			}
			return element;
		}
	
	//联系人电子邮件
		@Test
		public static WebElement ContactEmail() throws Exception{
			try{
				element =driver.findElement(By.name("email"));
			}catch (Exception e){
				Log.error("********ContactEmail is not found on the ProviderMessage Page********");
			}
			return element;
		}
		
		
		
		
		
	//传真开始接受时间workingHours   /html/body/div[12]/div[2]/form/table/tbody/tr[3]/td[2]/label[8]/span/span/input
		
		@Test//开始时间
		public static WebElement WorkingHoursBegin() throws Exception{
			try{
				element =driver.findElement(By.xpath("/html/body/div[12]/div[2]/form/table/tbody/tr[3]/td[2]/label[8]/span/span/input"));
			}catch (Exception e){
				Log.error("********WorkingHoursBegin is not found on the ProviderMessage Page********");
			}
			return element;
		}
	
		@Test//结束时间
		public static WebElement WorkingHoursEnd() throws Exception{
			try{
				element =driver.findElement(By.xpath("/html/body/div[12]/div[2]/form/table/tbody/tr[3]/td[2]/label[9]/span/span/input"));
			}catch (Exception e){
				Log.error("********WorkingHoursEnd is not found on the ProviderMessage Page********");
			}
			return element;
		}
	
		//部门选择
	
	public static WebElement Dept() throws Exception{
		try{
			element =driver.findElement(By.name("dept"));
		}catch (Exception e){
			Log.error("********Dept is not found on the ProviderMessage Page********");
		}
		return element;
	} 
	
	
	
	
	//联系人备注
	
	public static WebElement ContactRemark() throws Exception{
		try{
			element = driver.findElement(By.name("remark"));
		}catch (Exception e){
			Log.error("********ContratRemark is not found on the ProviderMessage Page********");
		}
		return element;
	}
	
	//保存联系人

	public static WebElement SaveContact() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/div[12]/div[2]/form/div/a[1]"));
		}catch (Exception e){
			Log.error("********SaveContact is not found on the ProviderMessage Page********");
		}
		return element;
	}
	
	
	//跳转到酒店房型页面
	public static WebElement HotelHomeStyle() throws Exception{
		try{
			element =driver.findElement(By.id("roomCat"));
		}catch (Exception e){
			Log.error("********HotelHomeStyle is not found on the ProviderMessage Page********");
		}
		return element;
	}
 	
	
	
	}
	
	
	
	
	
	
	
	
	

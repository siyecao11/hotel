package com.travelzen.Insurance.OperatorInsurance.PageObjects;

/**
 * author：qiqi.wang
 * */
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.travelzen.Utility.LogCenter.Log;

public class PolicySearchPage
{
	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	public static String option;

	public static void getDriver(WebDriver webDriver) throws Exception
	{
		driver = webDriver;
	}

	// 保单查询页面-输入保单号-输入框
	public static WebElement getPolicyNumInputElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.name("insurancePolicyCode"));
			Log.info("保单查询页面“保单号”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面“保单号”输入框元素，未找到。");
		}
		return element;
	}

	// 保单查询页面-输入订单号-输入框
	public static WebElement getOrderNumInputElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.name("orderId"));
			Log.info("保单查询页面“订单号”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面“订单号”输入框元素，未找到。");
		}
		return element;
	}

	// 保单查询页面-投保日期开始日期-日期控件
	public static WebElement getInsuranceStartDateElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.name("startDate"));
			Log.info("保单查询页面“投保日期开始日期”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面“投保日期开始日期”输入框元素，未找到。");
		}
		return element;
	}

	// 保单查询页面-投保日期结束日期-日期控件
	public static WebElement getInsuranceEndDateElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.name("endDate"));
			Log.info("保单查询页面“投保日期结束日期”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面“投保日期结束日期”输入框元素，未找到。");
		}
		return element;
	}

	// 保单查询页面-被保险人姓名-输入框
	public static WebElement getCustomerNameInputElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.name("insurant"));
			Log.info("保单查询页面“被保险人姓名”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面“被保险人姓名”输入框元素，未找到。");
		}
		return element;
	}

	// 保单查询页面-投保人姓名-输入框
	public static WebElement getApplicantNameInputElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.name("insurer"));
			Log.info("保单查询页面“投保人姓名”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面“投保人姓名”输入框元素，未找到。");
		}
		return element;
	}

	// 保单查询页面-产品选择-下拉框
	public static WebElement getInsuranceProductSelectElement()
			throws Exception
	{
		try
		{
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			jsExecutor
					.executeScript("var setDate=document.getElementsByName(\"saleName\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By.name("saleName"));
			Log.info("保单查询页面中“选择保险产品”下拉框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面中“选择保险产品”下拉框元素，未找到。");
		}
		return element;
	}

	// 保单查询页面-选择订单状态-下拉框
	public static WebElement getOrderStateSelectElement() throws Exception
	{
		try
		{
			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
			jsExecutor
					.executeScript("var setDate=document.getElementsByName(\"state\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By.name("state"));
			Log.info("保单查询页面中“订单状态”下拉框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面中“订单状态”下拉框元素，未找到。");
		}
		return element;
	}

	// 保单查询页面-弹出创建人弹窗-按钮
		public static WebElement getCreaterButtonElement() throws Exception
		{
			try
			{
				element = driver
						.findElement(By.className("btns btn-search ac-search-operateUser"));
				Log.info("保单查询页面中“创建人弹窗”按钮元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“创建人弹窗”按钮元素，未找到。");
			}
			return element;
		}

		// 保单查询页面-输入登录名-输入框
		public static WebElement getLoginNameInputElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.name("username"));
				Log.info("保单查询页面中“登录名”输入框元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“登录名”输入框元素，未找到。");
			}
			return element;
		}

		// 保单查询页面-创建人搜索-按钮
		public static WebElement getCreaterSearchButtonElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.id("randomid_896370713"));
				Log.info("保单查询页面中“创建人搜索”按钮元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“创建人搜索”按钮元素，未找到。");
			}
			return element;
		}

		// 保单查询页面-创建人选择-文本
		public static WebElement getCreaterSelectElement() throws Exception
		{
			try
			{
				element = driver.findElement(By
						.xpath(".//*[@id='randomid_860277597']/tbody/tr[1]/td[1]"));
				Log.info("保单查询页面中“创建人选择”文本元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“创建人选择”文本元素，未找到。");
			}
			return element;
		}
	// 保单查询页面-弹出客户名称弹框-按钮
	public static WebElement getCustomerNameButtonElement()
	{
		try
		{
			element = driver
					.findElement(By.className("btns btn-search ac-search-customer"));
			Log.info("保单查询页面中“客户名称”弹窗元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面中“客户名称”弹窗元素，未找到。");
		}
		return element;
	}

	// 保单查询页面-输入客户简称-输入框
	public static WebElement getCustomerShortNameInputElement()
			throws Exception
	{
		try
		{
			element = driver.findElement(By.name("shortName"));
			Log.info("保单查询页面中“客户简称”输入框元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面中“客户简称”输入框元素，未找到。");
		}
		return element;
	}

	// 保单查询页面-客户搜索-按钮
	public static WebElement getCustomerSearchButtonElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.id("randomid_809316574"));
			Log.info("保单查询页面中“客户搜索”按钮元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面中“客户搜索”按钮元素，未找到。");
		}
		return element;
	}

	// 保单查询页面-选择客户-文本
	public static WebElement getCustomerSelectElement() throws Exception
	{
		try
		{
			element = driver.findElement(By
					.xpath(".//*[@id='randomid_990437847']/tbody/tr[1]/td[1]"));
			Log.info("保单查询页面中“选择客户”文本元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面中“选择客户”文本元素，未找到。");
		}
		return element;
	}
	
	//保单查询页面-配送状态选择-下拉框
	public static WebElement getDeliveryStateSelectElement(){
		try{
			JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			jsExecutor.executeScript("var setDate=document.getElementsByName(\"isInvoiceDelivered\")[0];setDate.removeAttribute('style');");
			element = driver.findElement(By.name("isInvoiceDelivered"));
			Log.info("保单查询页面中“配送状态”选择框元素，已找到。");
		}catch(Exception e){
			Log.error("保单查询页面中“配送状态”选择框元素，未找到。");
		}
		return element;
	}
	
	//保单查询页面-保单查询-按钮
	public static WebElement getPolicySearchButtonElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.id("search-button"));
			Log.info("保单查询页面中“保单查询”按钮元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面中“保单查询”按钮元素，未找到。");
		}
		return element;
	}
	
	//保单查询页面-全部配送-按钮
	public static WebElement getDeliveryAllButtonElement() throws Exception
	{
		try
		{
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[4]/div[1]/span[1]/button"));
			Log.info("保单查询页面中“全部配送”按钮元素，已找到。");
		} catch (Exception e)
		{
			Log.error("保单查询页面中“全部配送”按钮元素，未找到。");
		}
		return element;
	}
	
	//保单查询页面-全部回收-按钮
		public static WebElement getRecoverAllButtonElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[4]/div[1]/span[2]/button"));
				Log.info("保单查询页面中“全部回收”按钮元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“全部回收”按钮元素，未找到。");
			}
			return element;
		}
	
	//保单查询页面-导出Excel-按钮
		public static WebElement getExportExcelButtonElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.id("exportExcel"));
				Log.info("保单查询页面中“导出Excel”按钮元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“导出Excel”按钮元素，未找到。");
			}
			return element;
		}
		
	//保单查询页面-保单日志-按钮
		public static WebElement getPolicyLogButtonElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.id("exportExcel"));
				Log.info("保单查询页面中“导出Excel”按钮元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“导出Excel”按钮元素，未找到。");
			}
			return element;
		}
		
	//保单查询页面-保单状态-文本
		public static WebElement getPolicyStateElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr[1]/td[2]"));
				Log.info("保单查询页面中“保单状态”文本元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“保单状态”文本元素，未找到。");
			}
			return element;
		}
	//保单查询页面-保单号-文本
		public static WebElement getPolicyNumElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr[1]/td[3]/span"));
				Log.info("保单查询页面中“保单号”文本元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“保单号”文本元素，未找到。");
			}
			return element;
		}
	
	//保单查询页面-订单号-文本
		public static WebElement getOrderNumElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr[1]/td[4]/a"));
				Log.info("保单查询页面中“订单号”文本元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“订单号”文本元素，未找到。");
			}
			return element;
		}
		
	//保单查询页面-被保人姓名-文本
		public static WebElement getCustomerNameElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr[1]/td[5]"));
				Log.info("保单查询页面中“被保人姓名”文本元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“被保人姓名”文本元素，未找到。");
			}
			return element;
		}
		
	//保单查询页面-证件类型-文本
		public static WebElement getCardStyleElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr[1]/td[6]"));
				Log.info("保单查询页面中“证件类型”文本元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“证件类型”文本元素，未找到。");
			}
			return element;
		}
		
	//保单查询页面-证件号码-文本
		public static WebElement getCardNumElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr[1]/td[7]"));
				Log.info("保单查询页面中“证件号码”文本元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“证件号码”文本元素，未找到。");
			}
			return element;
		}
		
	//保单查询页面-投保人-文本
		public static WebElement getApplicantNameElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr[1]/td[8]"));
				Log.info("保单查询页面中“投保人”文本元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“投保人”文本元素，未找到。");
			}
			return element;
		}
	
	//保单查询页面-生效日期-文本
		public static WebElement getInsuranceStartElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr[1]/td[9]"));
				Log.info("保单查询页面中“生效日期”文本元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“生效日期”文本元素，未找到。");
			}
			return element;
		}
		
	//保单查询页面-截止日期-文本
		public static WebElement getInsuranceEndElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr[1]/td[10]"));
				Log.info("保单查询页面中“截止日期”文本元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“截止日期”文本元素，未找到。");
			}
			return element;
		}
	//保单查询页面-投保日期-文本
		public static WebElement getCreateOrderDateElement() throws Exception
		{
			try
			{
				element = driver.findElement(By.xpath(".//*[@id='table-container']/div[2]/table/tbody/tr[1]/td[11]"));
				Log.info("保单查询页面中“投保日期”文本元素，已找到。");
			} catch (Exception e)
			{
				Log.error("保单查询页面中“投保日期”文本元素，未找到。");
			}
			return element;
		}
		
		
		
		
		
		
		
		
		
	

}

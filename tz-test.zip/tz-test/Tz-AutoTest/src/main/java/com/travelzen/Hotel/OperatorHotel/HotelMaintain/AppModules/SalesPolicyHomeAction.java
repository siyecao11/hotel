package com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.SalesPolicyHomePage;
import com.travelzen.Utility.LogCenter.*;

public class SalesPolicyHomeAction {
  
	@Test
	public static void transmitDriver(WebDriver driver) throws Exception{
		SalesPolicyHomePage.getWebDriver(driver);
	}
	
	@Test//点击“预付售价”按钮
	public static void excuteAddPrePayPrice() throws Exception{
		SalesPolicyHomePage.getAddPrepayPrice().click();
		Log.info("AddPrePayPrice Button is clicked, now enter into SalesPolicyAddPrePayPricePage");
	}
	
	@Test//点击“现付售价”按钮
	public static void excuteAddCashPrice() throws Exception{
		SalesPolicyHomePage.getAddCashPrice().click();
		Log.info("AddCashPrice Button is clicked, now enter into SalesPolicyAddPrePayPricePage");
	}
	
	@Test//输入规则名称
	public static void inputPolicyName(String name) throws Exception{
		//String name = new String();
		//name = "tllruler";//传入用例参数
		if(StringUtils.isNotBlank(name)){
			SalesPolicyHomePage.getPolicyName().sendKeys(name);
			Log.info(" ***********PolicyName is writed ***********");
		}
	}
	
	@Test//输入规则ID
	public static void inputPolicyId(String id) throws Exception{
		//String id = new String();
		//id = "tllruler";//传入用例参数
		if(StringUtils.isNotBlank(id)){
			SalesPolicyHomePage.getPolicyId().sendKeys(id);
			Log.info(" ***********PolicyId is writed ***********");
		}		
	}
	
	@Test//选择规则状态
	public static void selectPolicyStatus(String status) throws Exception{
		//String status = new String();
		//status = "已发布";//传入用例参数
		if(StringUtils.isNotBlank(status)){
			WebElement element = SalesPolicyHomePage.getPolicyStatus();
			Select oSelect = new Select(element);
			oSelect.selectByVisibleText(status);
			Log.info(" ***********PolicyStatus is selected ***********");
		}		
	}
	
	@Test//选择创建人还是操作人
	public static void selectSearchUserType(String userType) throws Exception{
		//String userType = new String();
		//userType = "创建人";//用例传入类型：创建人/操作人
		if(StringUtils.isNotBlank(userType)){
			WebElement element = SalesPolicyHomePage.getSearchUserType();
			Select oSelect = new Select(element);
			oSelect.selectByVisibleText(userType);
			Log.info(" ***********SearchUserType is selected ***********");
		}		
	}
	
	@Test//输入创建人/操作人名称
	public static void inputSearchUser(String searchUser) throws Exception{
		//String searchUser = new String();
		//searchUser = "仝琳琳";//用例传入参数
		if(StringUtils.isNotBlank(searchUser)){
			SalesPolicyHomePage.getSearchUser().sendKeys(searchUser);
			Log.info(" ***********SearchUser is writed ***********");
		}
	}
	
	@Test//选择创建起始日期
	public static void inputStartCreateTime(String startCreateTime) throws Exception{
		//String startCreateTime = new String();
		//startCreateTime = "2015-8-8";
		if(StringUtils.isNotBlank(startCreateTime)){
			SalesPolicyHomePage.getStartCreateTime().sendKeys(startCreateTime);
			Log.info(" ***********StartCreateTime is writed ***********");
		}
	}
	
	@Test//选择创建结束日期
	public static void inputEndCreateTime(String endCreateTime) throws Exception{
		//String endCreateTime = new String();
		//endCreateTime = "2016-8-8";
		if(StringUtils.isNotBlank(endCreateTime)){
			SalesPolicyHomePage.getEndCreateTime().sendKeys(endCreateTime);
			Log.info(" ***********EndCreateTime is writed ***********");
		}
	}
	
	@Test//选择客户组
	public static void selectCustomerGroup(String customerGroup) throws Exception{
		//String customerGroup = new String();
		//customerGroup = "艺龙";//用例传入
		if(StringUtils.isNotBlank(customerGroup)){
			WebElement element = SalesPolicyHomePage.getCustomerGroup();
			Select oSelect = new Select(element);
			oSelect.selectByVisibleText(customerGroup);
			Log.info(" ***********CustomerGroup is selected ***********");
		}		
	}
	
	@Test//选择规则类型
	public static void selectPolicyAddType(String policyAddType) throws Exception{
		//String policyAddType = new String();
		//policyAddType = "自签酒店";//用例传入类型
		if(StringUtils.isNotBlank(policyAddType)){
			WebElement element = SalesPolicyHomePage.getPolicyAddType();
			Select oSelect = new Select(element);
			oSelect.selectByVisibleText(policyAddType);
			Log.info(" ***********PolicyAddType is selected ***********");
		}		
	}
	
	/*@Test//输入城市名称
	public static void inputCityName(String cityName) throws Exception{
		//String cityName = new String();
		//cityName = "上海";//传入用例参数
		if(StringUtils.isNotBlank(cityName)){
			SalesPolicyHomePage.getCityName().sendKeys(cityName);
			Log.info(" ***********CityName is writed ***********");
		}
	}
	
	@Test//输入酒店名称
	public static void inputHotelName(String hotelName) throws Exception{
		//String hotelName = new String();
		//hotelName = "锦江之星";//传入用例参数
		if(StringUtils.isNotBlank(hotelName)){
			SalesPolicyHomePage.getHotelName().sendKeys(hotelName);
			Log.info(" ***********HotelName is writed ***********");
		}
	}
	
	@Test//输入客户名称
	public static void inputCustomerName(String customerName) throws Exception{
		//String customerName = new String();
		//customerName = "tllyucun";//传入用例参数
		if(StringUtils.isNotBlank(customerName)){
			SalesPolicyHomePage.getCustomerName().sendKeys(customerName);
			Log.info(" ***********CustomerName is writed ***********");
		}
	}
	
	@Test//点击查询
	public static void clickSearchPolicyBtn() throws Exception{
		SalesPolicyHomePage.getSearchPolicyBtn().click();
		Log.error(" ***********SearchPolicyBtn is clicked ***********");
	}*/
}

package com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.FunctionCases;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules.*;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.CheckPoints.BookingHotelCheckPoint;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.TestCase.FunctionCases.PointSearchHotel;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.Utility.Utils.dataProviderApp;
import com.travelzen.Hotel.OperatorHotel.utility.Constants.Constant;
import com.travelzen.Utility.Constants.Constants;
import com.travelzen.Utility.ResultCollection.Report;
import com.travelzen.Utility.ScreenShot.RetryFail;
import com.travelzen.Utility.Utils.*;

import java.lang.Integer;

@Listeners({com.travelzen.Utility.Assertion.AssertionListener.class, com.travelzen.Utility.ResultCollection.CustomReporter.class, com.travelzen.Utility.ScreenShot.ScreenShotListener.class,com.travelzen.Utility.ScreenShot.RetryListener.class})
public class NormalOrderOperator {

	// 正常单的创建NormalOrder_Create、订单审核（添加酒店确认码、结算信息）Order_Audit、订单详情查看Order_ViewDtail、获取支付页面订单号OrderID_Save
	//public static WebDriver currentDriver;
	public static WebDriver beDriver;
	public static WebDriver driver;
	
	
	@BeforeClass(alwaysRun=true)
	public static void beforeClass(){
		
		driver = PointSearchHotel.driver;

	}
	
	@AfterSuite(alwaysRun = true)
	public static void afterSuite() throws Exception{
		
		Report.showReport();
		driver.quit();
	}
	
	@BeforeMethod(alwaysRun=true)
	public static void beforeMethod() throws Exception{
		
		Constants.classDriver= driver;
		//如果 创建订单（预付正常单） 不是作为一个流程用例
		//即需要将创建订单的参数列表中所有用例数据都运行一篇
		//我们需要每执行完一个用例后，都需要将页面调到一个指定页面（初始化）
		//初始化：用例执行前
		if(dataProviderApp.isCreateOrderIncludeProcess.equalsIgnoreCase("false"))
		{
			//OrderManageOrderListAction.transmitDriver(driver);
			//OrderManageOrderListAction.excuteGotoHotelSearchsBtn();
			//searchBooking("OP3C100","2016-02-03","2016-02-05","1");
		}
	}
	
	// TestCase中的每一个Function都可以为其做一张参数表
	// 对我们需要输入的值参数化
	//@Parameters({ "customerName", "checkinDate", "checkoutDate", "roomNo" })

	@Test(dataProvider = "hotelQuery_data",retryAnalyzer = RetryFail.class, dataProviderClass = dataProviderApp.class,priority = 10, groups = {"酒店查询","预付酒店查询","正常单退订确认流程" })
	public static void searchBooking(String customerName, String checkinDate,String checkoutDate, String roomNo) throws Exception {

		driver.get(Constant.searchHotelURL);
		// Enter into hotel HomePage
		Thread.sleep(1000);
		BookingHotelAction.transmitDriver(driver);
		// 点击搜索客户按钮
		BookingHotelAction.CustomerSearch();
		Thread.sleep(5000);
		// 输入客户简称
		BookingHotelAction.CustomerName(customerName);// "OP3C100"
		Thread.sleep(4000);
		// 将客户名称记录到 断言表中
	//	ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "keHuName",customerName);
		// 点击搜索客户按钮
		BookingHotelAction.SearchCustomer();
		Thread.sleep(2000);
		// 选择客户
		BookingHotelAction.SelectCustomer();
		Thread.sleep(1000);
		// 点击城市输入框，弹出城市选择列表
		BookingHotelAction.City();
		Thread.sleep(1000);
		// 选择城市
		BookingHotelAction.SelectCity();
		// 将城市记录到 断言表中
		//ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "hotelCity","杭州");
		// 选择入住时间
		BookingHotelAction.CheckinDate(checkinDate);// "2015-09-13"
		// 选择出店时间
		BookingHotelAction.CheckoutDate(checkoutDate);// "2015-09-14"
		// 填写酒店位置和名称信息
		// Query_Booking_Action.Location("西湖");
		// Query_Booking_Action.HotelName("金");
		// 选择房间数
		int roomNo1 = Integer.parseInt(roomNo);
		BookingHotelAction.RoomNo(roomNo1);// 0;
		Thread.sleep(1000);
		BookingHotelAction.transmitDriver(driver);
		Thread.sleep(1000);
		// 选择酒店
		BookingHotelAction.SearchHotel();
		Thread.sleep(5000);
		// Query_Booking_Action.AllPrice();
		// 酒店搜索结果列表中检查 挂起酒店是否搜索出来
		BookingHotelCheckPoint.bookingHotelGuaqiCheckPoint();
		Thread.sleep(2000);
		// 点击预订按钮
		// BookingHotelAction.Reserve(Constant.bookHotelId);

	}
	

	// 创建订单（输入预订人姓名、订单确认预订、支付、保存订单号）
	//@Parameters("name")

	@Test(dataProvider = "tenantInfo_data",retryAnalyzer = RetryFail.class,dataProviderClass = dataProviderApp.class,priority = 11, groups = {"正常单创建","正常单审核取消", "正常单审核确认", "正常单退订确认流程" })
	public static void NormalOrderCreate(String customerName, String checkinDate,String checkoutDate, String roomNo, String name) throws Exception {

		searchBooking(customerName,  checkinDate, checkoutDate,  roomNo);
		// 点击预订按钮
	    BookingHotelAction.Reserve(Constant.bookHotelId);

		Utils.waitForElement(5, driver, "page");
		OrderManageNormalOrderCreateAction.transmitDriver(driver);

		// 填写订单客户姓名
		OrderManageNormalOrderCreateAction.Customer(name);// "张华"
		// 将客户名称记录到断言表中
		//ExcelAction.setValue("Hotel/OrderExpectHotelInfo.xls", "customerName",name);
		// 创建订单
		OrderManageNormalOrderCreateAction.CreateOrder();
		Thread.sleep(2000);
		// 获取订单ID
		OrderManageOrderPayAction.transmitDriver(driver);
		Constant.NormalOrderId = OrderManageOrderPayAction.GetOrderId();
		Constant.TempId = Constant.NormalOrderId;
		Thread.sleep(6000);
		
	}

	@Test(priority = 12,retryAnalyzer = RetryFail.class, groups = {"正常单审核取消" })
	public static void Order_AuditCancel() throws Exception {

		// currentDriver = NormalOrderOperator.currentDriver;
	//	System.out.println("Order_AuditCancel driver value" + driver);
		Thread.sleep(6000);
		// 页面跳转到订单列表页面
		OrderManageOrderListAction.transmitDriver(driver);
		// 输入订单号
		OrderManageOrderListAction.OrderIdInput(Constant.NormalOrderId);
		Thread.sleep(1000);
		// 点击搜索
		OrderManageOrderListAction.SearchOrder();
		Thread.sleep(1000);
		// 点击订单号，跳转到订单详情页
		OrderManageOrderListAction.OrderClick();
		Thread.sleep(2000);
		OrderManageNormalOrderAuditAction.transmitDriver(driver);
		OrderManageNormalOrderAuditAction.excuteCanclemBookingLink();
		Thread.sleep(2000);
		OrderManageNormalOrderAuditAction.excuteCancelRemark();
		Thread.sleep(2000);
		OrderManageNormalOrderAuditAction.excuteCancelOrderSave();
		Thread.sleep(2000);

		// 取消订单后，将页面指向搜索酒店页面
		driver.get(Constant.searchHotelURL);
		Thread.sleep(2000);
	}


	@Test(priority = 12,retryAnalyzer = RetryFail.class, groups = { "正常单审核确认", "正常单退订确认流程" })
	public static void Order_AuditConfirm() throws Exception {
		// currentDriver = NormalOrderOperator.currentDriver;
		Thread.sleep(3000);
		// 页面跳转到订单列表页面
		OrderManageOrderListAction.transmitDriver(driver);
		// 输入订单号
		OrderManageOrderListAction.OrderIdInput(Constant.NormalOrderId);
		Thread.sleep(1000);
		// 点击搜索
		OrderManageOrderListAction.SearchOrder();
		Thread.sleep(1000);
		// 点击订单号，跳转到订单详情页
		OrderManageOrderListAction.OrderClick();
		Thread.sleep(2000);
		// 进入审核页面
		// 点击确认审核按钮
		OrderManageNormalOrderAuditAction.transmitDriver(driver);
		Thread.sleep(2000);
		OrderManageNormalOrderAuditAction.excute_ConfirmBooking_Link();
		Thread.sleep(1000);
		// 选择不需要酒店确认码
		OrderManageNormalOrderAuditAction.excute_ConfirmID2();
		Thread.sleep(1000);
		// 保存酒店确认码
		OrderManageNormalOrderAuditAction.excute_Save_ConfirmID();
		Thread.sleep(1000);
		// 选择周结
		OrderManageNormalOrderAuditAction.excute_WEEK_SETTLE();
		Thread.sleep(1000);
		// 点击保存结算方式按钮
		OrderManageNormalOrderAuditAction.excute_Save_Count();
		Thread.sleep(1000);
	}
	
	// 订单详情页--添加客服说明
		@Test(dataProvider = "costomerRemark_data", dataProviderClass = dataProviderApp.class, priority = 15, groups = {"添加客服说明" })
		public static void pointOrderDetail(String orderID, String remark)
				throws Exception {
			// driver = AddHotelAudit.currentDriver;
			
			// driver传递到订单列表页面
			OrderManageOrderListAction.transmitDriver(driver);
			// 页面跳转到订单管理列表
			OrderManageOrderListAction.excuteGotoOrderManageBtn();
			Thread.sleep(5000);
			// 输入订单号
			OrderManageOrderListAction.OrderIdInput(orderID);

			Thread.sleep(1000);
			// 点击搜索
			OrderManageOrderListAction.SearchOrder();
			Thread.sleep(1000);
			// 点击订单号，跳转到订单详情页
			OrderManageOrderListAction.OrderClick();
			Thread.sleep(2000);
			// 页面跳转到订单列表页面
			addCostomerServiceRemarkAction.transmitDriver(driver);
			// 输入客服说明
			addCostomerServiceRemarkAction.excuteSendLogContent(remark);
			Thread.sleep(1000);
			// 点击添加客服说明
			addCostomerServiceRemarkAction.excuteAddCustomerServiceBtn();
			Thread.sleep(1000);
			// 点击订单管理，跳转到订单列表页
			addCostomerServiceRemarkAction.excuteGotoOrderManageBtn();
			Thread.sleep(2000);

		}

}

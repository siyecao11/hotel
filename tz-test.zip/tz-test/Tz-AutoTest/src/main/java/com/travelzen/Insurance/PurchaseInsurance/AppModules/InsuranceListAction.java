package com.travelzen.Insurance.PurchaseInsurance.AppModules;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.*;
import com.travelzen.Insurance.PurchaseInsurance.PageObjects.CreatOrderPage;
import com.travelzen.Insurance.PurchaseInsurance.PageObjects.InsuranceListPage;

public class InsuranceListAction {
	private static WebElement element;
	private static List<WebElement> elementList;
	public static WebDriver webdriver;
	private static Select oSelection;
	public static String insuranceName;
	private static WebElement[][] elementTable;

	/*
	 * author xuemei.ren date 07/01/2016
	 */
	public static void transmitDriver(WebDriver currentDriver) throws Exception {

		webdriver = currentDriver;
		InsuranceListPage.getDriver(currentDriver);
	}
	//产品列表页--产品信息--检查点
	// 产品信息--获取保险--序数
	@Test
	public static String excutInsuranceNameAction(String insuranceName) throws Exception {
		String num = "";
		int listSize = InsuranceListPage.getInsuranceProductListElement().size();
		System.out.println("size value" + listSize);
		for (int i = 2; i < listSize; i++) {
			 num = Integer.toString(i);
			// insuranceName =
			// InsuranceListPage.getInsuranceNameElement(num).getText();
			if (insuranceName.equals(InsuranceListPage.getInsuranceNameElement(num).getText())) {
				//InsuranceListPage.getBuyInsuranceElement(num).click();
				break;
			}
		}
		return num;
	}
	
	// 产品信息--获取保险公司
	@Test
	public static String excutGetCompanyAction(String number) throws Exception {
		String string = InsuranceListPage.getInsuranceCompanyElement(number).getText();
		Log.info("获取的保险公司是：" + string);
		return string;
	}
	// 产品信息--获取险种类型
		@Test
		public static String excutGetInsuranceTypeAction(String number) throws Exception {
			String string = InsuranceListPage.getInsuranceTypeElement(number).getText();
			Log.info("获取的险种类型是：" + string);
			return string;
		}
		// 产品信息--获取保险期限
		@Test
		public static String excutGetInsurancePeriodAction(String number) throws Exception {
			String string = InsuranceListPage.getInsurancePeriodElement(number).getText();
			Log.info("获取的保险期限是：" + string);
			return string;
		}
		// 产品信息--获取最高保额
		@Test
		public static String excutGetPolicyMaximumAction(String number) throws Exception {
			String string = InsuranceListPage.getPolicyMaximumElement(number).getText();
			Log.info("获取的最高保额是：" + string);
			return string;
		}
		// 产品信息--获取适用范围
		@Test
		public static String excutGetInsuranceApplicationAction(String number) throws Exception {
			String string = InsuranceListPage.getInsuranceApplicationElement(number).getText();
			Log.info("获取的适用范围是：" + string);
			return string;
		}
		// 产品信息--获取面价
		@Test
		public static String excutGetFacePriceAction(String number) throws Exception {
			String string = InsuranceListPage.getFacePriceElement(number).getText();
			Log.info("获取的面价是：" + string);
			return string;
		}
		// 产品信息--获取保险费用
		@Test
		public static String excutGetnsuranceFeeAction(String number) throws Exception {
			String string = InsuranceListPage.getInsuranceFeeElement(number).getText();
			Log.info("获取的保险费用是：" + string);
			return string;
		}
		//**************************立即购买***********************

	// 创建订单页面--立即购买
	public static void excutBuyInsuranceAction(String insuranceName) throws Exception {
		int listSize = InsuranceListPage.getInsuranceProductListElement().size();
		System.out.println("size value" + listSize);
		for (int i = 2; i < listSize; i++) {
			String num = Integer.toString(i);
			// insuranceName =
			// InsuranceListPage.getInsuranceNameElement(num).getText();
			if (insuranceName.equals(InsuranceListPage.getInsuranceNameElement(num).getText())) {
				InsuranceListPage.getBuyInsuranceElement(num).click();
				break;
			}
		}

		Log.info("点击立即订购按钮");
	}

}

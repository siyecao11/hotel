package com.travelzen.Hotel.PurchaseHotel;

public class Test {

}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.FunctionCases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import org.databene.feed4testng.FeedTest;
import org.databene.benerator.anno.*;

import com.travelzen.Utility.Utils.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.HotelMaintainHomeAction;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.AppModules.HotelHomeAction;
import com.travelzen.Login.OperatorLogin.TestCase.FunctionCases.LoginTC;

public class PointAddHotel extends FeedTest{

	public static WebDriver currentDriver;
	
	//TestCase中的每一个Function都可以为其做一张参数表
	//对我们需要输入的值参数化
	
	//这个Class是用于建立 AddHotel入口：完成在跳转到“添加酒店”之前的所有工作
	@Test
	public static void pointAddHotel(String username, String password) throws Exception {
		//Login system
		LoginTC.login(username, password);
		
		//fetch WebDriver
		currentDriver = LoginTC.driver;
		
		//location hotel maintain page
		Utils.waitForElement(5, currentDriver, "page");
		HotelHomeAction.transmitDriver(currentDriver);
		//currentDriver.get(Constant.hotelMaintainURL);
		HotelHomeAction.excuteHotelMaintain();
		
		//goto add hotel page, edit hotelInfo
		Utils.waitForElement(5, currentDriver, "page");
		HotelMaintainHomeAction.transmitDriver(currentDriver);
		HotelMaintainHomeAction.executeAddHotel();
		
	}
	
}

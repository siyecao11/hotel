package com.travelzen.Insurance.PurchaseInsurance.PageObjects;

import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.*;

public class OrderDetailPage {

	private static WebElement element;
	private static List<WebElement> elementList;
	public static WebDriver driver;
	private static Select oSelection;
	public static String option;
	private static WebElement[][] elementTable;

	/*
	 * author xuemei.ren date 07/01/2016
	 */
	public static void getDriver(WebDriver webdriver) throws Exception {
		driver = webdriver;
	}

	// ******************订单基本信息 start***********************
	// 订单详情页面--订单号--text
	@Test
	public static WebElement getOrderIdElement() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='orderIdSpan']/strong"));
			Log.info("订单号元素在订单详情页面");
		} catch (Exception e) {
			Log.error("订单号元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--下单日期--text
	@Test
	public static WebElement getOrderCreatDateElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/table/tbody/tr[2]/td[1]"));
			Log.info("下单日期元素在订单详情页面");
		} catch (Exception e) {
			Log.error("下单日期元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--支付方式--text
	@Test
	public static WebElement getPayTypeElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/table/tbody/tr[2]/td[2]"));
			Log.info("支付方式元素在订单详情页面");
		} catch (Exception e) {
			Log.error("支付方元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--订单状态--text
	@Test
	public static WebElement getOrderStatusElement() throws Exception {
		try {
			element = driver.findElement(By.className("endorsing"));
			Log.info("订单状态元素在订单详情页面");
		} catch (Exception e) {
			Log.error("订单状态元素不在订单详情页面");
		}
		return element;
	}

	// ******************订单基本信息 end***********************

	// **************************产品信息 start******************

	// 订单详情页面--产品名称--text
	@Test
	public static WebElement getProductNameElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div[2]/table/tbody/tr/td[1]"));
			Log.info("产品名称元素在订单详情页面");
		} catch (Exception e) {
			Log.error("产品名称元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--险种编号--text
	@Test
	public static WebElement getInsuranceIdElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div[2]/table/tbody/tr/td[2]"));
			Log.info("险种编号元素在订单详情页面");
		} catch (Exception e) {
			Log.error("险种编号元素不在订单详情页面");
		}
		return element;
	}
	// 订单详情页面--保险险种--text
	@Test
	public static WebElement getInsuranceTypeElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div[2]/table/tbody/tr/td[3]"));
			Log.info("险种类型元素在订单详情页面");
		} catch (Exception e) {
			Log.error("险种类型元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--保险期限--text
	@Test
	public static WebElement getInsurancePeriodElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div[2]/table/tbody/tr/td[4]"));
			Log.info("保险期限元素在订单详情页面");
		} catch (Exception e) {
			Log.error("保险期限元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--最高保额（元）--text
	@Test
	public static WebElement getPolicyMaximumElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div[2]/table/tbody/tr/td[5]"));
			Log.info("最高保额元素在订单详情页面");
		} catch (Exception e) {
			Log.error("最高保额元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--面价--text
	@Test
	public static WebElement getFacePriceElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div[2]/table/tbody/tr/td[6]"));
			Log.info("面价元素在订单详情页面");
		} catch (Exception e) {
			Log.error("面价元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--保险费用--text
	@Test
	public static WebElement getInsuranceFeeElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div[2]/table/tbody/tr/td[7]"));
			Log.info("保险费用元素在订单详情页面");
		} catch (Exception e) {
			Log.error("保险费用元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--适用范围--text
	@Test
	public static WebElement getApplicationElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div[2]/table/tbody/tr/td[8]"));
			Log.info("适用范围元素在订单详情页面");
		} catch (Exception e) {
			Log.error("适用范围元素不在订单详情页面");
		}
		return element;
	}

	// ***********************保单信息 start*********************
	// 订单详情页面--被保险人姓名--text
	@Test
	public static WebElement getInsureeNameElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[1]"));
			else
				element = driver
						.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[1]"));
			Log.info("被保险人姓名元素在订单详情页面");
		} catch (Exception e) {
			Log.error("被保险人姓名元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--被保险人证件类型--text
	@Test
	public static WebElement getInsureeDocTypeElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[2]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[2]"));
			Log.info("适用范围元素在订单详情页面");
		} catch (Exception e) {
			Log.error("适用范围元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--被保险人证件号码--text
	@Test
	public static WebElement getInsureeDocCodeElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[3]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[3]"));
			Log.info("被保险人证件号码元素在订单详情页面");
		} catch (Exception e) {
			Log.error("被保险人证件号码元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--被保险人性别--text
	@Test
	public static WebElement getInsureeGenderElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[4]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[4]"));
			Log.info("被保险人性别元素在订单详情页面");
		} catch (Exception e) {
			Log.error("被保险人性别元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--被保险人出生日期--text
	@Test
	public static WebElement getInsureeBirthdayElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[5]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[5]"));
			Log.info("被保险人出生日期元素在订单详情页面");
		} catch (Exception e) {
			Log.error("被保险人出生日期元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--被保险人手机号码--text
	@Test
	public static WebElement getInsureeMobilePhoneElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[6]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[6]"));
			Log.info("被保险人出生日期元素在订单详情页面");
		} catch (Exception e) {
			Log.error("被保险人出生日期元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--保单生效日期--text
	@Test
	public static WebElement getEffectiveDateElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[7]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[7]"));
			Log.info("单生效日期元素在订单详情页面");
		} catch (Exception e) {
			Log.error("单生效日期元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--保单号--text
	@Test
	public static WebElement getInsurerOrderIdElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[8]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[8]"));
			Log.info("保单号元素在订单详情页面");
		} catch (Exception e) {
			Log.error("保单号元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--份数--text
	@Test
	public static WebElement getCopiesElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[9]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[9]"));
			Log.info("保单份数元素在订单详情页面");
		} catch (Exception e) {
			Log.error("保单份数元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--保单状态-text
	@Test
	public static WebElement getInsureStatusElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[10]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[10]"));
			Log.info("保单状态元素在订单详情页面");
		} catch (Exception e) {
			Log.error("保单状态元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--投保人姓名--text
	@Test
	public static WebElement getInsureNameElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[11]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[11]"));
			Log.info("投保人姓名元素在订单详情页面");
		} catch (Exception e) {
			Log.error("投保人姓名元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--投保人证件类型--text
	@Test
	public static WebElement getInsureDocTypeElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[12]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[12]"));
			Log.info("投保人证件类型元素在订单详情页面");
		} catch (Exception e) {
			Log.error("投保人证件类型不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--投保人证件号码--text
	@Test
	public static WebElement getInsureDocCodeElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[13]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[13]"));
			Log.info("投保人证件号码元素在订单详情页面");
		} catch (Exception e) {
			Log.error("投保人证件号码不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--投保人手机号--text
	@Test
	public static WebElement getInsurePhoneElement(String number) throws Exception {
		try {
			if (number.equals("0"))
				element = driver.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr/td[14]"));
			else
			element = driver
					.findElement(By.xpath("html/body/section/div[2]/div[3]/table/tbody/tr[" + number + "]/td[14]"));
			Log.info("投保人手机号元素在订单详情页面");
		} catch (Exception e) {
			Log.error("投保人手机号不在订单详情页面");
		}
		return element;
	}

	// ***********************保单信息 end***********************
	// **************************结算备注信息 start******************
	// 订单详情页面--订单备注--text
	@Test
	public static WebElement getRemarkElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/section/div[2]/div[5]/div[2]/p"));
			Log.info("投保人订单备注元素在订单详情页面");
		} catch (Exception e) {
			Log.error("投保人订单备注不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--保险数量--text
	@Test
	public static WebElement getInsureAmountElement() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='ac']/div/div/b[1]"));
			Log.info("保险数量元素在订单详情页面");
		} catch (Exception e) {
			Log.error("保险数量不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--保险费用--text
	@Test
	public static WebElement getInsurefeeElement() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='ac']/div/div/b[2]"));
			Log.info("保险费用元素在订单详情页面");
		} catch (Exception e) {
			Log.error("保险费用不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--应收合计--text
	@Test
	public static WebElement getTotalPriceElement() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='ac']/div/div/strong"));
			Log.info("应收合计元素在订单详情页面");
		} catch (Exception e) {
			Log.error("应收合计不在订单详情页面");
		}
		return element;
	}

	// **********************订单详情页--取消投保--start***********************
	// 订单详情页--取消投保--点击取消投保
	public static WebElement getCancelInsureClickElement() throws Exception {
		try {
			element = driver.findElement(By.id("gotoCancelButton"));
			// xpath(""));
			Log.info("取消投保按钮元素在订单详情页");
		} catch (Exception e) {
			Log.error("取消投保按钮元素不在订单详情页");
		}
		return element;
	}

	// 订单详情页--取消投保--保单人数
	public static List<WebElement> getCancelInsureAmountElement() throws Exception {
		try {
			elementList = driver.findElements(By.className("abortPerson"));
			Log.info("取消投保保单人数元素在订单详情页");
		} catch (Exception e) {
			Log.error("取消投保保单人数元素不在订单详情页");
		}
		return elementList;
	}

	// 订单详情页面--取消投保--取消投保人选中--checkbox
	public static WebElement getCancelInsureChooseElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[9]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[1]/input"));
			Log.info("取消投保人选中checkbox元素在订单详情页面");
		} catch (Exception e) {
			Log.error("取消投保人选中checkbox不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--取消投保--取消投保人姓名--text
	public static WebElement getCancelInsureNameElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[9]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[2]"));
			Log.info("取消投保人姓名元素在订单详情页面");
		} catch (Exception e) {
			Log.error("取消投保人姓名元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--退保--取消投保人性别--text
	public static WebElement getCancelInsureGenderElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[9]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[3]"));
			Log.info("取消投保人性别元素在订单详情页面");
		} catch (Exception e) {
			Log.error("取消投保人性别元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--取消投保--保单生效日期--text
	public static WebElement getCancelInsureEffectiveDateElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[9]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[4]"));
			Log.info("取消投保保单生效日期元素在订单详情页面");
		} catch (Exception e) {
			Log.error("取消投保保单生效日期元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--取消投保--保单号--text
	public static WebElement getCancelInsureOrderIdElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[9]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[5]"));
			Log.info("取消投保保单号元素在订单详情页面");
		} catch (Exception e) {
			Log.error("取消投保保单号元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--取消投保--保单份数--text
	public static WebElement getCancelInsureAmountElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[9]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[6]"));
			Log.info("取消投保保单份数元素在订单详情页面");
		} catch (Exception e) {
			Log.error("取消投保保单份数元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--取消投保--保单状态--text
	public static WebElement getCancelInsureOrderStatusElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[9]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[7]"));
			Log.info("取消投保保单状态元素在订单详情页面");
		} catch (Exception e) {
			Log.error("取消投保保单状态元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--取消投保--提交--btn
	public static WebElement getCancelInsureSubmmitElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[9]/div[2]/div[3]/a[1]/span[2]"));
			Log.info("取消投保提交btn元素在订单详情页面");
		} catch (Exception e) {
			Log.error("取消投保提交btn元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--取消投保--取消--text
	public static WebElement getInsureCancelElement() throws Exception {
		try {
			element = driver.findElement(By.linkText("取消"));
			Log.info("投保取消btn元素在订单详情页面");
		} catch (Exception e) {
			Log.error("投保取消btn元素不在订单详情页面");
		}
		return element;
	}

	// **********************订单详情页--取消投保--end***********************
	// ******************************订单详情页--退保弹窗--start*******************************
	// 订单详情页面--退保--退保--btn
	public static WebElement getAbortElement() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='gotoAbortButton']/span[2]"));
			Log.info("退保btn元素在订单详情页面");
		} catch (Exception e) {
			Log.error("退保btn不在订单详情页面");
		}
		return element;
	}

	// 保险订单列表页--退保--获取保单人数
	public static List<WebElement> getSurrenderAmountElement() throws Exception {
		try {
			elementList = driver.findElements(By.className("abortPerson"));
			Log.info("退保人保单人数元素在订单详情页面");
		} catch (Exception e) {
			Log.error("退保人保单人数不在订单详情页面");
		}
		return elementList;
	}

	// 订单详情页面--退保--退保人选中--checkbox
	public static WebElement getSurrenderChooseElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[8]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[1]/input"));
			Log.info("退保人选中checkbox元素在订单详情页面");
		} catch (Exception e) {
			Log.error("退保人选中checkbox不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--退保--退保人姓名--text
	public static WebElement getSurrenderNameElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[8]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[2]"));
			Log.info("退保人姓名元素在订单详情页面" + element.getText());
		} catch (Exception e) {
			Log.error("退保人姓名元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--退保--退保人性别--text
	public static WebElement getSurrenderGenderElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[8]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[3]"));
			Log.info("退保人性别元素在订单详情页面");
		} catch (Exception e) {
			Log.error("退保人性别元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--退保--退保生效日期--text
	public static WebElement getSurrenderEffectiveDateElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[8]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[4]"));
			Log.info("退保生效日期元素在订单详情页面");
		} catch (Exception e) {
			Log.error("退保生效日期元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--退保--退保保单号--text
	public static WebElement getSurrenderOrderIdElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[8]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[5]"));
			Log.info("退保保单号元素在订单详情页面");
		} catch (Exception e) {
			Log.error("退保保单号元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--退保--退保份数--text
	public static WebElement getSurrenderAmountElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[8]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[6]"));
			Log.info("退保份数元素在订单详情页面");
		} catch (Exception e) {
			Log.error("退保份数元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--退保--退保保单状态--text
	public static WebElement getSurrenderOrderStatusElement(String number) throws Exception {
		try {
			element = driver
					.findElement(By.xpath("html/body/div[8]/div[2]/div[2]/table/tbody/tr[" + number + "]/td[7]"));
			Log.info("退保保单状态元素在订单详情页面");
		} catch (Exception e) {
			Log.error("退保保单状态元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--退保--退保提交--btn
	public static WebElement getSurrenderSubmmitElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[8]/div[2]/div[3]/a[1]/span[2]"));
			Log.info("退保提交btn元素在订单详情页面");
		} catch (Exception e) {
			Log.error("退保提交btn元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--退保--退保取消--text
	public static WebElement getSurrenderCancelElement() throws Exception {
		try {
			element = driver.findElement(By.linkText("取消"));
			Log.info("退保取消btn元素在订单详情页面");
		} catch (Exception e) {
			Log.error("退保取消btn元素不在订单详情页面");
		}
		return element;
	}

	// ********************订单详情页 --投保提交成功--start***********************
	// 订单详情页面--投保--btn
	@Test
	public static WebElement getUnderWriteElement() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='gotoUnderWriteButton']/span[2]"));
			Log.info("投保元素在订单详情页面");
		} catch (Exception e) {
			Log.error("投保不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--投保提交成功--text
	@Test
	public static WebElement getImsuccessElement() throws Exception {
		try {
			element = driver.findElement(By.className("messageSpan"));
			Log.info("投保提交成功元素在订单详情页面");
		} catch (Exception e) {
			Log.error("投保提交成功元素不在订单详情页面");
		}
		return element;
	}
	// ******************订单详情页面---新建订单--取消订单/支付--start*******************

	// 订单详情页面页--取消订单--link
	public static WebElement getCancelOrderElement() throws Exception {
		try {

			element = driver.findElement(By.xpath(".//*[@id='gotoCancelOrderButton']/span[2]"));
			// System.out.println("element:"+element);
			Log.info("取消订单元素在订单详情页面");
		} catch (Exception e) {
			Log.error("取消订单元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--取消订单--取消确认
	public static WebElement getCancelOrderConfirmElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[10]/div[2]/div/div[2]/a[1]/span[2]"));
			Log.info("取消订单确认元素在订单详情页面");
		} catch (Exception e) {
			Log.error("取消订单确认元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面--取消订单--取消放弃
	public static WebElement getCancelOrderQuitElement() throws Exception {
		try {
			element = driver.findElement(By.xpath("html/body/div[10]/div[2]/div/div[2]/a[2]"));
			Log.info("取消订单确认取消元素在订单详情页面");
		} catch (Exception e) {
			Log.error("取消订单确认取消元素不在订单详情页面");
		}
		return element;
	}

	// 订单详情页面---订单支付--link
	public static WebElement getOrderPayElement() throws Exception {
		try {
			element = driver.findElement(By.xpath(".//*[@id='gotoPayButton']/span[2]"));
			Log.info("支付元素在订单详情页面");
		} catch (Exception e) {
			Log.error("支付元素不在订单详情页面");
		}
		return element;
	}

	// *********************************跳转到订单管理页面
	// 订单详情页面--订单管理--link
	public static WebElement getOrderListElement() throws Exception {
		try {
			element = driver.findElement(By.linkText("订单管理"));
			Log.info("订单管理link元素在订单详情页面");
		} catch (Exception e) {
			Log.error("订单管理link元素不在订单详情页面");
		}
		return element;
	}
}
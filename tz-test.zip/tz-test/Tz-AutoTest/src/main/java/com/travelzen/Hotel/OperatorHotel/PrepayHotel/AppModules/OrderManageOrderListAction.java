package com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.travelzen.Utility.LogCenter.Log;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;

/*
 * 
 * 订单列表页面控制层
 * 
 */
public class OrderManageOrderListAction {

	public static void transmitDriver(WebDriver driver) throws Exception {
		OrderManageOrderListPage.getDriver(driver);
	}

	// 跳转--order manage--链接
	public static void excuteGotoOrderManageBtn() throws Exception {

		OrderManageOrderListPage.getOrderManageButton().click();
		Log.info("OrderManage Button is clicked");
	}
	
	// 跳转--hotel search--链接
	public static void excuteGotoHotelSearchsBtn() throws Exception {

		OrderManageOrderListPage.getSearchHotelButton().click();
		Log.info("HotelSearch Button is clicked");
	}

	// 在订单输入框中输入订单号
	public static void OrderIdInput(String OrderId) throws Exception {
		OrderManageOrderListPage.OrderIdInput().sendKeys(OrderId);
		Log.info("*************OrderIdInput is writed**************");
	}

	// 点击搜索按钮搜索出目标订单
	public static void SearchOrder() throws Exception {
		OrderManageOrderListPage.SearchOrder().click();
		Log.info("*************SearchOrder is clicked**************");
	}

	// 点击目标订单订单号
	public static void OrderClick() throws Exception {
		OrderManageOrderListPage.OrderIdClick().click();
		Log.info("*************OrderClick is clicked**************");
	}

}

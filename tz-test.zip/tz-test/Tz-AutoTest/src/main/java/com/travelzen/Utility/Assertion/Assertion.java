package com.travelzen.Utility.Assertion;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import com.travelzen.Utility.LogCenter.*;

import org.testng.Assert;

public class Assertion {

	public static boolean flag = true;

	public static List<Error> errors = new ArrayList<Error>();
	
	//断言失败不中断继续执行
	//把Assert.assertEquals给try catch住
	public static void verifyEquals(Object actual, Object expected) {
		try {
			
			Log.assertion("Actual value is [" + actual + "] , Expected value is [" + expected + "]");
			Assert.assertEquals(actual, expected);
			Log.assertPassInfo();
		} catch (Error e) {
			
			errors.add(e);
			//将Exception的详细信息输出到日志/控制台
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			pw.flush();
			sw.flush();
			if (sw != null) {
                try {
                    sw.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            if (pw != null) {
                pw.close();
            }
            //保存error信息至error日志文件中一份
            Log.error(sw.toString());
						
			Log.assertFailInfo(e);
			flag = false;
		}
	}
	
	public static void verifyEquals(Object actual, Object expected, String message) {
		
		try {
			Log.assertion("实际值是：[" + actual + "] , 期望值是： [" + expected + "]" + "----打印信息: " + message);
			Assert.assertEquals(actual, expected, message);
			Log.assertPassInfo();
			
		} catch (Error e) {
			
			errors.add(e);
			//将Exception的详细信息输出到日志/控制台
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			e.printStackTrace(pw);
			pw.flush();
			sw.flush();
			if (sw != null) {
                try {
                    sw.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
            if (pw != null) {
                pw.close();
            }
            //保存error信息至error日志文件中一份
            Log.error(sw.toString());
			
			Log.assertFailInfo(e);
			flag = false;
		}
	}
	
	public static void assertFail(){
		
		Assert.fail();
	}
}

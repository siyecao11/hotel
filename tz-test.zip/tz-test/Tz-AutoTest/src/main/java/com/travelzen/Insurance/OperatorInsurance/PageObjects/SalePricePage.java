package com.travelzen.Insurance.OperatorInsurance.PageObjects;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.travelzen.Utility.LogCenter.Log;

/**
 * 
 * @author changhui.hu
 *
 */
public class SalePricePage {
	
	public static WebDriver driver;
	private static WebElement element;
	public static Select select;
	public static List<WebElement> elementList;

	public static void getdriver(WebDriver webdriver) {
		driver = webdriver;
	}

	// 获取售价维护页面的“新建售价”按钮元素
	public static WebElement getCreateSalePriceElement() throws Exception {
		try {
			element = driver.findElement(By.id("addSalePriceButton"));
			Log.info("售价维护页面中新建售价按钮元素已找到");
		} catch (Exception e) {
			Log.error("售价维护页面中新建售价按钮元素未找到");
		}
		return element;
	}
	
	// 获取售价维护页面的“产品名称”元素
	public static Select getProductNameElement() throws Exception {
		try {
			// JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			// jsExecutor.executeScript("document.getElementByName(productName).style.display='block';");
			element = driver.findElement(By.name("productName"));
			select = new Select(element);
			Log.info("售价维护页面中产品名称元素已找到");
		} catch (Exception e) {
			Log.error("售价维护页面中产品名称元素已找到");
		}
		return select;
	}
	
	// 获取售价维护页面中“保险期限”元素
	public static Select getDeadLineElement() throws Exception {
		try {
			// JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
			// jsExecutor.executeScript("document.getElementByName(deadlina).style.display='block';");
			element = driver.findElement(By.name("deadlina"));
			select = new Select(element);
			Log.info("售价维护页面中保险期限元素已找到");
		} catch (Exception e) {
			Log.error("售价维护页面中保险期限元素已找到");
		}
		return select;
	}
	
	// 获取售价维护页面中“客户组名称”
	public static WebElement getGroupNameElement() throws Exception {
		try {
			element = driver.findElement(By.id("groupName"));
			Log.info("售价维护页面中的客户组名称元素已找到");
		} catch (Exception e) {
			Log.error("售价维护页面中的客户组名称元素未找到");
		}
		return element;
	}

	// 获取售价维护页面中的“查询”按钮元素
	public static WebElement getSearchElement() throws Exception {
		try {
			element = driver.findElement(By.id("btn-searh"));
			Log.info("售价维护页面中的查询按钮元素已找到");
		} catch (Exception e) {
			Log.error("售价维护页面中的查询按钮元素未找到");
		}
		return element;
	}

	// 获取售价维护列表中的“修改”元素
	public static WebElement getChangeElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[2]/table/tbody/tr[1]/td[1]/a[1]"));
			Log.info("售价维护列表中的修改元素已找到");
		} catch (Exception e) {
			Log.error("售价维护列表中的修改元素未找到");
		}
		return element;
	}

	// 获取售价维护列表中的“挂起”元素
	public static WebElement getDisabledElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[2]/table/tbody/tr[1]/td[1]/a[2]"));
			Log.info("售价维护列表中的挂起元素已找到");
		} catch (Exception e) {
			Log.error("售价维护列表中的挂起元素未找到");
		}
		return element;
	}

	// 获取售价维护列表中的产品名称元素
	public static WebElement getProNameElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[2]/table/tbody/tr[1]/td[3]"));
			Log.info("售价维护列表中的产品名称元素已找到");
		} catch (Exception e) {
			Log.error("售价维护列表中的产品名称元素未找到");
		}
		return element;
	}

	// 获取售价维护列表中的险种名称元素
	public static WebElement getInsuNameElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[2]/table/tbody/tr[1]/td[4]"));
			Log.info("售价维护列表中险种名称元素已找到");
		} catch (Exception e) {
			Log.error("售价维护列表中险种名称元素未找到");
		}
		return element;
	}

	// 获取售价维护列表中的险种编号元素
	public static WebElement getInsuNumberElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[2]/table/tbody/tr[1]/td[5]"));
			Log.info("售价维护列表中的险种编号元素已找到");
		} catch (Exception e) {
			Log.error("售价维护列表中的险种编号元素");
		}
		return element;
	}

	// 获取售价维护列表中期限元素
	public static WebElement getLimitedElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[2]/table/tbody/tr[1]/td[6]"));
			Log.info("售价维护列表中期限元素已找到");
		} catch (Exception e) {
			Log.error("售价维护列表中期限元素未找到");
		}
		return element;
	}

	// 获取售价维护列表中最高保额元素
	public static WebElement getMixPriceElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[1]/div/table/thead/tr/th[7]"));
			Log.info("售价维护列表中最高保额元素已找到");
		} catch (Exception e) {
			Log.error("售价维护列表中最高保额元素未找到");
		}
		return element;
	}

	// 获取售价维护列表中适用范围元素
	public static WebElement getUseRangeElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[2]/table/tbody/tr[1]/td[8]/span"));
			Log.info("获取售价维护列表中适用范围元素已找到");
		} catch (Exception e) {
			Log.error("获取售价维护列表中适用范围元素未找到");
		}
		return element;
	}

	// 获取售价维护列表中客户组元素
	public static WebElement getCustomerGroupElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[2]/table/tbody/tr[1]/td[9]/span"));
			Log.info("售价维护列表中客户组元素已找到");
		} catch (Exception e) {
			Log.error("售价维护列表中客户组元素未找到");
		}
		return element;
	}

	// 获取售价维护列表中面价元素
	public static WebElement getTopPriceElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[2]/table/tbody/tr[1]/td[10]"));
			Log.info("售价维护列表中面价元素已找到");
		} catch (Exception e) {
			Log.error("售价维护列表中面价元素未找到");
		}
		return element;
	}

	// 获取售价维护列表中底价元素
	public static WebElement getBottomPriceElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[2]/table/tbody/tr[1]/td[11]"));
			Log.info("售价维护列表中底价元素已找到");
		} catch (Exception e) {
			Log.error("售价维护列表中底价元素未找到");
		}
		return element;
	}

	// 获取售价维护列表中卖价元素
	public static WebElement getSalePriceElement() throws Exception {
		try {
			element = driver
					.findElement(By
							.xpath(".//*[@id='searchTable']/div[2]/table/tbody/tr[1]/td[12]"));
			Log.info("售价维护列表中卖价元素已找到");
		} catch (Exception e) {
			Log.error("售价维护列表中卖价元素未找到");
		}
		return element;
	}

}

package com.travelzen.Insurance.OperatorInsurance.TestCase.CheckPoints;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.travelzen.Insurance.OperatorInsurance.AppModules.ProductManageAction;
import com.travelzen.Utility.Assertion.Assertion;
import com.travelzen.Utility.DataDriver.ExcelAction;

/**
 * 
 * @author Weixing.Yang
 * 产品管理页面中，产品信息校验
 * 产品列表中每条产品信息校验
 */
public class ProductManageListCheckPoint {
	
	private static String excelName = "Insurance/Datas/KeepForProductInfo.xls";
	
	public static void productListCheckPoint(String productName, WebDriver driver) throws Exception{
		
		ProductManageAction.transmitDriver(driver);
		String aProductName = ProductManageAction.excuteProductNameAction(productName);
		String aCompanyName = ProductManageAction.excuteCompanyNameAction();
		String aTypeName = ProductManageAction.excuteTypeNameAction();
		String aTypeCode = ProductManageAction.excuteTypeCodeAction();
		String aDeadline = ProductManageAction.excuteDeadlineAction();
		String aInsuranceAmount = ProductManageAction.excuteInsuranceAmountAction().replaceAll(",", "");
		String aNormalPrice = ProductManageAction.excuteNormalPriceAction();
		String aUpsetPrice = ProductManageAction.excuteUpsetPriceAction();
		String aInsuranceScopeTem = ProductManageAction.excuteInsuranceScopeTemAction().replaceAll(",", ";");
		
		//System.out.println(aProductName + aCompanyName + aTypeName + aTypeCode + aDeadline + aInsuranceAmount + aNormalPrice + aUpsetPrice + aInsuranceScopeTem);
		
		String eProductName = ExcelAction.getValue(excelName, "productName");
		String eCompanyName = ExcelAction.getValue(excelName, "companyName");
		String eTypeName = ExcelAction.getValue(excelName, "typeName");
		String eTypeCode = ExcelAction.getValue(excelName, "typeCode");
		String eDeadline = ExcelAction.getValue(excelName, "deadline");
		String eInsuranceAmount = ExcelAction.getValue(excelName, "insuranceAmount");
		String eNormalPrice = ExcelAction.getValue(excelName, "normalPrice");
		String eUpsetPrice = ExcelAction.getValue(excelName, "upsetPrice");
		String eInsuranceScopeTem = ExcelAction.getValue(excelName, "scope");
		
		//System.out.println(eProductName + eCompanyName + eTypeName + eTypeCode + eDeadline + eInsuranceAmount + eNormalPrice + eUpsetPrice + eInsuranceScopeTem);
		Assertion.verifyEquals(aProductName, eProductName, "期望产品名称：" + eProductName + ";实际产品名称：" + aProductName);
		Assertion.verifyEquals(aCompanyName, eCompanyName, "期望保险公司名：" + eCompanyName + ";实际保险公司名：" + aCompanyName);
		Assertion.verifyEquals(aTypeName, eTypeName, "期望险种名称：" + eTypeName + ";实际险种名称：" + aTypeName);
		Assertion.verifyEquals(aTypeCode, eTypeCode, "期望险种编号：" + eTypeCode + ";实际险种编号：" + aTypeCode);
		Assertion.verifyEquals(aDeadline, eDeadline, "期望保险期限：" + eDeadline + ";实际保险期限：" + aDeadline);
		Assertion.verifyEquals(aInsuranceAmount, eInsuranceAmount, "期望最高保额(元)：" + eInsuranceAmount + ";实际最高保额(元)：" + aInsuranceAmount);
		Assertion.verifyEquals(aNormalPrice, eNormalPrice, "期望面价：" + eNormalPrice + ";实际面价：" + aNormalPrice);
		Assertion.verifyEquals(aUpsetPrice, eUpsetPrice, "期望底价：" + aUpsetPrice + ";实际底价：" + eUpsetPrice);
		Assertion.verifyEquals(aInsuranceScopeTem, eInsuranceScopeTem, "期望适用范围：" + eInsuranceScopeTem + ";实际适用范围：" + aInsuranceScopeTem);
	}
}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.TestCase.CheckPoints;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.util.List;

import org.databene.benerator.anno.Source;
import org.databene.feed4testng.FeedTest;
import org.openqa.selenium.WebDriver;
import com.travelzen.Utility.LogCenter.*;
import com.travelzen.Utility.DataDriver.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects.*;
import com.travelzen.Utility.Assertion.Assertion;

//@Listeners({com.travelzen.Utility.Assertion.Assertion.class})
public class HotelMaintainBookingClassCheckPoint extends FeedTest {

	private static WebDriver driver;
	
	public static void BookingClassCheckPoint()
			throws Exception {/*
	@Test(dataProvider = "feeder")
	@Source("LoginInfo_TestData.xls")
	public static void RoomCatCheckPoint(String username, String password)
			throws Exception {

		PointAddHotel.pointAddHotel(username, password);
		driver = PointAddHotel.currentDriver;
		// 酒店签约信息

		driver.get("http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/bookingClass/list?hotelId=55de68f0e4b00c7a69014a7a");
		HotelMaintainBookingClassAction.transmitDriver(driver);

		// 点击编辑房型
		// HotelMaintainRoomCatPage.getBookingClassItemElement().click();
		HotelMaintainBookingClassPage.getEditBookingClass().click();
*/
		// 获取 价格名称
		String EroomName = HotelMaintainBookingClassPage.geteEPriceName()
				.getAttribute("value");
		Log.info("Edit BookingClas RoomName value " + EroomName
				+ " is found in BookingClas Page");
		String priceName = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"priceName");
		Log.info("Actual value " + priceName + " is got");
		Assertion.verifyEquals(EroomName, priceName, "RoomName is " + EroomName
				+ " in actual");

		// 获取 价格说明/礼包备注
		String ERemarks = HotelMaintainBookingClassPage.getERemarks().getText();
		Log.info("Edit BookingClas Remarks value " + ERemarks
				+ " is found in BookingClas Page");
		String remarks = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"remarks");
		Log.info("Actual value " + remarks + " is got");
		Assertion.verifyEquals(ERemarks, remarks, "Remarks is " + ERemarks
				+ " in actual");

		// 获取 时段名称
		String EperiodName = HotelMaintainBookingClassPage.getEBkrate_Name()
				.getAttribute("value");
		Log.info("Edit BookingClas RoomName value " + EperiodName
				+ " is found in BookingClas Page");
		String periodName = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"periodName");
		Log.info("Actual value " + periodName + " is got");
		Assertion.verifyEquals(EperiodName, periodName, "RoomName is "
				+ EroomName + " in actual");

		// 获取 时段价格
		String EperiodCost = HotelMaintainBookingClassPage
				.getEBkrate_roomCost().getAttribute("value");
		Log.info("Edit BookingClas RoomName value " + EperiodCost
				+ " is found in BookingClas Page");
		String periodCost = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"periodCost");
		Log.info("Actual value " + periodCost + " is got");
		Assertion.verifyEquals(EperiodCost, periodCost, "RoomName is "
				+ EperiodCost + " in actual");

		// 获取 时段开始时间
		String EstartDate = HotelMaintainBookingClassPage.getEStartDate()
				.getText();
		Log.info("Edit BookingClas RoomName value " + EstartDate
				+ " is found in BookingClas Page");
		String startDate = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"startDate");
		Log.info("Actual value " + startDate + " is got");
		Assertion.verifyEquals(EstartDate, startDate, "RoomName is "
				+ EstartDate + " in actual");

		// 获取 时段结束时间
		String EendDate = HotelMaintainBookingClassPage.getEEndDate().getText();
		Log.info("Edit BookingClas EendDate value " + EendDate
				+ " is found in BookingClas Page");
		String endDate = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"endDate");
		Log.info("Actual value " + endDate + " is got");
		Assertion.verifyEquals(EendDate, endDate, "EendDate is " + EendDate
				+ " in actual");

		// 获取 早餐份数
		String EbreakFastNum = HotelMaintainBookingClassPage
				.getEBreakFastName().getAttribute("defaultvalue");
		Log.info("Edit BookingClas RoomName value " + EbreakFastNum
				+ " is found in BookingClas Page");
		String breakFastNum = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"breakFastNum");
		Log.info("Actual value " + breakFastNum + " is got");
		Assertion.verifyEquals(EbreakFastNum, breakFastNum, "EbreakFastNum is "
				+ EroomName + " in actual");

		// 获取 是否包含早餐
		String EcomplServices1 = HotelMaintainBookingClassPage
				.getEBookingClassRates_complServices1().getAttribute("checked");
		Log.info("Edit BookingClas EcomplServices1 value " + EcomplServices1
				+ " is found in BookingClas Page");
		String complServices1 = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"complServices1");
		Log.info("Actual value " + complServices1 + " is got");
		Assertion.verifyEquals(EcomplServices1, complServices1,
				"EcomplServices1 is " + EcomplServices1 + " in actual");

		// 获取 是否包含宽带
		String EcomplServices2 = HotelMaintainBookingClassPage
				.getEBookingClassRates_complServices2().getAttribute("checked");
		Log.info("Edit BookingClas RoomName value " + EcomplServices2
				+ " is found in BookingClas Page");
		String complServices2 = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"complServices2");
		Log.info("Actual value " + complServices2 + " is got");
		Assertion.verifyEquals(EcomplServices2, complServices2,
				"EcomplServices2 is " + EcomplServices2 + " in actual");

		// 获取 变更入住时间
		String EbcheckinTime = HotelMaintainBookingClassPage
				.getEBookingClassRates_checkinTime().getAttribute("defaultvalue");
		Log.info("Edit BookingClas RoomName value " + EroomName
				+ " is found in BookingClas Page");
		String bcheckinTime = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"bcheckinTime");
		Log.info("Actual value " + bcheckinTime + " is got");
		Assertion.verifyEquals(EbcheckinTime, bcheckinTime, "EbcheckinTime is "
				+ EbcheckinTime + " in actual");

		// 获取 变更退房时间
		String EbcheckoutTime = HotelMaintainBookingClassPage
				.getEBookingClassRates_checkoutTime().getAttribute("defaultvalue");
		Log.info("Edit BookingClas RoomName value " + EroomName
				+ " is found in BookingClas Page");
		String bcheckoutTime = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"bcheckoutTime");
		Log.info("Actual value " + bcheckoutTime + " is got");
		Assertion.verifyEquals(EbcheckoutTime, bcheckoutTime,
				"EbcheckoutTime is " + EbcheckoutTime + " in actual");

		// 获取 变更入住前天数
		String EcheckinDays = HotelMaintainBookingClassPage
				.getEBookingClassRates_checkoutTime().getAttribute("value");
		Log.info("Edit BookingClas RoomName value " + EcheckinDays
				+ " is found in BookingClas Page");
		String checkinDays = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"checkinDays");
		Log.info("Actual value " + checkinDays + " is got");
		Assertion.verifyEquals(EcheckinDays, checkinDays, "EcheckinDays is "
				+ EcheckinDays + " in actual");

		// 获取 变更入住前时间
		String EcheckInPoint = HotelMaintainBookingClassPage
				.getECheckinDays().getAttribute("value");
		Log.info("Edit BookingClas RoomName value " + EcheckInPoint
				+ " is found in BookingClas Page");
		String checkInPoint = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"checkInPoint");
		Log.info("Actual value " + checkInPoint + " is got");
		Assertion.verifyEquals(EcheckInPoint, checkInPoint, "EcheckInPoint is "
				+ EcheckInPoint + " in actual");

		// 获取 变更扣除房费规则
		String EbcancelTerms = HotelMaintainBookingClassPage.getECancelTerms()
				.getAttribute("defaultvalue");
		if(EbcancelTerms.equalsIgnoreCase("true")){
			EbcancelTerms = "1";
		}
		Log.info("Edit BookingClas RoomName value " + EbcancelTerms
				+ " is found in BookingClas Page");
		String bcancelTerms = ExcelAction.getValue("Hotel/AddHotel_TestData.xls",
				"bcancelTerms");
		Log.info("Actual value " + bcancelTerms + " is got");
		Assertion.verifyEquals(EbcancelTerms, bcancelTerms, "EbcancelTe"
				+ "ms is "
				+ EbcancelTerms + " in actual");
		// 保存、关闭价格计划页面
		HotelMaintainBookingClassPage.getSave_Button().click();
		Log.info("BookingClass Checkpoint has finished");

	}

}

package com.travelzen.Insurance.PurchaseInsurance.PageObjects;

import java.util.List;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.*;

public class basePage {

	private static WebElement element;
	private static List<WebElement> elementList;
	public static WebDriver driver;
	private static Select oSelection;
	public static String option;
	private static WebElement [][]elementTable;
	/*
	*author xuemei.ren
	*date 07/01/2016
	*/
	public static void getDriver(WebDriver webdriver) throws Exception{
		driver = webdriver;
	}
	
	//创建订单页面--保险生效日期--日历控件
	public static WebElement getInsuranceLinkElement() throws Exception{
		try{
		 element = driver.findElement(By.linkText("保险"));
			Log.info("登陆欢迎页页保险链接查找成功");
		}catch(Exception e){
			Log.error("登陆欢迎页页保险链接查找失败");
		}
		return element;
	}
	
	
}
	
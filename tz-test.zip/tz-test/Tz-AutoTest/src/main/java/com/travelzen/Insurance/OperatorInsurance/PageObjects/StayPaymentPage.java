package com.travelzen.Insurance.OperatorInsurance.PageObjects;
/**
 * author：qiqi.wang
 * */
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
/*
 * author：wang
 * */
import com.travelzen.Utility.LogCenter.Log;

public class StayPaymentPage
{
	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	public static String option;
	
	public static void getDriver(WebDriver webDriver) throws Exception{
		driver = webDriver;
	}
	
	//等待支付页面-修改订单-按钮
		public static WebElement getEditOrderButtonElement() throws Exception{
			try{
				element = driver.findElement(By.id("btn-edit-order"));
				Log.info("等待订单支付页面中“修改订单”按钮元素，已找到。");
			}catch (Exception e){
				Log.error("等待订单支付页面中“修改订单”按钮元素，未找到。");
			}
			return element;
		}
		
	//等待支付页面-取消订单-按钮
		public static WebElement getCancelOrderButtonElement() throws Exception{
			try{
				element = driver.findElement(By.id("btn-cancel-order"));
				Log.info("等待订单支付页面中“取消订单”按钮元素，已找到。");
			}catch (Exception e){
				Log.error("等待订单支付页面中“取消订单”按钮元素，未找到。");
			}
			return element;
		}
	
	//等待支付页面-支付订单-按钮
		public static WebElement getPayOrderButtonElement() throws Exception{
			try{
				element = driver.findElement(By.id("payBtn"));
				Log.info("等待订单支付页面中“支付”按钮元素，已找到。");
			}catch (Exception e){
				Log.error("等待订单支付页面中“支付”按钮元素，未找到。");
			}
			return element;
		}
	
	//等待支付页面-确认支付-按钮
		public static WebElement getConfirmPayOrderButtonElement() throws Exception{
			try{
				element = driver.findElement(By.xpath("html/body/div[7]/div[2]/div/div[2]/a[1]/span[2]"));
				Log.info("等待订单支付页面中“确认支付”按钮元素，已找到。");
			}catch (Exception e){
				Log.error("等待订单支付页面中“确认支付”按钮元素，未找到。");
			}
			return element;
		}
	
	//
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

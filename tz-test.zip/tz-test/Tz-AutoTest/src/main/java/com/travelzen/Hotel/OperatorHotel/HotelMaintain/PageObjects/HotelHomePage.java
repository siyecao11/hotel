package com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects;

import org.testng.annotations.Test;
import org.openqa.selenium.*;
import com.travelzen.Hotel.OperatorHotel.HotelMaintain.utility.Constants.*;
import com.travelzen.Utility.LogCenter.Log;

public class HotelHomePage {
	
	private static WebElement element;
	public static WebDriver driver;
	
	@Test
	public static void getWebDriver(WebDriver webdriver) throws Exception{
		
		driver = webdriver;
	}
	
	// get HotelSearch menuItem element
	@Test
	public static WebElement  getHotelSearchMenu() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/booking/search']"));
			Log.info("HotelSearch Menu item is found on the HotelHome Page");
		}catch (Exception e){
			Log.error("********HotelSearch Menu item is not found on the HotelHome Page********");
		}
		return element;
	}
	
	// get HotelMaintain menuItem element
	@Test
	public static WebElement  getHotelMaintainMenu() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/maintain/search']"));
			Log.info("HotelMaintain Menu item is found on the HotelHome Page");
		}catch (Exception e){
			Log.error("********HotelMaintain Menu item is not found on the HotelHome Page********");
		}
		return element;
	}
	
	// get OrderManage menuItem element
	@Test
	public static WebElement  getOrderManageMenu() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='http://order.hotel.op3.tdxinfo.com/tops-front-operator-hotel-order/order/hotel/hotelSearch']"));
			Log.info("OrderManage Menu item is found on the HotelHome Page");
		}catch (Exception e){
			Log.error("********OrderManage Menu item is not found on the HotelHome Page********");
		}
		return element;
	}
	
	// get SalePricy menuItem element
	@Test
	public static WebElement  getSalePricyMenu() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href='http://hotel.op3.tdxinfo.com/tops-front-operator-hotel/hotel/operator/salesPolicy/search/goSearch']"));
			Log.info("SalePricy Menu item is found on the HotelHome Page");
		}catch (Exception e){
			Log.error("********SalePricy Menu item is not found on the HotelHome Page********");
		}
		return element;
	}
	
	// get HotelReport menuItem element
	@Test
	public static WebElement  getHotelReportMenu() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href=" + Constant.hotelReportURL +"]"));
			Log.info("HotelReport Menu item is found on the HotelHome Page");
		}catch (Exception e){
			Log.error("********HotelReport Menu item is not found on the HotelHome Page********");
		}
		return element;
	}
	
	// get ProductMaintain menuItem element
	@Test
	public static WebElement  getProductMaintainMenu() throws Exception{
		
		try{
			element = driver.findElement(By.cssSelector("a[href=" + Constant.productMaintainURL +"]"));
			Log.info("ProductMaintain Menu item is found on the HotelHome Page");
		}catch (Exception e){
			Log.error("********ProductMaintain Menu item is not found on the HotelHome Page********");
		}
		return element;
	}
}

package com.travelzen.Hotel.OperatorHotel.HotelMaintain.PageObjects;


import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.travelzen.Hotel.OperatorHotel.HotelMaintain.utility.Constants.*;
import com.travelzen.Utility.LogCenter.Log;

public class HotelMantainMainContentPage extends BaseClass{

	private static WebElement element;
	private static List<WebElement> elements;
	public static WebDriver driver;
	public static Select select;
	
	public HotelMantainMainContentPage(WebDriver driver){
		super(driver);
	}
	
	public static void getDriver(WebDriver webdriver) throws Exception{
		driver = webdriver;
	}
	
	//签约经理
	@Test
	public static WebElement SignManager() throws Exception{
		try{
		 element = driver.findElement(By.cssSelector("select[id='signManager']"));
		}catch(Exception e){
			Log.error("********manager_select_checkbox is not found on the maincontent Page********");
		}
		return element;
	}
	/*WebElement element = driver.findElement(By.cssSelector("select[name='select']"));
	Select select = new Select(element);
	select.selectByValue("opel");
	select.selectByIndex(2);
	select.selectByVisibleText("Opel");*/
	
	//编辑酒店基本信息按钮
	@Test
	public static WebElement EditButton() throws Exception{
		try{
	          element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[4]/div[2]/a"));
		}catch (Exception e){
			Log.error("********edit_button is not found on the maincontent Page********");
		}
		return element;
	}
	
	//酒店名称输入框
	@Test
	public static WebElement HotelName() throws Exception{
		try{
			//WebElement Iframe = driver.findElement(By.xpath("/html/body/div[6]/div[2]/iframe"));
			WebElement Iframe = driver.findElement(By.cssSelector("iframe[class='k-content-frame']"));
			driver.switchTo().frame(Iframe);
			element = driver.findElement(By.id("name"));	
		}catch (Exception e){
		Log.error("********Hotel_Name_Input is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//排序输入框
	@Test
	public static WebElement DisplayOrder() throws Exception{
		try{//WebElement Iframe = driver.findElement(By.xpath("/html/body/div[6]/div[2]/iframe"));
			//driver.switchTo().frame(Iframe);
			element = driver.findElement(By.name("displayOrder"));	
		}catch (Exception e){
		Log.error("********Sort_Inout is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//推荐酒店勾选
	@Test
	public static WebElement IsRecommend() throws Exception{
		try{
			element = driver.findElement(By.id("isRecommend"));	
		}catch (Exception e){
		Log.error("********Recommend_Hotel is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//连锁品牌
	@Test
	public static WebElement BrandSelect() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[name='chainBrand.chainBrandId']"));
		}catch (Exception e){
		Log.error("********BrandSelect is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//酒店类型
	@Test
	public static WebElement HotelStyle() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[name='category.code']"));
		}catch (Exception e){
		Log.error("********HotelStyle is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//酒店星级
	@Test
	public static WebElement HotelStar() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[name='rating']"));
		}catch (Exception e){
		Log.error("********HotelStar is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//酒店大区
	@Test
	public static WebElement Region() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[id='region']"));
		}catch (Exception e){
		Log.error("********Region is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//ʡ酒店省
	@Test
	public static WebElement Province() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[id='province']"));
		}catch (Exception e){
		Log.error("********Province is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//酒店地址城市
	@Test
	public static WebElement City() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[id='city']"));
		}catch (Exception e){
		Log.error("********City is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//酒店地址行政区
	@Test
	public static WebElement District() throws Exception{
		try{
			element = driver.findElement(By.cssSelector("select[id='district']"));
		}catch (Exception e){
		Log.error("********District is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//酒店地址商业区
	@Test
	public static WebElement Commercial() throws Exception{
		try{
			element = driver.findElement(By.id("commercial"));
		}catch (Exception e){
		Log.error("********Commercial is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	@Test
	public static WebElement SelectCommercial() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='location-layer-1']/ul/li[1]"));
		}catch (Exception e){
		Log.error("********SelectCommercial is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//酒店地址ַ
	
	@Test
	public static WebElement HotelAddress() throws Exception{
		try{
			element = driver.findElement(By.id("address"));
		}catch (Exception e){
		Log.error("********HotelAddress is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//纬度
	@Test
	public static WebElement Latitude() throws Exception{
		try{
			element = driver.findElement(By.name("hotelLocation.latitude"));
		}catch (Exception e){
		Log.error("********Latitude is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//经度
	@Test
	public static WebElement Longitude() throws Exception{
		try{
			element = driver.findElement(By.name("hotelLocation.longitude"));
		}catch (Exception e){
		Log.error("********Longitude is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//酒店电话
	
	@Test
	public static WebElement MainPhone() throws Exception{
		try{
			element = driver.findElement(By.name("mainPhone"));
		}catch (Exception e){
		Log.error("********Mainphone is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//酒店网址
	
	@Test
	public static WebElement Website() throws Exception{
		try{
			element = driver.findElement(By.name("website"));
		}catch (Exception e){
		Log.error("********Website is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//酒店电子邮箱
	@Test
	public static WebElement Email() throws Exception{
		try{
			element = driver.findElement(By.name("email"));
		}catch (Exception e){
		Log.error("********Email is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//开业时间
	
	@Test
	public static WebElement OpenDate() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/div[1]/table/tbody/tr[8]/td[2]/input[1]"));
		}catch (Exception e){
		Log.error("********OpenDate is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//装修时间   renovationDate
	
	@Test
	public static WebElement RenovationDate() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/div[1]/table/tbody/tr[8]/td[2]/input[2]"));
		}catch (Exception e){
		Log.error("********RenovationDate is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	
	//楼层数  storey
	@Test
	public static WebElement Storey() throws Exception{
		try{
			element = driver.findElement(By.name("storey"));
		}catch (Exception e){
		Log.error("********Storey is not found on the maincontent Page********");
		}
	 return element;
	}
	
	
	//房间数   noOfRoom
	@Test
	public static WebElement NoofRoom() throws Exception{
		try{
			element = driver.findElement(By.name("noOfRoom"));
		}catch (Exception e){
		Log.error("********NoofRoom is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//备注 summary
	
	@Test
	public static WebElement Summary() throws Exception{
		try{
			element = driver.findElement(By.name("summary"));
		}catch (Exception e){
		Log.error("********Summary is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//保存酒店信息  .//*[@id='updateBaseInfoForm']/div[2]/a[1]
	
	@Test
	public static WebElement Save_button() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='updateBaseInfoForm']/div[2]/a[1]"));
		}catch (Exception e){
		Log.error("********Save_button is not found on the maincontent Page********");
		}
	 return element;
	}
	
	//取消保存酒店信息
	@Test
	public static WebElement CancleSave_button() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='updateBaseInfoForm']/div[2]/a[2]"));
		}catch (Exception e){
		Log.error("********CancleSave_button is not found on the maincontent Page********");
		}
	 return element;
	}
	
	/********************************************************************************************/
	
	
	//签约经理
	@Test
	public static WebElement ManagerSaveButton() throws Exception {
		try{
			element = driver.findElement(By.xpath(".//*[@id='signManagerAddForm']/div[3]/a"));
		}catch (Exception e){
			Log.error("********ManagerSaveButton is not found on the maincontent Page********");
		}
		return element;
	}
	
	/********************************************************************************************/
	
	
	
	
	
	
	//编辑酒店照片按钮
	
	@Test
	public static WebElement Edit_HotelPhoto_Button() throws Exception{
		try{
			driver.switchTo().defaultContent();
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[5]/div[2]/a"));
		}catch (Exception e){
			Log.error("********Edit_HotelPhoto_Button is not found on the maincontent Page********");
		}
		return element;
	}
	
	//上传照片
	@Test
	public static WebElement AddPhoto() throws Exception{
		try{
			WebElement Iframe = driver.findElement(By.xpath("/html/body/div[9]/div[2]/iframe"));
			driver.switchTo().frame(Iframe);
			((JavascriptExecutor) driver).executeScript("document.getElementById(\"defaultPhoto\").type ='file';");
			 element =driver.findElement(By.id("defaultPhoto"));
		}catch (Exception e){
			Log.error("********AddPhoto is not found on the maincontent Page********");
		}
		return element;
	}

	//保存照片
	@Test
	public static WebElement Submitphoto() throws Exception{
		try{
			element = driver.findElement(By.id("submit")) ;
		}catch (Exception e){
			Log.error("********Submitphoto is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	/********************************************************************************************/
	
	
	
	//编辑酒店规定
	@Test
	public static WebElement EditHotelRulesButton() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[6]/div[2]/a"));
		}catch (Exception e){
			Log.error("********EditHotelRulesButton is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	
	//选择宾客类型
	@Test//中宾
	public static WebElement GuestTypeCheckbox1() throws Exception{
		try{
			//WebElement Iframe = driver.findElement(By.xpath("/html/body/div[9]/div[2]/iframe"));
			WebElement Iframe = driver.findElement(By.cssSelector("iframe[class='k-content-frame']"));
			driver.switchTo().frame(Iframe);
			element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/label/input[1]"));
		}catch (Exception e){
			Log.error("********GuestTypeCheckbox1 is not found on the maincontent Page********");
		}
		return element;
	}
	
	@Test//港澳台
	public static WebElement GuestTypeCheckbox2() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/label/input[2]"));
		}catch (Exception e){
			Log.error("********GuestTypeCheckbox2 is not found on the maincontent Page********");
		}
		return element;
	}
	
	@Test//外宾
	public static WebElement GuestTypeCheckbox3() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/label/input[3]"));
		}catch (Exception e){
			Log.error("********GuestTypeCheckbox3 is not found on the maincontent Page********");
		}
		return element;
	}
	//备注ע guestremark
	@Test
	public static WebElement Guestremark() throws Exception{
		try{
			element =driver.findElement(By.name("guestRemark"));
		}catch (Exception e){
			Log.error("********Guestremark is not found on the maincontent Page********");
		}
		return element;
	}

	//儿童年龄标准 
	@Test
	public static WebElement AgeSelect() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/select[1]"));
		}catch (Exception e){
			Log.error("********AgeSelect is not found on the maincontent Page********");
		}
		return element;
	}
	
	//儿童身高标准
	@Test
	public static WebElement HegihtSelect() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/select[2]"));
		}catch (Exception e){
			Log.error("********HegihtSelect is not found on the maincontent Page********");
		}
		return element;
	}
	
	//可带宠物
	@Test
	public static List<WebElement> PetAllowed() throws Exception{
		try{
			 elements = driver.findElements(By.name("isPetAllowed"));
		}catch (Exception e){
			Log.error("********PetAllowed is not found on the maincontent Page********");
		}
		return elements;
	}
	//入住时间
	@Test
	public static WebElement CheckinTime() throws Exception{
		try{
			//WebElement Iframe = driver.findElement(By.cssSelector("iframe[class='k-content-frame']"));
			//driver.switchTo().frame(Iframe);
			element = driver.findElement(By.xpath(".//*[@id='updateTermForm']/table/tbody/tr[4]/td[2]/select[1]"));
		}catch (Exception e){
		Log.error("********CheckinTime is not found on the maincontent Page********");
		}
		return element;
	}
	
	//get 入住时间内容的元素 ，用于后面的断言检查点
	//如 入住时间：14:00之后
	//入住时间
	@Test
	public static Select getCheckinTime() throws Exception{
		try{
			WebElement Iframe = driver.findElement(By.cssSelector("iframe[class='k-content-frame']"));
			driver.switchTo().frame(Iframe);
			element = driver.findElement(By.xpath(".//*[@id='updateTermForm']/table/tbody/tr[4]/td[2]/select[1]"));
			select = new Select(element);
		}catch (Exception e){
		Log.error("********CheckinTime is not found on the maincontent Page********");
		}
		return select;
	}
	
	//退房时间
	@Test
	public static WebElement CheckoutTime() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='updateTermForm']/table/tbody/tr[4]/td[2]/select[2]"));
		}catch (Exception e){
		Log.error("********CheckoutTime is not found on the maincontent Page********");
		}
		return element;
	}
	
	//get 退房时间内容的元素 ，用于后面的断言检查点
	//如 退房时间：14:00之后
	//退房时间
	@Test
	public static Select getCheckoutTime() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='updateTermForm']/table/tbody/tr[4]/td[2]/select[2]"));
			select = new Select(element);
		}catch (Exception e){
		Log.error("********CheckinTime is not found on the maincontent Page********");
		}
		return select;
	}
	
	//get 变更取消内容的元素 ，用于后面的断言检查点
	//如 变更取消：入住前1天下午1点前更改或取消，不收取任何费用；入住前1天的下午1点后变更或取消，酒店扣除全部房费
	//变更取消
	@Test
	public static WebElement getCancelPolicy() throws Exception{
		try{
			element = driver.findElement(By.name("term.cancelPolicy"));
		}catch (Exception e){
		Log.error("********cancelPolicy is not found on the maincontent Page********");
		}
		return element;
	}
	
	//变更取消
	@Test//days
	public static WebElement CheckinDay() throws Exception{
		try{
			element = driver.findElement(By.id("checkinDays"));
		}catch (Exception e){
			Log.error("********CheckinDay is not found on the maincontent Page********");
		}
		return element;
	}
	@Test//points
	public static WebElement CheckinPoints() throws Exception{
		try{
			element = driver.findElement(By.id("checkinPoints"));
		}catch(Exception e){
			Log.error("********checkinPoints is not found on the maincontent Page********");
		}
		return element;
	}
	
	//全部房费
	@Test
	public static WebElement CancelTerms() throws Exception{
		try{
			element =driver.findElement(By.id("cancelTerms"));
		}catch(Exception e){
			Log.error("********CancelTerms is not found on the maincontent Page********");
		}
		return element;
	}
	
	//添加
	@Test
	public static WebElement AddrulesButton() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/div/div/a"));
		}catch(Exception e){
			Log.error("********AddrulesButton is not found on the maincontent Page********");
		}
		return element;
	}
	
	//保存规定
	@Test
	public static WebElement SaveRulesButton() throws Exception{
		try{
			element =driver.findElement(By.xpath("/html/body/form/div/a[1]"));
		}catch (Exception e){
			Log.error("********SaveRulesButton is not found on the maincontent Page********");
		}
		return element;
	}
	
	/********************************************************************************************/
	
	
	//编辑服务费用
	@Test
	public static WebElement EditServiceCharge() throws Exception{
		try{
			element = driver.findElement(By.xpath(".//*[@id='mainContent']/div[7]/div[2]/a"));
		}catch (Exception e){
			Log.error("********EditServiceCharge is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	@Test//
	public static WebElement BreakerCharge() throws Exception{
		try{
			WebElement Iframe = driver.findElement(By.xpath("/html/body/div[9]/div[2]/iframe"));
			driver.switchTo().frame(Iframe);
			element = driver.findElement(By.xpath("html/body/form/div[1]/ul[2]/li[2]/input"));
		}catch (Exception e){
			Log.error("********BreakerCharge is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	@Test//
	public static WebElement NetCharge() throws Exception{
		try{
			element = driver.findElement(By.xpath("html/body/form/div[1]/ul[2]/li[2]/input"));
		}catch (Exception e){
	
		Log.error("********NetCharge is not found on the maincontent Page********");
	}
	return element;
	}
	
	
	
	//
	@Test
	public static WebElement SaveServiceCharge() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/div[2]/a[1]"));
		}catch (Exception e){
	
		Log.error("********SaveServiceCharge is not found on the maincontent Page********");
	}
	return element;
	}
	
	
	
	
	
	/********************************************************************************************/
	//编辑服务设施
	
	
	//
	@Test
	public static WebElement EditServerFacility() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/div[3]/div[2]/div[8]/div[2]/a"));
		}catch (Exception e){
			Log.error("********EditServerFacility is not found on the maincontent Page********");
		}
		return element;
	} 
	
	//
	
	@Test
	public static List<WebElement> BusinessCenter() throws Exception{
		try{
			WebElement Iframe = driver.findElement(By.xpath("/html/body/div[9]/div[2]/iframe"));
			driver.switchTo().frame(Iframe);	
			elements = driver.findElements(By.name("facilityId"));
			//element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/ul/li[1]/label/input"));
		}catch (Exception e){
			Log.error("********BusinessCenter is not found on the maincontent Page********");
		}
		return elements;
	}
	
	//
	@Test
	public static WebElement SaveBusinessCenter() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/div/a[1]"));
		}catch (Exception e){
			Log.error("********SaveBusinessCenter is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	
	
	
	
	
	/********************************************************************************************/
	//编辑酒店备注
	@Test
	public static WebElement EditHotelRemark() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/div[3]/div[2]/div[9]/div[2]/a"));
		}catch (Exception e){
			Log.error("********EditHotelRemark is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	
	@Test
	public static WebElement PrivateRemark() throws Exception{
		try{
			WebElement Iframe = driver.findElement(By.xpath("/html/body/div[9]/div[2]/iframe"));
			driver.switchTo().frame(Iframe);
			element = driver.findElement(By.name("privateRemark"));
		}catch (Exception e){
			Log.error("********PrivateRemark is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	@Test
	public static WebElement PublicRemark() throws Exception{
		try{
			element = driver.findElement(By.name("publicRemark"));
		}catch (Exception e){
			Log.error("********PublicRemark is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	@Test
	public static WebElement SaveRemarkButton() throws Exception{
		try{
			element = driver.findElement(By.xpath("/html/body/form/div/a[1]"));
		}catch (Exception e){
			Log.error("********SaveRemarkButton is not found on the maincontent Page********");
		}
		return element;
	}
	
	
	
	
	
	/********************************************************************************************/
	//跳转到供应商信息页面
	@Test
	public static WebElement ProviderButton() throws Exception{
		try{
			driver.switchTo().defaultContent();
			element = driver.findElement(By.xpath("html/body/div[3]/div[2]/div[2]/div[2]/a[2]"));
		}catch (Exception e){
			Log.error("********ProviderButton is not found on the maincontent Page********");
		}
		return element;
	}
		
}

package com.travelzen.Hotel.OperatorHotel.PrepayHotel.AppModules;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.travelzen.Utility.LogCenter.Log;
import com.travelzen.Hotel.OperatorHotel.PrepayHotel.PageObjects.*;

public class OrderManageNormalOrderCompleteAction {

	private static WebDriver webdriver;
	private static List<WebElement> elementList;

	@Test
	public static void transmitDriver(WebDriver driver) throws Exception {

		webdriver = driver;
		OrderManageNormalOrderCompletePage.GetDriver(webdriver);
	}

	// 正常单完成  -- 创建变更单 --Action
	public static void CreateEndorseOrder() throws Exception {
		OrderManageNormalOrderCompletePage.CreatEndorseOrder().click();
		Log.info("**************CreateEndorseOrder is clicked***************");
	}

	// 正常单完成  -- 创建调账单 --Action
	public static void createAdjustmentOrder() throws Exception {
		OrderManageNormalOrderCompletePage.CreatAdjustmentOrder().click();
		Log.info("**************CreatAdjustmentOrder is clicked***************");
	}
	
	//**********************************创建退订单--弹窗退订条件--Start**************************************************
	// 正常单完成  -- 创建退订单 --Action
	public static void CreatRetreatOrder() throws Exception {
		OrderManageNormalOrderCompletePage.CreatRetreatOrder().click();
		Log.info("**************CreatRetreatOrder is clicked***************");
	}
	// 选择并输入退订条件
	@Test
	public static void excute_select_RetreatCondition(List<String> stringList)
			throws Exception {
		// 选择预定要求，bookingRequirement
		// element = elementList.get(0).getAttribute("value")
		switch (stringList.get(0)) {
		case "CHANGEALL":
			OrderManageNormalOrderCompletePage.getRetreat_CHANGEALL().click();
			break;
		case "CHANGEFIRST":
			OrderManageNormalOrderCompletePage.getRetreat_CHANGEFIRST().click();
			break;
		case "CHANGENONE":
			OrderManageNormalOrderCompletePage.getRetreat_CHANGENONE().click();
			break;
		case "EARLYCHECKOUT":
			excute_Retreat_EARLYCHECKOUT(stringList);
			break;

		}

	}

	// *****Switch分支条件*********
	// 选择提前离店
	@Test
	public static void excute_Retreat_EARLYCHECKOUT(List<String> stringList) throws Exception {
		
		OrderManageNormalOrderCompletePage.getRetreat_EARLYCHECKOUT().click();  //选中单选按钮
		
		elementList = OrderManageNormalOrderCompletePage
				.getRetreat_EARLYCHECKOUT_RefundDate();

		Log.info(elementList.size() + "elementList size");
		for (int i = 0; i < elementList.size(); i++) {
				//elementList.get(i).clear();
			if(stringList.get(i+1).equalsIgnoreCase("1")) elementList.get(i).click();
		}

	}
	
	// 保存退订条件
	@Test
	public static void excute_Save_RetreatCondition() throws Exception {
		OrderManageNormalOrderCompletePage.getRetreat_Save().click();
		Log.info("RetreatCondition has been saved");

	}
	//************************************创建退订单--弹窗退订条件--End***************************************************
	
	// ***********************************点击创建  --变更单-- 后页面弹出窗口Action  Start ********************************
	// 点击选择日期按钮
	public static void DateButton() throws Exception {
		OrderManageNormalOrderCompletePage.DateButton().click();
		Log.info("**************DateButton is clicked***************");
	}

	// 点击入住时间控件
	public static void CheckinDate() throws Exception {
		OrderManageNormalOrderCompletePage.CheckinDate().click();
		Log.info("**************CheckinDate is clicked***************");
	}

	// 点击选择入住日期
	public static void SetCheckinDate(String endorseCheckinDate) throws Exception {
		OrderManageNormalOrderCompletePage.SetCheckinDate(endorseCheckinDate).click();
		Log.info("**************SetCheckinDate is clicked***************");
	}

	// 点击离店时间控件
	public static void CheckoutDate() throws Exception {
		OrderManageNormalOrderCompletePage.CheckoutDate().click();
		Log.info("**************CheckoutDate is clicked***************");
	}

	// 点击选择离店时间
	public static void SetCheckoutDate(String endorseCheckoutDate) throws Exception {
		OrderManageNormalOrderCompletePage.SetCheckoutDate(endorseCheckoutDate).click();
		Log.info("**************SetCheckoutDate is clicked***************");
	}

	// 选择间数
	public static void RoomNo(String RoomNo) throws Exception {
		OrderManageNormalOrderCompletePage.RoomNo().sendKeys(RoomNo);
		Log.info("**************RoomNo is writed***************");
	}
	//点击保存按钮
	public static void SaveButton() throws Exception {
		OrderManageNormalOrderCompletePage.SaveDate().click();
		Log.info("**************SaveDate is clicked***************");
	}
	//点击预定按钮
	public static void bookButton(String BookHotelId) throws Exception {
		OrderManageNormalOrderCompletePage.Booking(BookHotelId).click();
		Log.info("**************bookButton is clicked***************");
	}
	// ***********************************点击创建  --变更单-- 后页面弹出窗口  End ********************************
}
